﻿/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/
var UIComponents = {
    BannerStatus : true,
    ShowMoreTopics : true,
    ShareLink : true,
    SeeAlso : true,
    AskAnExpert : true,
    Notes : true,
    KPathPortal : true,
    KPathLogout : true,
    Preferences : true,
    Help : true,
    TopicHelp: true,
    TitlePrefix : true, 
    ProvideUserFeedback: true
};