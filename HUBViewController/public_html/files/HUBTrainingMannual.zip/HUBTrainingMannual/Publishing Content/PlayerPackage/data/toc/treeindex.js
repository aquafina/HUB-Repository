﻿var parentIndex=[0,0,0];

var conceptIndex=[0,0,1];