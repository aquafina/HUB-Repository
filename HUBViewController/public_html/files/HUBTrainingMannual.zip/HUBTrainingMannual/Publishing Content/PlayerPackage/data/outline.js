﻿/******************************************************************
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
******************************************************************/

var moduleName="The HUB Training";
var bypassToc=true;var soundIsExported = true;var toc_hash="f8OKP5v3OMQRqQWb1tNTuL+wX40="