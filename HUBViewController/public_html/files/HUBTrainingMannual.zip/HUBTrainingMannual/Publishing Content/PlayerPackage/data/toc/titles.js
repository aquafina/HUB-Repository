﻿/******************************************************************
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
******************************************************************/
var titles=new Array("21f74c87-b8bc-477d-ac17-72e575784b98_1");var appnames=new Array("The HUB Training");