{
  "data":
  {
    "1":[{"t": "HUB", "y":"T", "g":"1a4b801f-3c49-4eed-9af4-440784a74cf9", "o":2, "r":[2,7], "c":0 }]  },
  "root":"21f74c87-b8bc-477d-ac17-72e575784b98",
  "indexer":
  [{"block":1, "min":1, "max":2}]
}
