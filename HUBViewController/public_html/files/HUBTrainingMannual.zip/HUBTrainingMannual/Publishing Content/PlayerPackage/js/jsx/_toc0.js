﻿
/* common.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

// Common functions between toc and lms

function filterHTML(s) {
    s = replaceString("&", "&amp;", s);
    s = replaceString("<", "&lt;", s);
    s = replaceString(">", "&gt;", s);
    return s;
}

function replaceString(oldString, newString, fullS) {
    if (fullS == null) return;
    var cReg = new RegExp(oldString, "g");
    var nString = fullS.replace(cReg, newString);
    return nString;
}

function PtToPx(pt, dpi) {
    return Math.floor((pt * dpi) / 72);
}

function PxToPt(px, dpi) {
    return (px / dpi) * 72;
}

function Bool(s) {
    if (typeof (s) == "boolean")
        return s;
    if (typeof (s) == "string") {
        if (s.toLowerCase() == "false")
            return false;
        if (s.toLowerCase() == "true")
            return true;
    }
    return null;
}

/*****************************************************************************/

function getDPICookie() {
    var cookie = new Cookie(document, "UPKDpiDailyWarning", "today", "/", null, false);
    cookie.Load();
    if (cookie.DPIdailyWarning == 1) {
        return true;
    }
    cookie.DPIdailyWarning = 1;
    cookie.Store();
    return false;
}

/*****************************************************************************/

var KeepAlive_url_ping = null;
var KeepAlive_url_closeserver = null;
var KeepAlive_finished = false;
var KeepAlive_timer = null;

function KeepAlive_Init(path) {
    if (KeepAlive_url_ping != null)
        return;
    KeepAlive_url_ping = path + "xml/ping.xml";
    KeepAlive_url_closeserver = path + "closeserver.xml";
    KeepAlive_finished = false;
    KeepAlive_timer = setInterval("KeepAlive_Ping()", 2000);
}

function KeepAlive_DoNotSendClose() {
    KeepAlive_finished = true;
}

function KeepAlive_Close() {
    if (KeepAlive_url_ping == null)
        return;
    if (KeepAlive_finished == true)
        return;
    KeepAlive_Track("close...");
    KeepAlive_finished = true;
    clearTimeout(KeepAlive_timer);
    LoadXMLDoc(KeepAlive_url_closeserver, KeepAlive_Return_OK, KeepAlive_Return_OK, "PING", true);
}

function KeepAlive_Ping() {
    KeepAlive_Track("ping...");
    if (KeepAlive_finished == true)
        return;
    LoadXMLDoc(KeepAlive_url_ping, KeepAlive_Return_OK, KeepAlive_Return_Error, "PING", false);
}

function KeepAlive_Return_OK(x) {
    KeepAlive_Track("ping returned");
    // nothing to do
}

function KeepAlive_Return_Error(x) {
    KeepAlive_Track("error returned");
    if (KeepAlive_finished == true)
        return;
    KeepAlive_finished = true;
    clearInterval(KeepAlive_timer);
    alert(R_playexe_comm_error);
}

var _KeepAlive_window = null;
var _KeepAlive_track = false;

function KeepAlive_Track(s) {
    if (_KeepAlive_track == false)
        return;
    if (_KeepAlive_window == null)
        _KeepAlive_window = window.open();
    _KeepAlive_window.document.writeln(s + "<br/>");
}

/* dialog.js */
/*
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
*/

var dlg_parent;
var dialogh_ref;
var device_dpi;
var dialog2_html;
var modal_dialog;
var dlg_width;
var dlg_height;
var dlg_autosizeheight = false;
var callback_end = "";
var isopened = false;
var dlg_context = "";
var grayPosition;
var overflowValue = "";
var resizefn = "";

function setParent(parentDialog) {
	dlg_parent = parentDialog;
}

function Click1() {
	closeDialog();
	$("#graydiv").remove();
}

function getDPI() {
	return device_dpi;
}

function setWidth(dlg, width) {
	$(dlg).css("width", width);
}

function setHeight(dlg, height) {
	$(dlg).css("height", height);
}

function setPadding(content, padding, classvalue) {
	var s = "<div style='padding:" + padding + "px'";
	if (classvalue && classvalue != "")
		s += " class='" + classvalue + "'";
	s += ">" + content + "</div>";
	return s;
}

function getContentSize(html) {
	var size = { width: 0, height: 0 };
	var o = $("<div style='display:visible;position:absolute;top:0px;left:0px;' id='04A98DB973UPK'>" + html + "</div>");
	$('body').append(o);
	size.width = $("#04A98DB973UPK").outerWidth(true);
	size.height = $("#04A98DB973UPK").outerHeight(true);
	$("#04A98DB973UPK").remove();
	return size;
}

function showDialog3(html, xpos, ypos, width, height, modal, dpi, noborder, outcontent) {

	showDialog2(html, xpos, ypos, width, height, modal, dpi, noborder);
	outcontent = "<div id='04A98DB974UPK'>" + outcontent + "</div>";
	$('body').append(outcontent);
}

function showDialog2(html, xpos, ypos, width, height, modal, dpi, noborder) {
	if (height == -1) {
		dlg_autosizeheight = true;
	}
	else dlg_autosizeheight = false;
	dialog2_html = html;
	showDialog("", xpos, ypos, width, height, modal, dpi, "", noborder);
}

(function ($) {
	$.fn.drags = function (opt) {
		opt = $.extend({
			handle: "",
			cursor: "move"
		}, opt);

		var $ehandler = $('<div>', {
			id: 'ehandler',
			css: {
				'position': 'absolute',
				'top': 0,
				'left': 0,
				'right': 0,
				'bottom': 0,
				'display': 'none',
				'cursor': opt.cursor,
				'z-index': 999,
				'background-color': 'red',
				'opacity': '0',
				'filter': 'alpha(opacity=0)'
			}
		}).appendTo(document.body)

		return this.addClass('draggable').each(function () {
			$drag = $(this);
			var $el = opt.handle === "" ? $drag : $drag.find(opt.handle);
			$el.addClass('active-handle')
                .on("mousedown", function (e) {
                	if (!$(e.target).is($(this))) {
                		return;
                	}
                	$drag.css('cursor', opt.cursor);
                	e.preventDefault();
                	var z_idx = $drag.css('z-index'),
                        drg_h = $drag.outerHeight(),
                        drg_w = $drag.outerWidth(),
                        pos_y = $drag.offset().top + drg_h - e.pageY,
                        pos_x = $drag.offset().left + drg_w - e.pageX;
                	$ehandler.show().on("mousemove", function (e) {
                		e.preventDefault();
                		y = e.pageY + pos_y - drg_h;
                		x = e.pageX + pos_x - drg_w;
                		if (y < 0) y = 0;
                		if (x < 0) x = 0;
                		$('.draggable').offset({
                			top: y,
                			left: x
                		})
                	}).add(document).on("mouseup", function (e) {
                		$drag.css('cursor', 'default');
                		e.preventDefault();
                		$(this).off("mousemove mouseup")
                		$ehandler.hide();
                	})
                })
		})
	}
})(jQuery);

function showDialog(href, xpos, ypos, width, height, modal, dpi, dialog1_path, noborder) {
	isopened = true;
	dpi = 96;
	if (xpos != -1) xpos = PtToPx(xpos, dpi);
	if (ypos != -1) ypos = PtToPx(ypos, dpi);
	width = PtToPx(width, dpi);
	height = PtToPx(height, dpi);

	dlg_width = width;
	dlg_height = height;
	device_dpi = dpi;
	dialogh_ref = href;
	modal_dialog = modal;

	var wpx, hpx;
	wpx = width;
	hpx = height;

	var centerx, centery, mainref;
	var scrollx = $(document.body).scrollLeft();
	var scrolly = $(document.body).scrollTop();

	if ((scrollx == 0 && scrolly == 0) && upk.browserInfo.isiOS()) {
	    scrollx = parent.window.pageXOffset;
	    scrolly = parent.window.pageYOffset;
	}

	if (xpos == -1 || ypos == -1) {
		// if the browser is IE then we can use pixel positioning
		var w = 0, h = 0;
		if (parent.window.innerWidth) {
		    w = parent.window.innerWidth;
		    h = parent.window.innerHeight;
		}
		else if (document.documentElement) {
			w = document.documentElement.scrollWidth;
			h = document.documentElement.scrollHeight;
		}
		centerx = Math.floor(w / 2 - (wpx / 2) + scrollx);
		centery = Math.floor(h / 2 - (hpx / 2) + scrolly);
	}
	else {
		//do we need scroll adjustment here too???
		centerx = xpos;
		centery = ypos;
	}
	if (noborder)
		mainref = dialogh_ref;

	if (document.body.scrollHeight < hpx) centery = 0;

    // 18373699 PREFS DIALOG IS OUT OF SCREEN FOR HIGH CONCEPTS IN KCENTER KNOWLEDGE PATH ON IOS 
	if (typeof lmsMode !== "undefined")
	    if (lmsMode && lmsMode == "LMS" && upk.browserInfo.isiOS()) centery = 20;

	var pos = "top:0;left:0;";
	if (upk.browserInfo.isIEQuirks()) {
	    grayPosition = "absolute";
	    pos = "top:" + scrolly + "px;left:" + scrollx + "px;";
	    overflowValue = $(document.body).css("overflow");	// check overflow
	    if (overflowValue === "auto") {
	        $(document.body).css("overflow", "hidden");	// removes overflow:auto
	    }
	    document.body.scroll = "no";	// removes scroll on html
	    resizefn = window.onresize;
	    window.onresize = "";
	}
	else {
	    grayPosition = "fixed";
	}

	if (modal) {
		$(document.body).append('<div id="graydiv" scrolling="no" class="pointerdiv" style="position:' + grayPosition + ';display:none;z-index: 99;' + pos + 'bottom:0;right:0;"></div>');
	}
	else {
	    $(document.body).append('<div id="graydiv" scrolling="no" class="pointerdiv2" style="position:' + grayPosition + ';display:none;z-index: 99;' + pos + 'bottom:0;right:0;" onclick="Click1();"></div>');
	}
	// we have to prevent the preview window in doit/testit to remain scrollable while our dialog is displayed
	$("#graydiv").on("touchmove", function (e) {
		return false;
	});
	// this prevents inputs to get focus while our dialog is displayed
	// I don't understand why inputs can have focus since graydiv is on top of them
	$("input").on("focus", function () { this.blur(); });
	$("#graydiv").show();
	style = 'left:' + centerx + 'px; top:' + centery + 'px; width: ' + wpx + 'px; height: ' + hpx + 'px;';


	wwpx = wpx - 60;//-2*margin
	hhpx = hpx - 60;//-2*margin

    // Internet Explorer box model bug(IE9)
    // more info:
    // http://en.wikipedia.org/wiki/Internet_Explorer_box_model_bug
	if ((upk.browserInfo.isIEQuirks() && upk.browserInfo.isIE9()) || (upk.browserInfo.isIEQuirks() && upk.browserInfo.isIE8())) {
	    wwpx -= 20;//-2*border
	    hhpx -= 20;//-2*border
	}

	innerstyle = 'width: ' + wwpx + 'px; height: ' + hhpx + 'px;';

	var mode = "iossafefordesktop";
	if (IsTouchDevice())
		mode = "iossafe";
	var emptyImage = "../img/empty.gif";
	if (dialog1_path) emptyImage = dialog1_path + "img/empty.gif";

	if (modal) {
		$(document.body).append('<div class="desktopDialog" id="dialog" style="' + style + '"><div id="closebtn" onclick="Click1();"><img id="closeimg" class="close_qualifier" src="' + emptyImage + '" alt="" width="16" /></div>' +
            '<div class="' + mode + '" style="' + innerstyle + '"><iframe id="dialogBody" frameborder="0" scrolling="no" src="' + href + '" style="width: 100%; height: 100%;margin:0px; padding:0px; position: absolute;top: 0px; left: 0px; background-color: white;"></iframe></div></div>');
		$('#dialog').drags();
		// we have to prevent the preview window in doit/testit to remain scrollable while our dialog is displayed
		$("#dialog").on("touchmove", function (e) {
			return false;
		});
	}
	else {
		innerstyle = 'width: ' + wpx + 'px; height: ' + hpx + 'px;';
		mainref = "../html/dialog2.html";
		$(document.body).append('<div class="noborderDialog" id="dialog" style="' + style + '">' +
        '<div id="dialogBodyDiv" class="noBorderDialogDesktop" style="' + innerstyle + '"><iframe id="dialogBody" frameborder="0" scrolling="no" src="' + mainref + '" style="width: 100%; height: 100%;margin:0px; padding:0px; position: absolute;top: 0px; left: 0px; background-color: white;"></iframe></div></div>');
	}
	if (dlg_context != "") {
		ctxHelper.SetContext(dlg_context);
	}
}

function isOpenDialog() {
	return isopened;
}

function removeDiv(dlgName) {
	$(dlgName).remove();
}

function appendDiv(div) {
	$(document.body).append(div);
}

function closeDialog() {
	$("#04A98DB974UPK").remove();
	$("#graydiv").remove();
	$("#dialog").remove();
	$("#ehandler").remove();
	if (dlg_context != "") {
		ctxHelper.SetPrevContext();
		dlg_context = "";
	}
	if (upk.browserInfo.isIEQuirks()) {
		if (overflowValue === "auto") {
			$(document.body).css("overflow", overflowValue);	// adds back overflow:auto
			overflowValue = "";
		}
		document.body.scroll = "auto";	// adds back scroll to html
		window.onresize = resizefn;
		resizefn = "";
	}
	isopened = false;
	if (dlg_parent) {
		if (callback_end) dlg_parent.eval(callback_end);
	}
	else {
		if (callback_end) eval(callback_end);
	}
	$("input").off("focus");
}

function setOnCloseEvent(functionname) {
	callback_end = functionname;
}

function getOnCloseEvent() {
	return callback_end;
}

function getDialog2Content() {
	return dialog2_html;
}

function setDlgCtx(context) {
	dlg_context = context;
}

/* swfobject.js */
/*	SWFObject v2.2 <http://code.google.com/p/swfobject/> 
	is released under the MIT License <http://www.opensource.org/licenses/mit-license.php> 
*/
var swfobject=function(){var D="undefined",r="object",S="Shockwave Flash",W="ShockwaveFlash.ShockwaveFlash",q="application/x-shockwave-flash",R="SWFObjectExprInst",x="onreadystatechange",O=window,j=document,t=navigator,T=false,U=[h],o=[],N=[],I=[],l,Q,E,B,J=false,a=false,n,G,m=true,M=function(){var aa=typeof j.getElementById!=D&&typeof j.getElementsByTagName!=D&&typeof j.createElement!=D,ah=t.userAgent.toLowerCase(),Y=t.platform.toLowerCase(),ae=Y?/win/.test(Y):/win/.test(ah),ac=Y?/mac/.test(Y):/mac/.test(ah),af=/webkit/.test(ah)?parseFloat(ah.replace(/^.*webkit\/(\d+(\.\d+)?).*$/,"$1")):false,X=!+"\v1",ag=[0,0,0],ab=null;if(typeof t.plugins!=D&&typeof t.plugins[S]==r){ab=t.plugins[S].description;if(ab&&!(typeof t.mimeTypes!=D&&t.mimeTypes[q]&&!t.mimeTypes[q].enabledPlugin)){T=true;X=false;ab=ab.replace(/^.*\s+(\S+\s+\S+$)/,"$1");ag[0]=parseInt(ab.replace(/^(.*)\..*$/,"$1"),10);ag[1]=parseInt(ab.replace(/^.*\.(.*)\s.*$/,"$1"),10);ag[2]=/[a-zA-Z]/.test(ab)?parseInt(ab.replace(/^.*[a-zA-Z]+(.*)$/,"$1"),10):0}}else{if(typeof O.ActiveXObject!=D){try{var ad=new ActiveXObject(W);if(ad){ab=ad.GetVariable("$version");if(ab){X=true;ab=ab.split(" ")[1].split(",");ag=[parseInt(ab[0],10),parseInt(ab[1],10),parseInt(ab[2],10)]}}}catch(Z){}}}return{w3:aa,pv:ag,wk:af,ie:X,win:ae,mac:ac}}(),k=function(){if(!M.w3){return}if((typeof j.readyState!=D&&j.readyState=="complete")||(typeof j.readyState==D&&(j.getElementsByTagName("body")[0]||j.body))){f()}if(!J){if(typeof j.addEventListener!=D){j.addEventListener("DOMContentLoaded",f,false)}if(M.ie&&M.win){j.attachEvent(x,function(){if(j.readyState=="complete"){j.detachEvent(x,arguments.callee);f()}});if(O==top){(function(){if(J){return}try{j.documentElement.doScroll("left")}catch(X){setTimeout(arguments.callee,0);return}f()})()}}if(M.wk){(function(){if(J){return}if(!/loaded|complete/.test(j.readyState)){setTimeout(arguments.callee,0);return}f()})()}s(f)}}();function f(){if(J){return}try{var Z=j.getElementsByTagName("body")[0].appendChild(C("span"));Z.parentNode.removeChild(Z)}catch(aa){return}J=true;var X=U.length;for(var Y=0;Y<X;Y++){U[Y]()}}function K(X){if(J){X()}else{U[U.length]=X}}function s(Y){if(typeof O.addEventListener!=D){O.addEventListener("load",Y,false)}else{if(typeof j.addEventListener!=D){j.addEventListener("load",Y,false)}else{if(typeof O.attachEvent!=D){i(O,"onload",Y)}else{if(typeof O.onload=="function"){var X=O.onload;O.onload=function(){X();Y()}}else{O.onload=Y}}}}}function h(){if(T){V()}else{H()}}function V(){var X=j.getElementsByTagName("body")[0];var aa=C(r);aa.setAttribute("type",q);var Z=X.appendChild(aa);if(Z){var Y=0;(function(){if(typeof Z.GetVariable!=D){try{var ab=Z.GetVariable("$version");}catch(er){}if(ab){ab=ab.split(" ")[1].split(",");M.pv=[parseInt(ab[0],10),parseInt(ab[1],10),parseInt(ab[2],10)]}}else{if(Y<10){Y++;setTimeout(arguments.callee,10);return}}X.removeChild(aa);Z=null;H()})()}else{H()}}function H(){var ag=o.length;if(ag>0){for(var af=0;af<ag;af++){var Y=o[af].id;var ab=o[af].callbackFn;var aa={success:false,id:Y};if(M.pv[0]>0){var ae=c(Y);if(ae){if(F(o[af].swfVersion)&&!(M.wk&&M.wk<312)){w(Y,true);if(ab){aa.success=true;aa.ref=z(Y);ab(aa)}}else{if(o[af].expressInstall&&A()){var ai={};ai.data=o[af].expressInstall;ai.width=ae.getAttribute("width")||"0";ai.height=ae.getAttribute("height")||"0";if(ae.getAttribute("class")){ai.styleclass=ae.getAttribute("class")}if(ae.getAttribute("align")){ai.align=ae.getAttribute("align")}var ah={};var X=ae.getElementsByTagName("param");var ac=X.length;for(var ad=0;ad<ac;ad++){if(X[ad].getAttribute("name").toLowerCase()!="movie"){ah[X[ad].getAttribute("name")]=X[ad].getAttribute("value")}}P(ai,ah,Y,ab)}else{p(ae);if(ab){ab(aa)}}}}}else{w(Y,true);if(ab){var Z=z(Y);if(Z&&typeof Z.SetVariable!=D){aa.success=true;aa.ref=Z}ab(aa)}}}}}function z(aa){var X=null;var Y=c(aa);if(Y&&Y.nodeName=="OBJECT"){if(typeof Y.SetVariable!=D){X=Y}else{var Z=Y.getElementsByTagName(r)[0];if(Z){X=Z}}}return X}function A(){return !a&&F("6.0.65")&&(M.win||M.mac)&&!(M.wk&&M.wk<312)}function P(aa,ab,X,Z){a=true;E=Z||null;B={success:false,id:X};var ae=c(X);if(ae){if(ae.nodeName=="OBJECT"){l=g(ae);Q=null}else{l=ae;Q=X}aa.id=R;if(typeof aa.width==D||(!/%$/.test(aa.width)&&parseInt(aa.width,10)<310)){aa.width="310"}if(typeof aa.height==D||(!/%$/.test(aa.height)&&parseInt(aa.height,10)<137)){aa.height="137"}j.title=j.title.slice(0,47)+" - Flash Player Installation";var ad=M.ie&&M.win?"ActiveX":"PlugIn",ac="MMredirectURL="+O.location.toString().replace(/&/g,"%26")+"&MMplayerType="+ad+"&MMdoctitle="+j.title;if(typeof ab.flashvars!=D){ab.flashvars+="&"+ac}else{ab.flashvars=ac}if(M.ie&&M.win&&ae.readyState!=4){var Y=C("div");X+="SWFObjectNew";Y.setAttribute("id",X);ae.parentNode.insertBefore(Y,ae);ae.style.display="none";(function(){if(ae.readyState==4){ae.parentNode.removeChild(ae)}else{setTimeout(arguments.callee,10)}})()}u(aa,ab,X)}}function p(Y){if(M.ie&&M.win&&Y.readyState!=4){var X=C("div");Y.parentNode.insertBefore(X,Y);X.parentNode.replaceChild(g(Y),X);Y.style.display="none";(function(){if(Y.readyState==4){Y.parentNode.removeChild(Y)}else{setTimeout(arguments.callee,10)}})()}else{Y.parentNode.replaceChild(g(Y),Y)}}function g(ab){var aa=C("div");if(M.win&&M.ie){aa.innerHTML=ab.innerHTML}else{var Y=ab.getElementsByTagName(r)[0];if(Y){var ad=Y.childNodes;if(ad){var X=ad.length;for(var Z=0;Z<X;Z++){if(!(ad[Z].nodeType==1&&ad[Z].nodeName=="PARAM")&&!(ad[Z].nodeType==8)){aa.appendChild(ad[Z].cloneNode(true))}}}}}return aa}function u(ai,ag,Y){var X,aa=c(Y);if(M.wk&&M.wk<312){return X}if(aa){if(typeof ai.id==D){ai.id=Y}if(M.ie&&M.win){var ah="";for(var ae in ai){if(ai[ae]!=Object.prototype[ae]){if(ae.toLowerCase()=="data"){ag.movie=ai[ae]}else{if(ae.toLowerCase()=="styleclass"){ah+=' class="'+ai[ae]+'"'}else{if(ae.toLowerCase()!="classid"){ah+=" "+ae+'="'+ai[ae]+'"'}}}}}var af="";for(var ad in ag){if(ag[ad]!=Object.prototype[ad]){af+='<param name="'+ad+'" value="'+ag[ad]+'" />'}}aa.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+ah+">"+af+"</object>";N[N.length]=ai.id;X=c(ai.id)}else{var Z=C(r);Z.setAttribute("type",q);for(var ac in ai){if(ai[ac]!=Object.prototype[ac]){if(ac.toLowerCase()=="styleclass"){Z.setAttribute("class",ai[ac])}else{if(ac.toLowerCase()!="classid"){Z.setAttribute(ac,ai[ac])}}}}for(var ab in ag){if(ag[ab]!=Object.prototype[ab]&&ab.toLowerCase()!="movie"){e(Z,ab,ag[ab])}}aa.parentNode.replaceChild(Z,aa);X=Z}}return X}function e(Z,X,Y){var aa=C("param");aa.setAttribute("name",X);aa.setAttribute("value",Y);Z.appendChild(aa)}function y(Y){var X=c(Y);if(X&&X.nodeName=="OBJECT"){if(M.ie&&M.win){X.style.display="none";(function(){if(X.readyState==4){b(Y)}else{setTimeout(arguments.callee,10)}})()}else{X.parentNode.removeChild(X)}}}function b(Z){var Y=c(Z);if(Y){for(var X in Y){if(typeof Y[X]=="function"){Y[X]=null}}Y.parentNode.removeChild(Y)}}function c(Z){var X=null;try{X=j.getElementById(Z)}catch(Y){}return X}function C(X){return j.createElement(X)}function i(Z,X,Y){Z.attachEvent(X,Y);I[I.length]=[Z,X,Y]}function F(Z){var Y=M.pv,X=Z.split(".");X[0]=parseInt(X[0],10);X[1]=parseInt(X[1],10)||0;X[2]=parseInt(X[2],10)||0;return(Y[0]>X[0]||(Y[0]==X[0]&&Y[1]>X[1])||(Y[0]==X[0]&&Y[1]==X[1]&&Y[2]>=X[2]))?true:false}function v(ac,Y,ad,ab){if(M.ie&&M.mac){return}var aa=j.getElementsByTagName("head")[0];if(!aa){return}var X=(ad&&typeof ad=="string")?ad:"screen";if(ab){n=null;G=null}if(!n||G!=X){var Z=C("style");Z.setAttribute("type","text/css");Z.setAttribute("media",X);n=aa.appendChild(Z);if(M.ie&&M.win&&typeof j.styleSheets!=D&&j.styleSheets.length>0){n=j.styleSheets[j.styleSheets.length-1]}G=X}if(M.ie&&M.win){if(n&&typeof n.addRule==r){n.addRule(ac,Y)}}else{if(n&&typeof j.createTextNode!=D){n.appendChild(j.createTextNode(ac+" {"+Y+"}"))}}}function w(Z,X){if(!m){return}var Y=X?"visible":"hidden";if(J&&c(Z)){c(Z).style.visibility=Y}else{v("#"+Z,"visibility:"+Y)}}function L(Y){var Z=/[\\\"<>\.;]/;var X=Z.exec(Y)!=null;return X&&typeof encodeURIComponent!=D?encodeURIComponent(Y):Y}var d=function(){if(M.ie&&M.win){window.attachEvent("onunload",function(){var ac=I.length;for(var ab=0;ab<ac;ab++){I[ab][0].detachEvent(I[ab][1],I[ab][2])}var Z=N.length;for(var aa=0;aa<Z;aa++){y(N[aa])}for(var Y in M){M[Y]=null}M=null;for(var X in swfobject){swfobject[X]=null}swfobject=null})}}();return{registerObject:function(ab,X,aa,Z){if(M.w3&&ab&&X){var Y={};Y.id=ab;Y.swfVersion=X;Y.expressInstall=aa;Y.callbackFn=Z;o[o.length]=Y;w(ab,false)}else{if(Z){Z({success:false,id:ab})}}},getObjectById:function(X){if(M.w3){return z(X)}},embedSWF:function(ab,ah,ae,ag,Y,aa,Z,ad,af,ac){var X={success:false,id:ah};if(M.w3&&!(M.wk&&M.wk<312)&&ab&&ah&&ae&&ag&&Y){w(ah,false);K(function(){ae+="";ag+="";var aj={};if(af&&typeof af===r){for(var al in af){aj[al]=af[al]}}aj.data=ab;aj.width=ae;aj.height=ag;var am={};if(ad&&typeof ad===r){for(var ak in ad){am[ak]=ad[ak]}}if(Z&&typeof Z===r){for(var ai in Z){if(typeof am.flashvars!=D){am.flashvars+="&"+ai+"="+Z[ai]}else{am.flashvars=ai+"="+Z[ai]}}}if(F(Y)){var an=u(aj,am,ah);if(aj.id==ah){w(ah,true)}X.success=true;X.ref=an}else{if(aa&&A()){aj.data=aa;P(aj,am,ah,ac);return}else{w(ah,true)}}if(ac){ac(X)}})}else{if(ac){ac(X)}}},switchOffAutoHideShow:function(){m=false},ua:M,getFlashPlayerVersion:function(){return{major:M.pv[0],minor:M.pv[1],release:M.pv[2]}},hasFlashPlayerVersion:F,createSWF:function(Z,Y,X){if(M.w3){return u(Z,Y,X)}else{return undefined}},showExpressInstall:function(Z,aa,X,Y){if(M.w3&&A()){P(Z,aa,X,Y)}},removeSWF:function(X){if(M.w3){y(X)}},createCSS:function(aa,Z,Y,X){if(M.w3){v(aa,Z,Y,X)}},addDomLoadEvent:K,addLoadEvent:s,getQueryParamValue:function(aa){var Z=j.location.search||j.location.hash;if(Z){if(/\?/.test(Z)){Z=Z.split("?")[1]}if(aa==null){return L(Z)}var Y=Z.split("&");for(var X=0;X<Y.length;X++){if(Y[X].substring(0,Y[X].indexOf("="))==aa){return L(Y[X].substring((Y[X].indexOf("=")+1)))}}}return""},expressInstallCallback:function(){if(a){var X=c(R);if(X&&l){X.parentNode.replaceChild(l,X);if(Q){w(Q,true);if(M.ie&&M.win){l.style.display="block"}}if(E){E(B)}}a=false}}}}();
/* browser.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

var _simulate_120_dpi = false;

function IsTouchDevice() {
    return upk.browserInfo.isTouchDevice();
}

var upk = upk || {};

// upk.browserInfo
(function (_this) {
    // PRIVATE
    var browserName = "";
    var version;
    var subversion;
    var trident = false;
    var tridentVersion;
    var isMac = false;
    var isFF3 = false;

    // PUBLIC

    _this.getAgentInfo = function () {
        if (typeof (document.documentMode) != "undefined")
            return navigator.userAgent + " - " + document.documentMode;
        else
            return navigator.userAgent;
    }

    _this.isSupportedBrowser = function () {
        var k = false;
        if (browserName == "MSIE" && (version >= 8 || (trident && tridentVersion >= 4)))
            k = true;
        if (browserName == "Firefox" && (version == 24 || version >= 27))
            k = true;
        if (browserName == "Safari" && version >= 6)
            k = true;
        if (browserName == "Chrome" && version >= 32)
            k = true;
        if (_this.isiOS())
            k = true;
        return k;
    }

    _this.isHardStop = function () {
        return (browserName == "MSIE" && version <= 6);
    }

    _this.isMacOs = function () {
        return isMac;
    }

    _this.isFF3 = function () {
        return isFF3;
    }

    _this.isFF = function () {
        return (browserName == "Firefox");
    }

    _this.isFF4 = function () {
        return (browserName == "Firefox" && version == 4);
    }

    _this.checkFFVersion = function (i) {
        return (browserName == "Firefox" && version == i);
    }

    _this.isSafari = function () {
        return (browserName == "Safari" || browserName == "Chrome");
    }

    _this.isChrome = function () {
        return (browserName == "Chrome");
    }

    _this.isExplorer = function () {
        return (browserName == "MSIE");
    }

    _this.isIEVersion = function (i) {
        return (browserName == "MSIE" && version == i);
    }

    _this.isIEQuirks = function () {
        if (_this.isExplorer() == false)
            return false;
        return (document.compatMode !== 'CSS1Compat'); // ? 'Standards' : 'Quirks');
    }

    _this.isIE8 = function () {
        if (browserName != "MSIE")
            return false;
        return (version == 8 && (trident && tridentVersion == 4));  // ie8 normal mode
    }

    _this.isIE9 = function () {
        if (browserName != "MSIE")
            return false;
        if (version == 9 && (trident && tridentVersion == 5))      // ie9 normal mode
            return true;
        if (version == 7 && (trident && tridentVersion == 5))      // ie9 compatability mode
            return true;
        return ((trident && tridentVersion == 6) && (version != 10 || document.documentMode != 10)); // ie10 compatibility mode
    }

    _this.isIE10 = function () {
        if (browserName != "MSIE")
            return false;
        return (version == 10 && (trident && tridentVersion == 6) && document.documentMode == 10); // ie10 normal mode
    }

    _this.isIE10orHigher = function () {
        if (browserName != "MSIE")
            return false;
        return (version >= 10 && (trident && tridentVersion >= 6) && document.documentMode >= 10); // ie10 or higher normal mode
    }

    _this.isIE11 = function () {
        if (browserName != "MSIE")
            return false;
        return (version == 11 && (trident && tridentVersion == 7) && document.documentMode == 11); // ie11 normal mode
    }

    _this.isIE11Compatibility = function () {
        if (browserName != "MSIE")
            return false;
        return ((trident && tridentVersion == 7) && (version != 11 || document.documentMode != 11)); // ie11 compatibility mode
    }

    _this.isActiveXEnabled = function () {
        var supported = null;
        var errorName = "";
        try {
            new ActiveXObject("");
        }
        catch (e) {
            // FF has ReferenceError here
            errorName = e.name;
        }
        try {
            supported = !!new ActiveXObject("htmlfile");
        } catch (e) {
            supported = false;
        }
        if (errorName != 'ReferenceError' && supported == false) {
            supported = false;
        } else {
            supported = true;
        }
        return supported;
    }

    _this.isIE10Modern = function () {
        if (_this.isIE10() == false)
            return false;
        return !_this.isActiveXEnabled();
    }

    _this.isiOS = function () {
        var p = navigator.platform;
        if (p === 'iPad' || p === 'iPad Simulator' || p === 'iPhone' || p === 'iPod')
            return true;
        return false;
    }

    _this.isiOS5 = function () {
        var p = navigator.userAgent;
        return (p.indexOf("CPU OS 5_") >= 0);
    }

    _this.isiOS6 = function () {
        var p = navigator.userAgent;
        return (p.indexOf("CPU OS 6_") >= 0);
    }

    _this.isiOS7 = function () {
        var p = navigator.userAgent;
        return (p.indexOf("CPU OS 7_") >= 0);
    }

    _this.isTouchDevice = function () {
        if (_this.isChrome())
            return null;
        return (window.Touch || window.navigator.msMaxTouchPoints);
    }

    _this.isSoundSupported = function () {
        if (_this.isiOS())
            return true;
        if (window.location.href.substr(0, 7).toLowerCase() == "file://")
            return false;
        if (swfobject.getFlashPlayerVersion().major > 0)
            return true;
        return false;
    }

    // CONSTRUCTOR
    var s = navigator.userAgent;
    var k = 0 - 1;
    if (s.indexOf("OPR") >= 0) {      // new opera version id
        browserName = "Opera";
        k = s.indexOf("OPR") + 4;
    }
    else if (s.indexOf("Chrome") >= 0) {
        browserName = "Chrome";
        k = s.indexOf("Chrome") + 7;
    }
    else if (s.indexOf("Opera") >= 0) {
        browserName = "Opera";
        k = s.indexOf("Opera") + 6;
    }
    else if (s.indexOf("Firefox") >= 0) {
        browserName = "Firefox";
        k = s.indexOf("Firefox") + 8;
    }
    else if (s.indexOf("Safari") >= 0) {
        browserName = "Safari";
        k = s.indexOf("Version") + 8;
    }
    else if (s.indexOf("MSIE") >= 0) {
        browserName = "MSIE";
        k = s.indexOf("MSIE") + 5;
        var ti = s.indexOf("Trident/");
        if (ti >= 0) {
            trident = true;
            tridentVersion = parseInt(s.substr(ti + 8));
        }
    }
    else if (s.indexOf(" rv:") >= 0) {
        browserName = "MSIE";
        k = s.indexOf(" rv:") + 3;
        var ti = s.indexOf("Trident/");
        if (ti >= 0) {
            trident = true;
            tridentVersion = parseInt(s.substr(ti + 8));
        }
    }
    else {
        browserName = "";
        version = 0;
    }
    if (browserName != "") {
        version = parseInt(s.substr(k));
        if (isNaN(version)) {
            k++;
            version = parseInt(s.substr(k));
        }
        subversion = parseInt(s.substr(k + 2, 1));
    }
    if (browserName == "Safari" && isNaN(version)) {
        version = 5;
        subversion = 0;
    }
    isMac = (s.indexOf("Macintosh") >= 0);
    isFF3 = (browserName == "Firefox" && s.indexOf("Firefox/3") > 0);

})(upk.browserInfo = {});

//
// Browser-independent object access (NS4, IE5+, Mozilla)
//

function getDIV(id) {
    return document.getElementById(id);
}

function getDIVstyle(id) {
    try {
        return document.getElementById(id).style;
    }
    catch (error) {
        //alert ("##### ERROR #####:\n" + error + "\n\n##### CALLER #####" + getDIVstyle.caller);
        return null;
    }
}

function shiftTo(id, x, y) {
    var obj = getDIVstyle(id);
    obj.left = x + "px";
    obj.top = y + "px";
}

/**
* #####################
* # START NEW CONTENT #
* #####################
*/

function getUniWidth(id) {
    return id.offsetWidth;
}

function getUniHeight(id) {
    return id.offsetHeight;
}

function getClientWidth(id) {
    return id.offsetWidth;
}

function getClientHeight(id) {
    return id.offsetHeight;
}

/**
* ###################
* # END NEW CONTENT #
* ###################
*/

function getObjHeight(id) {
    return getDIV(id).offsetHeight;
}

function getObjWidth(id) {
    return getDIV(id).offsetWidth;
}

function getObjLeft(id) {
    try {
        var obj = getDIVstyle(id);
        if (obj.pixelLeft) {
            return obj.pixelLeft;
        }
        else if (obj.left != "") {
            return parseInt(obj.left);
        }
        else {
            return document.getElementById(id).offsetLeft;
        }
    }
    catch (error) {
        return parseInt(id.offsetLeft);
    }
}

function getObjTop(id) {
    try {
        var obj = getDIVstyle(id);
        if (obj.pixelTop) {
            return obj.pixelTop;
        }
        else if (obj.top != "") {
            return parseInt(obj.top);
        }
        else {
            return document.getElementById(id).offsetTop;
        }
    }
    catch (error) {
        return parseInt(id.offsetTop);
    }
}


function getInsideWindowWidth() {
    if (window.innerWidth) {
        return window.innerWidth;
    }
    else {
        return document.body.clientWidth;
    }
}

function getInsideWindowHeight() {
    if (window.innerHeight) {
        return window.innerHeight;
    }
    else {
        return document.body.clientHeight;
    }
}

function getScrollLeft() {
    if (window.pageXOffset || window.pageXOffset == 0) {
        return window.pageXOffset;
    }
    else {
        return document.body.scrollLeft;
    }
}

function getScrollTop() {
    if (window.pageYOffset || window.pageYOffset == 0) {
        return window.pageYOffset;
    }
    else {
        return document.body.scrollTop;
    }
}

function show(id, strinput) {
    var obj = getDIVstyle(id);
    obj.visibility = "visible";
    if (strinput && upk.browserInfo.isiOS()) {
        try {
            if (playMode == "S") {
                if (showActObj.type == "Input") {
                    $("#" + id + " input").attr('readonly', true);
                }
            }
        }
        catch (e) { };
    }
}

function hide(id, strinput) {
    var obj = getDIVstyle(id);
    obj.visibility = "hidden";
}

var __DPIwidth = 0;

function getDpiInfo() {
    var d = document.getElementById("DPIInfoDiv");
    if (d != null) {
        __DPIwidth = d.clientWidth;
        if (__DPIwidth == 0) { //player is in hidden frame
            __DPIwidth = 96;
        }
        if (__DPIwidth != 0)
            document.getElementsByTagName("body")[0].removeChild(d);
    }
    return _simulate_120_dpi == true ? 120 : __DPIwidth;
}

function initDpiInfo() {
    document.write('<div id="DPIInfoDiv" style="visibility:hidden; width: 72pt; height: 1pt;">DPIINFODIV</div>');
}

function checkIEDPI() {
    return true;
    //    if (IsExplorer() == false)
    //        return true;
    //    return (screen.deviceXDPI == 96);
}

/*
functions from browser1.js
*/

function Get_Element(id) {
    return document.getElementById(id);
}

/*
END functions from browser1.js
*/

function touch(e) {
    if (e.originalEvent.touches && e.originalEvent.touches.length) {
        return e.originalEvent.touches[0];
    } else if (e.originalEvent.changedTouches && e.originalEvent.changedTouches.length) {
        return e.originalEvent.changedTouches[0];
    }
};

function isNavBar() {
    return (typeof navBar !== 'undefined');
}

/* cookie.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

/** @constructor */
function Cookie(doc, name, exp, path, domain, secure) {
    this.$document = doc;
    this.$name = name;
    if (exp == "today") {
        var d = new Date();
        d.setHours(23);
        d.setMinutes(59);
        d.setSeconds(59);
        this.$exp = d;
    }
    else if (exp)
        this.$exp = new Date((new Date()).getTime() + exp * 3600000 * 24);
    else
        this.$exp = null;
    if (path) this.$path = path; else this.$path = null;
    if (domain) this.$domain = domain; else this.$domain = null;
    if (secure) this.$secure = true; else this.$secure = false;
}

Cookie.prototype.Store = function () {
    if (!PlayerConfig.EnableCookies)
        return;

    var cookieval = "";
    for (var prop in this) {
        if ((prop.charAt(0) == "$") || ((typeof this[prop]) == 'function'))
            continue;
        if (cookieval != "") cookieval += "&";
        cookieval += prop + ":" + escape(this[prop]);
    }

    var cookie = this.$name + "=" + cookieval;
    if (this.$exp)
        cookie += "; expires=" + this.$exp.toGMTString();
    if (this.$path) cookie += "; path=" + this.$path;
    if (this.$domain) cookie += "; domain=" + this.$domain;
    if (this.$secure) cookie += "; secure=";

    this.$document.cookie = cookie;
}

Cookie.prototype.Load = function () {
    if (!PlayerConfig.EnableCookies)
        return false;

    var allcookies = this.$document.cookie;
    if (allcookies == "") return false;

    var start = allcookies.indexOf(this.$name + "=");
    if (start == -1) return false;
    start += this.$name.length + 1;

    var end = allcookies.indexOf(";", start);
    if (end == -1)
        end = allcookies.length;

    var cookieval = decodeURIComponent(allcookies.substring(start, end));

    var a = cookieval.split("&");
    for (var i = 0; i < a.length; i++) {
        var p = a[i].split(":");
        this[p[0]] = unescape(p[1]);
    }

    return true;
}

Cookie.prototype.Remove = function () {
    if (!PlayerConfig.EnableCookies)
        return;

    var cookie = this.$name + '=';
    if (this.$path) cookie += '; path=' + this.$path;
    if (this.$domain) cookie += '; domain=' + this.$domain;
    cookie += '; expires=Fri, 02-Jan-1970 00:00:00 GMT';

    this.$document.cookie = cookie;
}

/* escape.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

var Escape = (function()
{
	//*****************************************************************
	//Safe Escape/UnEscape support

	var SafeUri_EscapeCharacter = '/';

	var SafeUri_UnsafeCharacters = ['<', '>', '"', '\'', '%', ';', '(', ')', '&', '+'];
	
	return {
		SafeUriEscape: function(s) {
			return __Escape(s, 1);
		},

		SafeUriUnEscape: function(s) {
			return __UnEscape(s, 1);
		},


	//*****************************************************************
	// Simple Escape/UnEscape support

		MyEscape: function(s) {
			return __Escape(s, 0);
		},

		MyUnEscape: function(s) {
			return __UnEscape(s, 0);
		}
	}

	//*****************************************************************
	// private

	function __Escape(s, safe) {
		var snew = "";
		for (var i = 0; i < s.length; i++) {
			var ss = s.substr(i, 1);
			if (safe == 0 ? __Normal_Contains(ss) : !__SafeUri_Contains(ss)) {
				snew += ss;
			}
			else {
				ss = s.charCodeAt(i);
				var a = "0000" + ss.toString(16).toUpperCase();
				snew += (safe == 0 ? "$" : SafeUri_EscapeCharacter) + a.substr(a.length - 4);
			}
		}
		return snew;
	}

	function __UnEscape(s, safe) {
		var snew = "";
		var bEscape = false;
		for (var i = 0; i < s.length; i++) {
			var ss;
			if (bEscape) {
				ss = s.substr(i, 4);
				snew += String.fromCharCode(parseInt("0x" + ss));
				i += 3;
				bEscape = false;
			}
			else {
				ss = s.substr(i, 1);
				if (ss == (safe == 0 ? '$' : SafeUri_EscapeCharacter))
					bEscape = true;
				else
					snew += ss;
			}
		}
		return snew;
	}

	function __Normal_Contains(s) {
		return ((s >= '0' && s <= '9') || (s >= 'a' && s <= 'z') || (s >= 'A' && s <= 'Z'));
	}

	function __SafeUri_Contains(s) {
		var l = SafeUri_UnsafeCharacters.length;
		for (var i = 0; i < l; i++) {
			if (s == SafeUri_UnsafeCharacters[i])
				return true;
		}
		if (s == SafeUri_EscapeCharacter)
			return true;
		return false;
	}

})();

////////////////////////////////////////////////////////////////////////////////////////
// UrlParser object

/** @constructor */
function UrlParser() {
	this.params = new Array();
	this.safemode = false;
}

UrlParser.prototype.Clone = function() {
	var url = new UrlParser();
	url.params = new Array();
	url.safemode = this.safemode;
	for (var k in this.params) {
		var v = this.params[k];
		if (v == null)
			continue;
		url.params[k] = this.params[k];
	}
	return url;
}

UrlParser.prototype.Parse = function() {
	var strArgs;
	var strArg;
	var ss = document.location.hash.substring(1);
	strArgs = ss.split("&");
	if (strArgs.length == 0 || strArgs[0] == "") {
		ss = document.location.search.substring(1);
		strArgs = ss.split("&");
	};
	if (strArgs.length > 0) {
		if (strArgs[0].toLowerCase().substr(0, 3) == "su=") {
			this.safemode = true;
			strArgs = strArgs[0].substr(3);
			strArgs = Escape.SafeUriUnEscape(strArgs);
			strArgs = strArgs.split("&");
		}
	}
	for (var i = 0; i < strArgs.length; i++) {
		strArg = (strArgs[i]);
		if (strArg.length == 0)
			continue;
		var param = strArg.split("=");
		if (param.length == 2) {
			this.params[param[0].toLowerCase()] = param[1];
		}
		else if (param.length < 2) {
			this.params[param[0].toLowerCase()] = "";
		}
		else {
			this.params[param[0].toLowerCase()] = strArg.substr(param[0].length + 1);
		}
	}
}

UrlParser.prototype.GetSafeMode = function() {
	return this.safemode;
}

UrlParser.prototype.SetSafeMode = function(k) {
	this.safemode = k;
}

UrlParser.prototype.GetParameter = function(s) {
	return this.params[s.toLowerCase()];
}

UrlParser.prototype.AddParameter = function(s, v) {
	this.params[s.toLowerCase()] = v;
}

UrlParser.prototype.RemoveParameter = function(s) {
	this.params[s.toLowerCase()] = null;
}

UrlParser.prototype.ClearParameterList = function(s) {
	this.params = null;
	this.params = new Array();
}

UrlParser.prototype.BuildParameterList = function(s) {
	var s = "";
	var first = true;
	for (var k in this.params) {
		var v = this.params[k];
		if (v == null) {
			continue;
		}
		if (first == false) {
			s += "&";
		}
		first = false;
		if (v.length == 0) {
			s += k;
		}
		else {
			s += k + "=" + this.params[k];
		}
	}
	if (this.safemode) {
		s = "su=" + Escape.MyEscape(s);
	}
	return s;
}

UrlParser.prototype.GetCorrectUrl = function(url, nosu) {
	if (!this.safemode) { return url; }
	var strArgs;
	var k = url.indexOf("#");
	if (k == -1) { k = url.indexOf("?") }
	if (k >= 0) {
		var paramss = url.substring(k + 1);
		strArgs = paramss.split("&");
		if (strArgs[0].toLowerCase().substr(0, 3) == "su=") {
			return url;
		}
		var ss = url.substring(0, k + 1) + "su=" + Escape.SafeUriEscape(paramss);
		return ss;
	}
	else {
		return url + (nosu ? "" : "?su=");
	}
}

function UnescapeQuotes(s) {
	return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}

/* xmlloader.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

//////////////////////////////////////////////////////////////////////////////
// Simple function for load XML file by HTTPRequest
// Parameters:
//	url				url of xml file
//	workerFunction	name of callback function will be called with request in the following form:
//					workerFunction(req,extraInfo);
//	extraInfo		extra information for user will be give back with callback function

function AbsUrl(url) {
    return url;

    /*
    for (var i = 0; i < url.length; i++) {
    if (url.substr(i, 1) == ':')
    return url;
    }
    var base = window.location.href;

    var k1 = base.indexOf('?');
    var k2 = base.indexOf('#');
    if (k1 >= 0 || k2 >= 0) {
    if (k1 >= 0 && k2 >= 0) {
    base = base.substr(0, (k1 < k2 ? k1 : k2));
    }
    else if (k1 >= 0) {
    base = base.substr(0, k1);
    }
    else {
    base = base.substr(0, k2);
    }
    }

    var k;
    if (url.substr(0, 3) == "../") {
    k = base.lastIndexOf('/');
    base = base.substr(0, k);
    while (url.substr(0, 3) == "../") {
    k = base.lastIndexOf('/');
    base = base.substr(0, k);
    url = url.substr(3);
    }
    base = base + "/" + url;
    }
    else {
    if (url.substr(0, 1) == "/")
    url = url.substr(1);
    k = base.lastIndexOf('/');
    base = base.substr(0, k);
    base = base + "/" + url;
    }
    return (base);
    */
}

function LoadXMLDoc(url, workerFunction, errorFunction, extraInfo, synchronous) {
    var _url = AbsUrl(url);
    if (synchronous == undefined)
        synchronous = false;

    var _req = null;
    try {
        if (window.location.href.substr(0, 7).toLowerCase() == "http://" ||
			window.location.href.substr(0, 8).toLowerCase() == "https://")
            _req = new XMLHttpRequest();
        if (window.location.href.substr(0, 7).toLowerCase() == "file://" && IsTouchDevice()) {
            _req = new XMLHttpRequest();
        }
    }
    catch (e) { }
    finally {
        if (_req == null)
            _req = new ActiveXObject("Microsoft.XMLHTTP");
    }

    _req.onreadystatechange = function () { state_Change(_url, _req, workerFunction, errorFunction, extraInfo); };
    _req.open("GET", _url, !synchronous);
    if (extraInfo == "PING")
        _req.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2005 00:00:00 GMT");
    _req.send(null);
}

function state_Change(_url, _req, _workerFunction, _errorFunction, _extraInfo) {
    if (_req.readyState == 4) {
        if (_req.status == 200 || (_req.status == 0 && _extraInfo != "PING")) {
            if (_req.responseXML == null || _req.responseXML.documentElement == null) {
                var xmlDoc = null;
                try {
                    xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                    xmlDoc.async = false;
                    xmlDoc.loadXML(_req.responseText);
                }
                catch (e) {
                    var p = new window.DOMParser();
                    xmlDoc = p.parseFromString(_req.responseText, "application/xml");
                }
                var rpt = _req.responseText;
                _req = {};
                _req.responseXML = xmlDoc;
                _req.responseText = rpt;
            }
            _workerFunction(_req, _extraInfo);
        }
        else {
            if (_errorFunction) {
                if (_extraInfo != "PING")
                    alert(_url + " not found. Logged...");
                _errorFunction(_extraInfo);
            }
            else
                alert("Problem retrieving data: " + _req.statusText);
        }
    }
}

//////////////////////////////////////////////////////////////////////////////
// Function to load XML files contain simple arrays
// Parameters:
//	url				url of xml file
//	returnFunction	function will be call back with a simple array loaded from xml file
//	nodeName		name of node for load

function LoadXMLDocArray(url, returnFunction, errorFunction, nodeName, xmlmode) {
    LoadXMLDoc(url, xmlmode ? XMLDocArrayWorker2 : XMLDocArrayWorker, errorFunction, { nodeName: nodeName, returnFunction: returnFunction }, false);
}

function XMLDocArrayWorker(req, extraInfo) {
    var _nodesArray = [];
    var _nodes = req.responseXML.getElementsByTagName(extraInfo.nodeName);
    for (var i = 0; i < _nodes.length; i++) {
        var n = _nodes[i];
        var s = (n.textContent ? n.textContent : n.text);
        if (!s)
            s = "";
        var k = s.length;
        if (k >= 2) {
            if ((s.substr(0, 1) == '\"') && (s.substr(k - 1, 1) == '\"')) {
                s = s.substr(1, k - 2);
            }
        }
        _nodesArray[_nodesArray.length] = s;
    }
    extraInfo.returnFunction(_nodesArray);
}

function XMLDocArrayWorker2(req, extraInfo) {
    var _nodesArray = [];
    var _nodes = req.responseXML.getElementsByTagName(extraInfo.nodeName);
    for (var i = 0; i < _nodes.length; i++) {
        var n = _nodes[i];
        var xmlname = n.attributes[0].nodeValue;
        var xmltext = "";
        for (var j = 0; j < n.childNodes.length; j++) {
            if (n.childNodes[j].xml) {
                xmltext += n.childNodes[j].xml;
            } else {
                var oSerializer = new XMLSerializer();
                xmltext += oSerializer.serializeToString(n.childNodes[j]);
            }
        }
        _nodesArray[_nodesArray.length] = xmlname + "=" + xmltext;
    }
    extraInfo.returnFunction(_nodesArray);
}


/* lms_toc.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

// include lms_init.js
/*
document.write('<script type="text/javascript" src="./../config.js"></script>');
document.write('<script type="text/javascript" src="./../js/cookie.js"></script>');
document.write('<script type="text/javascript" src="./../js/lms_init.js"></script>');
*/
// callback functions from toc

var lms_TOCState = null;

function lms_LoadAdapterComplete() {
    __Ialert("lms_LoadAdapterComplete() called");

    var lmscom = document.LmsCom;
    lmscom.Begin();
    var parentlmscom = lmscom.ParentLmsCom;
    if (parentlmscom && parentlmscom.bigScoItemCount) {
        lmscom.OpenTOCStatus(parentlmscom.bigScoItemCount, parentlmscom.bigScoHash);
        lms_TOCState = lmscom.status_obj.getTocState();
        lmscom.bigsco = true;   // save/store asset stats differently
    } else
        lmscom.OpenBasicStatus();

    lms_UpdateUI(lmscom.status_obj.getStatus());
    lms_initialized = true;
    setTimeout(lms_store.callbackfunction, 1);
}

function GetChildLmsCom(child_store) {
    __Ialert("lms_GetChildLmsCom() called");
    var lmscom = document.LmsCom;
    var childlmscom = child_store.window.document.LmsCom = (Kpath_launch && child_store.cguid) ? new LmsComKPath() : new LmsComBase(lmscom);
    childlmscom.owner = child_store.window;
    var childindex = parseInt(child_store.childIndex, 10);
    childlmscom.SetOrdinalNumber(childindex);
    childlmscom.lesson_data = lms_TOCState ? (lms_TOCState.GetStatus(childindex) + lms_TOCState.GetChildren(childindex)) : "";
    lmscom.child = childlmscom;
    lmscom.lesson_location = child_store.childIndex;
}

function ListenChildClose() {
    __alert("lms_ListenChildClose() called");

    if (!_sco)
        return;
    var lmscom = document.LmsCom;
    var childlmscom = lmscom.child;
    if (childlmscom.lesson_status === LMS_NOT_ATTEMPTED)
        return;
    var index = childlmscom.GetOrdinalNumber();
    var state = Lms2Stat(childlmscom.lesson_status);
    var score = childlmscom.score;
    var childrenstatus = childlmscom.lesson_data.substring(1);
    lms_TOCState.SetStatus(index, state);
    lms_TOCState.SetScore(index, score);
    lms_TOCState.SetChildren(index, childrenstatus);
    lms_ItemStatus_Changed(index);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// Status handling in big sco


// get ordinal number of last item in toc visited
/*
function lms_getBookmark() {
__alert("lms_getBookmark called()");
var lmscom = document.LmsCom;
if (lmscom.lesson_location)
return parseInt(lmscom.lesson_location, 10);
else
return lmscom.GetBookmark(this.toc_hash);
}
*/

function lms_GetItemStatus(chindex) {
    return lms_TOCState.GetStatus(chindex);
}

function lms_SetItemStatus(chindex, value) {
    lms_TOCState.SetStatus(chindex, value);
}

function lms_ItemStatus_Changed(index) {
    UpdateItemStatus(index);
}

//----------------------------------------------------------------------------------------------/

var _lms_module_name = "lms_toc.js";
var _lms_show_alert = false;
var _lms_show_Ialert = false;
/* tocfunctions.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

/// <reference path="jquery.d.ts" />
/// <reference path="resource_b.js" />
/// <reference path="../config.js" />
/// <reference path="../data/outline.js" />
/// <reference path="../data/toc/treeindex.js" />
/// <reference path="../data/toc/titles.js" />
/// <reference path="../data/uiconfig.js" />

/// <reference path="common.js" />
/// <reference path="dialog.js" />
/// <reference path="swfobject.js" />
/// <reference path="browser.js" />
/// <reference path="cookie.js" />
/// <reference path="escape.js" />
/// <reference path="xmlloader.js" />
/// <reference path="lms_toc.js" />

/// <reference path="query.js" />
/// <reference path="preferences.js" />
/// <-reference path="tree.js" />
/// <reference path="relativelink.js" />
/// <reference path="lmsapplet.js" />
/// <reference path="lmscomfactory.js" />
/// <reference path="lmscom.js" />
/// <reference path="lms_init.js" />
/// <reference path="playerlaunch.js" />
/// <reference path="sound.js" />
/// <reference path="ctxhelper.js" />
/// <reference path="iashelper.js" />
/// <reference path="tascriptsintoc.js" />

var ctxHelper;


var lastExpressionF = "";
var lastExpressionH = "";
var roleStatusChanged = false;

var viewApplicable = false;
var viewSearch = false;
var selectorMode = "A";
var actuallySelected;
var actuallySelectedFull;
var actuallyChildIndex;

var playerwindow;

// ODS variables
var toc_safeUriMode = false;
var playMode = "P";
var odsTopicID;

var _goToFlatMode = false;
var _lastSearchResultIsEmpty = false;

var urlParser;

//SCORM Runtime Communication
/*
var API_1484_11 = null;
var api = null;
var UserID = 1;
*/

function InitRoles(roleexpression) {
    if (roleexpression == "NOROLES") {
        setTimeout("Init1();", 10);
        return;
    }
    var ev = QueryParser.Parse("URI", roleexpression);
    if (ev) {
        QueryProcessor.Start(ev, Init0);
    }
}

function SetRoles(roleexpression) {
    SearchProcess_Show(true);

    modeDescA.treeCreated = false;
    modeDescF.treeCreated = false;
    modeDescH.treeCreated = false;
    modeDescFH.treeCreated = false;

    roleStatusChanged = true;
    if (roleexpression != "NOROLES") {
        var ev = QueryParser.Parse("URI", roleexpression);
        if (ev) {
            QueryProcessor.Start(ev, result_Roles_Search);
        }
    }
    else {
        SetTopicList("NOROLES", null, result_Search2);
    }
}

function Trim(s) {
    if (s.length == 0)
        return "";
    while (s.substr(0, 1) == " ") {
        s = s.substr(1);
        if (s.length == 0)
            return "";
    }
    while (s.substr(s.length - 1, 1) == " ") {
        s = s.substr(0, s.length - 1);
    }
    return s;
}

function IsFilteredChar(s) {
    var filters = ".,;:!?(){}[]\\\'";
    for (var i = 0; i < filters.length; i++) {
        if (s == filters.substr(i, 1))
            return " ";
    }
    return s;
}

function SearchStringFilter(s) {
    var sret = "";
    var inQuot = false;
    for (var i = 0; i < s.length; i++) {
        var c = s.substr(i, 1);
        if (c == '\"') {
            inQuot = !inQuot;
            sret += c;
        }
        else {
            sret += (inQuot == true ? c : IsFilteredChar(c));
        }
    }
    return sret;
}

function TrimQuotes(s) {
    if (s.length == 0)
        return s;
    var ss = s;
    if (s.substr(0, 1) == '\"')
        ss = ss.substr(1);
    if (s.substr(s.length - 1, 1) == '\"')
        ss = ss.substr(0, ss.length - 1);
    return ss;
}

function Select(k) {
    SearchProcess_Show(true);

    if (k == 0) {
        if (viewApplicable && viewSearch) {
            if (lastExpressionH == "" && lastExpressionF == "")
                k = 3;
        }
        else if (viewApplicable) {
            if (lastExpressionH == "")
                k = 2;
        }
        else if (viewSearch) {
            if (lastExpressionF == "")
                k = 1;
        }
    }

    if (k == 0)		// All view
    {
        if (viewApplicable && viewSearch) {
            selectorMode = "FH";
            setTimeout(ShowFilteredHemi, 0);
        }
        else if (viewApplicable) {
            selectorMode = "H";
            setTimeout(ShowHemi, 0);
        }
        else if (viewSearch) {
            selectorMode = "F";
            setTimeout(ShowFiltered, 0);
        }
        else {
            selectorMode = "A";
            setTimeout(ShowAll, 0);
        }
    }
    else if (k == 1)	// Filtered view
    {
        _lastChangeIsFilterOnly = false;
        var sb = $("#searchbox");
        var stext = sb.val();
        stext = Trim(SearchStringFilter(stext));
        sb.val(TrimQuotes(stext));
        if (stext.length == 0) {
            SearchProcess_Show(false);
            return;
        }
        var ks = stext.indexOf("\'");
        if (ks >= 0) {
            SearchProcess_Show(false);
            return;
        }
        selectorMode = "F";
        if (lastExpressionF != stext) {
            modeDescF.treeCreated = false;
            modeDescFH.treeCreated = false;
            lastExpressionF = stext;
            var ev = QueryParser.Parse("EXPR", stext);
            if (ev) {
                QueryProcessor.Start(ev, result_Search);
            }
        }
        else {
            if (viewApplicable)
                setTimeout(ShowFilteredHemi, 0);
            else
                setTimeout(ShowFiltered, 0);
        }
        return;
    }
    else if (k == 2)	// Hemi view
    {
        if (hemiParam == null && genericMode == true) {
            selectorMode = "H";
            ShowGenToc2();
            return;
        }
        var stext = hemiParam;
        if (stext.length == 0) {
            SearchProcess_Show(false);
            return;
        }
        selectorMode = "H";
        if (lastExpressionH != stext) {
            modeDescH.treeCreated = false;
            modeDescFH.treeCreated = false;
            lastExpressionH = stext;
            var ss = 'e' + stext;
            var ev = QueryParser.Parse("URI", ss);
            if (ev) {
                QueryProcessor.Start(ev, result_Search);
            }
        }
        else {
            if (viewApplicable)
                setTimeout(ShowFilteredHemi, 0);
            else
                setTimeout(ShowHemi, 0);
        }
        return;
    }
    else if (k == 3)	//Filtered Hemi view part 1
    {
        sb = $("#searchbox");
        stext = Trim(sb.val());
        stext = SearchStringFilter(stext);
        modeDescF.treeCreated = false;
        lastExpressionF = stext;
        selectorMode = "FH1";
        var ev = QueryParser.Parse("EXPR", stext);
        if (ev) {
            QueryProcessor.Start(ev, result_Search);
        }
        return;
    }
    else if (k == 4)	// Filtered Hemi view part 2
    {
        if (hemiParam == null && genericMode == true) {
            selectorMode = "FH2";
            ShowGenToc2();
            return;
        }
        var stext = hemiParam;
        modeDescH.treeCreated = false;
        lastExpressionH = stext;
        ss = 'e' + stext;
        selectorMode = "FH2";
        var ev = QueryParser.Parse("URI", ss);
        if (ev) {
            QueryProcessor.Start(ev, result_Search);
        }
        return;
    }
    else if (k == 5)	// generic mode
    {
        selectorMode = "H";
        onTocLoaded = true;
    }
}

function result_Search2() {
    if (selectorMode == "F") {
        if (viewApplicable)
            setTimeout(ShowFilteredHemi, 0);
        else
            setTimeout(ShowFiltered, 0);
    }
    else if (selectorMode == "H") {
        if (viewSearch)
            setTimeout(ShowFilteredHemi, 0);
        else
            setTimeout(ShowHemi, 0);
    }
    else if (selectorMode == "FH1") {
        setTimeout(function () { Select(4) }, 0);
    }
    else if (selectorMode == "FH2" || selectorMode == "FH") {
        setTimeout(ShowFilteredHemi, 0);
    }
    else {
        setTimeout(ShowAll, 0);
    }
}

function result_Roles_Search(topiclist) {
    SetTopicList("ROLES", topiclist, result_Search2);
}

function result_Search(topiclist) {
    _lastSearchResultIsEmpty = (topiclist.length == 0);
    if (genericMode_SearchHemi == true) {
        ShowGenToc2(topiclist);
        return;
    }
    if (selectorMode == "F") {
        SetTopicList("FILTERED", topiclist, result_Search2);
    }
    else if (selectorMode == "H") {
        SetTopicList("HEMI", topiclist, result_Search2);
    }
    else if (selectorMode == "FH1") {
        SetTopicList("FILTERED", topiclist, result_Search2);
    }
    else if (selectorMode == "FH2") {
        SetTopicList("HEMI", topiclist, result_Search2);
    }
}

var _showBookmark = true;

var MyBookmark = new function () {
    function GetBookmarkCookie() {
        var c = new Cookie(document, "Bookmark_" + toc_hash, 30);
        c.Load();
        return c;
    }
    this.StoreBookmark = function (k) {
        var c = GetBookmarkCookie();
        c.Location = k;
        c.Store();
    }
    this.ReadBookmark = function () {
        var c = GetBookmarkCookie();
        if (typeof (c.Location) == "undefined")
            return 0;
        return parseInt(c.Location);
    }
}

function ShowAll() {
    var dA = document.getElementById("treeControlHostForAll");
    var dS = document.getElementById("treeControlHostForFiltered");
    var dSf = document.getElementById("flatControlHostForFiltered");
    var dH = document.getElementById("treeControlHostForHemi");
    var dHf = document.getElementById("flatControlHostForHemi");
    var dFH = document.getElementById("treeControlHostForFilteredHemi");
    var dFHf = document.getElementById("flatControlHostForFilteredHemi");
    dS.style.display = "none";
    dSf.style.display = "none";
    dH.style.display = "none";
    dHf.style.display = "none";
    dFH.style.display = "none";
    dFHf.style.display = "none";
    dA.style.display = "block";
    treeViewMode = "ALL";

    var troot = (_tree_root == "" ? titles[0] : _tree_root);
    if (_associated_content == false && _see_also == false && _showBookmark) {
        var bookmarkIndex = MyBookmark.ReadBookmark();
        var kb = troot.substr(37);
        if (_treeIndex >= 0) {
            bookmarkIndex = _treeIndex;
            kb = "0";
        }
        var chindex = null;
        try {
            chindex = parseInt(kb, 10) + bookmarkIndex;
        }
        catch (e) { };
        createTreeControl(troot, false, null, null, chindex);
    }
    else {
        createTreeControl(troot, false, null, _seealso_selecteditem, null);
    }
    SearchResult_Show(false);
    _showBookmark = false;
}

function ShowFiltered() {
    var dA = document.getElementById("treeControlHostForAll");
    var dS = document.getElementById("treeControlHostForFiltered");
    var dSf = document.getElementById("flatControlHostForFiltered");
    var dH = document.getElementById("treeControlHostForHemi");
    var dHf = document.getElementById("flatControlHostForHemi");
    var dFH = document.getElementById("treeControlHostForFilteredHemi");
    var dFHf = document.getElementById("flatControlHostForFilteredHemi");
    // hide other divs
    dA.style.display = "none";
    dH.style.display = "none";
    dHf.style.display = "none";
    dFH.style.display = "none";
    dFHf.style.display = "none";
    // determine view
    var _fm = GetActualFlatView();
    if (_goToFlatMode == true)
        _fm = true;
    // set filtered view
    dS.style.display = (_fm ? "none" : "block");
    dSf.style.display = (_fm ? "block" : "none");

    _goToFlatMode = false;
    treeViewMode = "FILTERED";
    createTreeControl(titles[0], _fm, null, null, null);
    SearchResult_Show(true);
    _showBookmark = false;
    document.getElementById("resulttext").innerHTML = filterHTML(lastExpressionF);
}

function ShowHemi() {
    var dA = document.getElementById("treeControlHostForAll");
    var dS = document.getElementById("treeControlHostForFiltered");
    var dSf = document.getElementById("flatControlHostForFiltered");
    var dH = document.getElementById("treeControlHostForHemi");
    var dHf = document.getElementById("flatControlHostForHemi");
    var dFH = document.getElementById("treeControlHostForFilteredHemi");
    var dFHf = document.getElementById("flatControlHostForFilteredHemi");
    // hide other divs
    dA.style.display = "none";
    dS.style.display = "none";
    dSf.style.display = "none";
    dFH.style.display = "none";
    dFHf.style.display = "none";
    // determine view
    var _fm = GetActualFlatView();
    if (_goToFlatMode == true)
        _fm = true;
    // set hemi view
    dH.style.display = (_fm ? "none" : "block");
    dHf.style.display = (_fm ? "block" : "none");
    _goToFlatMode = false;
    treeViewMode = "HEMI";
    createTreeControl(titles[0], _fm, null, null, null);
    SearchResult_Show(false);
    _showBookmark = false;
}

function ShowFilteredHemi() {
    var dA = document.getElementById("treeControlHostForAll");
    var dS = document.getElementById("treeControlHostForFiltered");
    var dSf = document.getElementById("flatControlHostForFiltered");
    var dH = document.getElementById("treeControlHostForHemi");
    var dHf = document.getElementById("flatControlHostForHemi");
    var dFH = document.getElementById("treeControlHostForFilteredHemi");
    var dFHf = document.getElementById("flatControlHostForFilteredHemi");

    // hide other divs
    dA.style.display = "none";
    dS.style.display = "none";
    dSf.style.display = "none";
    dH.style.display = "none";
    dHf.style.display = "none";
    // determine view
    var _fm = GetActualFlatView();
    if (_goToFlatMode == true)
        _fm = true;
    // set filtered hemi view
    dFH.style.display = (_fm ? "none" : "block");
    dFHf.style.display = (_fm ? "block" : "none");
    _goToFlatMode = false;
    treeViewMode = "FILTEREDHEMI";
    createTreeControl(titles[0], _fm, null, null, null);
    SearchResult_Show(true);
    _showBookmark = false;
    document.getElementById("resulttext").innerHTML = filterHTML(lastExpressionF);
}

function EmptyContent(hemi) {
    if (!hemi)
        hemi = false;
    if (hemi == true) {
        return '<div style="text-align: center; color: red; font-size: 16px;">' + R_no_results +
							'<br/><br/><a class="tocMyRoles" href="javascript:viewAll()">' + R_no_results_linkToAll + "</a></div>";
    }
    else {
        return '<div style="text-align: center; color: red; font-size: 16px;">' + R_toc_emptycontent + "</div>";
    }
}

function FastDoIt() {
    if (bypassToc == false)
        return;
    var p = topicDescriptorCache[actuallySelected];
    if (p == undefined) {
        setTimeout(function () { FastDoIt() }, 100);
        return;
    }
    if (p.playmodes.indexOf("D") >= 0) {
        HideToc();
        PlayFastDoIt();
    }
    bypassToc = false;
}

function TreeFinished(mode, isEmpty) {

    SetSelectionViewText(false);

    var FDI_called = false;
    if (bypassToc == true) {
        if (treeViewMode == "HEMI") {
            if (GetActualFlatView() == true) {
                if (GetActualFlatItemCounter() == 1) {
                    FDI_called = true;
                    setTimeout(FastDoIt, 0);
                }
            }
        }
    }
    if (FDI_called == false)
        bypassToc = false;

    if (!isEmpty) {
        EnableSelectionViewText(true);
        return;
    }
    var d;
    var dA = document.getElementById("treeControlHostForAll");
    var dS = document.getElementById("treeControlHostForFiltered");
    var dSf = document.getElementById("flatControlHostForFiltered");
    var dH = document.getElementById("treeControlHostForHemi");
    var dHf = document.getElementById("flatControlHostForHemi");
    var dFH = document.getElementById("treeControlHostForFilteredHemi");
    var dFHf = document.getElementById("flatControlHostForFilteredHemi");
    if (mode == "ALL") {
        dA.innerHTML = EmptyContent(false);
    }
    else if (mode == "FILTERED") {
        dS.innerHTML = EmptyContent(false);
        dSf.innerHTML = EmptyContent(false);
    }
    else if (mode == "HEMI") {
        dH.innerHTML = EmptyContent(true);
        dHf.innerHTML = EmptyContent(true);
    }
    else if (mode == "FILTEREDHEMI") {
        dFH.innerHTML = EmptyContent(true);
        dFHf.innerHTML = EmptyContent(true);
    }
    EnableSelectionViewText(false);

    Refresh(null);
}

var _tocHidden = false;

function HideToc() {
    return;
    /*
    _tocHidden = true;
    window.moveBy(-2000, 0);
    */
}

function ResumeToc() {
    return;
    /*
    if (_tocHidden == true) {
    window.moveBy(2000, 0);
    }
    _tocHidden = false;
    */
}

function DoItFinished(closeToc) {
    if (_closing)
        return;
    window.focus();
    ResumeToc();
    if (closeToc == true) {
        top.opener = null;      // top -> the toc can be included to gateway...
        top.open('', '_self');
        top.close();
    }
}

var topicDescriptorCache = new Array();

function topicDescriptorObj(title, type, tpc, playmodes, jumpInArray, leadin, concept, printitname, userdefined, remediation, qreference, bigsco) {
    this.title = title;
    this.type = type;
    this.tpc = tpc;
    this.playmodes = playmodes;
    this.jumpInArray = jumpInArray;
    this.leadin = leadin;
    this.concept = concept;
    this.printitname = encodeURIComponent(printitname);
    this.userdefined = userdefined;
    this.remediation = remediation;
    this.seealsoroot = "";
    this.seealsolinks = new Array();
    this.qreference = qreference;
    this.bigsco = bigsco;
}

function _getFilteredStatus(guid) {
    return getFilteredStatus(guid);
}

function seeAlsoLink(type, title, guid) {
    this.type = type;
    this.title = title;
    this.guid = guid;
    this.filtered = false;
}

function JumpInPoint(label, frameid) {
    this.label = label;
    this.frame_id = frameid;
}

function CheckSeeAlso(tdesc) {
    if (_see_also == true)
        return false;
    return true;
}

var _playConceptSound = true;

function PlayConceptSound() {
    return _playConceptSound;
}

function SCO_Supported() {
    return _sco;
}

var _launchMode = "";
var _lastSelectedItem = "";
var _lastMode = "Init";
var _lastTpc = "Init";

function TreeItemSelected(tpc, mode) {
    _launchMode = "";
    if (tpc) {
        var kb = getBaseIndex();
        var ki = tpc.substr(37);
        var chIndex = ki - kb;
        if (selectorMode == "A")
            MyBookmark.StoreBookmark(chIndex);
        if (_lastMode != mode || _lastTpc != tpc)
            actuallyChildIndex = -2222;
        _lastMode = mode;
        _lastTpc = tpc;
        if (chIndex == actuallyChildIndex) {
            SearchProcess_Show(false);
            try {
                if (viewApplicable == true) {
                    this.frames["myconceptframeToc"].SetCtxexParam(lastExpressionH);
                }
                else {
                    this.frames["myconceptframeToc"].SetCtxexParam(null);
                }
            }
            catch (e) { };
            if (roleStatusChanged == true) {
                try {
                    this.frames["myconceptframeToc"].RoleStatusChanged();
                }
                catch (e) { }
                roleStatusChanged = false;
            }
            if (tpc == null && mode == null)
                SetSelectionViewText(true);
            else
                SetSelectionViewText(false);
            EnableSelectionViewText(!_lastSearchResultIsEmpty);
            return;
        }
        actuallyChildIndex = ki - kb;
        //        alert(actuallyChildIndex);

        //        setTimeout("lms_ItemStatus_Changed('" + tpc + "')", 1000);

    }
    _lastMode = mode;
    _lastTpc = tpc;

    if (tpc == null && mode == null)
        SetSelectionViewText(true);
    else
        SetSelectionViewText(false);

    EnableSelectionViewText(!_lastSearchResultIsEmpty);
    if (mode == "HIDE") {
        SearchProcess_Show(false);
        return;
    }
    FocusToSearchField();
    if (tpc == null) {
        //    	SetSelectionViewText(true,true);
        Refresh(null);
        return;
    }
    var guid = tpc.substr(0, 36);
    actuallySelected = guid;
    actuallySelectedFull = tpc.split('#')[0];
    _playConceptSound = true;
    if (topicDescriptorCache[guid]) {
        Refresh(guid);
    }
    else {
        var s = "tpc/" + guid + "/descriptor.xml";
        LoadXMLDoc(s, TreeItemSelected_Returned_Descriptor, null, guid, false);
    }
}

function _StartTopic(lMode) {
    try {
        var s = this.frames["myconceptframeToc"].location.href;
        if (s.indexOf("lmstart.html") < 0) {
            setTimeout("_StartTopic('" + lMode + "')", 100);
            return;
        }
        s = this.frames["myconceptframeToc"].frames["myframe"].location.href;
        if (s.indexOf("lmsui.html") < 0) {
            setTimeout("_StartTopic('" + lMode + "')", 100);
            return;
        }
        if (!this.frames["myconceptframeToc"].frames["myframe"].launchTopic) {
            setTimeout("_StartTopic('" + lMode + "')", 100);
            return;
        }
        if (actuallySelected != this.frames["myconceptframeToc"].topicID) {
            setTimeout("_StartTopic('" + lMode + "')", 100);
            return;
        }
    }
    catch (e) {
        setTimeout("_StartTopic('" + lMode + "')", 100);
        return;
    }
    setTimeout("this.frames['myconceptframeToc'].StartTopic('" + lMode + "')", 100);
}

function TreeItemDoubleSelected() {
    var tdc = topicDescriptorCache[actuallySelected];

    try {
        if (tdc.type == "Topic") {
            UserPrefs.LoadCookie();
            var mode = UserPrefs.DefaultPlayMode;
            _playConceptSound = false;
            if (tdc.playmodes.indexOf(mode) >= 0) {
                //            PlayTopic(mode);
                _launchMode = mode;
                if (_lastSelectedItem == actuallySelected) {
                    _StartTopic(_launchMode);
                }
            }
            else {
                var modestr = R_mode_seeit;
                switch (mode) {
                    case "T":
                        modestr = R_mode_tryit;
                        break;
                    case "K":
                        modestr = R_mode_knowit;
                        break;
                    case "D":
                        modestr = R_mode_doit;
                        break;
                    case "P":
                        modestr = R_mode_printit;
                        break;
                    default:
                        modestr = R_mode_seeit;
                        break;
                }
                alert(R_not_playable1 + modestr + R_not_playable2);
            }
        }
    }
    catch (e) {
        setTimeout(TreeItemDoubleSelected, 0);
        return;
    }

}

function fixHTMLString(strHTMLString) {
    strHTMLString = replaceString("<", "&lt;", strHTMLString);
    strHTMLString = replaceString(">", "&gt;", strHTMLString);
    strHTMLString = replaceString("'", "&#39;", strHTMLString);
    strHTMLString = replaceString('"', "&#34;", strHTMLString);

    return strHTMLString;
}

function getDescriptorItem(req, itemname) {
    var item = "";
    try {
        var nodes = req.responseXML.getElementsByTagName(itemname);
        if (nodes.length > 0) {
            var n = nodes[0];
            if (n.textContent != null)
                item = n.textContent;
            else if (n.text != null)
                item = n.text;
            else if (n.firstChild.data != null)
                item = n.firstChild.data;
        }
    }
    catch (e) { };
    return item;
}

var firstrun = true;

function TreeItemSelected_Returned_Descriptor(req, id) {

    if (firstrun) {
        firstrun = false;
        window.scrollTo(0, 0);
    }

    var playmodes = getDescriptorItem(req, "PlayModes");

    var jumpInArray = new Array();
    var nodes = req.responseXML.getElementsByTagName("JumpIn");
    for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (n.textContent)
            var label = n.textContent;
        else if (n.text)
            label = n.text;
        else if (n.firstChild.data)
            label = n.firstChild.data;
        a = n.attributes[0];
        var frameid = a.nodeValue;
        jumpInArray[jumpInArray.length] = new JumpInPoint(fixHTMLString(label), frameid);
    }
    var _leadIn = "./../html/empty.html";
    nodes = req.responseXML.getElementsByTagName("Leadin");
    if (nodes.length > 0) {
        _leadIn = "./tpc/" + id + "/leadin.html";
    }
    var _concept = "";
    nodes = req.responseXML.getElementsByTagName("Concept");
    if (nodes.length > 0) {
        n = nodes[0];
        if (n.textContent)
            _concept = n.textContent;
        else if (n.text)
            _concept = n.text;
        else if (n.firstChild.data)
            _concept = n.firstChild.data;

        if (_concept.indexOf('odrel://') == 0)
            _concept = resolve(_concept);
    }
    var _title = getDescriptorItem(req, "Title");
    var _type = getDescriptorItem(req, "Type");
    var _printitname = getDescriptorItem(req, "PrintItName");
    var _userdefined = getDescriptorItem(req, "UserDefined");

    var _remediation = getDescriptorItem(req, "Remediation");
    if (_remediation == "")
        _remediation = "Always";
    var _qreference = getDescriptorItem(req, "Reference");
    var _bigsco = getDescriptorItem(req, "BigSco");

    topicDescriptorCache[id] = new topicDescriptorObj(_title, _type, id, playmodes, jumpInArray, _leadIn, _concept, _printitname, _userdefined, _remediation, _qreference, _bigsco);

    nodes = req.responseXML.getElementsByTagName("SeeAlsoRoot");
    if (nodes.length > 0) {
        n = nodes[0];
        var saroot = "";
        if (n.textContent)
            saroot = n.textContent;
        else if (n.text)
            saroot = n.text;
        else if (n.firstChild.data)
            saroot = n.firstChild.data;
        topicDescriptorCache[id].seealsoroot = saroot;
    }

    nodes = req.responseXML.getElementsByTagName("SeeAlso");
    for (var i = 0; i < nodes.length; i++) {
        n = nodes[i];
        var type = "";
        var title = "";
        var guid = "";
        for (var j = 0; j < n.attributes.length; j++) {
            var a = n.attributes[j];
            if (a.nodeName == "Type")
                type = getTextContent(a);
            if (a.nodeName == "Title")
                title = getTextContent(a);
            if (a.nodeName == "Guid")
                guid = getTextContent(a);
        }
        if (type.length > 0 && title.length > 0) {
            topicDescriptorCache[id].seealsolinks[topicDescriptorCache[id].seealsolinks.length] = new seeAlsoLink(type, title, guid);
        }
    }

    Refresh(id);
}

function getTextContent(n) {
    try {
        if (n.textContent)
            return n.textContent;
        else if (n.text)
            return n.text;
        else if (n.firstChild.data)
            return n.firstChild.data;
        return "";
    }
    catch (e) {
        return "";
    }
}

var lastConcept = "";

var rcTimeout = null;

var nextConcept = "";

function EmptyHtmlLoaded() {
    this.frames["myconceptframeToc"].location.replace(urlParser.GetCorrectUrl(nextConcept));
}

function SetConceptLocation(s) {
    nextConcept = AbsUrl(s);
    EmptyHtmlLoaded();
    //    this.frames["myconceptframe"].location.replace(AbsUrl("./toc/empty.html?callback"));
}

function _RefreshConcept(noplaysound) {
    if (!noplaysound)
        noplaysound = false;
    if (lastConcept != "") {
        if (lastConcept.indexOf(".htm") > 0) {
            if (noplaysound == true)
                _playConceptSound = false;
            SetConceptLocation(lastConcept);
        }
    }
}

function RefreshConcept() {
    try {
        clearTimeout(rcTimeout);
    }
    catch (e) {
    }
    //    rcTimeout = setTimeout("_RefreshConcept();", 300);
}

function OnUpdatePreferences() {
    _RefreshConcept(true);
}

var psInit = null;

function PlaySound_Init() {
    try {
        this.frames["myconceptframeToc"].PlaySound_Init();
    }
    catch (e) { };
}

function ShowConcept(s) {
    if (s == lastConcept) {
        try {
            if (_playConceptSound == true)
                psInit = setTimeout(PlaySound_Init, 0);
            else
                clearTimeout(psInit);
        }
        catch (e) { };
        return;
    }
    lastConcept = s;
    SetConceptLocation(s);
}

/*
// I don't know what the assessment player is going to need yet, so these are just copied from the
// PlayerPackage sample referenced by "Assessments in the Player" [Alan Groupe]
function api_endcourse()
{
if (api != null)
{
api.SetValue("cmi.exit", "suspended"); // if completed, then exit=normal, else exit=suspended
api.SetValue("cmi.session_time", "PT1H5M") ;
api.SetValue("cmi.suspend_data", "suspend_data") ;
api.SetValue("cmi.completion_status", "incomplete") 
//if (assess || question || topic that has knowit) && TrackScore==true)
//{
//    api.SetValue("cmi.score.scaled") 
//    api.SetValue("cmi.score.raw") 
//    api.SetValue("cmi.score.min") 
//    api.SetValue("cmi.score.max") 
//}
api.Terminate("");
}
}

function api_Getparam()
{
if (api != null)
{
api.Initialize("");
var completionStatus = api.GetValue("cmi.completion_status")  
var suspendData = api.GetValue("cmi.suspend_data")	
var studendID = api.GetValue("cmi.student_id")
var studentName = api.GetValue("cmi.student_name")
}
}
*/


function Refresh(id) {
    //End Leaerner Session
    /*    
    if (apiframe.APIControl != undefined && apiframe.APIControl != null)
    {
    apiframe.APIControl.EndLearnerSession();
    }
    api=null;
    API_1484_11 = null;
    */
    //Continue to Launch new item
    if (id != null)
        TreeRefreshed(id.substr(0, 36));
    SearchProcess_Show(false);
    if (id == null || id == "null") {
        setTimeout('ShowConcept("./../html/empty.html")', 1);
        conceptVisible = false;
        Resize();
        return;
    }
    var desc = topicDescriptorCache[id];
    var concept = desc.concept;

    if (desc.type == "Outline" || desc.type == "Section" || desc.type == "Topic") {
        var mparam = "";
        if (_launchMode.length > 0) {
            mparam = "&mode=" + _launchMode;
        }
        if (desc.type == "Topic" && viewApplicable == true) {
            if (lastExpressionH.length > 0 || genericMode == true) {
                var i = actuallySelectedFull.split("#")[0];
                var ctx = getModeDesc(false).filteredGuids[i].context;
                var guid = getModeDesc(false).filteredGuids[i].guid.substr(0, 36);
                mparam += "&guid=" + guid + "&contextlist=" + ctx;
            }
        }
        var kparam = urlParser.GetParameter("guid");
        if (kparam != null)
            mparam += "&guid=" + kparam;
        kparam = urlParser.GetParameter("contextlist");
        if (kparam != null)
            mparam += "&contextlist=" + kparam;
        concept = "./tpc/" + id + "/lmstart.html?toc" + (_launchFromKPath ? "&launchFromKPath" : "") + "&lmsChildIndex=" + actuallyChildIndex + mparam;
    }

    if (desc.type == "Question") {
        concept = "./tpc/" + id + "/lmstart.html?toc" + (_launchFromKPath ? "&launchFromKPath" : "") + "&lmsChildIndex=" + actuallyChildIndex;
    }
    if (desc.type == "Assessment") {
        var ownerid = "";
        ownerid = getOwnerOfSelection().substr(0, 36);
        concept = "./tpc/" + id + "/lmstart.html?toc" + (_launchFromKPath ? "&launchFromKPath" : "") + "&owner=" + ownerid + "&lmsChildIndex=" + actuallyChildIndex;
    }
    _lastSelectedItem = actuallySelected;
    if (concept.length == 0)
        concept = desc.leadin;

    setTimeout('ShowConcept("' + concept + '")', 50);
    //	this.frames["myconceptframe"].location.href=AbsUrl(concept);
    conceptVisible = true;
    //	document.getElementById("concepttitle").innerHTML=desc.title;

    RolesRemoved();

    Resize();

    //    LoadRuntime(id);
}

function LoadRuntime(id) {
    var desc = topicDescriptorCache[id];
    var concept = desc.concept;

    /*	
    //SCORM get runtime
    if (desc.playmodes.length != 0 || concept.length != 0)
    {
    try
    {
    apiframe.LoadRuntime(UserID, id, 0, 0, 0);
    api = apiframe.API;            
    }
    catch(e)
    {
    api = null;
    }
    }
	
    if (desc.playmodes.length != 0) //Topic
    {
    api_Getparam();
    API_1484_11 = null;
    }
    else //Concept
    {    
    API_1484_11 = api; //Concept SCO tries to find API_1484_11 in parent window when it is launched.
    }
    */
    if (concept.length == 0)
        concept = desc.leadin;

    setTimeout('ShowConcept("' + concept + '")', 50);
    conceptVisible = true;
    RolesRemoved();

    Resize();
}

function GetBasePath() {
    var base = this.location.href;
    var k = base.indexOf('?');
    if (k < 0)
        k = base.indexOf('#');
    if (k >= 0)
        base = base.substr(0, k);
    k = base.lastIndexOf('/');
    var b = base.substr(0, k);
    return b;
}

function ClosePlayer() {
    try {
        if (playerwindow) {
            if (!playerwindow.closed) {
                playerwindow.close();
            }
        }
    }
    catch (e) { };
}

function PlayFastDoIt() {
    _playConceptSound = false;
    try {
        this.frames["myconceptframeToc"].Sound_Stop();
    }
    catch (e) { };

    var params = "mode=D";
    if (viewApplicable == true) {
        if (lastExpressionH.length > 0) {
            var i = actuallySelectedFull.split("#")[0];
            var ctx = getModeDesc(false).filteredGuids[i].context;
            var guid = getModeDesc(false).filteredGuids[i].guid.substr(0, 36);
            params += "&contextlist=" + ctx;
            params += "&guid=" + guid;
        }
    }
    var desc = topicDescriptorCache[actuallySelected];
    var k = desc.playmodes.indexOf("P");
    if (k >= 0 && desc.printitname.length > 0) {
        params += "&printitname=" + desc.printitname;
    }
    if (bypassToc == true) {
        params += "&fastdoit=true";
    }
    if (toc_safeUriMode == true) {
        params = "su=" + Escape.SafeUriEscape(params);
    }
    var b = GetBasePath();
    LaunchDoIt(b + "/tpc/" + actuallySelected + "/", params);
}

function OnQuestionContinue() {
    //    alert("next");
    GoToNext();

}

/**** moved here from toc0 *****************************************************************************/


var showParameters = false;
var searchParam = null;
var hemiParam = null;
var appParam = null;
var ctxParam = null;
var udvParam = null;
var shParam = null;
var XDTParam = null;
var genericMode = false;
var genericMode_SearchHemi = false;
var searchVisible = false;
var conceptVisible = false;
var allRoles = new Array();
var _rolesRemoved = false;
var ctxTopicList = new Array();
var ctxTopicList2 = new Array();
var onTocLoaded = false;
var showButtons = new Array();
var _tree_root = "";
var _sco = false;
var _associated_content = false;
var _see_also = false;
var _seealso_selecteditem = 0;
var isTocHtml = true;
var _selectedItemId = 0;
var _deviceDPI = 0;
var _launchFromKPath = false;
var _treeIndex = -1;
var _launchedFromSharedLink = false;

function IsReducedMode() {
    return (_tree_root.length > 0);
}

function NoWrap(s) {
    var ss = "";
    for (var i = 0; i < s.length; i++) {
        if (s.substr(i, 1) == " ") {
            ss += "&nbsp;";
        }
        else {
            ss += s.substr(i, 1);
        }
    }
    return ss;
}

function _getObjectById(owner, id) {
    for (var i = 0; i < owner.childNodes.length; i++) {
        var cni = owner.childNodes[i];
        if (cni.id == id) {
            return cni;
        }
        else {
            var obj = _getObjectById(cni, id);
            if (obj != null)
                return obj;
        }
    }
    return null;
}

function getObjectById(id) {
    return document.getElementById(id);
    //				return _getObjectById(document.body,id);
}

////////////////////////////////////////////////////////////////////////////

var _header1DivObj = null;
var _treeContainerObj = null;
var _searchResultObj = null;
var _pmTableObj = null;
var _ctTableObj = null;
var _searchBoxObj = null;
var _changeViewObj = null;
var _resulttextObj = null;
var _vbordersize = 5;
var _hbordersize = 5;
var _sbordersize = 5;

function getOffsetLeft(myobj) {
    var parentOffsets = 0;
    if (myobj.parentNode)
        parentOffsets = getOffsetLeft(myobj.parentNode);
    var offset = (myobj.offsetLeft ? myobj.offsetLeft : 0);
    return offset + parentOffsets;
}

function getOffsetTop(myobj) {
    var parentOffsets = 0;
    if (myobj.parentNode)
        parentOffsets = getOffsetTop(myobj.parentNode);
    var offset = (myobj.offsetTop ? myobj.offsetTop : 0);
    return offset + parentOffsets;
}

var _cover_dragged = false;
var treeWidth = 250;

function RefreshPdf() {
    if (upk.browserInfo.isiOS()) {
        var l = $("#contentdiv").position().left;
        setTimeout(function () {
            $("#contentdiv").css({ left: (l + 1) + "px" });
            setTimeout(function () {
                $("#contentdiv").css({ left: l + "px" });
            }, 100);
        }, 100);
    }
}

function SetFocusToTree() {
    $("#searchtopcontainer").focus();
}

function lmsUILoaded() {
    if (upk.browserInfo.isiOS()) {
        setTimeout(function () {
            RefreshPdf();
        }, 100);
    }
    for (var i = 1; i <= 4; i++) {
        setTimeout(function () {
            SetFocusToTree();
        }, 300 * i);
    }
}

function initSeparator() {
    var sepPrevX = 0, sepX = 0;
    var sepMoved = false, sepClick, sepClickTimer;
    var treeVisible = true, toggleInMove = false;
    var preventMove = true;

    $("#sepdiv").on('mousedown', sepD);
    $("#cover").on('mousemove', sepM);
    $("#cover").on('mouseup', sepU);
    if (IsTouchDevice()) {
        $("#sepbutton").on("touchstart", function (e) {
            sepD(e);
            e.preventDefault();
        })
        $(document).on("touchstart", function (e) {
            treeD(e);
        })
    } else {
        $("#sepbutton").on('click', function () { toggleTree(); });
    }

    function treeD(event) {
        if (toggleInMove) { event.preventDefault(); return false; }
        var e = event;
        if (IsTouchDevice()) { e = touch(e); }
        sepPrevX = sepX = e.pageX;
        preventMove = false;
        //if (e.pageX > 10) { return true; }
        //else {
        $(document).on("touchmove", function (e) {
            sepM(e);
        }).on("touchend", function (e) {
            sepU();
        });
        //event.preventDefault();
        return true;
        //}
    }

    function sepD(event) {
        var e = event;
        if (IsTouchDevice()) { e = touch(e); }
        _cover_dragged = true;
        sepMoved = false;
        sepClick = true;
        if (!treeVisible) {
            var w = e.clientX - $("#sepdiv").width() / 2;
            if (IsTouchDevice()) {
                w += window.pageXOffset + 4;
            }
            sepClickTimer = setTimeout(function () {
                sepClick = false;
                treeVisible = true;
                $("#sepbutton>.left").show();
                $("#sepbutton>.right").hide();
                $("#contentdiv").css({ left: w + "px" });
                $("#treeside").css({ width: w + "px", "-webkit-transform": "translate3d(0,0,0)" }).show();
            }, 250)
        }
        if (IsTouchDevice()) {
            $(document).on("touchmove", function (e) {
                sepM(e);
            }).on("touchend", function (e) {
                sepU();
            });
            sepPrevX = sepX = e.pageX;
        }
        $("#cover").show();
        var coverobj = document.getElementById("cover");
        if (coverobj.setCapture)
            coverobj.setCapture();
    }

    function sepM(event) {
        if (toggleInMove) { event.preventDefault(); return false; }
        var e = event;
        if (e == null) { e = window.event; }
        if (IsTouchDevice()) { e = touch(e); }
        if (!_cover_dragged) {
            if (sepX != e.pageX) sepPrevX = sepX;
            sepX = e.pageX;
            //var speed = sepPrevX - sepX;
            //if (preventMove || (speed > 10 && treeVisible) || (speed < -10 && !treeVisible)) {
            //	preventMove = true;
            //	event.preventDefault();
            //	return false;
            //}
            //else {
            //	//if (sepX != e.pageX) {
            //		$(document).off("touchmove").off("touchend");
            //	//}
            return true;
            //}
        }
        clearTimeout(sepClickTimer);
        sepMoved = true;
        var w = e.clientX - $("#sepdiv").width() / 2;
        if (IsTouchDevice()) {
            w += window.pageXOffset + 4;
            if (sepX != e.pageX) sepPrevX = sepX;
            sepX = e.pageX;
            event.preventDefault();
        }
        if (w < $("#container").width() - 200) {
            $("#contentdiv").css("left", (w) + "px");
            $("#treeside").css("width", (w) + "px");
        }
        if (!treeVisible) {
            $("#sepbutton>.left").show();
            $("#sepbutton>.right").hide();
            $("#treeside").css({ "-webkit-transform": "translate3d(0,0,0)" }).show();
            treeVisible = true;
        }
        if (_treeContainerObj == null)
            _treeContainerObj = getObjectById("treecontainer");
        w = _treeContainerObj.clientWidth - 40;
        setTimeout(_HResize, 1);
    }

    function sepU() {
        $(document).off("touchmove").off("touchend");
        if (!_cover_dragged) {
            var speed = sepPrevX - sepX;
            if ((speed > 30 && treeVisible) || (speed < -30 && !treeVisible)) {
                toggleTree();
            }
            return true;
        }
        clearTimeout(sepClickTimer);
        _cover_dragged = false;
        $("#cover").hide();
        var coverobj = document.getElementById("cover");
        if (coverobj.releaseCapture) { coverobj.releaseCapture(); }
        if (document.frames) { document.frames[0].focus(); }
        var swipeTree = false;
        if (IsTouchDevice()) {
            if (!sepMoved && sepClick) { toggleTree(); return true; }
            var speed = sepPrevX - sepX;
            if ((speed > 30 && treeVisible) || (speed < -30 && !treeVisible)) {
                swipeTree = true;
            }
        }
        if (($("#treeside").width() < 125 && treeVisible) || swipeTree) {
            toggleTree();
        } else if (sepMoved) {
            treeWidth = $("#treeside").width();
            if (treeWidth < 125) { treeWidth = 125; }
            var c = new Cookie(document, "OnDemandToc", 365, null, null, false);
            c.Load();
            c.Separator = treeWidth;
            c.Store();
        }
    }

    function toggleTree() {
        if (toggleInMove) { return; }
        toggleInMove = true;
        var l = $("#contentdiv").position().left;
        $("#treeDiv").scrollLeft(0);
        if (treeVisible) {
            w = $("#treeside").width();
            $("#sepbutton>.left").hide();
            $("#sepbutton>.right").show();
            if (IsTouchDevice()) {
                $("#treeside, #sepbutton, #contentdiv").addClass("swipeanim");
                $("#treeside").css({ "-webkit-transform": "translate3d(" + (-(w)) + "px,0,0)" });
                $("#contentdiv").on("webkitTransitionEnd", function () {
                    $("#contentdiv").off("webkitTransitionEnd");
                    $("#treeside, #sepbutton, #contentdiv").removeClass("swipeanim");
                    $("#treeside").css({ "width": (treeWidth) + "px", "-webkit-transform": "translate3d(" + (-(treeWidth)) + "px,0,0)" });
                    $("#treeinner").css({ "border-left-width": "8px" });
                    $("#contentdiv").css({ left: "7px", "-webkit-transform": "translate3d(0,0,0)" });
                    toggleInMove = false;
                })
                $("#contentdiv").css({ "-webkit-transform": "translate3d(" + (-(w - 7)) + "px,0,0)" });
            } else {
                $("#treeside").animate({ width: "0" }, 300);
                $("#contentdiv").animate({
                    left: "0"
                }, 300, function () {
                    toggleInMove = false;
                })
            }
            treeVisible = false;
        } else {
            $("#sepbutton>.left").show();
            $("#sepbutton>.right").hide();
            if (IsTouchDevice()) {
                $("#treeside, #sepbutton, #contentdiv").addClass("swipeanim");
                $("#treeside").css({ "-webkit-transform": "translate3d(0,0,0)" });
                $("#contentdiv").on("webkitTransitionEnd", function () {
                    $("#contentdiv").off("webkitTransitionEnd");
                    $("#treeside, #sepbutton, #contentdiv").removeClass("swipeanim");
                    $("#treeside").css({ "width": (treeWidth) + "px" });
                    //$("#treeinner").css({ "border-left-width": "" });
                    $("#contentdiv").css({ left: treeWidth + "px", "-webkit-transform": "translate3d(0,0,0)" });
                    toggleInMove = false;
                })
                $("#contentdiv").css({ "-webkit-transform": "translate3d(" + treeWidth + "px,0,0)" });
            } else {
                $("#treeside").animate({ width: treeWidth + "px" }, 300);
                $("#contentdiv").animate({
                    left: treeWidth + "px"
                }, 300, function () {
                    toggleInMove = false;
                })
            }
            treeVisible = true;
        }
    }
}

////////////////////////////////////////////////////////////////////////////

function OpenSeeAlso(seeAlsoRoot, index) {
    this.frames["myconceptframeToc"].OpenSeeAlso(seeAlsoRoot, index);
    //			var base = GetBasePath();
    //			window.open(base + "/toc.html?seealso=" + seeAlsoRoot + "&selectitem=" + index);
}

function launchTopic(mode, frame_id, fromjumpin) {
    // launch topic (in lms.js)
    this.frames["myconceptframeToc"].StartTopic(mode, frame_id, fromjumpin);
}

function ShowAbout() {
    // in pt (400x500px)
    if (this.frames["myconceptframeToc"].OnPrepareDialog)
        this.frames["myconceptframeToc"].OnPrepareDialog();
    var ctx = "about";
    setDlgCtx(ctx);
    showDialog(GetBasePath() + "/../html/about.html", -1, -1, 300, 375, true, _deviceDPI, null, false);
}

function TreeRefreshed(id) {
    _selectedItemId = id;
}

function ConnectionLostEvent(errText) {
    this.frames["myconceptframeToc"].ConnectionLostEvent(errText);
}

////////////////////////////////////////////////////////////////////////////

function SearchResult_Show(k) {
    if (_searchResultObj == null)
        _searchResultObj = getObjectById("searchresult");
    _searchResultObj.style.display = (k ? "" : "none");
    viewSearch = k;
    searchVisible = k;
    Resize();
}

function SearchProcess_Show(k) {
    if (k) {
        document.getElementById("coversearch").style.width = "100%";
        document.getElementById("coversearch").style.height = "100%";
        var sprd = document.getElementById("searchprdiv");
        sprd.style.display = "block";
        var w = Math.round((document.body.clientWidth / 2) - 60);
        var h = Math.round((document.body.clientHeight / 2) - 20);
        sprd.style.left = "" + w + "px";
        sprd.style.top = "" + h + "px";
    }
    else {
        document.getElementById("coversearch").style.width = "0px";
        document.getElementById("coversearch").style.height = "0px";
        document.getElementById("searchprdiv").style.display = "none";
    }
}

function Resize() {
    setTimeout(_Resize, 0);
}

function Resize0() {
    setTimeout(_Resize, 0);
}

function _HResize() {
    if (checkIEDPI() == false)
        return;
}

function _Resize() {
    if (checkIEDPI() == false)
        return;
    if (document.body.clientHeight < 100 || document.body.clientWidth < 100) {
        _HResize();
        return false;
    }
    if (hemiParam != null || XDTParam != null || (allRoles.length > 0 && PlayerConfig.EnableCookies == true)) {
        getObjectById("appandroles").className = 'tocSearchColor';
    }
    if (_header1DivObj == null)
        _header1DivObj = getObjectById("header1");
    if (_treeContainerObj == null)
        _treeContainerObj = getObjectById("treecontainer");
    if (_searchResultObj == null)
        _searchResultObj = getObjectById("searchresult");
    if (_changeViewObj == null)
        _changeViewObj = getObjectById("changeview");
    if (_pmTableObj == null)
        _pmTableObj = getObjectById("playmodetable");
    if (_ctTableObj == null)
        _ctTableObj = getObjectById("concepttitletable");

    _HResize();

    var h = $("#treeinner").height();

    if (upk.browserInfo.isSafari() || upk.browserInfo.isFF())
        h -= 2;

    h -= 8;

    var showChangeView = (viewApplicable || searchVisible);

    _changeViewObj.className = (showChangeView ? 'tocFrameText modebuttonshow' : 'tocFrameText modebuttonhide');

    var hh = 0;
    if (searchVisible)
        hh = _searchResultObj.clientHeight;

    if (showChangeView)
        hh += getObjectById("changeview").clientHeight;

    if (!IsTouchDevice()) {
        try {
            var _approles_correction = $("#searchtopcontainer").height() + $("#appandroles").height();
            _treeContainerObj.style.height = "" + (h - _approles_correction - hh) + "px";
        }
        catch (e) {
            _treeContainerObj.style.height = "0px";
        }
    }
    RefreshConcept();
}

function MyEventKeyDown(event) {
    if (!event)
        event = window.event;
    var code = event.keyCode;
    if (code == 27) {
        // todo: this must be handled in some way
        // probably dialog2.html should handle key events
        // this function is obsolete
        //				JumpIn_Show(null, null);
        try {
            if (parent.isOpenDialog()) {
                parent.closeDialog();
                return;
            }
        }
        catch (e) { };
    }
    if (code == 13 && _inputHasFocus == true) {
        Search_Click();
        return false;
    }
    if (upk.browserInfo.isSafari())
        EventKeyDown(event);
}

function FocusToSearchField() {
    return;
    /*
    try {
    var sb = getObjectById("searchbox");
    sb.focus();
    }
    catch (e) {
    }
    */
}

function applicable_Click() {
    if ($("#chapp").prop("checked")) {
        viewApplicable = true;
        _goToFlatMode = true;
        Select(0);
    }
    else {
        viewApplicable = false;
        Select(0);
    }
}

function applicable_Clear() {
    $("#chapp").prop("checked", false);
    applicable_Click();
}

function Search_Click() {
    if (_inputIsEmpty == true)
        return;
    viewSearch = true;
    _goToFlatMode = true;
    FocusToSearchField();
    if (IsTouchDevice()) {
        document.getElementById("searchcontainer2").focus();
    }
    SetSelectionViewText(true);
    Select(1);
}

function Search_Clear_Click() {
    $("#searchbox").val("");
    OnInputBlur();
    if (viewSearch == false)
        return;
    viewSearch = false;
    FocusToSearchField();
    Select(0);
    SearchProcess_Show(false);
}

function SetSelectionViewText(empty) {
    var flatMode = GetActualFlatView();
    if (!empty)
        empty = IsActualViewEmpty();
    if (empty == true) {
        document.getElementById("selectionviewtext").innerHTML = "";
    }
    else {
        document.getElementById("selectionviewtext").innerHTML = (flatMode ? R_toc_tree_view_in_outline : R_toc_tree_view_resultlist);
    }
}

function EnableSelectionViewText(enable) {
    //    if (viewApplicable)
    //        enable = true;
    if (enable) { $("selectionviewtext").show() }
    else { $("selectionviewtext").hide() }
    //	s = (enable ? 'visible' : 'hidden');
    //	document.getElementById("selectionviewtext").style.visibility = s;
}

function ChangeView_Click() {
    var flatMode = ChangeTreeView();
    _goToFlatMode = flatMode;
    SetSelectionViewText(false);
}

var _inputIsEmpty = true;
var _inputHasFocus = false;

function OnInputFocus() {
    _inputHasFocus = true;
    if (_inputIsEmpty == true) {
        var sb = $("#searchbox").val("").attr("class", "tocSearch");
    }
    _inputIsEmpty = false;
}

function OnInputBlur() {
    _inputHasFocus = false;
    var sb = $("#searchbox");
    if (sb.val() == "") {
        _inputIsEmpty = true;
        sb.val(R_Toc_search);
        sb.attr("class", "tocSearchBarText");
    }
    else {
        _inputIsEmpty = false;
        sb.attr("class", "tocSearch");
    }
}

function SearchFontSize(s) {
    for (var i = 1; i < document.styleSheets.length; i++) {
        var ss = document.styleSheets[i];
        var rules = ("rules" in ss) ? ss["rules"] : (("cssRules" in ss) ? ss["cssRules"] : []);
        for (var j = 0; j < rules.length; j++) {
            var rr = rules[j];
            if (rr.selectorText == s) {
                return rr.style.fontSize;
            }
        }
    }
    return "";
}

function getAbsoluteXPosInToc(nonabspos) {
    _sbordersize = $("#sepdiv").width();
    var ftcwidth = $("#treeside").width();
    return ftcwidth + nonabspos + _vbordersize + _sbordersize;
}

function getAbsoluteYPosInToc(nonabspos) {
    // since #thorizontal1 has been removed, we cannot calculate with its height
    //_hbordersize = $("#thorizontal1").height();
    // todo: its replacement should go here, until then it is set to 0
    _hbordersize = 5;
    return _header1DivObj.clientHeight + _hbordersize + nonabspos;
}

function Toc_onCloseDialog() {
    if (upk.browserInfo.isExplorer()) {
        $("#searchbox").focus();
        $("#searchbox").blur();
    }
}

function viewAll() {
    if (applicable_Clear)
        applicable_Clear();
}

function loadResources() {
    $("*[data-value]").each(function () {
        $(this).text(function () {
            return window[$(this).attr("data-value")];
        })
    })
    $("*[data-alt]").each(function () {
        $(this).attr("alt", function () {
            return window[$(this).attr("data-alt")];
        })
    })
    $("*[data-title]").each(function () {
        $(this).attr("title", function () {
            return window[$(this).attr("data-title")];
        })
    })
}

$(function () { setTimeout(Init, 0); });

//if the player is in a hidden frame, - only in Firefox - the #treeside does not get display:block property, so when the frame is displayed, the tree remains empty, this is a fix or this bug
$(window).load(function () {
    if (/*$.browser.mozilla*/navigator.userAgent.indexOf("Firefox") >= 0) {
        $('#treeside').css('display', 'block');
    }
});

function Init() {
    loadResources();

    // Get the current device DPI
    if (_deviceDPI == 0)
        _deviceDPI = getDpiInfo();

    if (_deviceDPI == 0) {
        //if the player is in a hidden frame, it goes endless, because _deviceDPI = 0, see the fix in getDpiInfo
        setTimeout(Init, 100);
        return;
    }

    if (_deviceDPI != 96) {
        if (getDPICookie() == false) {
            this.location.replace("./../html/unsuppdpi.html?" + Escape.MyEscape(AbsUrl(this.location.href)));
            return;
        }
    }

    ctxHelper.SetContext("toc");

    setOnCloseEvent("Toc_onCloseDialog()");
    ParseArguments();

    if (_see_also == false && _associated_content == false)
        InitLmsMode("toc");
    var chindex = 0;
    if (_lmsMode != null)
        chindex = 0 - 1;
    if (_see_also == true || _associated_content == true)
        chindex = 0 - 1;

    try {
        if (soundIsExported == undefined)
            soundIsExported = false;
        if (soundIsExported == null)
            soundIsExported = false;
    }
    catch (e) {
        soundIsExported = false;
    }

    if (_lmsMode != null) {
        if (urlParser.GetParameter("nosound") == null) {
            if (Sound_Init(soundIsExported, UserPref_PlayAudio_Original, null, false, "../") == false)
                return;
        }
    }

    if (lms_initialized == false) {
        lms_InitPage(chindex, (_lmsMode == null ? window.opener : null), null, "Init()");
        return;
    }

    if (urlParser.GetParameter("nosound") != null) {
        SetNoSound(true);
    }

    if (IsTouchDevice()) {
        $("#container").addClass("ipad");
    }

    /*upk_Outline.*/tree_Init();

    //    this.frames["mytreeframe"].location.replace("./toc/outline-tree.html");
}

function Init_treeloaded() {
    /*
    if (!document.all) {
    bypassToc = false;
    }
    */
    //	 $("#header1").css("min-width",function (){
    //		var w = $("#header1table").width() + $("#bannerimg").width();
    //		return w;
    //	 });

    //    var h1 = getObjectById("header1table");
    //    h3img = getObjectById("bannerimg");
    //    w = h3img.clientWidth;
    //    h3img.style.height = "" + (h1.clientHeight) + "px";
    //    h3img.style.width = "" + w + "px";

    {
        var sbox = document.getElementById("searchbox");
        var fs = parseInt(SearchFontSize(".tocSearch"));
        var h = parseInt(sbox.style.height);
        var d = Math.floor((h - fs) / 2);
        sbox.style.height = "" + (h - d) + "px";
        sbox.style.paddingTop = "" + d + "px";
    }

    try {
        if (_sco == false) {
            var tpref = (UIComponents.TitlePrefix == true ? R_toc_title + " - " : "");
            document.title = tpref + UnescapeQuotes(moduleName);
        }
    }
    catch (e) {
        _Resize();
        //				alert("The content is empty");
        window.onresize = Resize0;
        //document.getElementById("cover").onmousemove = sepM;
        //$("#sepdiv").on('mousedown', sepD);
        //if (!IsTouchDevice()) { $("#sepbutton").on('click', function () { toggleTree(); }); }
        document.getElementById("searchbox").disabled = true;
        document.getElementById("contentisemptydiv").innerHTML = R_toc_content_empty;
        document.getElementById("treecontainer").style.verticalAlign = "top";
        document.getElementById("mytreeframe").style.display = "none";
        document.getElementById("contentisemptydiv").style.display = "block";
        return;
    }

    if (_resulttextObj == null)
        _resulttextObj = getObjectById("resulttext");
    if (document.all) {
        _resulttextObj.style.width = "100px";
    }

    //	Enable Preferences button
    if (PlayerConfig.EnableCookies == true && UserPrefs.EnablePreferences == true) {
        var o = getObjectById("prefsbutton");
        //				o.style.display = 'block';
    }

    LoadXMLDocArray("roles.xml", Roles_Returned, Roles_Error, "Role", false);

}

function RolesRemoved() {
    if (_rolesRemoved == true)
        alert(R_roles_all_removed);
    _rolesRemoved = false;
}

function Roles_Returned(ret) {

    if (UIComponents.Help === false) {
        ret = new Object();
        ret.length = 0;
    }

    for (var i = 0; i < ret.length; i++) {
        allRoles[i] = ret[i];
    }
    var o = getObjectById("hasrole");
    if (allRoles.length > 0 && PlayerConfig.EnableCookies == true) {
        o.style.display = 'inline';
        //					setTimeout("Init1()",50);
    }

    if (UIComponents.Help === false) {
        setTimeout(Init1, 50);
        return;
    }

    UserRoles.LoadCookie();
    var topLevelLmsMode = GetTopLevelLmsMode();
    if ((topLevelLmsMode != "Cookie") && (topLevelLmsMode != "KPT"))
        UserRoles.Filtering = false;
    if (_associated_content == true)
        UserRoles.Filtering = false;
    if (_launchedFromSharedLink == true)
        UserRoles.Filtering = false;
    if (UserRoles.Filtering == true && allRoles.length == 0) {
        UserRoles.Filtering = false;
        UserRoles.StoreCookie();
        _rolesRemoved = true;
    }
    $("#chroles").prop("checked", UserRoles.Filtering);
    if (UserRoles.Filtering == true) {
        InitRoles(GetRolesQueryString());
    }
    else {
        setTimeout(Init1, 50);
    }
}

function Roles_Error() {
    setTimeout(Init1, 50);
}

function Init0(topiclist) {
    SetTopicList("ROLES", topiclist, Init1);
}

function GetAllRoles() {
    return allRoles;
}

function onRoles() {
    if (this.frames["myconceptframeToc"].OnPrepareDialog)
        this.frames["myconceptframeToc"].OnPrepareDialog();
    var ctx = "roles";
    setDlgCtx(ctx);
    showDialog(GetBasePath() + "/../html/roles.html", -1, -1, 320, 290, true, _deviceDPI, null, false);
}

function roles_Click() {
    var o = $("#chroles");
    if (o.prop("checked") && UserRoles.Roles.length == 0) {
        o.prop("checked", false);
        onRoles();
        TocToTop(100);
        return;
    }
    UserRoles.Filtering = o.prop("checked");
    UserRoles.StoreCookie();
    setRoleFiltering();
    TocToTop(100);
}

function onUpdateRoles() {
    setRoleFiltering();
    TocToTop(200);
}

function TocToTop(k) {
    if (upk.browserInfo.isiOS()) {
        setTimeout(function () { window.scrollTo(0, 0); }, k);
    }
}

function GetRolesQueryString() {
    if (!UserRoles.Filtering) {
        return "NOROLES";
    }
    var l = UserRoles.Roles.length;
    if (l == 0) {
        return "NOROLES";
    }
    var s = "r";
    for (var i = 0; i < l; i++) {
        var rolestr = UserRoles.Roles[i];
        rolestr = Escape.MyUnEscape(rolestr);
        rolestr = rolestr.toLowerCase();
        rolestr = Escape.MyEscape(rolestr);
        s += "'" + rolestr + "'";
        if (i != (l - 1))
            s += "-";
    }
    return s;
}

function setRoleFiltering() {
    SetSelectionViewText(true)
    UserRoles.LoadCookie();
    $("#chroles").prop("checked", UserRoles.Filtering);
    var s = GetRolesQueryString();
    SetRoles(s);
}

var XdtTimeout = null;

function Init1() {
    if (XDTParam != null) {
        if (window.parent == window) {
            Init2();
            return;
        }
        XdtTimeout = setTimeout(function () {
            if (XdtTimeout != null) {
                clearTimeout(XdtTimeout);
                XdtTimeout = null;
                Init2();
            }
        }, 15 * 1000);
        XdTransfer.AddListener(
        this,
        function (messageName, messageData) {
            if (XdtTimeout == null)
                return;
            if (messageName == "oraupk-context") {
                clearTimeout(XdtTimeout);
                XdtTimeout = null;
                XdTransfer.PostMessage(window.parent, 'oraupk-debuginfo_searchexpression', { 'data': messageData }); //to the test page
                var ev = QueryParser.Parse("XDT", messageData);
                if (ev) {
                    QueryProcessor.Start(ev, result_XDT);
                }
            }
        });
    }
    XdTransfer.PostMessage(this.parent, "oraupk-ready", null); //it is sent always from onload
    Init2();
}

function result_XDT(topiclist) {
    hemiParam = null;
    genericMode = true;
    selectorMode = "H";
    ShowGenToc(topiclist);
}

function Init2() {
    if (upk.browserInfo.isSafari())
        document.onkeydown = MyEventKeyDown;
    else
        document.onkeypress = MyEventKeyDown;

    FocusToSearchField();

    if (hemiParam != null || genericMode == true || XDTParam == true) {
        sb = $("#hasapp");
        sb.css("display", "inline");
        sb.css("paddingLeft", "4px");
    }
    else {
        if (allRoles.length > 0 && PlayerConfig.EnableCookies == true) {
            sb = $("#hasrole");
            sb.css("paddingLeft", "4px");
        }
    }

    if (hemiParam == null && genericMode == false || XDTParam == false || allRoles.length == 0) {
        var sbox = document.getElementById("searchbox");
        if (upk.browserInfo.isFF3()) {
            sbox.style.marginTop = "" + (-2) + "px";
        }
        else if (upk.browserInfo.isSafari()) {
            sbox.style.marginTop = "" + (0) + "px";
        }
        else {
            sbox.style.marginTop = "" + (-1) + "px";
        }
    }

    var c = new Cookie(document, "OnDemandToc", 365, null, null, false);
    c.Load();
    treeWidth = c.Separator ? Number(c.Separator) : 250;
    $("#contentdiv").css("left", treeWidth + "px");
    $("#treeside").css("width", treeWidth + "px");

    $("#container").css("top", (Number($("#header1").height()) + 5) + "px");
    _Resize();
    window.onresize = Resize0;

    initSeparator();
    $("#searchbox").val("");
    OnInputBlur();

    if (_tree_root != "") {
        document.getElementById("appandroles").style.display = "none";
        document.getElementById("searchcontainer1").style.display = "none";
        document.getElementById("searchcontainer2").style.display = "none";
        document.getElementById("searchcontainer3").style.display = "none";

        if (_associated_content == true) {
            document.getElementById("specialcontentdiv").style.display = "block";
            document.getElementById("specialcontenttext").innerHTML = R_toc_associated_content;
        }
        if (_see_also == true) {
            document.getElementById("specialcontentdiv").style.display = "block";
            document.getElementById("specialcontenttext").innerHTML = R_toc_see_also;
        }
        if (_sco == true) {
            document.getElementById("specialcontentdiv").style.display = "block";
            document.getElementById("specialcontenttext").innerHTML = "";
        }

        if (upk.browserInfo.isFF() || upk.browserInfo.isSafari()) {
            document.getElementById("specialcontentdiv").style.paddingTop = "5px";
        }

    }
    $("#treeside").show();
    if (genericMode == true || XDTParam == true)              // generic mode
    {
        OnInputBlur();
        var sb = $("#chapp");
        sb.prop("disabled", false);
        sb.prop("checked", true);
        InitApplicableOutlineDisplay();
        Select(viewApplicable ? 5 : 0);
    }
    else if (searchParam != null && hemiParam != null) // Filtered Hemi view
    {
        var sb = $("#searchbox");
        sb.val(searchParam);
        OnInputBlur();
        sb = $("#chapp");
        sb.prop("disabled", false);
        sb.prop("checked", true);
        InitApplicableOutlineDisplay();
        Select(viewApplicable ? 3 : 1);
    }
    else if (searchParam != null)	// Filtered view
    {
        sb = $("#searchbox");
        sb.val(searchParam);
        OnInputBlur();
        Select(1);
    }
    else if (hemiParam != null)	// Hemi view
    {
        sb = $("#chapp");
        sb.prop("disabled", false);
        sb.prop("checked", true);
        InitApplicableOutlineDisplay();
        Select(viewApplicable ? 2 : 0);
    }
    else	// All view
    {
        Select(0);
    };
}

function InitApplicableOutlineDisplay() {
    var k = UserPrefs.ApplicableOutlineDisplay;
    switch (k) {
        case ("A"):
            viewApplicable = false;
            break;
        case ("O"):
            viewApplicable = true;
            _goToFlatMode = false;
            break;
        default:
            viewApplicable = true;
            _goToFlatMode = true;
            break;
    }
    var o = $("#chapp");
    o.prop("checked", viewApplicable);
}

function UnescapeHemiParam(s) {
    return replaceString("%27", "'", s);
}

function ParseArguments() {
    if (showParameters == true) {
        var ss = document.location.hash.substring(1);
        var strArgs = ss.split("&");
        if (strArgs.length == 0 || strArgs[0] == "") {
            ss = document.location.search.substring(1);
        };
        alert(ss);
    }

    urlParser = new UrlParser();
    urlParser.Parse();
    toc_safeUriMode = urlParser.GetSafeMode();

    var k = null;
    if (searchParam = urlParser.GetParameter("search")) {
        _goToFlatMode = true;
    }
    if (hemiParam = urlParser.GetParameter("ctxex") || null) {
        hemiParam = UnescapeHemiParam(hemiParam);
        if (hemiParam == "" || hemiParam == "''") {
            hemiParam = null;
        }
        else {
            _goToFlatMode = true;
            appParam = urlParser.GetParameter("app");
            ctxParam = urlParser.GetParameter("ctx");
            udvParam = urlParser.GetParameter("udv");
            shParam = urlParser.GetParameter("sh");
        }
    }
    if (XDTParam = urlParser.GetParameter("XDT")) {
        XDTParam = true;
    }
    if (urlParser.GetParameter("genctx") != null) {
        genericMode = true;
        _goToFlatMode = true;
    }
    if (k = urlParser.GetParameter("sac") || "") {
        _tree_root = k;
        _associated_content = true;
    }
    if (k = urlParser.GetParameter("sco") || "") {
        _tree_root = k;
        _sco = true;
    }
    if (k = urlParser.GetParameter("seealso") || "") {
        _tree_root = k;
        _see_also = true;
    }
    var si;
    if (si = urlParser.GetParameter("selectitem")) {
        _seealso_selecteditem = parseInt(si, 10);
    }
    if (urlParser.GetParameter("launchfromkpath") != null) {
        _launchFromKPath = true;
    }
    if (genericMode == true) {
        searchParam = null;
    }
    if (k = urlParser.GetParameter("treeindex") || "") {
        _treeIndex = parseInt(k, 10);
    }
    if (k = urlParser.GetParameter("keep-alive-timer") != null) {
        KeepAlive_Init("../");
    }
    if (urlParser.GetParameter('treeindex') != null && urlParser.GetParameter('guid') != null && urlParser.GetParameter('bypasstoc') != null) {
        _launchedFromSharedLink = true;
    }
}

function IndexObject(index, score) {
    this.index = index;
    this.score = score;
}

function SortFunction(a, b) {
    var k = b.score - a.score;
    return k;
}

function ShowGenToc(x) {
    ctxTopicList = new Array();
    ctxTopicList2 = new Array();
    for (var i = 0; i < x.length; i++) {
        ctxTopicList[ctxTopicList.length] = new IndexObject(x[i].index, (typeof (x[i].score) != "undefined" ? x[i].score : x[i].weight));
    }
    ctxTopicList.sort(SortFunction);
    if (hemiParam == null) {
        ShowGenToc2(null);
    }
    else {
        genericMode_SearchHemi = true;
        Select(2);
    }
}

function ShowGenToc2(x) {
    genericMode_SearchHemi = false;
    if (x != null) {
        for (var i = 0; i < x.length; i++) {
            var ki = x[i].index;
            var _found = false;
            for (var j = 0; j < ctxTopicList.length; j++) {
                var kj = ctxTopicList[j].index;
                if (ki == kj) {
                    _found = true;
                    break;
                }
            }
            if (_found == false) {
                for (var j = 0; j < ctxTopicList2.length; j++) {
                    var kj = ctxTopicList2[j].index;
                    if (ki == kj) {
                        _found = true;
                        break;
                    }
                }
            }

            if (_found == false) {
                ctxTopicList2[ctxTopicList2.length] = new IndexObject(ki, 1);
            }
        }
        if (ctxTopicList2.length > 0) {
            for (var i = 0; i < ctxTopicList.length; i++) {
                ctxTopicList2[ctxTopicList2.length] = ctxTopicList[i];
            }
            ctxTopicList = ctxTopicList2;
        }
    }
    result_Search(ctxTopicList);
}

function IsEmptyArgument(s, keywordlen) {
    if (s.length <= keywordlen)
        return true;
    if (s.length > keywordlen + 2)
        return false;
    var ss = s.substr(keywordlen);
    if (ss == '""' || ss == "''")
        return true;
    return false;
}

var _closing = false;

function Closing2() {
    if (!upk.browserInfo.isExplorer())
        Closing();
}

function Closing() {
    lms_ClosePage(false);
    _closing = true;
    ClosePlayer();
    KeepAlive_Close();
    var c = new Cookie(document, "OnDemandToc", 365, null, null, false);
    c.Load();
    if (window.screenLeft != null)	// IE
    {
        c.TocLeft = window.screenLeft - 4;
        c.TocTop = window.screenTop - 30;
        c.TocWidth = document.body.clientWidth;
        c.TocHeight = document.body.clientHeight;
    }
    else	// Mozilla
    {
        c.TocLeft = window.screenX;
        c.TocTop = window.screenY;
        c.TocWidth = window.innerWidth;
        c.TocHeight = window.innerHeight;
    }
    c.Store();
}

function NotSupportedYet() {
    alert("Coming soon ...");
}

/* query.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

/// <reference path="resource.js" />
/// <reference path="xmlloader.js" />
/// <reference path="escape.js" />

// OnDemand query parser

//TEMPORARY
var logger_enabled_query = false;
//var logger_enabled_query = true;

function log(x) {
	if (logger_enabled_query) {
		if (window.top.console) {
			window.top.console.log(x);
		}
	}
}


var datasourceroot = "querydb/";
var ConvertDbSelector = { t: "text", u: "ctxod", e: "ctxex", r: "role", g: "genctx" };

var q_search_and = " and ";
var q_search_or = " or ";

function ToHalfWidth(str) {
	var halfKatakanaSet = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";
	var fullKatakanaSet = "ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン";

	var result = "";

	for (var i = 0; i < str.length; i++) {
		var k = fullKatakanaSet.indexOf(str.charAt(i));
		if (k !== -1)
			result += halfKatakanaSet.charAt(k);
		else if (str.charCodeAt(i) >= 0xff01 && str.charCodeAt(i) <= 0xff5f)
			result += String.fromCharCode(str.charCodeAt(i) - 0xfee0);
		else
			result += str.charAt(i);
	}

	return result;
}

var QueryParser = (function ()
{	
	var PS; // stack
	var PT = [ 0,
//     e   (   )   &|  !  EOT q
	[  2,  3,  0,  0,  0,  0, 4 ],
	[ -1, -1, -1, -1,  5, -1, 0 ],
	[  2,  3,  0,  0,  0,  0, 6 ],
	[  0,  0,  0,  7,  0, 10, 0 ],
	[ -2, -2, -2, -2, -2, -2, 0 ],
	[  0,  0,  8,  7,  0,  0, 0 ],
	[  2,  3,  0,  0,  0,  0, 9 ],
	[ -4, -4, -4, -4, -4, -4, 0 ],
	[ -3, -3, -3, -3, -3, -3, 0 ]];

	function Parse(query_type, query_expression)
	{
		log('QueryProcessor.Parse');

		if (query_type === 'XDT') {
			var retobj = ParseXDT(query_expression);
			return JSON.stringify(retobj);
		}

		q_search_and = " " + R_search_AND.toLowerCase() + " ";
		q_search_or = " " + R_search_OR.toLowerCase() + " ";

		var lexer;
		var keyws;
		if ("URI" === query_type) {
			lexer = /\(|\)|\+|-|[u,e,k,r,g]|!|\d|'[^']+'/g;
			keyws = ["(",")","+","-","u","e","t","r","g","!","0","1","2","3","4","5","6","7","8","9"];
		} else {
			lexer = new RegExp('\\(|\\)|'+q_search_and+'|'+q_search_or+'|"[^"]+"|[^ \\(\\)]+(?=\\(|\\)|\\s|$)','gi'); //doesn't support db|!|\d
			keyws = ["(",")",q_search_and,q_search_or];
		}
		var codem = [1,2,3,3,5,5,5,5,5,4,4,4,4,4,4,4,4,4,4,4];
		var semvm = [0,0,"&","|",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];


		if (query_type !== 'URI')
		{
			query_expression = ToHalfWidth(query_expression);
			query_expression = query_expression.toLowerCase();
		}
	
		var ev = null;
		var pr = null;
		PS = [];
		PS.push({st: 1, se: 0});
	
		var result;
		var i;
		var opm = 0; // operator missing
		var cdb = "t"; // current database
		while ((result = lexer.exec(query_expression)) != null) {
			var sem = result[0]; // semantic value
			var sym = 0; // symbol value
			for (i in keyws) {
				if (sem === keyws[i]) {
					sym = codem[i];
					if (semvm[i])
						sem = semvm[i];
					break;
				}
			}

			// lexical preprocessor
			// 1) implicit db settings
			// 2) implicit operator '&'
			if (sym === 5) { // db change is stored but not passed
				cdb = sem;
				continue;
			}
			if (sym === 3) // operator
				opm = 0;
			if ((sym === 0 || sym === 1) && opm) { 
				if (SM(3, "&")) // insert missing '&'
					return;
				opm = 0;
			}
			if (sym === 0) { // condition
				if (sem.charAt(0) === '"' || sem.charAt(0) === "'")
					sem = sem.slice(1, sem.length - 1);
				if ("URI" !== query_type) 
				{
					// remove trailing % or *
					if (sem.length > 1) {
						var lc = sem[sem.length - 1];
						if (lc === '%' || lc === '*')
							sem = sem.slice(0, -1);
					}
					sem = Escape.MyEscape(sem.toLowerCase());
				}
				sem = cdb + sem;
				opm = 1;
			}
			if (SM(sym, sem)) {
				log('QueryProcessor.Parse return');
				return;
			}
		}
		if (!SM(5, "$")) {
			ev = PS[1].se.ev;
			pr = PS[1].se.pr;
		}
		log('QueryProcessor.Parse ' + ev + ' ' + pr);
		//	alert(ev + "\n" + pr);

		return ev;
	}
	function ParseXDT(query_object) {
		var retval = [];
		switch (query_object[0].Op) {
			case '&':
			case '|':
				retval = ParseXDT(query_object[1]);

				for (var i = 2; i < query_object.length; i++) {
					retval = retval.concat(ParseXDT(query_object[i]));
					retval.push({ "a": "o", "p": query_object[0].Op });
				}
				return retval;
			case "EM":
				retval[0] = { "a": "s", "d": "e",
					"p": (query_object[0].App + "$" + Escape.MyEscape(query_object[1])) };

				for (var i = 2; i < query_object.length; i++) {
					retval.push({ "a": "s", "d": "e",
						"p": (query_object[0].App + "$" + Escape.MyEscape(query_object[i])) });
					retval.push( { "a": "o", "p" : '&' } ) ; 
				}
				return retval; 
        
			case "SM":
				return [ { "a": "s", "d" : "g", "p": query_object } ] ;

			default:
				console.log("Error: Unknown operator " + query_object[0].Op);
				break; 
		}

		return null; 
	}

	function SM(sym, sem)
	{
		//	alert(sym + ", " + sem);
		log('QueryProcessor.SM ' + sym + ' ' + sem);
		while (1) {
			var sp = PS[PS.length - 1];
			var ptv = PT[sp.st][sym];
			if (ptv === 10) {
				//			alert("accept");
				return false;
			}
			if (ptv === 0) {
				//			alert("error");
				return true; // error
			}
			if (ptv > 0) { // shift
				PS.push({st: ptv, se: sem});
				return false;
			}
			if (ptv < 0) {
				var nsem;
				var p = PS.length;
				var p1 = PS[p - 1];
				var p2 = PS[p - 2];
				var p3 = PS[p - 3];
				switch (-ptv) {
					case 1: 
						nsem = { 
							ev: "{a:'s', d:'" + p1.se.charAt(0) + "', p:'" + p1.se.slice(1) + "'}", 
							pr: p1.se.slice(1) }; 
						break;
					case 2:	
						if (p1.se === "!") {
							nsem = { ev: "{a:'s', d:'" + p2.se.charAt(0) + "', p:'" + p2.se.slice(1) + "', m:'" + p1.se + "'}" };
						} else {
							var ss = p2.se.slice(1, parseInt(p1.se) + 1) + "$002A";
							nsem = {
								ev: "{a:'s', d:'" + p2.se.charAt(0) + "', p:'" + p2.se.slice(1) +
								"'}, {a:'s', d:'" + p2.se.charAt(0) + "', p:'" + ss + 
								"'}, {a:'o', p:'|'}" };
						}
						nsem.pr = p2.se.slice(1);
						break;
					case 3: nsem = {
						ev: p3.se.ev + ", " + p1.se.ev + ", {a:'o', p:'" + p2.se + "'}",
						pr: p3.se.pr + (p2.se === "|" ? " or " : " ") + p1.se.pr };
						break;
					case 4: nsem = {
						ev: p2.se.ev,
						pr: "(" + p2.se.pr + ")" };	
						ptv = -3;
						break;
				}
				if (ptv === -1 || ptv === -2) {
					nsem.pr = decodeURIComponent(nsem.pr);
					if (nsem.pr.search(/\s/) !== -1)
						nsem.pr = '"' + nsem.pr + '"';
				}
				PS.length += ptv;
				PS.push({st: PT[PS[PS.length - 1].st][6], se: nsem});
			}
		}
	}

	function o(op, op1, op2)
	{
		//	debug.insertAdjacentHTML("beforeEnd", "<div>" + op + ", " + op1 + ", " + op2 + "</div>");
		return op1 + op + op2;
	}

	function e(db, se, st) {
		if (!st)
			st = "";
		se = decodeURIComponent(se);
		//	debug.insertAdjacentHTML("beforeEnd", "<div>" + db + ", " + se + ", " + st + "</div>");

		return db + "=" + se + st;
	}

	return {
		Parse: Parse
	}
})();

var QueryProcessor = {
	rr: null,
Start: function(q, r)
{
	log('QueryProcessor.Start');
	this.rr = r;
	if (q.slice(0, 1) === "[" && q.slice(-1) === "]")
		this.qa = eval(q);
	else
		eval("this.qa = [" + q + "]");
	this.qp = 0;
	this.Eval();
},

Eval: function()
{
	var n = this.qa[this.qp];
	if (n.a === "s") {
		if (n.d === "g")
			SearchSM(n.p, function (r) { QueryProcessor.ReportResult(r); });
		else {
			var m = n.d === "t" ? false : true;
			if (n.m === "!")
				m = !m;
			SearchDBs[n.d].Search(n.p, m);
		}
	} else if (n.a === "o") {
		if (n.p === "&")
			this.qa[this.qp - 2].And(this.qa[this.qp - 1]);
		else
			this.qa[this.qp - 2].Or(this.qa[this.qp - 1]);
		this.qp -= 2;
		this.qa.splice(this.qp + 1, 2);
		this.Next();
	}
},

Next: function()
{
	if (this.qa.length === 1) {
		this.rr(this.qa[0].rs);
		return;
	}
	this.qp++;
	this.Eval();
},

ReportResult: function(r)
{
	log('QueryProcessor.ReportResult r = ' + r);
	log('QueryProcessor.ReportResult this.qa = ' + this.qa + ' this.qp = ' + this.qp + ' ' + this.qa[this.qp]);
	this.qa[this.qp] = r;
	this.Next();
}
};

function ReadBase64_6(i)
{
	if (i === 43)
		return 62;
	if (i === 45)
		return 63;
	if (i < 58)
		return i - 48;
	if (i < 91)
		return i - 55;
	else
		return i - 61;
}

function ReadBase64_32(s)
{
	var i, j;
	j = 0;
	i = 0x20;
	while (i & 0x20) {
		i = ReadBase64_6(s.s.charCodeAt(s.p));
		j <<= 5;
		j |= (i & 0x1f);
		s.p++;
	}
	return j;
}

function ReadBase64_ITP(s, ctr)
{
	var r = [];
	var c, n, l = 0;
	while (s.p < s.s.length) {
		n = ReadBase64_32(s);
		c = 1 === n ? ReadBase64_32(s) : 1;
		while (c) {
			l += n;
			r.push(new ctr(l));
			c--;
		}
	}
	return r;
}

function SearchDB(dbid)
{
	log('SearchDB dbid = ' + dbid);
	this.db_id = dbid;
	this.ResetIndex();
	this.request_total = 0;
	this.request_count = 0;
}

SearchDB.prototype.ResetIndex = function () {
	this.index = [];
	this.index.push({ key: null, node: "1" });
};

SearchDB.prototype.k = function (args) {
	log('SearchDB.k() args.length = ' + args.length);
	var prev = "";
	for (var i = 0; i < args.length; i++) {
		var s = { s: args[i], p: 0 };
		var l;
		var w = "";
		l = ReadBase64_32(s);
		var nk;
		nk = i === args.length - 1 ? this.index[this.index_insert_position] : {};
		nk.node = l > 0 ? s.s.slice(s.p, s.p + l) : 0;
		s.p += l;
		l = ReadBase64_32(s);
		w += prev.slice(0, l);
		l = ReadBase64_32(s);
		w += s.s.slice(s.p, s.p + l);
		s.p += l;
		if (w.length > 0) {
			nk.key = w;
		}
		prev = w;
		while (s.p < s.s.length) {
			nk.values = [];
			l = ReadBase64_32(s);
			nk.values.push(s.s.slice(s.p, s.p + l));
			s.p += l;
		}
		if (i < args.length - 1) {
			this.index.splice(this.index_insert_position, 0, nk);
			this.index_insert_position++;
		}
	}
	this.d();
};

SearchDB.prototype.LoadScript = function (f) {
	//log('SearchDB.LoadScript() f = ' + f);
	CDB = this;
	var dbPath = ConvertDbSelector[this.db_id];
	//	setTimeout("jsdbfile.src='" + datasourceroot + dbPath + "/" + f + ".js'", 1);
	LoadXMLDocArray(datasourceroot + dbPath + "/" + f + ".xml", (function (sdb) { return function (p) { sdb.LoadScript_Callback(p); } })(SearchDBs[this.db_id]), null, "N", false);
	this.request_total++;
	this.request_count++;
};

SearchDB.prototype.LoadScript_Callback = function (a) {
	//log('SearchDB.LoadScript_Callback() a = ' + a);
	CDB = this;
	CDB.k(a);
};

SearchDB.prototype.Search = function (s, m, c) {
	log('SearchDB.Search() = ' + s);
	if (c) {
		this.Search_CallBack = c;
	}
	else {
		this.Search_CallBack = QueryProcessor.ReportResult;
	}
	//log('SearchDB.Search() this.Search_CallBack = ' + this.Search_CallBack.toString());
	this.RequestCount = 0;
	this.search = s;
	this.exact_match = m;
	this.results = new SearchResultSet(null);
	if (this.search.length === 0)
		return;
	this.index_match = 0;
	this.d = this.d1;
	this.d();
};

SearchDB.prototype.IndexSearch = function () {
	log('SearchDB.IndexSearch() this.index.length = ' + this.index.length);
	var i;
	for (i = this.index_match; i < this.index.length; i++)
		if (null == this.index[i].key || this.search <= this.index[i].key)
			break;

	this.index_match = i;
	log('SearchDB.IndexSearch() this.index_match = ' + this.index_match);
};

SearchDB.prototype.d1 = function () {
	log('SearchDB.d1()');
	this.IndexSearch();
	if (null != this.index[this.index_match].key && this.search === this.index[this.index_match].key) {
		//log('SearchDB.d1() 1');
		if (!this.exact_match && this.index[this.index_match].values.length < 2) {
			//log('SearchDB.d1() 2');
			//Bug 17502091 - share - kp.html doesn't have concept with outline link
			this.results.Or(new SearchResultSet(this.index[this.index_match].values[0]));
			this.index_match++;
			this.d = this.d2;
			this.d();
		} else {
			//log('SearchDB.d1() 1 else');
			var v = this.index[this.index_match].values;
			for (var j in v) {
				this.results.Or(new SearchResultSet(v[j]));
				if (this.exact_match)
					break;
			}
			//QueryProcessor.ReportResult(this.results);
			this.ReportResult(this.results);
		}
	} else {
		//log('SearchDB.d1() else');
		if (this.index[this.index_match].node != 0) {
			this.index_insert_position = this.index_match;
			this.LoadScript(this.index[this.index_match].node);
		} else {
			if (!this.exact_match) {
				this.d = this.d2;
				this.d();
			}
			else {
				//QueryProcessor.ReportResult(this.results);
				this.ReportResult(this.results);
			}
		}
	}
};

SearchDB.prototype.d2 = function () {
	log('SearchDB.d2()');
	if (this.index[this.index_match].node !== 0) { // key has smaller children that are not yet loaded, load them
		this.index_insert_position = this.index_match;
		this.LoadScript(this.index[this.index_match].node);
	} else if (null !== this.index[this.index_match].key && this.index[this.index_match].key.substring(0, this.search.length) === this.search) { // substring match
		this.results.Or(new SearchResultSet(this.index[this.index_match].values[0])); // add to results
		this.index_match++; // move to next
		this.d2();
	} else { // no children, no match, end of traversal, report results
		log('SearchDB.d2() this.results = ' + this.results);
		this.ReportResult(this.results);
		return;
	}
};

SearchDB.prototype.ReportResult = function (r) {
	log('SearchDB.ReportResult() r = ' + r);

	if (this.db_id !== 'g') {
		QueryProcessor.ReportResult(r);
	}
	else {
		this.Search_CallBack(r);
	}
};

var SearchDBs = { t: new SearchDB("t"), u: new SearchDB("u"), e: new SearchDB("e"), r: new SearchDB("r"), g: new SearchDB("g") };
var CDB = null;

function SearchResult(index)
{
	this.index = index;
	this.weight = 1.0;
}

function SearchResultSet(s)
{
	if (s) {
		var ss = { s: s, p: 0 };
		this.rs = ReadBase64_ITP(ss, SearchResult);
	} else
		this.rs = [];
}

SearchResultSet.prototype.Or = function (srs) {
	this.AOR(srs, true);
};

SearchResultSet.prototype.AOR = function (srs, or, weight) {
	var i, j;
	for (i = 0, j = 0; i < srs.rs.length; i++) {
		while (j < this.rs.length && this.rs[j].index < srs.rs[i].index)
			j++;
		if (j === this.rs.length || this.rs[j].index !== srs.rs[i].index)
			this.rs.splice(j, 0, srs.rs[i]);
		else {
			var w1 = this.rs[j].weight;
			var w2 = srs.rs[i].weight;
			//log('AOR w1 = ' + w1 + ' w2 = ' + w2 + ' or = ' + or + ' weight = ' + weight);
			this.rs[j].weight = or ? Math.max(w1, w2) : w1 + w2 * weight;
		}
	}
};

SearchResultSet.prototype.Combine = function (srs, weight) {
	this.AOR(srs, false, weight);
};

SearchResultSet.prototype.GetMaxWeight = function () {
	var maxValue = 0;
	for (var i = 0; i < this.rs.length; i++) {
		if (this.rs[i].weight > maxValue) {
			maxValue = this.rs[i].weight;
		}
	}
	return maxValue;
};

SearchResultSet.prototype.CutOffByLimit = function (limit) {
	for (var i = 0; i < this.rs.length; i++) {
		if (this.rs[i].weight < limit) {
			this.rs.splice(i, 1);
		}
	}
};


SearchResultSet.prototype.And = function (srs) {
	var i, j;
	for (i = 0, j = 0; i < srs.rs.length && j < this.rs.length; i++) {
		while (j < this.rs.length && this.rs[j].index < srs.rs[i].index)
			this.rs.splice(j, 1);
		if (j < this.rs.length && srs.rs[i].index === this.rs[j].index) {
			var w1 = this.rs[j].weight;
			var w2 = srs.rs[i].weight;
			this.rs[j].weight = Math.min(w1, w2);
			j++;
		}
	}
	this.rs.splice(j, this.rs.length - j);
};


/* preferences.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

function UserPreferences() {
    this.EnablePreferences = true;
    this.TimeStamp = "000000000000";
    this.PlayAudio = "all";
    this.ShowLeadIn = "all";
    this.MarqueeColor = "red";
    this.TryIt = new Object;
    this.TryIt.EnableSkipping = true;
    this.DoIt = new Object
    this.DoIt.HotKey = new Object;
    this.DoIt.HotKey.Ctrl = "L";
    this.DoIt.HotKey.Shift = "N";
    this.DoIt.HotKey.Alt = "L";
    this.DefaultPlayMode = "S";
    this.WebPageAutoPlayback = true;
    this.ApplicableOutlineDisplay = "L";    // L - List, O - Outline, A - All
    this.NavbarVolume = 100;
    this.EnableShowDiagnostics = false;
}

UserPreferences.prototype.Copy = function (src) {
    this.TimeStamp = src.TimeStamp;
    this.PlayAudio = src.PlayAudio;
    this.ShowLeadIn = src.ShowLeadIn;
    this.MarqueeColor = src.MarqueeColor;
    this.TryIt.EnableSkipping = src.TryIt.EnableSkipping;
    this.DoIt.HotKey.Ctrl = src.DoIt.HotKey.Ctrl;
    this.DoIt.HotKey.Shift = src.DoIt.HotKey.Shift;
    this.DoIt.HotKey.Alt = src.DoIt.HotKey.Alt;
    this.DefaultPlayMode = src.DefaultPlayMode;
    this.WebPageAutoPlayback = src.WebPageAutoPlayback;
    this.ApplicableOutlineDisplay = src.ApplicableOutlineDisplay;
    this.NavbarVolume = src.NavbarVolume;
    this.EnableShowDiagnostics = src.EnableShowDiagnostics;
}

UserPreferences.prototype.Compare = function (src) {
    if (this.PlayAudio != src.PlayAudio) return true;
    if (this.ShowLeadIn != src.ShowLeadIn) return true;
    if (this.MarqueeColor != src.MarqueeColor) return true;
    if (this.TryIt.EnableSkipping != src.TryIt.EnableSkipping) return true;
    if (this.DoIt.HotKey.Ctrl != src.DoIt.HotKey.Ctrl) return true;
    if (this.DoIt.HotKey.Shift != src.DoIt.HotKey.Shift) return true;
    if (this.DoIt.HotKey.Alt != src.DoIt.HotKey.Alt) return true;
    if (this.DefaultPlayMode != src.DefaultPlayMode) return true;
    if (this.WebPageAutoPlayback != src.WebPageAutoPlayback) return true;
    if (this.ApplicableOutlineDisplay != src.ApplicableOutlineDisplay) return true;
    if (this.NavbarVolume != src.NavbarVolume) return true;
    if (this.EnableShowDiagnostics != src.EnableShowDiagnostics) return true;
    return false;
}

UserPreferences.prototype.GetCookie = function () {
    return new Cookie(document, "OnDemandPlayer", 365, "/", null, false);
}

UserPreferences.prototype.LoadCookie = function () {
    var cookie = this.GetCookie();
    cookie.Load();
    if (cookie.PlayAudio)
        this.PlayAudio = cookie.PlayAudio;
    UserPref_PlayAudio_Original = this.PlayAudio;
    if (upk.browserInfo.isSoundSupported() == false)
        this.PlayAudio = "none";

    if (UserPrefs.TimeStamp != "000000000000" && (!cookie.TimeStamp || UserPrefs.TimeStamp > cookie.TimeStamp))
        return;

    if (cookie.ShowLeadIn)
        this.ShowLeadIn = cookie.ShowLeadIn;
    if (cookie.MarqueeColor)
        this.MarqueeColor = cookie.MarqueeColor;
    if (cookie.TryIt_EnableSkipping)
        this.TryIt.EnableSkipping = (cookie.TryIt_EnableSkipping == "true");
    if (cookie.DoIt_HotKey_Ctrl)
        this.DoIt.HotKey.Ctrl = cookie.DoIt_HotKey_Ctrl;
    if (cookie.DoIt_HotKey_Shift)
        this.DoIt.HotKey.Shift = cookie.DoIt_HotKey_Shift;
    if (cookie.DoIt_HotKey_Alt)
        this.DoIt.HotKey.Alt = cookie.DoIt_HotKey_Alt;
    if (cookie.DefaultPlayMode)
        this.DefaultPlayMode = cookie.DefaultPlayMode;
    if (cookie.WebPageAutoPlayback)
        this.WebPageAutoPlayback = cookie.WebPageAutoPlayback;
    if (cookie.ApplicableOutlineDisplay)
        this.ApplicableOutlineDisplay = cookie.ApplicableOutlineDisplay;
    if (cookie.NavbarVolume)
        this.NavbarVolume = cookie.NavbarVolume;
    if (cookie.EnableShowDiagnostics)
        this.EnableShowDiagnostics = (cookie.EnableShowDiagnostics == "true");
}

UserPreferences.prototype.StoreCookie = function () {
    var cookie = this.GetCookie();
    cookie.TimeStamp = this.TimeStamp;
    cookie.PlayAudio = this.PlayAudio;
    cookie.ShowLeadIn = this.ShowLeadIn;
    cookie.MarqueeColor = this.MarqueeColor;
    cookie.TryIt_EnableSkipping = this.TryIt.EnableSkipping;
    cookie.DoIt_HotKey_Ctrl = this.DoIt.HotKey.Ctrl;
    cookie.DoIt_HotKey_Shift = this.DoIt.HotKey.Shift;
    cookie.DoIt_HotKey_Alt = this.DoIt.HotKey.Alt;
    cookie.DefaultPlayMode = this.DefaultPlayMode;
    cookie.WebPageAutoPlayback = this.WebPageAutoPlayback;
    cookie.ApplicableOutlineDisplay = this.ApplicableOutlineDisplay;
    cookie.NavbarVolume = this.NavbarVolume;
    cookie.EnableShowDiagnostics = this.EnableShowDiagnostics;
    cookie.Store();
}

UserPreferences.prototype.GetUrlParamString = function () {
    return "PP_SOUND=" + this.PlayAudio +
		"&PP_LEADIN=" + this.ShowLeadIn +
		"&PP_SKIP=" + (this.TryIt.EnableSkipping ? "true" : "false") +
		"&PP_MARQUEE=" + this.MarqueeColor +
		"&PP_ENABLE=" + (this.EnablePreferences ? "true" : "false") +
		"&PP_HOTKEY=" + this.DoIt.HotKey.Ctrl + this.DoIt.HotKey.Shift + this.DoIt.HotKey.Alt;
}

UserPreferences.prototype.ParseUrlParamString = function (param_str) {
    var params = param_str.split('&');
    for (var p = 0; p < params.length; p++) {
        var paritem = params[p].split("=");
        if (paritem[0].toUpperCase() == "PP_SOUND")
            this.PlayAudio = paritem[1];
        else if (paritem[0].toUpperCase() == "PP_LEADIN")
            this.ShowLeadIn = paritem[1];
        else if (paritem[0].toUpperCase() == "PP_MARQUEE")
            this.MarqueeColor = paritem[1];
        else if (paritem[0].toUpperCase() == "PP_SKIP")
            this.TryIt.EnableSkipping = (paritem[1] == "true");
        else if (paritem[0].toUpperCase() == "PP_ENABLE")
            this.EnablePreferences = (paritem[1] == "true");
        else if (paritem[0].toUpperCase() == "PP_HOTKEY") {
            this.DoIt.HotKey.Ctrl = paritem[1].charAt(0);
            this.DoIt.HotKey.Shift = paritem[1].charAt(1);
            this.DoIt.HotKey.Alt = paritem[1].charAt(2);
        }
    }
}

var UserPrefs = new UserPreferences();
var UserPref_PlayAudio_Original = "";

if (typeof SetDefaultPreferences !== "undefined")
    SetDefaultPreferences();
if (UserPrefs.EnablePreferences)
    UserPrefs.LoadCookie();

var paramstr = unescape(document.location.hash.substring(1));
if (paramstr == "")
    paramstr = unescape(document.location.search.substring(1));

UserPrefs.ParseUrlParamString(paramstr);

function OpenPreferencesDialog(path, nosound) {
    if (!UserPrefs.EnablePreferences)
        alert(R_preferences_disabled);
    else {
    	var p = path + "/html/preferences.html";
        var h;
        if (upk.browserInfo.isChrome())
            h = 430;
        else if (upk.browserInfo.isFF())
            h = 420;
        else if (upk.browserInfo.isSafari())
            h = 350;
        else
            h = 412;
        var params = new Array();
        try {
            if (lms_IsUserProfileAvailable()) {
                var url = lms_GetUserProfileUrl();
                if (url != "")
                    params[params.length] = "UserProfileUrl=" + Escape.MyEscape(url);
            }
        }
        catch (e) { };
        if (nosound) {
            params[params.length] = "nosound";
        }
        for (var i = 0; i < params.length; i++) {
            p += (i == 0) ? "?" : "&";
            p += params[i];
        }
        if (IsTouchDevice() || upk.browserInfo.isIE10Modern()) {
        	var w = 400;
        	h += 50;
        	showDialog(p, -1, -1, w, h, true, 96, "../../../", false);
        }
        else {
        	window.open(p, "prefwin", "width=500,height=" + h + ",resizable=1,scrollbars=0,top=" + (screen.availHeight - 290) / 2 + ",left=" + (screen.availWidth - 500) / 2);
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////

function SessionPreferences() {
    this.swipeInstructionShowed = false;
}

SessionPreferences.prototype.GetCookie = function () {
    return new Cookie(document, "OnDemandPlayerSession", null, "/");
}

SessionPreferences.prototype.LoadCookie = function () {
    var cookie = this.GetCookie();
    cookie.Load();
    if (cookie.swipeInstructionShowed)
        this.swipeInstructionShowed = cookie.swipeInstructionShowed;
}

SessionPreferences.prototype.StoreCookie = function () {
    var cookie = this.GetCookie();
    cookie.swipeInstructionShowed = this.swipeInstructionShowed;
    cookie.Store();
}

var SessionPrefs = new SessionPreferences();

///////////////////////////////////////////////////////////////////////////////////////////////

function GetContentPathName() {
    var s = window.location.pathname;
    var k = s.indexOf("data/toc.html");
    if (k > 0)
        return s.substr(0, k);
    k = s.indexOf("html/roles.html");
    if (k > 0)
        return s.substr(0, k);
    k = s.indexOf("data/tpc/");
    if (k > 0)
        return s.substr(0, k);
    k = s.indexOf("html/lmsui.html");
    if (k > 0)
        return s.substr(0, k);
    return s;
}

function UserRolesClass() {
    this.Filtering = false;
    this.Roles = new Array();
}

UserRolesClass.prototype.Copy = function (src) {
    this.Filtering = src.Filtering;
    this.Roles = new Array();
    for (var r = 0; r < src.Roles.length; r++)
        this.Roles[r] = src.Roles[r];
}

UserRolesClass.prototype.Compare = function (src) {
    if (this.Filtering != src.Filtering) return true;
    if (this.Roles.length != src.Roles.length) return true;
    for (var r = 0; r < this.Roles.length; r++) {
        if (this.Roles[r] != src.Roles[r]) return true;
    }
    return false;
}

UserRolesClass.prototype.GetCookie = function () {
    return new Cookie(document, "OnDemandPlayerRoles", 90, GetContentPathName(), null, false);
}

UserRolesClass.prototype.LoadCookie = function () {
    var cookie = this.GetCookie();
    cookie.Load();
    this.Filtering = false;
    if (cookie.Filtering)
        this.Filtering = (cookie.Filtering == "true");
    this.Roles = new Array();
    if (cookie.Roles)
        this.Roles = cookie.Roles.split("+");
}

UserRolesClass.prototype.StoreCookie = function () {
    var cookie = this.GetCookie();
    cookie.Filtering = this.Filtering ? "true" : "false";
    cookie.Roles = this.Roles.join("+");
    cookie.Store();
}

UserRolesClass.prototype.GetUrlParamString = function () {
    return "PP_ROLEFILTERING=" + (this.Filtering ? "true" : "false") + "&PP_ROLES=" + encodeURIComponent(this.Roles.join('+'));
}

UserRolesClass.prototype.ParseUrlParamString = function (param_str) {
    var params = param_str.split('&');
    for (var p = 0; p < params.length; p++) {
        var paritem = params[p].split("=");
        if (paritem[0].toUpperCase() == "PP_ROLEFILTERING")
            this.Filtering = (paritem[1] == "true");
        else if (paritem[0].toUpperCase() == "PP_ROLES") {
            this.Roles = new Array();
            if (paritem[1])
                this.Roles = paritem[1].split('+');
        }
    }
}

var UserRoles = new UserRolesClass();
UserRoles.LoadCookie();
UserRoles.ParseUrlParamString(paramstr);

function OpenRolesDialog(path) {
    window.open(path + "/html/roles.html", "roleswin", "width=500,height=318,resizable=1,scrollbars=0,top=" + (screen.availHeight - 286) / 2 + ",left=" + (screen.availWidth - 500) / 2);
}

/* toctreedata.js */
/// <reference path="jquery.d.ts" />
/// <reference path="xmlloader.js" />
/// <reference path="query.js" />

/*
interface TreeDataNode {
	t: string;
	y: string;
	g: string;
	o: number;
	r: Array<number>;
}

interface TreeData {
	data: { [ordinal: string]: Array<TreeDataNode> };
	indexer: Array<{ block: number; min: number; max: number }>;
	root: string;
	rootNode: TreeDataNode;
}
*/

// json outline tree data acccess layer
var upk_tocTreeData = (function () {

    var treeData /*: TreeData*/;
    var callbacksByBlockId /*: { [id: number]: Array<() => void> }*/ = {};
    var loadedByBlockId /*: { [id: number] : boolean}*/ = {};
    var dataPath /*: string*/ = "";

    function setDataPath(path /*:string*/) {
        dataPath = path;
    }

    function getRootNode() {
        if (!treeData.rootNode) {
            treeData.rootNode = { t: null, y: "S", g: treeData.root, o: 1, r: null };
        }
        return treeData.rootNode;
    }

    function loadByBlockId(id /*: number*/, done /*: () => void*/) {
        if (id in callbacksByBlockId) {
            callbacksByBlockId[id].push(done);
        } else {
            callbacksByBlockId[id] = [done];
            LoadXMLDoc(dataPath + "toc/" + id + ".json.js", function (xhr /*: XMLHttpRequest*/) {
                var node = $.parseJSON(xhr.responseText);
                if (id == 1) {
                    treeData = node;
                } else {
                    for (var key in node.data) {
                        treeData.data[key] = node.data[key];
                    }
                }
                loadedByBlockId[id] = true;
                for (var i = 0; i < callbacksByBlockId[id].length; i++) {
                    callbacksByBlockId[id][i]();
                }
                delete callbacksByBlockId[id];
            }, null, null, true);
        }
    }

    function getByOrdinal(id /*: number*/, result /*: (id: number, children: Array<TreeDataNode>) => void*/) {

        var ids = id.toString();
        var blockIndex = 0;

        function load() {
            if (ids in treeData.data) {
                result(id, treeData.data[ids]);
            } else {
                while (treeData.indexer[blockIndex].block in loadedByBlockId || treeData.indexer[blockIndex].min > id || treeData.indexer[blockIndex].max < id)
                    blockIndex++;
                loadByBlockId(treeData.indexer[blockIndex].block, load);
            }
        }

        if (treeData)
            load();
        else
            loadByBlockId(1, load);
    }

    function getByCIndex(cindex /*: number*/, result /*: (path: Array<TreeDataNode>, name: string, type: string, relcindex: number) => void*/) {

        var path /*: Array<TreeDataNode>*/ = null;

        function traverse(id /*: number*/, children /*: Array<TreeDataNode>*/) {
            if (path == null)
                path = [getRootNode()];
            for (var i = children.length - 1; i >= 0; i--) {
                var c = children[i];
                if (c.r[0] <= cindex) {
                    path.push(c);
                    if (cindex <= c.r[1]) {
                        result(path, c.t, c.y, cindex - c.r[0]);
                    } else {
                        getByOrdinal(c.o, traverse);
                    }
                    break;
                }
            }
        }

        getByOrdinal(1, traverse);
    }

    function getPathByOrdinal(ordinal /*: number*/, result /*: (path: Array<TreeDataNode>, name: string, type: string: number) => void*/) {

        var path /*: Array<TreeDataNode>*/ = null;

        function traverse(id /*: number*/, children /*: Array<TreeDataNode>*/) {
            if (path == null)
                path = [getRootNode()];
            for (var i = children.length - 1; i >= 0; i--) {
                var c = children[i];
                if (c.o <= ordinal) {
                    path.push(c);
                    if (ordinal == c.o) {
                        result(path, c.t, c.y);
                    } else {
                        getByOrdinal(c.o, traverse);
                    }
                    break;
                }
            }
        }

        getByOrdinal(1, traverse);
    }

    function getByGuid(guid /*: string*/, result /*: (path: Array<TreeDataNode>, name: string, type: string, relcindex: number) => void*/) {
        QueryProcessor.Start(QueryParser.Parse("URI", "t'" + Escape.MyEscape('"' + guid) + "'"), function (hits) {
            getByCIndex(hits[0].index, result);
        });
    }

    // public
    return {
        getByOrdinal: getByOrdinal,
        getByCIndex: getByCIndex,
        getByGuid: getByGuid,
        getPathByOrdinal: getPathByOrdinal,
        setDataPath: setDataPath
    };
})();
/* tree.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

/// <reference path="jquery.d.ts" />
/// <reference path="resource_b.js" />
/// <reference path="../config.js" />
/// <reference path="../data/outline.js" />
/// <reference path="../data/toc/treeindex.js" />
/// <reference path="../data/toc/titles.js" />
/// <reference path="../data/uiconfig.js" />

/// <reference path="common.js" />
/// <reference path="dialog.js" />
/// <reference path="swfobject.js" />
/// <reference path="browser.js" />
/// <reference path="cookie.js" />
/// <reference path="escape.js" />
/// <reference path="xmlloader.js" />
/// <reference path="lms_toc.js" />
/// <-reference path="tocfunctions_.ts" />
/// <reference path="query.js" />
/// <reference path="preferences.js" />

/// <reference path="relativelink.js" />
/// <reference path="lmsapplet.js" />
/// <reference path="lmscomfactory.js" />
/// <reference path="lmscom.js" />
/// <reference path="lms_init.js" />
/// <reference path="playerlaunch.js" />
/// <reference path="sound.js" />
/// <reference path="ctxhelper.js" />
/// <reference path="iashelper.js" />
/// <reference path="tascriptsintoc.js" />

// common variables

//var upk_Outline = (function () {

var treeControlDB = false;
var bigsco = false;
var treeControl;

function ModeDesc(k) {
    this.treeCreated = false;
    this.lastSelected = null;
    this.filteredGuids = new Array();
    this.filteredGuidList = new Array();
    this.filteredTopicCount = 0;
    this.guidsForFlat = new Array();
    this.lastSelectedFlat = null;
    this.flatMode = false;
    this.modeLetter = k;
    this.treeControl = null;
    this.flatControl = null;
    this.loadedGuids = new Array();
    this.foundItemMap = new Array();
}

var modeDescA = new ModeDesc("A");
var modeDescF = new ModeDesc("F");
var modeDescH = new ModeDesc("H");
var modeDescFH = new ModeDesc("X");

var treeViewMode = "ALL"; 			// view mode ("ALL" or "FILTERED" or "HEMI" or "FILTEREDHEMI")
var treeIsEmpty;
var _rootData = "";

function GetJunctionId(s) {
    var k = s.indexOf('_');
    var kk = s.indexOf('_', k + 1)
    return s.substr(0, kk);
}

////////////////////////////////////
// filtering support

var filteredGuidsR = new Array(); // associative array contains all guid to show
var filteredTopicCountR = 0; 	// number of filtered topics (ROLES)
var rolefilter_enabled = false;

var selection_need = 0;
var stl_mode = "ALL";
var stl_callback;
var stl_myTopicArray = new Array();
var stl_myscoresArray = new Array();
var stl_i = 0;
var seeAlsoSelection = 0;

var _lastChangeIsFilterOnly = false;

function AddToFoundItemMap(_guid, _ordinal, _cindexobject) {
    var md = modeDescA;
    if (md.foundItemMap[_guid] == null) {
        md.foundItemMap[_guid] = new Object({ guid: _guid, ordinal: _ordinal, cindexes: new Array() });
    }
    md.foundItemMap[_guid].cindexes.push(_cindexobject);
}

function SetTopicList(mode, topicarray0, callbackfn) {
    var topicarray = new Array();
    modeDescA.foundItemMap = new Array();
    if (topicarray0) {
        for (var i = 0; i < topicarray0.length; i++) {
            topicarray.push(topicarray0[i]);
            upk_tocTreeData.getByCIndex(topicarray0[i].index,
            function (p1, t1, o1) {
                var pp1 = p1[p1.length - 1];
                AddToFoundItemMap(pp1.g, pp1.o, new Object({ cindex: topicarray0[i].index, nullindex: pp1.r[0], score: topicarray0[i].score }));
                if (pp1.d) {
                    var dups = pp1.d.split(",");
                    for (var k = 0; k < dups.length; k++) {
                        upk_tocTreeData.getPathByOrdinal(dups[k],
                            function (p2, t2, o2) {
                                var pp2 = p2[p2.length - 1];
                                var di = topicarray0[i].index - pp1.r[0];
                                AddToFoundItemMap(pp2.g, pp2.o, new Object({ cindex: pp2.r[0] + di, nullindex: pp2.r[0], score: topicarray0[i].score }));
                                topicarray.push(new Object({ index: pp2.r[0] + di, weight: topicarray0[i].score }));
                            });
                    }
                }
            });
        }
    }
    stl_mode = mode;
    stl_callback = callbackfn;
    _lastChangeIsFilterOnly = false;
    getModeDesc().loadedGuids = new Array();
    if (mode == "FILTERED") {
        modeDescF.filteredGuids = new Array();
        modeDescF.filteredGuidList = new Array();
        modeDescF.filteredTopicCount = topicarray.length;
        modeDescF.guidsForFlat = new Array();
        modeDescF.flatMode = true;
    }
    else if (mode == "HEMI") {
        modeDescH.filteredGuids = new Array();
        modeDescH.filteredGuidList = new Array();
        modeDescH.filteredTopicCount = topicarray.length;
        modeDescH.guidsForFlat = new Array();
        modeDescH.flatMode = true;
    }
    else if (mode == "ROLES") {
        filteredGuidsR = new Array();
        filteredTopicCountR = topicarray.length;
        rolefilter_enabled = true;
        _lastChangeIsFilterOnly = true;
    }
    else	// "NOROLES"
    {
        rolefilter_enabled = false;
        _lastChangeIsFilterOnly = true;
        stl_callback();
        return;
    }
    stl_myTopicArray = new Array();
    stl_myTopicArray = topicarray;
    stl_myscoresArray = new Array();
    if (topicarray.length > 0) {
        try {
            var a = topicarray[0].index;
            if (a) {
                stl_myTopicArray = new Array();
                for (var i = 0; i < topicarray.length; i++) {
                    stl_myTopicArray[stl_myTopicArray.length] = topicarray[i].index;
                    stl_myscoresArray[topicarray[i].index] = topicarray[i].score;
                }
            }
        }
        catch (e) {
        }
    }
    stl_i = 0;
    SetTopicList_Next();
}

function SetTopicList_Next() {
    var fTC = modeDescF.filteredTopicCount;
    if (stl_mode == "HEMI")
        fTC = modeDescH.filteredTopicCount;
    if (stl_mode == "ROLES")
        fTC = filteredTopicCountR;
    if (!(stl_i < fTC)) {
        stl_callback();
        return;
    }
    var j = stl_myTopicArray[stl_i];
    upk_tocTreeData.getByCIndex(j, SetTopicList_Next2);
}

function ItemDesc(type, title, empty) {
    this.type = type;
    this.title = title;
    this.empty = empty;
    this.found = false;
    this.parentguid = null;
    this.openable = new Array();
    this.treeitemdiv = null;
    this.loaded = false;
}

function AddItemdesc(o, array, sss, type, title, empty, found, topicguid, parentguid) {
    var l = false;
    var _ss = sss.split("#");
    var ss = _ss[0];
    try {
        l = array[ss].title.length > 0;
    }
    catch (e) { };
    if (!l) {
        array[ss] = new ItemDesc(type, title, empty);
        if (o)
            o.filteredGuidList[o.filteredGuidList.length] = ss;
        AddToIndexMap(ss);
    }
    array[ss].parentguid = parentguid;
    if (found == true)
        array[ss].found = true;
    if (topicguid.length > 0)
        array[ss].openable[array[ss].openable.length] = topicguid;
    if (array[ss].guid == undefined) {
        array[ss].guid = ss;
        array[ss].context = _ss[1];
    }
    else {
        array[ss].context += _ss[1];
    }
}

function AddTreeItemToItemDesc(guid, itemdiv) {
    var md = getModeDesc(false);
    try {
        if (treeViewMode == "FILTEREDHEMI") {
            if (!md.filteredGuids)
                md.filteredGuids = new Array();
            if (!md.filteredGuids[guid]) {
                md.filteredGuids[guid] = new ItemDesc("", "", false);
                md.filteredGuidList[md.filteredGuidList.length] = guid;
            }
            AddToIndexMap(guid);
        }
        md.filteredGuids[guid].treeitemdiv = itemdiv;
    }
    catch (e) { }
    saveModeDesc(md);
}

function GetTreeItemOfItemDesc(guid) {
    var md = getModeDesc(false);
    var _item = null;
    try {
        _item = md.filteredGuids[guid].treeitemdiv;
    }
    catch (e) { }
    return _item;
}

function FlatItemDesc(type, title, empty, guid, isroot, score) {
    this.type = type;
    this.title = title;
    this.empty = empty;
    this.guid = guid;
    this.isroot = isroot;
    if (!score)
        score = 0;
    this.score = score;
}

function AddFlatItemdesc(array, guid, type, title, empty, isroot, score) {
    var k = guid.indexOf('#');
    var guid = k < 0 ? guid : guid.substring(0, k);
    for (var i = 0; i < array.length; i++) {
        if (array[i].guid == guid)
            return;
        if (array[i].guid.substr(0, 36) == guid.substr(0, 36))
            return;
    }
    array[array.length] = new FlatItemDesc(type, title, empty, guid, isroot, score);
}

function SetTopicList_Next2(path, title, _type, relcindex) {
    var k, i, s, _empty = false, type, ss;
    var pathwid = [];
    for (i = 0; i < path.length; i++)
        pathwid.push(path[i].g + "_" + path[i].o);
    s = pathwid.join("/");
    var _tguid = pathwid[pathwid.length - 1];
    switch (_type) {
        case "S": type = "Section"; break;
        case "E": type = "Section"; _empty = true; break;
        case "T": type = "Topic"; break;
        case "Q": type = "Question"; break;
        case "A": type = "Assessment"; break;
    };
    var _concept = path[path.length - 1].c;
    s += relcindex > 0 ? "#C" + relcindex : "";

    k = s.indexOf('/');
    var _pguid = null;
    if (_type == "T" || _concept == 1 || _type == "Q" || _type == "A") {
        while (k >= 0) {
            ss = "" + s.substr(0, k);
            if (stl_mode == "FILTERED") {
                //  			filteredGuidsF[ss]=itemdesc;
                //  			filteredGuidsF[ss.substr(0,36)]=itemdesc;
                AddItemdesc(modeDescF, modeDescF.filteredGuids, ss, type, title, _empty, false, _tguid, _pguid);
                AddItemdesc(modeDescF, modeDescF.filteredGuids, ss.substr(0, 36), type, title, _empty, false, _tguid, _pguid);
            }
            else if (stl_mode == "HEMI") {
                //  			filteredGuidsH[ss]=itemdesc;
                AddItemdesc(modeDescH, modeDescH.filteredGuids, ss, type, title, _empty, false, _tguid, _pguid);
                AddItemdesc(modeDescH, modeDescH.filteredGuids, ss.substr(0, 36), type, title, _empty, false, _tguid, _pguid);
            }
            else	// "ROLES"
            {
                //  			filteredGuidsR[ss]=itemdesc;
                AddItemdesc(null, filteredGuidsR, ss, type, title, _empty, false, _tguid, null);
                AddItemdesc(null, filteredGuidsR, ss.substr(0, 36), type, title, _empty, false, _tguid, null);
            }
            _pguid = ss;
            ss = s.substr(k + 1);
            s = ss;
            k = s.indexOf('/');
        }
        if (s.length > 0) {
            ss = s;
            k = s.indexOf('#');
            if (k < 0)
                ss += "#";
            if (stl_mode == "FILTERED") {
                //  			filteredGuidsF[ss]=itemdesc;
                AddItemdesc(modeDescF, modeDescF.filteredGuids, ss, type, title, _empty, true, "", _pguid);
                AddFlatItemdesc(modeDescF.guidsForFlat, ss, type, title, _empty, false, 0);
            }
            else if (stl_mode == "HEMI") {
                //  			filteredGuidsH[ss]=itemdesc;
                AddItemdesc(modeDescH, modeDescH.filteredGuids, ss, type, title, _empty, true, "", _pguid);
                var _score = stl_myscoresArray[stl_myTopicArray[stl_i]];
                AddFlatItemdesc(modeDescH.guidsForFlat, ss, type, title, _empty, false, _score);
            }
            else {
                //  			filteredGuidsR[ss]=itemdesc;
                AddItemdesc(null, filteredGuidsR, ss, type, title, _empty, true, "", null);
                AddItemdesc(null, filteredGuidsR, ss.substr(0, 36), type, title, _empty, true, "", null);
            }
        }
    }
    stl_i++;
    SetTopicList_Next();
}

//////////////////////////////////////////////////////////////////////////////

function TreeViewModeLetter() {
    if (treeViewMode == "FILTEREDHEMI")
        return "X";
    return treeViewMode.substr(0, 1);
}

function IsFiltered(guid, tMode) // true if the guid must be show
{
    var k;
    var l = 0;
    try {
        l = filteredGuidsR[guid].title.length;
    }
    catch (e) { };

    var roles = 0; //not enabled
    if (rolefilter_enabled) {
        roles = (l > 0 ? 1 : 2); // 1 -> found, 2 -> not found
    }

    if (tMode == "ALL") {
        if (roles == 0) {
            treeIsEmpty = false;
            return true;
        }
        else if (roles == 1) {
            var ll = false;
            try {
                ll = (filteredGuidsR[guid].openable.length > 0 || filteredGuidsR[guid].found);
            }
            catch (e) { };
            if (ll)
                treeIsEmpty = false;
            return ll;
        }
        else {
            return false;
        }


    }
    else if (tMode == "FILTERED") {
        l = 0;
        try {
            l = modeDescF.filteredGuids[guid].title.length;
        }
        catch (e) { };
        if (l == 0)
            return false;

        if (roles == 0) {
            treeIsEmpty = false;
            return true;
        }
        else if (roles == 1) {
            ll = false;
            try {
                ll = Cut(modeDescF.filteredGuids[guid].openable, filteredGuidsR[guid].openable) ||
							(modeDescF.filteredGuids[guid].found && filteredGuidsR[guid].found);
            }
            catch (e) { };
            if (ll)
                treeIsEmpty = false;
            return ll;
        }
        else {
            return false;
        }
    }
    else if (tMode == "HEMI") {
        l = 0;
        try {
            l = modeDescH.filteredGuids[guid].title.length;
        }
        catch (e) { };
        if (l == 0)
            return false;

        if (roles == 0) {
            treeIsEmpty = false;
            return true;
        }
        else if (roles == 1) {
            ll = false;
            try {
                ll = Cut(modeDescH.filteredGuids[guid].openable, filteredGuidsR[guid].openable) ||
							(modeDescH.filteredGuids[guid].found && filteredGuidsR[guid].found);
            }
            catch (e) { };
            if (ll)
                treeIsEmpty = false;
            return ll;
        }
        else {
            return false;
        }
    }
    else	// FILTEREDHEMI
    {
        if (roles == 0) {
            ll = false;
            try {
                ll = Cut(modeDescF.filteredGuids[guid].openable, modeDescH.filteredGuids[guid].openable) ||
							(modeDescF.filteredGuids[guid].found && modeDescH.filteredGuids[guid].found);
            }
            catch (e) { };
            if (ll)
                treeIsEmpty = false;
            return ll;
        }
        else if (roles == 1) {
            ll = false;
            try {
                ll = Cut3(modeDescF.filteredGuids[guid].openable, modeDescH.filteredGuids[guid].openable, filteredGuidsR[guid].openable) ||
							(modeDescF.filteredGuids[guid].found && modeDescH.filteredGuids[guid].found && filteredGuidsR[guid].found);
            }
            catch (e) { };
            if (ll)
                treeIsEmpty = false;
            return ll;

        }
        else {
            return false;
        }
    }
}

function Cut(array1, array2) {
    if (array2 == null) {
        return array1.length > 0;
    }
    for (var i = 0; i < array1.length; i++) {
        for (var j = 0; j < array2.length; j++) {
            if (array1[i] == array2[j])
                return true;
        }
    }
    return false;
}

function Cut3(array1, array2, array3) {
    if (array3 == null)
        return Cut(array1, array2);
    for (var i = 0; i < array1.length; i++) {
        for (var j = 0; j < array2.length; j++) {
            for (var k = 0; k < array3.length; k++) {
                if (array1[i] == array2[j] && array2[j] == array3[k])
                    return true;
            }
        }
    }
    return false;
}

function IsOpenable(guid) {
    var roleArray = null;
    if (rolefilter_enabled == true) {
        roleArray = filteredGuidsR[guid].openable;
    }

    if (treeViewMode == "ALL") {
        if (rolefilter_enabled) {
            var l = false;
            try {
                l = roleArray.length > 0;
            } catch (e) { };
            return l;
        }
        return true;
    }
    else if (treeViewMode == "FILTERED") {
        l = true;
        try {
            l = Cut(modeDescF.filteredGuids[guid].openable, roleArray);
        }
        catch (e) { };
        return l;
    }
    else if (treeViewMode == "HEMI") {
        l = true;
        try {
            l = Cut(modeDescH.filteredGuids[guid].openable, roleArray);
        }
        catch (e) { };
        return l;
    }
    else		// FILTEREDHEMI
    {
        l = Cut3(modeDescF.filteredGuids[guid].openable, modeDescH.filteredGuids[guid].openable, roleArray);
        return l;
    }
}

var _expandLevel = -1;

function IsAutoExpand(element, needOpen)	// true if the tree must be appear expanded
{
    if (GetActualFlatView() == true) {
        if (treeViewMode == "FILTERED")
            return (modeDescF.filteredTopicCount < TreeConfig.AutoExpandLimit)
        else if (treeViewMode == "FILTEREDHEMI")
            return (modeDescF.filteredTopicCount < TreeConfig.AutoExpandLimit)
        else	//"HEMI"
            return (modeDescH.filteredTopicCount < TreeConfig.AutoExpandLimit)
    }
    else {
        var md = getModeDesc();
        var tpc = GetTpcAttribute(element);
        if (tpc == null && element.i) {
            tpc = element.i;
        }
        if (tpc == null && element.d) {
            tpc = element.d;
        }
        if (tpc == null && element.id) {
            var e = element.id;
            if (e[8] == '-' && e[13] == '-' && e[18] == '-' && e[36] == '_') {
                var k1 = e.indexOf('_');
                var k2 = e.lastIndexOf('_');
                if (k1 == k2)
                    tpc = e;
                else
                    tpc = e.substr(0, k2);
            }
        }
        var depth = 0;
        while (tpc in md.filteredGuids) {
            depth++;
            tpc = md.filteredGuids[tpc].parentguid;
        }
        if (_expandLevel < 0) {
            try {
                _expandLevel = parseInt(TreeConfig.DefaultExpandLevel, 10);
            }
            catch (e) {
                _expandLevel = 1;
            }
            if (_expandLevel < 1)
                _expandLevel = 1;
            _expandLevel--;
        }
        if (!needOpen)
            return (depth <= _expandLevel)
        return (depth < _expandLevel);
    }
}

function Queue_Next(t)	// load next section html file
{
    if (_childItem_found) {
        _childItem_found = false;
        createTreeControl(null, false, null, null, null);
    }
    else {
        if (selection_need > 0) {
            var sel = false;
            if (_lastSelectedGlobal.length > 0) {
                if (rolefilter_enabled == true) {
                    var l = 0;
                    try {
                        l = filteredGuidsR[_lastSelectedGlobal].title.length;
                    }
                    catch (e) { };
                    if (l > 0) {
                        sel = true;
                    }
                }
                else {
                    sel = true;
                }
            }

            if (sel == true) {
                selection_need = 0;
                if (ChangeTreeView_CallBack() == true)
                    return;
            }
            t.SelectFirstItem();
        }
        if (TreeFinished) {
            TreeFinished(treeViewMode, treeIsEmpty);
        }
    }
}

function SelectionCallBack(_item) {
    var t;
    var md = getModeDesc(false);
    switch (treeViewMode) {
        case "ALL":
            if (_lastSelectedItem_tree != null) {
                if (_lastSelectedItem_tree.startAction == true) {
                    _lastSelectedItem_tree.startAction = false;
                }
                else {
                    _lastSelectedItem_tree.startAction = true;
                    ChangeTreeView_CallBack()
                    return;
                }
            }
            t = (_item == null ? md.lastSelected : _item);
            break;
        default:
            if (md.flatMode == true) {
                SetFlatSelection();
                return;
            }
            t = ((md.flatMode == true) ? md.lastSelectedFlat : (_item == null ? md.lastSelected : _item));
            break;
    }

    if (t == null) {
        if (TreeItemSelected)
            TreeItemSelected(null, null);
        return;
    };
    var tpc = t.getAttribute("tpc");
    if (tpc == null)
        tpc = t.parentNode.getAttribute("tpc");
    if (tpc == null)
        tpc = t.parentNode.parentNode.getAttribute("tpc");
    if (md.flatMode == false) {
        ChangeSelection(t);
        window.scrollTo(0, (t.parentNode.offsetTop / 2) + 10);
    }
    if (tpc != null)
        SetLastSelected(tpc, treeViewMode, false);
    if (TreeItemSelected)
        TreeItemSelected(tpc, treeViewMode);
}

function ClearDescriptor(md, fm) {
    md.treeCreated = true;
    md.lastSelected = null;
    md.lastSelectedFlat = null;
    //	if (_lastChangeIsFilterOnly==false)
    md.flatMode = fm;
    for (var i = 0; i < md.filteredGuidList.length; i++) {
        var s = md.filteredGuidList[i];
        md.filteredGuids[s].treeitem = null;
        md.filteredGuids[s].treeitemdiv = null;
        md.filteredGuids[s].loaded = false;
    }
    md.loadedGuids = new Array();
}

function LastSelectedItem(guid, mode) {
    this.guid = guid;
    this.mode = mode;
    this.startAction = false;
    this.firsdBuild = false;
}

var _lastSelectedItem_tree = null;
var _lastSelectedGlobal = "";
var _lastSelectedGlobalMode = "";

function SetLastSelected(guid, mode, force) {
    _lastSelectedGlobal = guid;
    _lastSelectedGlobalMode = mode;
    if (!force) {
        if (treeViewMode == "ALL")
            return;
    }
    _lastSelectedItem_tree = new LastSelectedItem(guid, mode);
}

function GetTpcAttribute(obj) {
    var tpc = null;
    while (tpc == null) {
        try {
            tpc = obj.getAttribute("tpc");
        }
        catch (e) {
            return null;
        }
        if (tpc == null)
            obj = obj.parentNode;
    }
    return tpc;
}

var _childItem = null;
var _childItem2 = null;
var _childItem_found = false;

function createTreeControl(rootData, flatmode, _item, selection, childitem) {
    if (rootData)
        _rootData = rootData;
    try {
        bigsco = SCO_Supported();
    }
    catch (e) { }
    InitTocStates();
    if (selection)
        seeAlsoSelection = selection;
    if (childitem) {
        _childItem = childitem;
        _childItem2 = childitem;
    }
    var fm = (flatmode == true ? true : false);
    selection_need = 1;
    if (treeViewMode == "ALL") {
        if (modeDescA.treeCreated == true) {
            SelectionCallBack(_item);
            return;
        }
        ClearDescriptor(modeDescA, false);
        if (_lastSelectedItem_tree != null) {
            _lastSelectedItem_tree.startAction = true;
            _lastSelectedItem_tree.firstBuild = true;
        }
        else {
            selection_need = 2;
        }
    }
    else if (treeViewMode == "FILTERED") {
        if (modeDescF.treeCreated == true) {
            //			if (fm==true && _lastChangeIsFilterOnly==false)
            //				modeDescF.flatMode=true;
            modeDescF.flatMode = fm;
            SelectionCallBack(_item);
            return;
        }
        ClearDescriptor(modeDescF, fm);
    }
    else if (treeViewMode == "FILTEREDHEMI") {
        if (modeDescFH.treeCreated == true) {
            //			if (fm==true && _lastChangeIsFilterOnly==false)
            //				modeDescFH.flatMode=true;
            modeDescFH.flatMode = fm;
            SelectionCallBack(_item);
            return;
        }
        ClearDescriptor(modeDescFH, fm);
    }
    else	//"HEMI"
    {
        if (modeDescH.treeCreated == true) {
            //			if (fm==true && _lastChangeIsFilterOnly==false)
            //				modeDescH.flatMode=true;
            modeDescH.flatMode = fm;
            SelectionCallBack(_item);
            return;
        }
        ClearDescriptor(modeDescH, fm);
    }
    treeIsEmpty = true;
    if (treeViewMode == "ALL")
        treeControl = new TreeControl(document.getElementById("treeControlHostForAll"), rootData);
    else if (treeViewMode == "FILTERED") {
        treeControl = new TreeControl(document.getElementById("treeControlHostForFiltered"), rootData);
        modeDescF.flatControl = new FlatControl("flatControlHostForFiltered");
        modeDescF.flatControl.Load();
        selection_need = (modeDescF.flatMode == true ? 0 : 1);
    }
    else if (treeViewMode == "FILTEREDHEMI") {
        treeControl = new TreeControl(document.getElementById("treeControlHostForFilteredHemi"), rootData);
        modeDescFH.flatControl = new FlatControl("flatControlHostForFilteredHemi");
        modeDescFH.flatControl.Load();
        selection_need = (modeDescFH.flatMode == true ? 0 : 1);
    }
    else	//"HEMI"
    {
        treeControl = new TreeControl(document.getElementById("treeControlHostForHemi"), rootData);
        modeDescH.flatControl = new FlatControl("flatControlHostForHemi");
        modeDescH.flatControl.Load();
        selection_need = (modeDescH.flatMode == true ? 0 : 1);
    }

    treeControl.LoadScript(treeControl.rootData, treeControl.treeHost.id);
}

function TreeControl(host, rootData) {
    this.host = host;
    this.rootData = rootData;

    host.innerHTML = "";
    this.treeHost = document.createElement("div");
    this.treeHost.id = rootData + "_" + TreeViewModeLetter();
    this.treeHost.className = "treeControlNode";
    this.treeHost.onclick = this.OnClick;
    this.treeHost.onmouseup = this.OnMouseUp;
    this.treeHost.ondblclick = this.OnDoubleClick;
    this.host.appendChild(this.treeHost);
}

TreeControl.prototype.LoadScript = function (src, indexedSrc) {
    setTimeout(function () { treeControl.LoadScriptInternal(src, indexedSrc); }, 0);
}

TreeControl.prototype.LoadScriptInternal = function (src, indexedSrc) {
    treeControlDB = true;
    upk_tocTreeData.getByOrdinal(parseInt(src.substring(37)), function (id, c) {
        // convert to legacy data format
        var lc = [];
        for (var i = 0; i < c.length; i++) {
            lc[i] = { t: c[i].t, y: c[i].y };
            lc[i][(c[i].y == "S" || c[i].y == "E" ? "d" : "i")] = c[i].g + "_" + c[i].o;
        }
        treeControl.Bind({ c: lc }, indexedSrc);
    });
}

TreeControl.prototype.Bind = function (data, indexedSrc) {
    if (treeControlDB) {
        treeControlDB = false;
        this.TraverseChildren(data.c, document.getElementById(indexedSrc));
        _childNode_Loaded(null);
    }
    if (directMode == true)
        ChangeTreeView_CallBack()
    else
        Queue_Next(this);
}

function GetClassNameFromFile(filename) {

    var mytool_array = filename.split("/");
    var cname = mytool_array[mytool_array.length - 1];
    return cname.replace(".gif", "");
}

TreeControl.prototype.TraverseNode = function (node, parentElement, image, last) {
    var md = getModeDesc();
    var guid = (node.i ? node.i : node.d);
    var hasChildren = node.c || node.d;
    var _openable = (node.d ? IsOpenable(node.d) : false)
    if (guid in md.filteredGuids) {
        if (md.filteredGuids[guid].loaded == true) {
            if (hasChildren && _openable) {
                if (node.d) {
                    return node.d + "_" + TreeViewModeLetter(); ;
                }
            }
            else
                return null;
        }
        md.filteredGuids[guid].loaded = true;
    }
    var e, f, g;
    var _empty = node.y == "E";
    if (treeViewMode == "ALL") {
        var pGuid = parentElement.getAttribute("id");
        var k = pGuid.lastIndexOf("_");
        pGuid = pGuid.substr(0, k);
        var iGuid = (node.d ? node.d : node.i);
        AddItemdesc(modeDescA, modeDescA.filteredGuids, iGuid, "", "-", _empty, false, "", pGuid);
        AddTreeItemToItemDesc(iGuid, true);
    }
    node.element = document.createElement("div");
    f = node.element;
    f.className = "treeControlNode";

    g = f.appendChild(document.createElement("div"));
    g.setAttribute("tpc", guid);

    e = g.appendChild(document.createElement("img"));
    e.setAttribute("srcroot", "../img/outl_" + image);
    if (_empty || (node.d && !_openable)) {
        var esrc = e.getAttribute("srcroot") + ".gif";
        e.className = GetClassNameFromFile(esrc);
        e.openable = false;
        e.src = "../img/empty.gif";
    }
    else {
        esrc = e.getAttribute("srcroot") + (hasChildren ? (IsAutoExpand(e) ? "o.gif" : "c.gif") : ".gif");
        e.className = GetClassNameFromFile(esrc);
        e.src = "../img/empty.gif";
        e.openable = (hasChildren ? (IsAutoExpand(e) ? true : true) : false);
    }

    e = g.appendChild(document.createElement("img"));
    if (bigsco) {
        var stat = GetItemStatus(guid);
        e.className = _GetItemStatusFile(stat);
        e.src = "../img/empty.gif";
        e.title = _GetItemStatusTitle(stat);
        e.alt = _GetItemStatusTitle(stat);
    }
    else {
        e.src = "../img/empty.gif";
        e.className = "sco_empty";
    }

    e = g.appendChild(document.createElement("img"));

    if (_empty) {
        esrc = "../img/emptysection.gif";
        e.className = GetClassNameFromFile(esrc);
        e.src = "../img/empty.gif";

    }
    else {
        esrc = (hasChildren ? ((IsAutoExpand(e) && _openable) ? "../img/module_o.gif" : "../img/module_c.gif") :
							"../img/topic.gif");
        e.src = "../img/empty.gif";
        e.className = GetClassNameFromFile(esrc);

        if (node.y == "Q") {
            e.className = "question_player"; // GetClassNameFromFile("../img/question.gif");
        }
        if (node.y == "A") {
            e.className = "assessment_player"; // GetClassNameFromFile("../img/assessment.gif");
        }

    }
    e = g.appendChild(document.createElement("span"));
    var ee = e.appendChild(document.createElement("a"));
    ee.className = "";
    ee.style.cursor = "pointer";
    ee.onmouseover = this.OnOverItem;
    ee.onmouseout = this.OnOutItem;
    ee.appendChild(document.createTextNode(UnescapeQuotes(node.t)));
    AddTreeItemToItemDesc(guid, ee);

    parentElement.appendChild(f);

    if (hasChildren && _openable) {
        e = node.element.appendChild(document.createElement("table"));
        e.className = "treeControlChildren" + (!IsAutoExpand(node) ? "H" : "V");
        e.cellSpacing = 0;
        e = e.appendChild(document.createElement("tbody"));
        e = e.appendChild(document.createElement("tr"));
        f = e.appendChild(document.createElement("td"));
        //f.className = "treeControlLine" + (last ? "H" : "V") + (bigsco ? "W" : "");
        f.className = (last ? "horz_line" : "vert_line") + (bigsco ? "_wide" : "");
        f = f.appendChild(document.createElement("img"));
        f.src = "../img/empty.gif";
        f.className = "s";  // class for s.gif

        f = e.appendChild(document.createElement("td"));
        if (node.c)
            this.TraverseChildren(node.c, f);
        if (node.d) {
            f.id = node.d + "_" + TreeViewModeLetter();
            return f.id;
        }
    }
    return null;
}

TreeControl.prototype.TraverseChildren = function (children, parentElement) {
    if (!children)
        return;

    var md = getModeDesc();
    var guid = (children[0].d ? children[0].d : children[0].i);
    if (md.loadedGuids[guid])
        return;
    md.loadedGuids[guid] = true;

    var children2 = new Array();
    var childrendivs = new Array();

    for (var c = 0; c < children.length; c++) {
        guid = (children[c].d ? children[c].d : children[c].i);
        if (IsFiltered(guid, treeViewMode))
            children2[children2.length] = children[c];
    }

    if (children2.length > 0) {
        if (parentElement.className == "treeControlNode") {
            if (children2.length == 1) {
                childrendivs[0] = this.TraverseNode(children2[0], parentElement, "r", true);
            }
            else {
                childrendivs[0] = this.TraverseNode(children2[0], parentElement, "f", false);
                var lasti = children2.length - 1;
                for (var i = 1; i < lasti; i++)
                    childrendivs[i] = this.TraverseNode(children2[i], parentElement, "m", false);
                childrendivs[lasti] = this.TraverseNode(children2[lasti], parentElement, "l", true);
            }
        }
        else {
            var lasti = children2.length - 1;
            for (var i = 0; i < lasti; i++)
                childrendivs[i] = this.TraverseNode(children2[i], parentElement, "m", false);
            childrendivs[lasti] = this.TraverseNode(children2[lasti], parentElement, "l", true);
        }
    }

    if (children2.length > 0) {
        if (IsAutoExpand(parentElement, true)) {
            for (var j = 0; j < children2.length; j++) {
                if (children2[j].d && children2[j].y == "S")
                    this.LoadScript(children2[j].d, childrendivs[j])
            }
        }
    }

    for (var j = 0; j < children2.length; j++) {
        var chindex = (children2[j].d ? children2[j].d.substr(37) : children2[j].i.substr(37));
        try {
            chindex = parseInt(chindex, 10);
        }
        catch (e) { };
        if (chindex == _childItem2) {
            _childItem = _childItem2;
            _childItem_found = false;
        }
    }

    if (_childItem != null) {
        var maxindex = children2.length - 1;
        for (var j = 0; j < children2.length; j++) {
            var chindex = (children2[j].d ? children2[j].d.substr(37) : children2[j].i.substr(37));
            try {
                chindex = parseInt(chindex, 10);
            }
            catch (e) { };
            if (chindex > _childItem && j == 0) {
                _childItem = null;
                // FAILED
                break;
            }
            else if (chindex < _childItem && j == maxindex) {
                if (children2[j].d) {
                    this.LoadScript(children2[j].d, childrendivs[j]);
                    break;
                }
                else {
                    _childItem = null;
                    // FAILED
                    break;
                }

            }
            else if (chindex == _childItem) {
                _childItem = null;
                _childItem_found = true;
                SetLastSelected(children2[j].d ? children2[j].d : children2[j].i, "ALL", true);
                // FOUND
                break;
            }
            else if (chindex > _childItem) {
                if (children2[j - 1].d) {
                    this.LoadScript(children2[j - 1].d, childrendivs[j - 1]);
                    break;
                }
                else {
                    _childItem = null;
                    // FAILED
                    break;
                }
            }
        }
    }

}

TreeControl.prototype.OnOverItem = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    if (target.className == "tselected")
        return;
    target.className = "thover";
}

TreeControl.prototype.OnOutItem = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    if (target.className == "tselected")
        return;
    target.className = "";
}

TreeControl.prototype.OnMouseUp = function (event) {
    try {
        if (event.target.nodeName == "A") {
            event.target.focus();
        }
    }
    catch (e) { };
}

TreeControl.prototype.OnClick = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    treeControl.OnClickHandler(event, target);
}

TreeControl.prototype.OnDoubleClick = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    if (!target.tagName)
        target = target.parentNode;
    if (target.tagName == "A" || target.tagName == "IMG") {
        if (target.tagName == "IMG") {
            // todo: prior statement converted to check classes instead of image file names, should be checked whether the statement itself is OK!
            var cl = target.className;
            if (cl.indexOf("topic") < 0 && cl.indexOf("question") < 0 && cl.indexOf("assessment") < 0)
                return;
        }
        var t = target.parentNode.parentNode.firstChild;
        target = t;
        treeControl.OnClickHandler(event, target);
        if (TreeItemDoubleSelected)
            TreeItemDoubleSelected();
    }
    clearTextSelection();
}

function ChangeSelection(e) {
    var ee = (e.tagName == "A" ? e : e.childNodes[0]);
    SetLastSelected(GetTpcAttribute(ee), treeViewMode, false);
    if (treeViewMode == "ALL") {
        if (modeDescA.lastSelected) {
            modeDescA.lastSelected.className = "";
        }
        modeDescA.lastSelected = ee;
        modeDescA.lastSelected.className = "tselected";
    }
    else if (treeViewMode == "FILTERED") {
        if (modeDescF.lastSelected) {
            modeDescF.lastSelected.className = "";
        }
        modeDescF.lastSelected = ee;
        modeDescF.lastSelected.className = "tselected";
    }
    else if (treeViewMode == "FILTEREDHEMI") {
        if (modeDescFH.lastSelected) {
            modeDescFH.lastSelected.className = "";
        }
        modeDescFH.lastSelected = ee;
        modeDescFH.lastSelected.className = "tselected";
    }
    else	//"HEMI"
    {
        if (modeDescH.lastSelected) {
            modeDescH.lastSelected.className = "";
        }
        modeDescH.lastSelected = ee;
        modeDescH.lastSelected.className = "tselected";
    }
}

TreeControl.prototype.SelectFirstItem = function () {
    var hostname = "";
    if (treeViewMode == "ALL")
        hostname = "treeControlHostForAll";
    else if (treeViewMode == "FILTERED")
        hostname = "treeControlHostForFiltered";
    else if (treeViewMode == "FILTEREDHEMI")
        hostname = "treeControlHostForFilteredHemi";
    else	//"HEMI"
        hostname = "treeControlHostForHemi";
    var tpc = "";
    var span;
    var f = document.getElementById(hostname).firstChild;

    if (seeAlsoSelection >= f.childNodes.length) {
        f = f.firstChild;
    }
    else {
        f = f.childNodes[seeAlsoSelection];
    }

    while (tpc == "") {
        try {
            var t = f.getAttribute("tpc");
        }
        catch (e) {
            return;
        }
        if (t) {
            tpc = t;
            span = f.lastChild;
        }
        f = f.firstChild;
    }
    ChangeSelection(span);
    var mode = treeViewMode;
    if (selection_need == 1) {
        mode = "HIDE";
    }
    selection_need = 0;
    if (TreeItemSelected)
        TreeItemSelected(tpc, treeViewMode);
}

TreeControl.prototype.OnClickHandler = function (event, t) {
    var realselect = false;
    var callback = true;
    //	var t = event.target;
    if (!t.tagName)
        t = t.parentNode;
    if (t.tagName == "IMG") {
        var e = t.parentNode.parentNode.lastChild;
        if (e.tagName == "TABLE") // section icon
        {
            var f = t.parentNode.firstChild;

            if (t.openable || f.openable || e.openable) {
                if (e.className == "treeControlChildrenV") {
                    var fsrc = f.getAttribute("srcroot") + "c.gif";
                    f.src = "../img/empty.gif";
                    f.className = GetClassNameFromFile(fsrc);
                    f = f.nextSibling;
                    f = f.nextSibling;
                    f.src = "../img/empty.gif";
                    f.className = GetClassNameFromFile("../img/module_c.gif");
                    e.className = "treeControlChildrenH";
                    _go_closed = true;
                }
                else {
                    fsrc = f.getAttribute("srcroot") + "o.gif";
                    f.src = "../img/empty.gif";
                    f.className = GetClassNameFromFile(fsrc);
                    f = f.nextSibling;
                    f = f.nextSibling;
                    f.src = "../img/empty.gif";
                    f.className = GetClassNameFromFile("../img/module_o.gif");
                    e.className = "treeControlChildrenV";
                    var g = e.firstChild.firstChild.lastChild;
                    if (!g.firstChild) {
                        var goriginal = (g.id.length > 36 ? GetJunctionId(g.id) : g.id);
                        callback = false;
                        treeControl.LoadScript(goriginal, g.id);
                    }
                }
            }
        }
        else	// topic icon
        {
            var e = t.parentNode.lastChild;
            if (e.tagName == "IMG")
                return;
            ChangeSelection(e);
            realselect = true;
        }
    }
    if (t.tagName == "A") // text field in <A> tag
    {
        ChangeSelection(t);
        realselect = true;
    }

    var tpc = t.parentNode.getAttribute("tpc");
    if (tpc == null)
        tpc = t.parentNode.parentNode.getAttribute("tpc");
    if (realselect && TreeItemSelected)
        TreeItemSelected(tpc, treeViewMode);
    if (callback) {
        var n = null;
        try {
            n = f.parentNode.childNodes[f.parentNode.childNodes.length - 1].childNodes[0];
        }
        catch (e) { };
        _childNode_Loaded(n);
    }
}

function GetTableItemForThis(_item) {
    var _tItem = _item.parentNode;
    if (_tItem == null)
        return null;
    while (_tItem.tagName != "TABLE") {
        _tItem = _tItem.parentNode;
        if (_tItem == null)
            return null;
    }
    return _tItem;
}

function ShowTreeItem(guid) {
    var mdActual = getModeDesc(false);
    var mdSource = getModeDesc(true);
    var _item = GetTreeItemOfItemDesc(guid);
    if (_item == null) {
        while (_item == null) {
            var Item = null;
            Item = mdSource.filteredGuids[guid];
            if (Item == null)
                Item = modeDescF.filteredGuids[guid];
            if (Item == null)
                Item = modeDescH.filteredGuids[guid];
            if (Item == null)
                return false;
            guid = Item.parentguid;
            if (guid == null)
                return false;
            _item = GetTreeItemOfItemDesc(guid);
        }
        treeControl.LoadScript(guid, guid + "_" + mdActual.modeLetter);
    }
    return true;
}

function OpenItem(_tItem) {
    if (_tItem.className == "treeControlChildrenH") {
        var f = _tItem.parentNode.firstChild.firstChild;
        f.src = "../img/empty.gif";
        var fscr = f.getAttribute("srcroot") + "o.gif";
        f.className = GetClassNameFromFile(fscr);
        f = f.nextSibling;
        f = f.nextSibling;
        f.src = "../img/empty.gif";
        f.className = GetClassNameFromFile("../img/module_o.gif");
        _tItem.className = "treeControlChildrenV";
    }
}

function ChangeTreeView() {
    var retvalue = false;
    var dA = document.getElementById("treeControlHostForAll");
    var dS = document.getElementById("treeControlHostForFiltered");
    var dSf = document.getElementById("flatControlHostForFiltered");
    var dH = document.getElementById("treeControlHostForHemi");
    var dHf = document.getElementById("flatControlHostForHemi");
    var dFH = document.getElementById("treeControlHostForFilteredHemi");
    var dFHf = document.getElementById("flatControlHostForFilteredHemi");

    if (treeViewMode == "FILTERED") {
        modeDescF.flatMode = !modeDescF.flatMode;
        retvalue = modeDescF.flatMode;
        dS.style.display = (modeDescF.flatMode ? "none" : "block");
        dSf.style.display = (modeDescF.flatMode ? "block" : "none");
    }
    else if (treeViewMode == "HEMI") {
        modeDescH.flatMode = !modeDescH.flatMode;
        retvalue = modeDescH.flatMode;
        dH.style.display = (modeDescH.flatMode ? "none" : "block");
        dHf.style.display = (modeDescH.flatMode ? "block" : "none");
    }
    else	// FILTEREDHEMI
    {
        modeDescFH.flatMode = !modeDescFH.flatMode;
        retvalue = modeDescFH.flatMode;
        dFH.style.display = (modeDescFH.flatMode ? "none" : "block");
        dFHf.style.display = (modeDescFH.flatMode ? "block" : "none");
    }
    ChangeTreeView_CallBack();
    return retvalue;
}

var directMode = false;

function _rec_SearchAInFlat(obj, tpc) {
    if (obj.nodeName == "IMG") {
        var attr = obj.getAttribute("tpc");
        if (attr == tpc) {
            return obj;
        }
    }
    for (var i = 0; i < obj.childNodes.length; i++) {
        var r = _rec_SearchAInFlat(obj.childNodes[i], tpc);
        if (r != null)
            return r;
    }
    return null;
}

function _rec_GetFirstObjInFlat(obj) {
    if (obj.nodeName == "IMG") {
        return obj;
    }
    for (var i = 0; i < obj.childNodes.length; i++) {
        var r = _rec_GetFirstObjInFlat(obj.childNodes[i]);
        if (r != null)
            return r;
    }
    return null;
}

function SetFlatSelection() {
    var mdActual = getModeDesc(false);
    var obj = _rec_SearchAInFlat(mdActual.flatControl.host, _lastSelectedGlobal);
    if (obj == null)
        obj = _rec_GetFirstObjInFlat(mdActual.flatControl.host);
    if (obj != null) {
        mdActual.flatControl.OnClickHandler(null, obj);
        return;
    }
    if (TreeItemSelected)
        TreeItemSelected(null, null);
}

function ChangeTreeView_CallBack() {
    var mdActual = getModeDesc(false);
    var mdSource = getModeDesc(true);
    var _item = null;
    if (mdActual.flatMode == true) {
        SetFlatSelection();
        return true;
    }
    if (mdActual.flatMode == false || treeViewMode == "ALL") {
        var guid = null;
        //	    if (treeViewMode=="ALL")
        //	    {
        //	        guid=_lastSelectedItem.guid;
        //	    }
        //	    else
        //	    {
        //		    guid=mdSource.lastSelectedFlat.getAttribute("tpc");
        //		}
        guid = _lastSelectedGlobal;
        _item = GetTreeItemOfItemDesc(guid);
        if (_item == null) {
            if (!IsFiltered(guid, treeViewMode)) {
                return false;
            }
            directMode = true;
            return ShowTreeItem(guid);
        }
        if (_item != null) {
            var _tItem = GetTableItemForThis(_item);
            while (_tItem != null) {
                OpenItem(_tItem);
                _tItem = GetTableItemForThis(_tItem);
            }
        }
    }
    directMode = false;
    createTreeControl(null, mdActual.flatMode, _item, null, null);
    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FLAT VIEW
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function FlatControl(hostname) {
    this.host = document.getElementById(hostname);
    this.document = (this.host.document ? this.host.document : this.host.ownerDocument);
}

function showOnFlat(desc) {
    var k = parseInt(desc.guid.split("_")[1]);
    if (desc.isroot == true && k == 1)
        return false;
    if (rolefilter_enabled == false)
        return true;
    var ret = false;
    if (typeof (filteredGuidsR[desc.guid]) != "undefined") {
        ret = filteredGuidsR[desc.guid].found;
    }
    return ret;
}

function isInOutline(mydesc, guid) {
    if (mydesc.filteredGuids.length == 0)
        return true;
    var p = mydesc.filteredGuids[guid].parentguid;
    if (p == null)
        return false;
    var a = p.split("_");
    if (a[1] == "1")
        return true;
    else
        return isInOutline(mydesc, p);
}

function getModeDesc(source) {
    if (source == null)
        source = false;
    var mode = (source == true ? _lastSelectedGlobalMode : treeViewMode);
    if (mode == "ALL") {
        return modeDescA;
    }
    else if (mode == "FILTERED") {
        return modeDescF;
    }
    else if (mode == "HEMI") {
        return modeDescH;
    }
    else if (mode == "FILTEREDHEMI") {
        modeDescFH.guidsForFlat = new Array();
        for (var i = 0; i < modeDescF.guidsForFlat.length; i++) {
            var guidF = modeDescF.guidsForFlat[i];
            for (var j = 0; j < modeDescH.guidsForFlat.length; j++) {
                var guidH = modeDescH.guidsForFlat[j];
                if (guidF.guid == guidH.guid) {
                    modeDescFH.guidsForFlat[modeDescFH.guidsForFlat.length] = guidF;
                }
            }
        }
        modeDescFH.filteredGuids = new Array();
        modeDescFH.filteredGuidList = new Array();
        for (var i = 0; i < modeDescF.filteredGuidList.length; i++) {
            guidF = modeDescF.filteredGuidList[i]
            for (var j = 0; j < modeDescH.filteredGuidList.length; j++) {
                guidH = modeDescH.filteredGuidList[j];
                if (guidF.guid == guidH.guid) {
                    if (modeDescFH.filteredGuids[guidF] == undefined)
                        modeDescFH.filteredGuids[guidF] = new Object();
                    modeDescFH.filteredGuids[guidF].guid = guidF;
                    modeDescFH.filteredGuids[guidF].context = modeDescH.filteredGuids[guidH].context;
                    modeDescFH.filteredGuidList.push(guidF);
                }
            }
        }
        return modeDescFH;
    }
    return null;
}

function saveModeDesc(md) {
    if (treeViewMode == "ALL") {
        modeDescA = md;
    }
    else if (treeViewMode == "FILTERED") {
        modeDescF = md;
    }
    else if (treeViewMode == "HEMI") {
        modeDescH = md;
    }
    else if (treeViewMode == "FILTEREDHEMI") {
        modeDescFH = md;
    }
}

FlatControl.prototype.Load = function () {
    var myDesc = getModeDesc(false);
    this.host.innerHTML = "";

    var div = this.host.appendChild(this.document.createElement("div"));
    div.className = "treeControlNode";
    div.onclick = this.OnClick;
    div.ondblclick = this.OnDoubleClick;
    div.onmouseup = this.OnMouseUp;
    var table = div.appendChild(this.document.createElement("table"));
    table.cellSpacing = 0;
    var first = true;
    var showCt = 0;
    var z = [];
    UserPrefs.LoadCookie();
    var SHOWDEBUG = (Debug.EnableShowDiagnostics == true && UserPrefs.EnableShowDiagnostics == true) || Debug.is_ta_debug;
    //Debug.is_ta_debug is a hidden way to get the test data, when no access to the config.js
    for (var i = 0; i < myDesc.guidsForFlat.length; i++) {
        var itemdesc = myDesc.guidsForFlat[i];
        if (showOnFlat(itemdesc) && isInOutline(myDesc, itemdesc.guid)) {
            showCt++;
            if (showCt > TreeConfig.SearchResultLimit)
                continue;
            myDesc.actualFlatCounter = showCt;
            var tr = table.appendChild(this.document.createElement("tbody"));
            tr = tr.appendChild(this.document.createElement("tr"));
            var td = tr.appendChild(this.document.createElement("td"));
            var img = td.appendChild(this.document.createElement("img"));
            var esrc = (itemdesc.type == "Topic" ? "../img/topic.gif" : (itemdesc.empty ? "../img/emptysection.gif" : "../img/module_c.gif"));
            img.className = GetClassNameFromFile(esrc);
            img.src = "../img/empty.gif";
            img.setAttribute("tpc", itemdesc.guid);
            td = tr.appendChild(this.document.createElement("td"));
            td.className = "treeControlNode flatControl";
            var a = td.appendChild(this.document.createElement("a"));
            if (first == true) {
                myDesc.lastSelectedFlat = a;
                saveModeDesc(myDesc);
            }
            a.className = (first == true ? "tselected" : "");
            if (first == true && _lastChangeIsFilterOnly == false) {
                SetLastSelected(itemdesc.guid, treeViewMode, false);
            }
            first = false;
            a.style.cursor = "pointer";
            a.setAttribute("tpc", itemdesc.guid);
            a.onmouseover = this.OnOverItem;
            a.onmouseout = this.OnOutItem;
            var str = itemdesc.title;
            if (SHOWDEBUG && treeViewMode == "HEMI") {
                var q = CreateItemStr(itemdesc);
                z.push(q);
                str += ' [';
                for (var k = 0; k < q['info'].length; k++) {
                    str += '{a:' + q['info'][k].a + ' c:' + q['info'][k].c + ' w:' + parseInt(q['info'][k].w * 100) + '} ';
                }
                str += ' {' + q['o'] + '}]';
            }
            a.appendChild(this.document.createTextNode(str));
        }
    }

    if (SHOWDEBUG) {
        XdTransfer.PostMessage(window.parent, 'oraupk-debuginfo_outlinedata', { 'data': z });
    }

    if (myDesc.flatMode == true) {
        SetFlatSelection();
    }
    var tpc = null;
    try {
        tpc = myDesc.lastSelectedFlat.getAttribute("tpc");
    }
    catch (e) { };
    if (TreeItemSelected)
        TreeItemSelected(tpc, treeViewMode);

    function CreateItemStr(itemdesc) {
        var q = { 'o': itemdesc.guid, 'info': [], 't': itemdesc.title };
        var g = itemdesc.guid.split("_")[0];
        var d = modeDescA.foundItemMap[g];
        if (d != null) {
            for (var i = 0; i < d.cindexes.length; i++) {
                var z = {};
                z['a'] = d.cindexes[i].cindex;
                z['c'] = d.cindexes[i].cindex - d.cindexes[i].nullindex;
                z['w'] = d.cindexes[i].score;
                q['info'].push(z);
            }
        }
        return q;
    }
}

FlatControl.prototype.OnOverItem = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    if (target.className == "tselected")
        return;
    target.className = "thover";
}

FlatControl.prototype.OnOutItem = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    if (target.className == "tselected")
        return;
    target.className = "";
}

FlatControl.prototype.OnMouseUp = function (event) {
    try {
        if (event.target.nodeName == "A") {
            event.target.focus();
        }
    }
    catch (e) { };
}

FlatControl.prototype.OnClick = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    var mdActual = getModeDesc(false);
    mdActual.flatControl.OnClickHandler(event, target);
}

FlatControl.prototype.OnDoubleClick = function (event) {
    if (!event)
        event = window.event;
    var target = event.target;
    if (!target)
        target = event.srcElement;
    var mdActual = getModeDesc(false);
    mdActual.flatControl.OnClickHandler(event, target);
    if (TreeItemDoubleSelected)
        TreeItemDoubleSelected();
}

FlatControl.prototype.OnClickHandler = function (event, target) {
    var a = target;
    var t = GetTpcAttribute(a);
    if (t != null)
        SetLastSelected(t, treeViewMode, false);
    if (target.tagName != "A" && target.tagName != "IMG")
        return;
    if (target.tagName != "A") {
        var tr = target.parentNode.parentNode;
        for (var i = 0; i < tr.childNodes.length; i++) {
            var k = tr.childNodes[i].childNodes[0];
            if (k.tagName == "A") {
                a = k;
                continue;
            }
        }
    }
    if (treeViewMode == "FILTERED") {
        modeDescF.lastSelectedFlat.className = "";
    }
    else if (treeViewMode == "HEMI") {
        modeDescH.lastSelectedFlat.className = "";
    }
    else	// FILTEREDHEMI
    {
        modeDescFH.lastSelectedFlat.className = "";
    }
    a.className = "tselected";
    if (treeViewMode == "FILTERED") {
        modeDescF.lastSelectedFlat = a;
    }
    else if (treeViewMode == "HEMI") {
        modeDescH.lastSelectedFlat = a;
    }
    else	// FILTEREDHEMI
    {
        modeDescFH.lastSelectedFlat = a;
    }
    var tpc = a.getAttribute("tpc");
    if (TreeItemSelected)
        TreeItemSelected(tpc, treeViewMode);
}

function GetActualFlatView() {
    var md = getModeDesc(false);
    return md.flatMode;
}

function GetActualFlatItemCounter() {
    var md = getModeDesc(false);
    return md.actualFlatCounter;
}

function IsActualViewEmpty() {
    var md = getModeDesc(false);
    if (md.filteredGuidList.length == 0)
        return true;
    if (md.flatMode == true && $("#chroles").prop("checked") == true) {
        for (var i = 0; i < md.guidsForFlat.length; i++) {
            var g = md.guidsForFlat[i].guid;
            var ret = false;
            if (typeof (filteredGuidsR[g]) != "undefined") {
                ret = filteredGuidsR[g].found;
            }
            if (ret == true)
                return false;
        }
        return true;
    }
    return false;
}

//////////////////////////////////////////////////////////////////////////////////////////

function getActualIndex_Flat() {
    var md = getModeDesc(false);
    if (md.flatMode == true) {
        for (var i = 0; i < md.flatControl.host.firstChild.firstChild.childNodes.length; i++) {
            if (md.flatControl.host.firstChild.firstChild.childNodes[i].firstChild.childNodes[1].firstChild.className == "tselected") {
                return i;
            }
        }
    }
    return -1;
}

function getActualIndex_Tree(ls, md) {
    for (var i = 0; i < ls.length; i++) {
        if (ls[i].firstChild.childNodes[3].firstChild.className == "tselected") {
            return i;
        }
    }
    if (md.lastSelected != null) {
        var _tpc = md.lastSelected.parentNode.parentNode.getAttribute("tpc");
        for (var i = 0; i < ls.length; i++) {
            if (ls[i].firstChild.getAttribute("tpc") == _tpc)
                return i;
        }
    }
    return -1;
}

function getTargetForIndex_Flat(md, i) {
    return md.flatControl.host.firstChild.firstChild.childNodes[i].firstChild.firstChild.firstChild;
}

var ls;

function getTargetForIndex_Tree(i) {
    return ls[i].firstChild.childNodes[3].firstChild;
}

function getActualImageObj_Tree(md) {
    return md.lastSelected.parentNode.parentNode.firstChild;
}

function getSpecifiedImageObj_Tree(ls, k) {
    return ls[k].firstChild.firstChild;
}

function getOwnerOfSelection() {
    var md = getModeDesc(false);
    var myid = md.lastSelected.parentNode.parentNode.parentNode.childNodes[0].getAttribute("tpc");
    var owner = md.filteredGuids[myid].parentguid;
    return owner;
}

function getOpenedStatus(obj) {
    /*
    s = obj.getAttribute("src");
    k = s.indexOf(".gif");
    c = s.substr(k - 1, 1);
    */
    var s = obj.className;
    var c = s.substr(s.length - 1, 1);
    return (c == "o");
}

function getFilteredStatus(guid) {
    var r = IsFiltered(guid, "ALL");
    return !r;
}

function _getLinearStructure_Recursive(o, a) {
    a[a.length] = o;
    var _imgObj = o.firstChild.firstChild;
    if (getOpenedStatus(_imgObj) == true) {
        for (var i = 0; i < o.childNodes[1].firstChild.firstChild.childNodes[1].childNodes.length; i++) {
            _getLinearStructure_Recursive(o.childNodes[1].firstChild.firstChild.childNodes[1].childNodes[i], a);
        }
    }
}

function getRoot(o) {
    if (o.tagName == "DIV" && o.id.substr(0, 15) == "treeControlHost")
        return o.firstChild;
    return getRoot(o.parentNode);
}

function getLinearStructure_Tree(md) {
    var oArray = new Array();
    var root = getRoot(md.lastSelected);
    //    root = treeControl.host.firstChild;
    for (var i = 0; i < root.childNodes.length; i++) {
        _getLinearStructure_Recursive(root.childNodes[i], oArray);
    }
    return oArray;
}

function EventKeyDown(event) {
    if (event == null)
        event = window.event;
    var code = event.which ? event.which : event.keyCode;
    if (code == 13) {
        if (TreeItemDoubleSelected && _inputHasFocus != true)
            TreeItemDoubleSelected();
        return;
    }
    var md = getModeDesc(false);
    if (md.flatMode == true) {
        var index = getActualIndex_Flat();
        if (code == 38) {  // up
            if (index > 0) {
                var t = getTargetForIndex_Flat(md, index - 1);
                md.flatControl.OnClickHandler(null, t);
            }
        }
        else if (code == 40) {  // down
            if (index < md.actualFlatCounter - 1) {
                t = getTargetForIndex_Flat(md, index + 1);
                md.flatControl.OnClickHandler(null, t);
            }
        }
    }
    else {
        var imgObj = getActualImageObj_Tree(md);
        var _isOpenable = (imgObj.openable ? imgObj.openable : imgObj.getAttribute("openable"));
        var _isOpened = getOpenedStatus(imgObj);
        ls = getLinearStructure_Tree(md);
        index = getActualIndex_Tree(ls, md);
        if (code == 37) {  // left
            if (_isOpenable == true) {
                if (_isOpened == true) {
                    treeControl.OnClickHandler(null, imgObj);
                    return false;
                }
            }
        }
        else if (code == 38) {  // up
            if (index > 0) {
                t = getTargetForIndex_Tree(index - 1);
                treeControl.OnClickHandler(null, t);
            }
        }
        else if (code == 39) {  // right
            if (_isOpenable == true) {
                if (_isOpened == false) {
                    treeControl.OnClickHandler(null, imgObj);
                    return false;
                }
            }
        }
        else if (code == 40) {  // down
            if (index < ls.length - 1) {
                t = getTargetForIndex_Tree(index + 1);
                treeControl.OnClickHandler(null, t);
            }
        }
    }
}

function tree_SetFocus() {
    document.frames[0].document.childNodes[1].childNodes[1].focus();
}

function tree_Init() {
    document.onkeydown = EventKeyDown;
    if (Init_treeloaded)
        Init_treeloaded();
}

function clearTextSelection() {
    if (document.selection)
        document.selection.empty();
    if (window.getSelection)
        window.getSelection().removeAllRanges();
}

function GoToNext() {
    var md = getModeDesc(false);
    if (md.flatMode == true) {
        var index = getActualIndex_Flat();
        if (index < md.actualFlatCounter - 1) {
            var t = getTargetForIndex_Flat(md, index + 1);
            md.flatControl.OnClickHandler(null, t);
        }
    }
    else {
        var imgObj = getActualImageObj_Tree(md);
        var _isOpenable = (imgObj.openable ? imgObj.openable : imgObj.getAttribute("openable"));
        var _isOpened = getOpenedStatus(imgObj);
        ls = getLinearStructure_Tree(md);
        index = getActualIndex_Tree(ls, md);
        if (index < ls.length - 1) {
            t = getTargetForIndex_Tree(index + 1);
            treeControl.OnClickHandler(null, t);
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////

function TreeNavigator() {
    this.GoForward = function () {
        Navigation_Down();
    }
    this.GoBack = function () {
        Navigation_Up();
    }
    this.isForwardEnabled = function () {
        return !isLastItem();
    }
    this.isBackEnabled = function () {
        return !isFirstItem();
    }
}
var treeNavigator = new TreeNavigator();

var _go_next = false;
var _go_prev = false;
var _go_closed = false;

function Navigation_Up() {
    var md = getModeDesc(false);
    if (md.flatMode == false) {
        ls = getLinearStructure_Tree(md);
        var index = getActualIndex_Tree(ls, md);
        var prevImgObj = getSpecifiedImageObj_Tree(ls, index - 1);
        var _isOpenable = Bool(prevImgObj.openable != undefined ? prevImgObj.openable : prevImgObj.getAttribute("openable"));
        var _isOpened = getOpenedStatus(prevImgObj);
        if (_isOpenable && !_isOpened) {
            _go_prev = true;
            treeControl.OnClickHandler(null, prevImgObj);
            return;
        }
    }

    var e = { keyCode: 38 };
    EventKeyDown(e);
}

function Navigation_Down() {
    var md = getModeDesc(false);
    if (md.flatMode == false) {
        var imgObj = getActualImageObj_Tree(md);
        var _isOpenable = Bool(imgObj.openable != undefined ? imgObj.openable : imgObj.getAttribute("openable"));
        var _isOpened = getOpenedStatus(imgObj);
        if (_isOpenable && !_isOpened) {
            _go_next = true;
            var e = { keyCode: 39 };
            EventKeyDown(e);
            return;
        }
    }
    var e = new Object();
    e.keyCode = 40;
    EventKeyDown(e);
}

function isFirstItem() {
    var md = getModeDesc(false);
    if (md.flatMode == true) {
        var index = getActualIndex_Flat();
    }
    else {
        if (md.lastSelected == null)
            return true;
        ls = getLinearStructure_Tree(md);
        index = getActualIndex_Tree(ls, md);
    }
    return (index == 0);
}

function isLastItem() {
    var md = getModeDesc(false);
    if (md.flatMode == true) {
        var index = getActualIndex_Flat();
        return (index == md.filteredTopicCount - 1);
    }
    else {
        if (md.lastSelected == null)
            return false;
        ls = getLinearStructure_Tree(md);
        index = getActualIndex_Tree(ls, md);
        if (index == ls.length - 1) {
            var imgObj = getActualImageObj_Tree(md);
            var _isOpenable = imgObj.openable;
            return (_isOpenable == false);
        }
        return false;
    }
}

function _childNode_Loaded(node) {
    if (_go_next == true) {
        _go_next = false;
        Navigation_Down();
    }
    if (_go_prev == true) {
        var md = getModeDesc(false);
        if (md.flatMode == false) {
            ls = getLinearStructure_Tree(md);
            var index = getActualIndex_Tree(ls, md);
            var prevImgObj = getSpecifiedImageObj_Tree(ls, index - 1);
            var _isOpenable = Bool(prevImgObj.openable != undefined ? prevImgObj.openable : prevImgObj.getAttribute("openable"));
            var _isOpened = getOpenedStatus(prevImgObj);
            if (_isOpenable && !_isOpened) {
                _go_prev = true;
                treeControl.OnClickHandler(null, prevImgObj);
                return;
            }
            else {
                _go_prev = false;
                Navigation_Up();
            }
        }
    }
    if (_go_closed == true) {
        _go_closed = false;
        md = getModeDesc(false);
        if (md.flatMode == false) {
            ls = getLinearStructure_Tree(md);
            index = getActualIndex_Tree(ls, md);
            if (index == -1) {
                treeControl.OnClickHandler(null, node);
            }
        }
    }
}

///////////////////////////////////////////////////////////////////////////////

var indexMap = new Array();
var treeIndex = new Array();

function AddToIndexMap(s) {
    if (bigsco == false)
        return;
    if (s.length <= 36)
        return;
    var guid = s.substr(0, 36);
    var index = s.substr(37);
    indexMap[index] = guid;
}

var _tocStates2 = null;
var _tocStates_initialized = false;

function InitTocStates() {
    if (_tocStates_initialized)
        return;
    _tocStates_initialized = true;
    if (bigsco == false)
        return;

    for (var i = 0; i < parentIndex.length; i++) {
        treeIndex[i] = new Array();
        treeIndex[i][0] = parentIndex[i];
    }
    for (var i = 0; i < parentIndex.length; i++) {
        var v = parentIndex[i];
        treeIndex[v][treeIndex[v].length] = i;
    }

    _tocStates2 = new Array();
    for (var i = 0; i < lms_TOCState.NodeCounter; i++) {
        _tocStates2[i] = lms_GetItemStatus(i);
    }
    InitOneItemState(childIndexLocal2Global(0));
    var a = lms_GetItemStatus(0);
    var b = _tocStates2[0];
    if (a != b) {
        lms_SetItemStatus(0, b);
    }
    updateTreeTrace()
}

// global index parameter
function InitOneItemState(k) {
    var ch = index_getChildList(k, false);
    for (var i = 0; i < ch.length; i++) {
        InitOneItemState(ch[i]);
    }
    var x = childIndexGlobal2Local(k);
    if (k != 0)
        _tocStates2[k] = BuildItemStatus(k);
}

function GetItemStatus(guid) {
    var g_index = guid.substr(37);
    var l_index = childIndexGlobal2Local(g_index);
    var s = BuildItemStatus(g_index);
    _tocStates2[l_index] = s;
    return s;
}

function _GetItemStatusFile(status) {
    var base = "";
    switch (status) {
        case "N": return base + "sco_notstarted";
        case "I": return base + "sco_incomplete";
        case "C": return base + "sco_completed";
        case "P": return base + "sco_passed";
        case "F": return base + "sco_failed";
    }
    return "";
}

function _GetItemStatusTitle(status) {
    switch (status) {
        case "N": return R_status_tree_notstarted;
        case "I": return R_status_tree_inprogress;
        case "C": return R_status_tree_complete;
        case "P": return R_status_tree_passed;
        case "F": return R_status_tree_failed;
    }
    return "";
}

// local index parameter
function UpdateItemStatus(index) {
    _tocStates2[index] = lms_GetItemStatus(index);
    var i = childIndexLocal2Global(index);
    var guid = indexMap[i] + "_" + i;
    RefreshItemStatus(guid);
    BuildRootItemStatus();
    updateTreeTrace();
}

function RefreshItemStatus(guid) {
    if (bigsco == false)
        return;
    var md = getModeDesc(guid);

    var item = md.filteredGuids[guid];
    if (item == null)
        return;

    var stat = GetItemStatus(guid);
    item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("src", "../img/empty.gif");
    var _itemState = _GetItemStatusFile(stat);
    item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("class", _itemState); // for FF, Chrome, Safari
    item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("className", _itemState); // for IE
    item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("title", _GetItemStatusTitle(stat));
    item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("alt", _GetItemStatusTitle(stat));

    if (item.parentguid == null)
        return;
    RefreshParentItemStatus(item.parentguid);
}

function RefreshParentItemStatus(guid) {
    var g_index = guid.substr(37);
    var l_index = childIndexGlobal2Local(g_index);
    var st0 = _tocStates2[l_index];
    var st1 = BuildItemStatus(g_index);
    if (l_index == 0) {
        if (st1 == "N") {
            return;
        }
    }
    if (st1 != st0) {
        //        parent.lms_SetItemStatus(l_index, st1);
        _tocStates2[l_index] = st1;
        if (l_index == 0) {
            lms_SetItemStatus(0, st1);
        }
        updateTreeTrace();
        var md = getModeDesc(guid);
        var item = md.filteredGuids[guid];
        if (item == null)
            return;
        item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("src", "../img/empty.gif");
        var _itemState = _GetItemStatusFile(st1);
        item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("class", _itemState); // for FF, Chrome, Safari
        item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("className", _itemState); // for IE
        item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("title", _GetItemStatusTitle(st1));
        item.treeitemdiv.parentNode.parentNode.childNodes[1].setAttribute("alt", _GetItemStatusTitle(st1));
        if (item.parentguid != null)
            RefreshParentItemStatus(item.parentguid);
    }
}

function getBaseIndex() {
    return parseInt(_rootData.substr(37));
}

function childIndexLocal2Global(x) {
    return (parseInt(x) + getBaseIndex());
}

function childIndexGlobal2Local(x) {
    return (x - getBaseIndex());
}

function index_getParent(x) {
    if (!index_checkIndex(x))
        return -1;
    return treeIndex[x][0];
}

function index_getChildList(x, f) {
    if (!index_checkIndex(x))
        return [];
    var a0 = treeIndex[x];
    var a = new Array();
    for (var i = 1; i < a0.length; i++) {
        if (!f)
            a[i - 1] = a0[i];
        else if (f != a0[i])
            a[i - 1] = a0[i];
    }
    return a;
}

function index_hasChildren(x) {
    if (!index_checkIndex(x))
        return -1;
    var a0 = treeIndex[x];
    return (a0.length > 1);
}

function index_checkIndex(x) {
    if (x > treeIndex.length - 1)
        return false;
    return (treeIndex[x].length > 0);
}

// global index parameter
function BuildItemStatus(x) {
    var l_x = childIndexGlobal2Local(x);
    var s = BuildItemStatus2(x, l_x);
    return s;
}

function BuidStatus(s, haschild) {
    if (s.indexOf("I") >= 0)
        return "I";
    if (s.indexOf("N") >= 0) {
        if (s.indexOf("C") >= 0 || s.indexOf("F") >= 0 || s.indexOf("P") >= 0)
            return "I";
        else
            return "N";
    }
    if (s.indexOf("F") >= 0) {
        if (haschild == false)
            return "F";
        else
            return "C";
    }
    if (s.indexOf("P") >= 0) {
        if (haschild == false)
            return "P";
        else
            return "C";
    }
    return "C";
}

function BuildItemStatus2(x, l_x) {
    var ch = index_getChildList(x, false);
    var s = "";
    if (l_x != 0) {
        if (conceptIndex[x] > 0)
            s += lms_GetItemStatus(l_x);
    }
    for (var i = 0; i < ch.length; i++) {
        s += _tocStates2[childIndexGlobal2Local(ch[i])];
    }
    var _stat = BuidStatus(s, ch.length > 0);
    return _stat;
}

function BuildRootItemStatus() {
    var x = childIndexLocal2Global(0);
    var ch = index_getChildList(x, false);
    var s = "";
    for (var i = 0; i < ch.length; i++) {
        s += _tocStates2[childIndexGlobal2Local(ch[i])];
    }
    var _stat = BuidStatus(s, ch.length > 0);
    _tocStates2[0] = _stat;
}

/************************************************************************************/

var treeTraceOn = false;
var treeTraceWnd = null;

function updateTreeTrace() {
    try {
        if (!treeTraceOn)
            return;
        if (treeTraceWnd == null)
            treeTraceWnd = window.open();
        treeTraceWnd.document.body.innerHTML = "";
        for (var i = 0; i < _tocStates2.length; i++) {
            treeTraceWnd.document.write(" " + i + ": " + _tocStates2[i] + " - " + lms_GetItemStatus(i) + "<br/>");
        }
    }
    catch (e) { };
}

/*
return {
tree_Init: tree_Init
};

})();
*/

/* relativelink.js */
// Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.

// Split an URI into three main parts
function splitUri(uri) {
    // Split the URI into parts
    var parts = uri.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
    parts.shift();

    // Identidy tge different parts
    var scheme = parts[1], authority = parts[3], path = parts[4], querystring = parts[6], frag = parts[8];

    // Build the three main part of the URI: prefix, path, postfix
    parts = [scheme + "://" + authority, path, querystring + frag];

    // Return the three main parts as an array
    return parts;
}

// Combine base and relative URL into a resolved URL
function combine(baseUrl, relativeUrl) {

    // Remove the "odrel://" prefix if exists
    var relativePath = relativeUrl;
    if (relativePath.indexOf('odrel://') == 0)
        relativePath = relativePath.substr('odrel://'.length);

    // Empty relative path points to base path
    if (relativePath == "") relativePath = ".";

    // Split the base url into the main three parts
    var baseUrlparts = splitUri(baseUrl);
    var baseUrlPrefix = baseUrlparts[0]; var baseUrlPath = baseUrlparts[1];

    // Trim slashes
    if (baseUrlPath.charAt(0) == '/') baseUrlPath = baseUrlPath.substr(1);
    if (baseUrlPath.charAt(baseUrlPath.length - 1) == '/') baseUrlPath = baseUrlPath.substr(0, baseUrlPath.length - 1);
    if (relativePath.charAt(relativePath.length - 1) == '/') relativePath = relativePath.substr(0, relativePath.length - 1);

    // Split the paths into segments
    var baseUrlPathSegments = baseUrlPath.split('/');
    var relativePathSegments = relativePath.split('/');

    if ((relativePathSegments.length > 2) && (relativePathSegments[0] == '') && (relativePathSegments[1] == '')) {
        var path = baseUrlPrefix.split(':')[0] + ":/";
        for (var i = 2; i < relativePathSegments.length; i++)
            path += "/" + relativePathSegments[i];

        return path;
    }

    // Initialize the segments of the resolved path
    var resolvedPathSegments = new Array();
    for (var i = 0; i < baseUrlPathSegments.length; i++)
        resolvedPathSegments[i] = baseUrlPathSegments[i];

    // Resolve the relative address
    for (var i = 0; i < relativePathSegments.length; i++) {
        if (relativePathSegments[i] == "..") {
            if (resolvedPathSegments.length > 0) {
                // Remove the last folder in the URI
                resolvedPathSegments = resolvedPathSegments.slice(0, resolvedPathSegments.length - 1);
            }
        }
        else if (relativePathSegments[i] == ".") {
            // Do nothing
        }
        else if (relativePathSegments[i] == "") {
            // Remove all segments from the base URL
            resolvedPathSegments = new Array();
        }
        else {
            // Add the segment to the end of the resolved address
            resolvedPathSegments[resolvedPathSegments.length] = relativePathSegments[i];
        }
    }

    // Build the resolved path
    var resolvedPath = '';
    for (var i = 0; i < resolvedPathSegments.length; i++)
        resolvedPath += '/' + resolvedPathSegments[i];
    var resolvedUrl = baseUrlPrefix + resolvedPath;

    // Return the resolved URI
    return resolvedUrl;
}

// Get the root URL of the player (folder of the index.html)
function getRootUrl() {

    // If the function is running in toc.html
    if (typeof (isTocHtml) != "undefined") {
        var url = document.location.href;
        return url.substr(0, url.lastIndexOf("/"));
    }

    // Split the URL of current document into parts
    var documentUrlParts = splitUri(document.location.href);
    var documentUrlPrefix = documentUrlParts[0];
    var documentUrlPath = documentUrlParts[1];

    // Trim the document path
    if (documentUrlPath.charAt(0) == '/') documentUrlPath = documentUrlPath.substr(1);

    // Split the document URL path into segments
    var documentPathSegments = documentUrlPath.split('/');

    // Find the tpc folder in the document path
    var i;
    for (i = documentPathSegments.length - 1; documentPathSegments[i] != 'tpc' && i >= 0; i--) { };

    if (i > 0) i = i - 1;

    // Build the path of the root URL
    var rootPath = "";
    for (var j = 0; j < i; j++)
        rootPath += "/" + documentPathSegments[j];

    // Build the root URL
    var rootUrl = documentUrlPrefix + rootPath;

    // Return the root URL
    return rootUrl;
}

function isRelative(uri) {
    // Split the URI into parts
    var parts = uri.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);

    // If there is no scheme in the uri, then it's relative
    return (parts[1] == '') || (parts[1] == undefined);
}

// Checks the url and resolves if it is relative
function resolveIfRelative(Url) {
    if (Url.indexOf("odrel://") == 0)
        return resolve(Url);
    else
        return Url;
}

// Resolve a relative URL based on the configured base address
function resolve(relativeUrl) {

    // If the base URL is relative
    if (isRelative(PlayerConfig.BaseUrl)) {
        // Get the URL of the player root
        var rootUrl = getRootUrl();
        // Get hte basolute base URL
        var absoluteBaseUrl = combine(rootUrl, PlayerConfig.BaseUrl);
        // Resolve the relative URL
        return combine(absoluteBaseUrl, relativeUrl);
    }
    // If the base URL is absolute
    else {
        // Resolve the relative URL
        return combine(PlayerConfig.BaseUrl, relativeUrl);
    }
}

// Resolve all link in a web page
function resolveLinksInWebPage() {
    // Get the links from the document
    var links = document.getElementsByTagName("a");

    // For each link
    for (var i = 0; i < links.length; i++)
    // If the link is relative        
        if (links[i].getAttribute("href").indexOf('odrel://') == 0) {
        // Resolve the URL
        links[i].href = resolve(links[i].getAttribute("href"));
    }
}
/* lmsapplet.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

// the following code must exist for AICC
// Only add the java applet to the page when running a course through HACP.

var intPos = window.location.search.toLowerCase().indexOf("aicc_url");
var intPos2 = window.location.search.toLowerCase().indexOf("aicc_sid");
function getOnlyPath(s) {
    while (s.indexOf('\\') != -1)
        s = s.replace('\\', '/');
    return s.substr(0, s.lastIndexOf("/"));
}
if ((intPos>-1) && (intPos2>-1)) {
	//running in AICC mode
	if (LmsConfig.AiccAppletPath == "") {
		//using applet from package
        var currentPgPath = window.location.protocol + "//" + window.location.host + getOnlyPath(window.location.pathname);
		fullPath = currentPgPath + "/" + lms_path + "aicc";
	}
	else {
		//using applet from predeifned location
	    fullPath = LmsConfig.AiccAppletPath;
	}

	document.write("<div style='position: absolute;'><applet NAME='GetHTTPPostData' codebase='" + fullPath + "' archive='gethttppostdata.jar' code='GetHTTPPostData' width='1' height='1' MAYSCRIPT><param name='permissions' value='sandbox' /></applet></div>");
}

/* lmscomfactory.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

// This function is reposible for inserting
// the KPath API into the environment if
// the asset is running under KPath and 
// no API can currently be found. 
//
// This call inserts an invisible iframe and 
// sets its source to a HTML page that will 
// contains the KPATH Scorm API adaptor when
// the page is configured to run under Kpath UT.
//
// Since invisible iframe page will load asyncronously
// we have to tie the LmsCom creation with the 
// onload of the iframe.
function InsertRuntimeAPI(loadcallback) {

    /* If we are not running with Kpath we do not have
       to insert the API so just directly call the
       load callback. */ 
    if (Kpath_launch == false) {
        setTimeout(loadcallback, 1);
        return;
    }

    /* We are running under KPath, check to see if
    the frame hosting the low level KPath
    API adaptor has been loaded somewhere.
    If so, do nothing else but directly
    call the load call back.
       
    Else we have to asynchronously load the
    API frame into the environment */
    var apiframe = findKPathAPIFrame(window);

    if (apiframe == null) {
        apiframe = document.createElement("iframe");
        apiframe.id = "KPATH_API_FRAME";
        apiframe.style.display = 'none';

        document.body.appendChild(apiframe);

        if (loadcallback) {
            if (navigator.appName == "Microsoft Internet Explorer")
                apiframe.attachEvent("onload", loadcallback);
            else
                apiframe.onload = loadcallback;

        }

        apiframe.src = Kpath_Runtime_API;
    }
    else
        setTimeout(loadcallback, 1);
}

function findKPathAPIFrame(win) {
    var apiframe = null;
    var depth = 0;
    var w = win;

    try {
        while (w != null) {
            apiframe = w.document.getElementById("KPATH_API_FRAME");
    
            if (apiframe != null)
                return apiframe.contentWindow;
    
            depth++;
            // Note: 7 is an arbitrary number, but should
            // be more than sufficient
            if (depth > 7) {
                break;
            }
    
            if (w === w.parent) break;
            w = w.parent;
        }
    
        if (win.top.opener != null)
            return findKPathAPIFrame(win.top.opener);
    } catch (e) {
        return null;
    }


    return null;
}

var _GlobalLmsComFactory = null; 

function GetLmsComFactory() {

    if (_GlobalLmsComFactory == null)
        alert(R_initializelmscom_not_called);
        
    return _GlobalLmsComFactory;
}


function CheckForLMSAPI() {
    if (_lmsMode == "LMS" &&
            !(_GlobalLmsComFactory.api_type == "scorm2004" ||
              _GlobalLmsComFactory.api_type == "scorm12" ||
              _GlobalLmsComFactory.api_type == "aicc" ||
              (_GlobalLmsComFactory.api_type == "kpath" && findKPathAPIFrame(window))
            )
        )
            alert(R_scorm_noapi);
    if (_lmsMode == "KPT" && !findKPathAPIFrame(window))
        alert(R_scorm_noapi);
}


function InitializeLmsCom() {
    _GlobalLmsComFactory = new LmsComFactory(window.location.search);
}

/* LmsComFactory uses environmental information like URL  parameters
   and runtime variables to determine which type of LmsCom object
   it should instantiated.  Note that code outside of the JS file 
   should use GetLmsCom instead since GetLmsCom has logic in it 
   that allows the parent page to provide the LmsCom object if 
   it wants to. */ 
function LmsComFactory(launcharg) {
    var fname = "LmsComFactory";

    this.api_type = "none";
    
    this.launch_arg = launcharg;
    this.aicc_url = "";
    this.aicc_sid = "";

    //maintain the api pointer if found so that lmscomscorm constructors can use it
    this.scorm_api_12 = null;
    this.scorm_api_2004 = null; 

    if (launcharg == null)
        launcharg = "";
        
    var strArgs = this.launch_arg.substring(1).split("&");

    lmslog.addEntry(0, fname, "strArgs", strArgs);
    for (var i = 0; i < strArgs.length; i++) {
        strArg = strArgs[i];

        var val;

        val = this.CheckParam(strArg, "aicc_url=");
        if (val != "") {
            // this is aicc Hacp, set flag to indicate this
            if (val.substr(0, 4).toLowerCase() != "http") {
                this.aicc_url = LmsConfig.AiccUrlProtocol + val;
            }
            else
                this.aicc_url = val;

            continue;
        } 
        
        val = this.CheckParam(strArg, "aicc_sid=");
        if (val != "") {
            this.aicc_sid = val;
            continue;
        }
    }

    //maintain the api pointer if found so that lmscomscorm constructors can use it
    if (LmsConfig.ScormVersion !== "1.2")
        this.scorm_api_2004 = this.FindScorm2004API();
    if (this.scorm_api_2004 == null && LmsConfig.ScormVersion !== "2004")
        this.scorm_api_12 = this.FindScorm12API();

    if ((this.aicc_url != "") && (this.aicc_sid != "")) {
        this.api_type = "aicc";
    }
    else if (Kpath_launch == true) {
        this.api_type = "kpath"; 
    }
    else if (this.scorm_api_2004 != null) {
        this.api_type = "scorm2004";
    }
    else if (this.scorm_api_12 != null) {
        this.api_type = "scorm12";
    }
}


/* The factory method for LmsCom. */
// LZ: LmsComKPath added
LmsComFactory.prototype.CreateLmsCom = function() {

    if (this.api_type == "aicc") {
        return new LmsComAICC(this.aicc_url, this.aicc_sid);
    }
    else if (this.api_type == "scorm2004") {
        return new LmsComScorm2004();
    }
    // If portal launch, there will be an adapter to be found and top level SCO
    // should use it rather than calling LoadRuntime.
    else if (this.api_type == "kpath") {
        var lmscom = new LmsComKPath();
        lmscom.API = this.scorm_api_2004;
        return lmscom;
    }
    else if (this.api_type == "scorm12") {
        return new LmsComScorm12();
    }

    if (PlayerConfig.EnableCookies)
        return new LmsComCookie();
    else
        return new LmsComBase(); 
}

LmsComFactory.prototype.FindScorm12API = function () {
    try {
        var theAPI = this.FindWindowScorm12API(window);
    
        if ((theAPI == null) && (top.window.opener != null) && (!top.window.opener.closed)) {
            theAPI = this.FindWindowScorm12API(top.window.opener);
        }
    
        return theAPI;
    } catch (e) {
        return null;
    }
}

LmsComFactory.prototype.FindWindowScorm12API = function(win) {
   var findAPITries = 0;
   while ((win.API == null) && (win.parent != null) && (win.parent != win))
   {
      findAPITries++;
      // Note: 500 is an arbitrary number, but should be more than sufficient
      if (findAPITries > 500) 
      {
        lmslog.addEntry(0, "FindScorm12API", "", R_scorm_apideep);
        return null;
      }
      
      win = win.parent;
  }
   
   return win.API;
}

LmsComFactory.prototype.FindScorm2004API = function() {
    try {
        var theAPI = this.FindWindowScorm2004API(window);

        if ((theAPI == null) && (top.window.opener != null) && (!top.window.opener.closed)) {
            theAPI = this.FindWindowScorm2004API(top.window.opener);
        }

        return theAPI;
    } catch (e) {
        return null;
    }
}

LmsComFactory.prototype.FindWindowScorm2004API = function(win) {
    var findAPITries = 0;
 
    while ((win.API_1484_11 == null) && (win.parent != null) && (win.parent != win)) {
        findAPITries++;

        if (findAPITries > 500) {
            lmslog.addEntry(0, "FindScorm2004API", "", R_scorm_apideep);
            return null;
        }
        win = win.parent;
    }

    return win.API_1484_11;
}

LmsComFactory.prototype.CheckParam = function(strArg, param) {
    var len = param.length;
    var val = "";

    if (strArg.substr(0, len).toLowerCase() == param) {
        val = strArg.substring(len);
    }

    return val;
}


/* lmscom.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

/* Constant for the different statuses that a coarse may have.  
These ID corresponsed to the values used by both SCORM and 
AICC. */
var LMS_PASSED = "passed";
var LMS_FAILED = "failed";
var LMS_COMPLETED = "completed";
var LMS_INCOMPLETE = "incomplete";
var LMS_NOT_ATTEMPTED = "not attempted";

/* Extend internal Date object to format for SCORM 2004 */
Date.prototype.toSCORM = function () {
    return this.getFullYear() + "-" + ("0" + (this.getMonth() + 1)).slice(-2) + "-" + ("0" + this.getDate()).slice(-2)
        + "T" + ("0" + this.getHours()).slice(-2) + ":" + ("0" + this.getMinutes()).slice(-2) + ":" + ("0" + this.getSeconds()).slice(-2);
}

///////////////////////////////////////
//
// LmsCom object defintions
//
///////////////////////////////////////

///////////////////////////////////////
// Base LmsCom object defintion
///////////////////////////////////////
function LmsComBase(parent) {
    this.status_obj = null;
    this.ordinal_number = 0;

    this.start_date = "";
    this.end_date = "";
    this.student_id = "";
    this.student_name = "";
    this.credit = "";
    this.lesson_status = LMS_NOT_ATTEMPTED;
    this.lesson_flag = "";
    this.lesson_location = "";
    this.lesson_data = "";
    this.original_lesson_data = "";
    this.core_vendor = "";
    this.score = "";
    this.time = "";
    this.idle_time = 0;         // session idle time only computed for lmscomkpath
    this.mode_idle_time = 0;    // idle time for topic mode launch
    this.doit_child_time = 0;   // time spent in see_it/try_it launched from do_it

    this.owner = null;  // owner window of this lmscom
    this.guid = null;   // guid of associated asset

    this.session_active = false;
    this.bigsco = false;    // executing in a big sco, so asset status stored differently

    if (parent != null) {
        this.Copy(parent);
        this.ParentLmsCom = parent;
    }

    this.object_type_name = "LmsComBase";
}

LmsComBase.prototype.GetOrdinalNumber = function () {
    return this.ordinal_number;
}

LmsComBase.prototype.SetOrdinalNumber = function (ordnum) {
    this.ordinal_number = ordnum;
}

/* Copies just that invarient information.  Allows child 
pages to report on student info if they need to. */
LmsComBase.prototype.Copy = function (from) {

    this.student_id = from.student_id;
    this.student_name = from.student_name;
    this.credit = from.credit;
    this.lesson_status = from.lesson_status;
    this.bigsco = from.bigsco;
    this.lesson_data = from.lesson_data;
    this.lesson_location = from.lesson_location;
}

/* Starts a session.  For LmsComBase, all this does is
records the start time. */
LmsComBase.prototype.Begin = function () {
    this.start_date = new Date().getTime();

    if (this.session_active)
        alert(R_lmscom_already_active);

    this.session_active = true;

    return true;
}

/* Ends a session.  For LmsComBase, all this does is
records the end time. */
LmsComBase.prototype.End = function () {

    if (!this.session_active)
        alert(R_lmscom_inactive);

    this.end_date = new Date().getTime();
    this.session_active = false;

    return true;
}

/* Load the SCORM API adapter if needed and save reference to it. */
LmsComBase.prototype.LoadAPIAdapter = function (callback) {
    //setTimeout(callback,1);
    // Above timeout caused mode launches to hang on ipad. Apparently it isn't cross-tab
    // execution that is blocked, but only the timer thread in inactive tabs.
    callback();
}

/* Sends completion status to the LMS. This is factored out of LmsCom.End() so
that completion information may be sent immediately to allow the LMS to
update any visual feedback. */
LmsComBase.prototype.SendCompletionInfo = function () { }

/* Notifies parent lmscom to roll up the status of this lmscom */
LmsComBase.prototype.NotifyParent = function () {
    var parentlmscom = this.ParentLmsCom;
    if (parentlmscom && !parentlmscom.owner.closed && parentlmscom.owner.ListenChildClose)
        parentlmscom.owner.ListenChildClose();
}

LmsComBase.prototype.getReportedLessonStatus = function () {
    if (this.lesson_status === LMS_PASSED)
        return LmsConfig.ReportOnPass;
    else if (this.lesson_status === LMS_FAILED)
        return LmsConfig.ReportOnFail;
    else
        return this.lesson_status;
}
/* Internal helper method that computes elapse time in
seconds. */
LmsComBase.prototype.computeTime = function (bdate, edate) {
    var elapsedSeconds = ((edate - bdate - this.idle_time) / 1000);
    return this.convertTotalSeconds(elapsedSeconds);
}

/* Internal helper method that computes elapse time in
seconds. Discounts time spent in Do It child launchs. */
LmsComBase.prototype.computeTime2 = function (bdate, edate) {
    var elapsedSeconds = ((edate.getTime() - bdate - this.doit_child_time) / 1000);
    return "" + elapsedSeconds;
}

/* Internal helper method that converts date/time into
seconds. */
LmsComBase.prototype.convertTotalSeconds = function (ts) {
    var sec = (ts % 60);
    ts -= sec;
    var tmp = (ts % 3600);  //# of seconds in the total # of minutes
    ts -= tmp;              //# of seconds in the total # of hours
    // convert seconds to conform to CMITimespan type (e.g. SS.00)
    sec = Math.round(sec * 100) / 100;
    var strSec = new String(sec);
    var strWholeSec = strSec;
    var strFractionSec = "";
    if (strSec.indexOf(".") != -1) {
        strWholeSec = strSec.substring(0, strSec.indexOf("."));
        strFractionSec = strSec.substring(strSec.indexOf(".") + 1, strSec.length);
    }
    if (strWholeSec.length < 2) {
        strWholeSec = "0" + strWholeSec;
    }
    strSec = strWholeSec;
    if ((ts % 3600) != 0)
        var hour = 0;
    else var hour = (ts / 3600);
    if ((tmp % 60) != 0)
        var min = 0;
    else var min = (tmp / 60);
    if ((new String(hour)).length < 2)
        hour = "0" + hour;
    if ((new String(min)).length < 2)
        min = "0" + min;
    var rtnVal = hour + ":" + min + ":" + strSec;
    return rtnVal;
}

// Get current bookmark. This is only needed for a TOC that is called via lmstart
// but not from an LMS. If you open a Big SCO's concept from kp.html and launch
// it, the Big SCO toc will get an lmscombase from the lmstart, but the lmstart
// page doesn't have the toc_hash, so it can't get the bookmark.
// Note that "view outline" from a normal concept does not need this. It replaces
// the lmstart page with the toc, so the toc will end up with an lmscomcookie of
// its own.
/*
LmsComBase.prototype.GetBookmark = function(toc_hash) {
if (this.ParentLmsCom)
return this.ParentLmsCom.GetBookmark(toc_hash);
return 0;
}
*/

// Support for UPK specific functionality. Delegate to parent until an lmscomkpath is found
LmsComBase.prototype.doGetUPKValue = function (name) {
    if (this.ParentLmsCom)
        return this.ParentLmsCom.doGetUPKValue(name);
    return "";
}

LmsComBase.prototype.doSetUPKValue = function (name, value) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.doSetUPKValue(name, value);
}

LmsComBase.prototype.doUPKCommit = function () {
    if (this.ParentLmsCom)
        this.ParentLmsCom.doUPKCommit();
}

/* Record an interaction completion. Only an lmscomkpath will actually do this, so
a question in the outline will delegate to its parent lmscom (from lmstart). */
LmsComBase.prototype.setInteraction = function (index, qlmscom) {
    if (this.ParentLmsCom)
        return this.ParentLmsCom.setInteraction(index, qlmscom);
}
LmsComBase.prototype.getAnsweredQuestions = function () {
    if (this.ParentLmsCom)
        return this.ParentLmsCom.getAnsweredQuestions();
    return {};
}

LmsComBase.prototype.setObjective = function (index, objective) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.setObjective(index, objective);
}

// sequencing at end of pre/post assessment
LmsComBase.prototype.requestContinue = function () {
    if (this.ParentLmsCom)
        this.ParentLmsCom.requestContinue();
}

/* Indicate if LMS connection is live */
LmsComBase.prototype.IsConnected = function () {
    if (this.ParentLmsCom)
        return this.ParentLmsCom.IsConnected();
    return false;
}

/* This method reads persisted data from LmsCom 
(primary from lesson_data) and creates a LmsBasicStatus
object from that. */
LmsComBase.prototype.OpenBasicStatus = function () {
    this.status_obj = new LmsBasicStatus();
    this.status_obj.status = this.lesson_status;

    return this.status_obj;
}

/* This method reads persisted data from LmsCom 
(primary from lesson_data) and creates a LmsTopicStatus
object from that. */
LmsComBase.prototype.OpenTopicStatus = function (lmsModes, playerModes) {
    var fname = "OpenTopicStatus";
    this.status_obj = new LmsTopicStatus();
    this.status_obj.setRequiredMode(lmsModes, playerModes);
    lmslog.addEntry(0, fname, "RequiredMode", this.status_obj.requiredMode);
    this.status_obj.isScored = !!lmsModes["K"];

    var availableModes;
    if (GetTopLevelLmsMode() == "LMS")
        availableModes = lmsModes;
    else
        availableModes = playerModes;
    this.status_obj.setModeavail("S", availableModes["S"]);
    this.status_obj.setModeavail("T", availableModes["T"]);
    this.status_obj.setModeavail("K", availableModes["K"]);
    this.status_obj.setModeavail("D", availableModes["D"]);
    this.status_obj.setModeavail("P", availableModes["P"]);
    this.status_obj.setModeavail("E", availableModes["E"]);
    lmslog.addEntry(0, fname, "SeeIt", this.status_obj.getModeavail("S"));
    lmslog.addEntry(0, fname, "TryIt", this.status_obj.getModeavail("T"));
    lmslog.addEntry(0, fname, "KnowIt", this.status_obj.getModeavail("K"));
    lmslog.addEntry(0, fname, "DoIt", this.status_obj.getModeavail("D"));
    lmslog.addEntry(0, fname, "PrintIt", this.status_obj.getModeavail("P"));
    lmslog.addEntry(0, fname, "TestIt", this.status_obj.getModeavail("E"));

    if (this.bigsco) {
        this.status_obj.savedStatus = this.lesson_data.charAt(0);
        this.lesson_data = this.lesson_data.substring(1);
    }
    this.status_obj.initTopicstat(this.lesson_data);

    return this.status_obj;
}

// duplicates code for TopicStatus, except available modes are stored differently in
// topic.html than in lmstart.html
LmsComBase.prototype.OpenTopicLaunchStatus = function (mode, lmsModes, playerModes) {
    var fname = "OpenTopicLaunchStatus";

    this.status_obj = new LmsTopicLaunchStatus(mode);
    this.status_obj.setRequiredMode(lmsModes, playerModes);
    lmslog.addEntry(0, fname, "RequiredMode", this.status_obj.requiredMode);
    this.status_obj.isScored = lmsModes.indexOf("K") != -1;

    var availableModes;
    if (GetTopLevelLmsMode() == "LMS")
        availableModes = lmsModes;
    else
        availableModes = playerModes;
    this.status_obj.setModeavail("S", availableModes.indexOf("S") != -1);
    this.status_obj.setModeavail("T", availableModes.indexOf("T") != -1);
    this.status_obj.setModeavail("K", availableModes.indexOf("K") != -1);
    this.status_obj.setModeavail("D", availableModes.indexOf("D") != -1);
    this.status_obj.setModeavail("P", availableModes.indexOf("P") != -1);
    this.status_obj.setModeavail("E", availableModes.indexOf("E") != -1);
    lmslog.addEntry(0, fname, "SeeIt", this.status_obj.getModeavail("S"));
    lmslog.addEntry(0, fname, "TryIt", this.status_obj.getModeavail("T"));
    lmslog.addEntry(0, fname, "KnowIt", this.status_obj.getModeavail("K"));
    lmslog.addEntry(0, fname, "DoIt", this.status_obj.getModeavail("D"));
    lmslog.addEntry(0, fname, "PrintIt", this.status_obj.getModeavail("P"));
    lmslog.addEntry(0, fname, "TestIt", this.status_obj.getModeavail("E"));

    this.status_obj.initTopicstat(this.lesson_data);

    return this.status_obj;
}

/* This method reads persisted data from LmsCom 
(primary from lesson_data) and creates a 
LmsQuestionStatus object from that. */
LmsComBase.prototype.OpenQuestionStatus = function () {
    this.status_obj = new LmsQuestionStatus();
    this.status_obj.status = LMS_NOT_ATTEMPTED;
    this.status_obj.savedStatus = this.lesson_data ? Stat2Lms(this.lesson_data) : LMS_NOT_ATTEMPTED;

    return this.status_obj;
}

/* This method reads persisted data from LmsCom 
(primary from lesson_data) and creates a 
LmsAssessmentStatus object from that. */
LmsComBase.prototype.OpenAssessmentStatus = function (itemCount, hash) {
    this.status_obj = new LmsAssessmentStatus();
    this.status_obj.hash = hash;    // save hash for when saving

    var str = this.lesson_data;
    var count;
    var savedhash = null;

    if (str) {
        if (!this.bigsco) {
            var index = str.indexOf("@");
            if (index > 0) {
                count = parseInt(str.substring(0, index));
                // if aicc lms (moodle) replaced "+" in hash with " ", put "+" back
                savedhash = str.substring(index + 1, index + count + 1).replace(/ /g, "+");
                str = str.substring(index + count + 1);
            }
        } else
            savedhash = hash;   // to satisfy test below
    }

    if (hash === savedhash && str.length === itemCount + 1) {
        this.status_obj.savedStatus = str.charAt(0);
        this.status_obj.status = str.charAt(0) === "I" ? LMS_INCOMPLETE : LMS_NOT_ATTEMPTED;
        for (var i = 0; i < itemCount; i++)
            this.status_obj.questionstatus[i] = str.charAt(i + 1);
    } else {
        if (str && !this.bigsco) {  // there was data but we need to invalidate
            this.status_obj.stateDiscarded = true;
            if (str.charAt(0) === "I")
                this.status_obj.savedStatus = "N"
            else
                this.status_obj.savedStatus = str.charAt(0);
        } else
            this.status_obj.savedStatus = "N";
        this.status_obj.status = LMS_NOT_ATTEMPTED;
        for (var i = 0; i < itemCount; i++)
            this.status_obj.questionstatus[i] = "N";
    }

    return this.status_obj;
}

/* This method reads persisted data from LmsCom 
(primary from lesson_data) and creates a 
LmsTOCStatus object from that. */
LmsComBase.prototype.OpenTOCStatus = function (nodecount, tocversion) {
    var tc = new LmsTOCStatus();
    this.status_obj = tc;

    var tocstate = new TOCState(nodecount, tocversion);
    tc.setTocState(tocstate);

    if (this.lesson_data != null && this.lesson_data.length > 0)
        tocstate.DeserializeTOC(this.lesson_data);
    return tc;
}

LmsComBase.prototype.SaveStatus = function () {
    if (this.status_obj)
        this.status_obj.Save(this);
}

// Add methods for communicating to UT (Kpath lite)
LmsComBase.prototype.utGetModeIndex = function () {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utGetModeIndex();
}
LmsComBase.prototype.utPushModeIndex = function () {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utPushModeIndex();
}
LmsComBase.prototype.utPopModeIndex = function () {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utPopModeIndex();
}
LmsComBase.prototype.utRecordType = function (type) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordType(type);
}
LmsComBase.prototype.utRecordStartTime = function (time) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordStartTime(time);
}
LmsComBase.prototype.utRecordTimespan = function (seconds) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordTimespan(seconds);
}
LmsComBase.prototype.utRecordEndTime = function (time) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordEndTime(time);
}
LmsComBase.prototype.utRecordCompletionStatus = function (status) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordCompletionStatus(status);
}
LmsComBase.prototype.utRecordSuccessStatus = function (status) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordSuccessStatus(status);
}
LmsComBase.prototype.utRecordScoreScaled = function (score) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordScoreScaled(score);
}
LmsComBase.prototype.utRecordFrameViewed = function (frame) {
    if (this.ParentLmsCom)
        this.ParentLmsCom.utRecordFrameViewed(frame);
}

///////////////////////////////////////
// SCORM 1.2 LmsCom object defintion
///////////////////////////////////////
function LmsComScorm12() {
    this.allow_launch = false;

    this.object_type_name = "LmsComScorm12";
}

LmsComScorm12.prototype = new LmsComBase();
LmsComScorm12.prototype.constructor = LmsComScorm12;
LmsComScorm12.prototype.BaseClass = LmsComBase.prototype;

LmsComScorm12.prototype.Begin = function () {
    LmsComScorm12.prototype.BaseClass.Begin.call(this);

    //Initalizes communication with the LMS.
    var fname = "LmsComScorm12.Begin"
    lmslog.addEntry(0, fname, "", "Start");

    //SCORM - Gets all startup parameters from the LMS
    if (this.API == null) {
        this.allow_launch = true;
        return false;
    }

    if (this.API.LMSInitialize("") == "false") {
        var err = this.API.LMSGetLastError();
        var errDesc = this.API.LMSGetErrorString(err) + "\n" + this.API.LMSGetDiagnostic("");
        this.API = null;   // flag as disconnected
        lms_ConnectionLost(err + " " + errDesc);
        lmslog.addEntry(0, fname, "", errDesc);
        return false;
    }

    this.lesson_status = this.original_lesson_status = this.doLMSGetValue("cmi.core.lesson_status");
    this.lesson_data = this.doLMSGetValue("cmi.suspend_data");
    this.lesson_location = this.doLMSGetValue("cmi.core.lesson_location");
    this.student_id = this.doLMSGetValue("cmi.core.student_id");
    this.student_name = this.doLMSGetValue("cmi.core.student_name");
    this.allow_launch = true;

    lmslog.addEntry(0, fname, "", "LMS session started");

    return true;
}

LmsComScorm12.prototype.End = function () {
    LmsComScorm12.prototype.BaseClass.End.call(this);

    //SCORM - Calls LMS to indicate that course session has ended
    var fname = "LmsComScorm12.End";
    lmslog.addEntry(0, fname, "", "Start");

    if (!this.allow_launch)
        return false;

    this.allow_launch = false;

    if (this.API == null) {
        return false;
    }

    if (this.lesson_status == LMS_INCOMPLETE)
        this.doLMSSetValue("cmi.core.exit", "suspend");
    else
        this.doLMSSetValue("cmi.core.exit", "");    // GS set this to suspend, too

    var sesstime = this.computeTime(this.start_date, this.end_date);
    this.doLMSSetValue("cmi.core.session_time", sesstime);
    // SCORM compliance suite dies if you send it an empty string (like, say, if you
    // wanted to clear out the value)
    if (this.lesson_data)
        this.doLMSSetValue("cmi.suspend_data", this.lesson_data);
    if (this.lesson_location)
        this.doLMSSetValue("cmi.core.lesson_location", this.lesson_location);

    this.SendCompletionInfo(true);

    if (this.API && this.API.LMSFinish("") == "false") {
        var err = this.API.LMSGetLastError();
        var errDesc = this.API.LMSGetErrorString(err) + "\n" + this.API.LMSGetDiagnostic("");
        this.API = null;   // flag as disconnected
        lms_ConnectionLost(err + " " + errDesc);
        lmslog.addEntry(0, fname, "", errDesc);
        return false;
    }

    this.API = null;  // 13102364 - prevents errors from get/set if window close occurs before page callback

    lmslog.addEntry(0, fname, "", "LMS session terminated");

    return true;
}

/* Sends completion status to the LMS. This is factored out of LmsCom.End() so
that completion information may be sent immediately to allow the LMS to
update any visual feedback. "not attempted" is sent as "incomplete" because
the SCORM1.2 spec can be interpreted to make "not attempted" an illegal value
to set */
LmsComScorm12.prototype.SendCompletionInfo = function (isEnding) {
    if (this.lesson_status === LMS_NOT_ATTEMPTED) {
        if (this.original_lesson_status === LMS_NOT_ATTEMPTED)
            this.doLMSSetValue("cmi.core.lesson_status", LMS_INCOMPLETE);
        else
            this.doLMSSetValue("cmi.core.lesson_status", this.original_lesson_status);
    } else
        this.doLMSSetValue("cmi.core.lesson_status", this.getReportedLessonStatus());

    if (this.score !== "") {
        this.doLMSSetValue("cmi.core.score.raw", this.score);
        this.doLMSSetValue("cmi.core.score.min", "0");
        this.doLMSSetValue("cmi.core.score.max", "100");
    }
    if (!isEnding)
        this.doLMSCommit();
}

/* Load the SCORM API adapter if needed and save reference to it. */
LmsComScorm12.prototype.LoadAPIAdapter = function (callback) {
    this.API = null
    if (GetLmsComFactory())
        this.API = GetLmsComFactory().scorm_api_12;
    callback();
}

/* Indicate if LMS connection is live */
LmsComScorm12.prototype.IsConnected = function () {
    return this.API != null;
}

// SCORM adapter definitions

LmsComScorm12.prototype.ErrorCodes = {
    NoError: 0,
    GeneralException: 101,
    ElementCannotHaveChildren: 202,
    ElementNotAnArray: 203,
    NotInitialized: 301,
    NotImplemented: 401,
    InvalidSetValue: 402,
    ElementIsReadOnly: 403,
    ElementIsWriteOnly: 404,
    IncorrectDataType: 405
};

LmsComScorm12.prototype.doLMSGetValue = function (name) {
    var fname = "doLMSGetValue";
    if (this.API == null) {
        return "";
    }

    var value = this.API.LMSGetValue(name);
    var err = this.API.LMSGetLastError();
    if (err != this.ErrorCodes.NoError) {
        var errDesc = this.API.LMSGetErrorString(err);
        lms_ConnectionLost(err + " " + errDesc + ", " + name);
        lmslog.addEntry(0, fname, "", R_scorm_getvalfail + name + " " + errDesc);
        return "";
    }

    lmslog.addEntry(1, fname, name, value);
    return value;
}

LmsComScorm12.prototype.doLMSSetValue = function (name, value) {
    var fname = "doLMSSetValue";
    if (this.API == null) {
        return "false";
    }

    if (this.API.LMSSetValue(name, value) == "false") {
        var err = this.API.LMSGetLastError();
        if (err != this.ErrorCodes.NoError && err != this.ErrorCodes.NotImplemented) {
            var errDesc = this.API.LMSGetErrorString(err);
            lms_ConnectionLost(err + " " + errDesc + ", " + name + ", " + value);
            lmslog.addEntry(0, fname, "", R_scorm_setvalfail + name + ":" + value + " " + errDesc);
            return "false";
        }
    }

    lmslog.addEntry(1, fname, name, value);
    return "true";
}

LmsComScorm12.prototype.doLMSCommit = function () {
    var fname = "doLMSCommit";
    if (this.API == null) {
        return "false";
    }

    if (this.API.LMSCommit("") == "false") {    // is commit failure a drop?
        var err = this.API.LMSGetLastError();
        var errDesc = this.API.LMSGetErrorString(err);
        lms_ConnectionLost(err + " " + errDesc);
        lmslog.addEntry(0, fname, "", errDesc);
        this.API = null;
        return "false";
    }

    lmslog.addEntry(1, fname, "", "");
    return "true";
}

///////////////////////////////////////
// SCORM 1.3 (SCORM2004) LmsCom object defintion
///////////////////////////////////////
function LmsComScorm2004() {
    this.allow_launch = false;
    this.object_type_name = "LmsComScorm2004";
    this.lesson_data_location = "cmi.suspend_data";
}

LmsComScorm2004.prototype = new LmsComBase();
LmsComScorm2004.prototype.constructor = LmsComScorm2004;
LmsComScorm2004.prototype.BaseClass = LmsComBase.prototype;

LmsComScorm2004.prototype.Begin = function () {
    LmsComScorm2004.prototype.BaseClass.Begin.call(this);

    //Initalizes communication with the LMS.
    var fname = "LmsComScorm2004.Begin"
    lmslog.addEntry(0, fname, "", "Start");

    //SCORM - Gets all startup parameters from the LMS
    if (this.API == null) {
        this.allow_launch = true;
        return false;
    }

    if (this.API.Initialize("") == "false") {
        var err = this.API.GetLastError();
        var errDesc = this.API.GetErrorString(err) + "\n" + this.API.GetDiagnostic("");
        this.API = null;   // flag as disconnected
        lms_ConnectionLost(err + " " + errDesc);
        lmslog.addEntry(0, fname, "", errDesc);
        return false;
    }

    this.lesson_status = this.doGetValue("cmi.completion_status");
    if (this.lesson_status === "unknown") {
        this.lesson_status = LMS_NOT_ATTEMPTED;
    } else if (this.lesson_status === LMS_COMPLETED) {
        var success_status = this.doGetValue("cmi.success_status");
        if (success_status === LMS_PASSED || success_status === LMS_FAILED)
            this.lesson_status = success_status;
    }
    this.original_lesson_status = this.lesson_status;
    this.lesson_data = this.doGetValue(this.lesson_data_location);
    this.lesson_location = this.doGetValue("cmi.location");
    this.student_id = this.doGetValue("cmi.learner_id");
    this.student_name = this.doGetValue("cmi.learner_name");
    this.allow_launch = true;

    lmslog.addEntry(0, fname, "", "LMS session started");

    return true;
}

LmsComScorm2004.prototype.End = function () {
    LmsComScorm2004.prototype.BaseClass.End.call(this);

    //SCORM - Calls LMS to indicate that course session has ended
    var fname = "LmsComScorm2004.End";
    lmslog.addEntry(0, fname, "", "Start");

    if (!this.allow_launch)
        return false;

    this.allow_launch = false;

    if (this.API == null) {
        return false;
    }

    if (this.lesson_status == LMS_INCOMPLETE)
        this.doSetValue("cmi.exit", "suspend");
    else
        this.doSetValue("cmi.exit", "normal");

    var sesstime = this.computeTime(this.start_date, this.end_date);
    this.doSetValue("cmi.session_time", sesstime);
    // SCORM compliance suite dies if you send it an empty string (like, say, if you
    // wanted to clear out the value)
    if (this.lesson_data)
        this.doSetValue(this.lesson_data_location, this.lesson_data);
    if (this.lesson_location)
        this.doSetValue("cmi.location", this.lesson_location);

    this.SendCompletionInfo(true);

    if (this.API && this.API.Terminate("") == "false") {
        var err = this.API.GetLastError();
        var errDesc = this.API.GetErrorString(err) + "\n" + this.API.GetDiagnostic("");
        this.API = null;   // flag as disconnected
        lms_ConnectionLost(err + " " + errDesc);
        lmslog.addEntry(0, fname, "", errDesc);
        return false;
    }

    this.API = null;  // 13102364 - prevents errors from get/set if window close occurs before page callback

    lmslog.addEntry(0, fname, "", "LMS session terminated");

    return true;
}

/* Load the SCORM API adapter if needed and save reference to it. */
LmsComScorm2004.prototype.LoadAPIAdapter = function (callback) {
    this.API = null
    if (GetLmsComFactory())
        this.API = GetLmsComFactory().scorm_api_2004;
    //setTimeout(callback,1);
    // Above timeout caused mode launches to hang on ipad. Apparently it isn't cross-tab
    // execution that is blocked, but only the timer thread in inactive tabs.
    callback();
}

/* Sends completion status to the LMS. This is factored out of LmsCom.End() so
that completion information may be sent immediately to allow the LMS to
update any visual feedback. */
LmsComScorm2004.prototype.SendCompletionInfo = function (isEnding) {
    var lesson_status = this.getReportedLessonStatus();
    if (lesson_status === LMS_NOT_ATTEMPTED)
        lesson_status = this.original_lesson_status;
    // split scorm1.2/aicc completion into scorm2004 values
    // maybe it would be better to hold them in the scorm2004 manner and join
    // for aicc/scorm1.2
    if (lesson_status == LMS_PASSED || lesson_status == LMS_FAILED) {
        this.doSetValue("cmi.success_status", lesson_status);
        this.doSetValue("cmi.completion_status", LMS_COMPLETED);
    } else
        this.doSetValue("cmi.completion_status", lesson_status);

    if (this.score !== "") {
        this.doSetValue("cmi.score.raw", this.score);
        this.doSetValue("cmi.score.scaled", this.score / 100);
        this.doSetValue("cmi.score.min", "0");
        this.doSetValue("cmi.score.max", "100");
    }
    if (!isEnding)
        this.doCommit();
}

/* Internal helper method that converts date/time into
seconds. This version generates a 1.3 compliant (second,10,2) result */
LmsComScorm2004.prototype.convertTotalSeconds = function (ts) {
    var sec = (ts % 60);
    ts -= sec;
    var tmp = (ts % 3600);  //# of seconds in the total # of minutes
    ts -= tmp;              //# of seconds in the total # of hours
    // convert seconds to conform to CMITimespan type (e.g. SS.00)
    sec = Math.round(sec * 100) / 100;
    var strSec = new String(sec);
    var strWholeSec = strSec;
    var strFractionSec = "";
    if (strSec.indexOf(".") != -1) {
        strWholeSec = strSec.substring(0, strSec.indexOf("."));
        strFractionSec = strSec.substring(strSec.indexOf(".") + 1, strSec.length);
    }
    if (strWholeSec.length < 2) {
        strWholeSec = "0" + strWholeSec;
    }
    strSec = strWholeSec;
    if ((ts % 3600) != 0)
        var hour = 0;
    else var hour = (ts / 3600);
    if ((tmp % 60) != 0)
        var min = 0;
    else var min = (tmp / 60);
    if ((new String(hour)).length < 2)
        hour = "0" + hour;
    if ((new String(min)).length < 2)
        min = "0" + min;
    var rtnVal = "PT" + hour + "H" + min + "M" + strSec + "S";
    return rtnVal;
}

/* Indicate if LMS connection is live */
LmsComScorm2004.prototype.IsConnected = function () {
    return this.API != null;
}

// SCORM adapter definitions

LmsComScorm2004.prototype.ErrorCodes = {
    NoError: 0,
    GeneralException: 101,
    GeneralInitializationFailure: 102,
    AlreadyInitialized: 103,
    ContentInstanceTerminated: 104,
    GeneralTerminationFailure: 111,
    TerminationBeforeInitialization: 112,
    TerminationAfterTermination: 113,
    RetrieveDataBeforeInitialization: 122,
    RetrieveDataAfterTermination: 123,
    StoreDataBeforeInitialization: 132,
    StoreDataAfterTermination: 133,
    CommitBeforeInitialization: 142,
    CommitAfterTermination: 143,
    GeneralArgumentError: 201,
    GeneralGetFailure: 301,
    GeneralSetFailure: 351,
    GeneralCommitFailure: 391,
    UndefinedDataModelElement: 401,
    UnimplementedDataModelElement: 402,
    DataModelElementValueNotInitialized: 403,
    DataModelElementIsReadOnly: 404,
    DataModelElementIsWriteOnly: 405,
    DataModelElementTypeMismatch: 406,
    DataModelElementValueOutOfRange: 407,
    DataModelDependencyNotEstablished: 408,

    KPathTimeout: 1501,
    KPathConnect: 1502,
    KPathBusy: 1503
};

LmsComScorm2004.prototype.doGetValue = function (name) {
    var fname = "doGetValue";
    if (this.API == null) {
        return "";
    }

    var value = this.API.GetValue(name);
    var err = this.API.GetLastError();
    if (err != this.ErrorCodes.NoError && err != this.ErrorCodes.DataModelElementValueNotInitialized) {
        if (err == this.ErrorCodes.KPathTimeout && this.object_type_name == "LmsComKPath") {
            lmslog.addEntry(0, fname, "", "KCenter timeout");
            var idle = this.API.GetValue("upk.idle_time");
            lmslog.addEntry(0, fname, "upk.idle_time", idle);
            this.idle_time += idle;
            this.mode_idle_time += idle;
            lmslog.addEntry(0, fname, "idle_time", this.idle_time);
            return this.doGetValue(name);  // redo the call
        } else {
            var errDesc = this.API.GetErrorString(err);
            lms_ConnectionLost(err + " " + errDesc + ", " + name);
            lmslog.addEntry(0, fname, "", R_scorm_getvalfail + name + " " + errDesc);
            return "";
        }
    }

    lmslog.addEntry(1, fname, name, value);
    return value;
}

LmsComScorm2004.prototype.doSetValue = function (name, value) {
    var fname = "doSetValue";
    if (this.API == null) {
        return "false";
    }

    if (this.API.SetValue(name, value) == "false") {
        var err = this.API.GetLastError();
        if (err != this.ErrorCodes.NoError && err != this.ErrorCodes.UnimplementedDataModelElement) {
            if (err == this.ErrorCodes.KPathTimeout && this.object_type_name == "LmsComKPath") {
                lmslog.addEntry(0, fname, "", "KCenter timeout");
                var idle = this.API.GetValue("upk.idle_time");
                lmslog.addEntry(0, fname, "upk.idle_time", idle);
                this.idle_time += idle;
                this.mode_idle_time += idle;
                lmslog.addEntry(0, fname, "idle_time", this.idle_time);
                return this.doSetValue(name, value);
            } else {
                var errDesc = this.API.GetErrorString(err);
                lms_ConnectionLost(err + " " + errDesc + ", " + name + ", " + value);
                lmslog.addEntry(0, fname, "", R_scorm_setvalfail + name + ":" + value + " " + errDesc);
                return "false";
            }
        }
    }
    //alert(fname+":"+name+":"+value);
    lmslog.addEntry(1, fname, name, value);
    return "true";
}

LmsComScorm2004.prototype.doCommit = function () {
    var fname = "doCommit";
    if (this.API == null) {
        return "false";
    }

    if (this.API.Commit("") == "false") {
        var err = this.API.GetLastError();
        var errDesc = this.API.GetErrorString(err);
        this.API = null;   // flag as disconnected
        lms_ConnectionLost(err + " " + errDesc);
        lmslog.addEntry(0, fname, "", errDesc);
        return "false";
    }

    lmslog.addEntry(1, fname, "", "");
    return "true";
}


///////////////////////////////////////
// Knowledge Pathways LmsCom object defintion
///////////////////////////////////////
function LmsComKPath(parent) {
    this.allow_launch = false;

    if (parent != null) {
        this.Copy(parent);
        this.ParentLmsCom = parent;
    }

    this.object_type_name = "LmsComKPath";
    this.lesson_data_location = "upk.sco_data";
    this.commitActive = false; // asynchronous commit in progress
    this.commitNeeded = false; // another commit needed when current one completes 
}

LmsComKPath.prototype = new LmsComScorm2004();
LmsComKPath.prototype.constructor = LmsComKPath;
LmsComKPath.prototype.BaseClass = LmsComScorm2004.prototype;

LmsComKPath.prototype.Begin = function () {
    var fname = "LmsComKPath.Begin"
    lmslog.addEntry(0, fname, "", "Start");
    var result = LmsComKPath.prototype.BaseClass.Begin.call(this);
    this.doSetValue("upk.launch_from", GetTopLevelLmsMode());
    lmslog.addEntry(0, fname, "", "LMS session started");
    return result;
}

/* Sends completion status to the LMS. This is factored out of LmsCom.End() so
that completion information may be sent immediately to allow the LMS to
update any visual feedback. Unlike the other lmscom types, we want to send
LMS_NOT_ATTEMPTED to kpath if no new attempt is made */
LmsComKPath.prototype.SendCompletionInfo = function (isEnding) {
    var lesson_status = this.getReportedLessonStatus();
    if (lesson_status === LMS_NOT_ATTEMPTED) {
        this.doSetValue("cmi.completion_status", LMS_NOT_ATTEMPTED);
        return;
    }
    // split scorm1.2/aicc completion into scorm2004 values
    // maybe it would be better to hold them in the scorm2004 manner and join
    // for aicc/scorm1.2
    if (lesson_status == LMS_PASSED || lesson_status == LMS_FAILED) {
        this.doSetValue("cmi.success_status", lesson_status);
        this.doSetValue("cmi.completion_status", LMS_COMPLETED);
    } else
        this.doSetValue("cmi.completion_status", lesson_status);

    if (this.score !== "") {
        this.doSetValue("cmi.score.raw", this.score);
        this.doSetValue("cmi.score.scaled", this.score / 100);
        this.doSetValue("cmi.score.min", "0");
        this.doSetValue("cmi.score.max", "100");
    }
    if (!isEnding)
        this.doCommit();
}

/* Load the SCORM API adapter if needed and save reference to it. */
LmsComKPath.prototype.LoadAPIAdapter = function (callback) {
    if (!this.API) {    // don't overwrite previously set adapter
        var apiframe = findKPathAPIFrame(window);
        if (apiframe && apiframe.LoadRuntime && this.guid) {
            this.deferred_callback = callback;
            var that = this;
            apiframe.LoadRuntime(this.guid, 0, 0, 0, function (s, g, a, e) { that.LoadAPIAdapterCallback(s, g, a, e) }, upk.browserInfo.isTouchDevice());
        } else {
            callback();
        }
    } else
        callback();
}

LmsComKPath.prototype.LoadAPIAdapterCallback = function (succeeded, guid, APIControl, ErrorMessage) {
    if (succeeded == "succeeded" && guid == this.guid) {
        this.API = APIControl.GetAPI();
        lmslog.addEntry(0, "LoadAPIAdapterCallback", "", "KPath adapter bound");
        try {
            this.deferred_callback();
        } catch (e) { } // catch case where we cycle quickly through the toc & lmscom page closed before API callback runs
    } else if (succeeded == "no SCO") {
        this.API = null;    // fall back to lmscombase functionality
        lmslog.addEntry(0, "LoadAPIAdapterCallback", "", ErrorMessage);
        this.deferred_callback();
    } else {
        alert(R_scorm_noapi + " " + ErrorMessage);
        lmslog.addEntry(0, "LoadAPIAdapterCallback", "", ErrorMessage);
        this.deferred_callback();
    }
}

LmsComKPath.prototype.doGetUPKValue = function (name) {
    var ret = this.doGetValue(name);
    if (ret === "")
        ret = -1;
    return ret;
}

LmsComKPath.prototype.doSetUPKValue = function (name, value) {
    this.doSetValue(name, value);
}

LmsComKPath.prototype.doUPKCommit = function () {
    this.doCommit();
}

// do asynchronous commits to kcenter
LmsComKPath.prototype.doCommit = function () {
    var fname = "doCommit";
    if (this.API == null) {
        return "false";
    }
    if (this.commitActive) {
        lmslog.addEntry(0, fname, "commitActive==true", "")
        this.commitNeeded = true;
        return "true";
    }

    lmslog.addEntry(1, fname, "", "");
    if (!upk.browserInfo.isTouchDevice()) {  // do sync commits on ipad
        this.commitActive = true;
        var that = this;
        var callback = function (s, e) { that.doCommitCallback(s, e); }
    } else {
        var callback = null;
    }
    if (this.API.Commit("", callback) == "false") {
        this.commitActive = false;
        var err = this.API.GetLastError();
        var errDesc = this.API.GetErrorString(err);
        if (err == this.ErrorCodes.KPathTimeout && this.object_type_name == "LmsComKPath") {
            lmslog.addEntry(0, fname, "", "KCenter timeout");
            var idle = this.API.GetValue("upk.idle_time");
            lmslog.addEntry(0, fname, "upk.idle_time", idle);
            this.idle_time += idle;
            this.mode_idle_time += idle;
            lmslog.addEntry(0, fname, "idle_time", this.idle_time);
            return this.doCommit();
        } else {
            this.API = null;   // flag as disconnected
            lms_ConnectionLost(err + " " + errDesc);
            lmslog.addEntry(0, fname, "", errDesc);
            return "false";
        }
    }
    return "true";
}

LmsComKPath.prototype.doCommitCallback = function (success, error) {
    lmslog.addEntry(1, "doCommitCallback", "", "");
    this.commitActive = false;
    if (!success) {
        this.API = null;   // flag as disconnected
        lms_ConnectionLost(error);
        lmslog.addEntry(0, "doCommitCallback", "", error);
    }
    if (this.commitNeeded) {
        this.commitNeeded = false;
        this.doCommit();
    }
}


// Record an interaction completion.
LmsComKPath.prototype.setInteraction = function (index, qlmscom) {
    if (!this.API)  // if running in "lmscombase mode"
        return;

    var statobj = qlmscom.status_obj;
    var count = this.doGetValue("cmi.interactions._count");
    if (index == -1) index = count;
    if (index >= count)
        this.doSetValue("cmi.interactions." + index + ".id", qlmscom.guid);
    this.doSetValue("cmi.interactions." + index + ".type", statobj.getQuestionType());
    this.doSetValue("cmi.interactions." + index + ".timestamp", (new Date()).toSCORM());
    this.doSetValue("cmi.interactions." + index + ".weighting", "1");
    if (statobj.getResult()) {
        this.doSetValue("cmi.interactions." + index + ".learner_response", statobj.getLearnerResponse());
        this.doSetValue("cmi.interactions." + index + ".result", statobj.getResult());
    }
    this.doCommit();
    return index;
}

LmsComKPath.prototype.getAnsweredQuestions = function () {
    var answeredQuestions = {};
    if (!this.API)
        return answeredQuestions;

    var count = this.doGetValue("cmi.interactions._count");
    for (var i = 0; i < count; i++) {
        var id = this.doGetValue("cmi.interactions." + i + ".id");
        answeredQuestions[id] = { index: i };
        answeredQuestions[id].weighting = this.doGetValue("cmi.interactions." + i + ".weighting");
        answeredQuestions[id].result = this.doGetValue("cmi.interactions." + i + ".result");
    }
    return answeredQuestions;
}

LmsComKPath.prototype.setObjective = function (index, objective) {
    if (this.API) {
        var objectiveID = objective.objectiveGuid == "PRIMARYOBJ" ? "PRIMARYOBJ" : "OBJ_" + objective.objectiveGuid;
        this.doSetValue("cmi.objectives." + index + ".id", objectiveID);
        this.doSetValue("cmi.objectives." + index + ".score.scaled", objective.score / 100);
        this.doSetValue("cmi.objectives." + index + ".completion_status", objective.completed ? "completed" : "incomplete");
        this.doSetValue("cmi.objectives." + index + ".success_status", objective.completed ? "passed" : "failed");
    }
}

// sequencing at end of pre/post assessment
LmsComKPath.prototype.requestContinue = function () {
    this.doSetValue("adl.nav.request", "continue");
}

// Add methods for communicating to UT (Kpath lite)
LmsComKPath.prototype.utGetModeIndex = function () {
    this.mode_index = this.doGetValue("upk.modes._count");
}
// single entry stack for ut tracking seeit/tryit/printit from doit
LmsComKPath.prototype.utPushModeIndex = function () {
    this.saved_mode_index = this.mode_index;
    this.utGetModeIndex();
}
LmsComKPath.prototype.utPopModeIndex = function () {
    this.mode_index = this.saved_mode_index;
    delete this.saved_mode_index;
}
LmsComKPath.prototype.utRecordType = function (type) {
    this.doSetValue("upk.modes." + this.mode_index + ".type", type);
}
LmsComKPath.prototype.utRecordStartTime = function (time) {
    this.doSetValue("upk.modes." + this.mode_index + ".start_time", time.toSCORM());
    this.mode_idle_time = 0;
}
LmsComKPath.prototype.utRecordEndTime = function (time) {
    this.doSetValue("upk.modes." + this.mode_index + ".end_time", time.toSCORM());
}
LmsComKPath.prototype.utRecordTimespan = function (seconds) {
    this.doSetValue("upk.modes." + this.mode_index + ".timespan", seconds - this.mode_idle_time / 1000);
}
LmsComKPath.prototype.utRecordCompletionStatus = function (status) {
    this.doSetValue("upk.modes." + this.mode_index + ".completion_status", status);
}
LmsComKPath.prototype.utRecordSuccessStatus = function (status) {
    this.doSetValue("upk.modes." + this.mode_index + ".success_status", status);
}
LmsComKPath.prototype.utRecordScoreScaled = function (score) {
    this.doSetValue("upk.modes." + this.mode_index + ".score.scaled", score);
}
LmsComKPath.prototype.utRecordFrameViewed = function (frame) {
    this.doSetValue("upk.modes." + this.mode_index + ".frame_viewed", frame);
    var sesstime = this.computeTime(this.start_date, new Date().getTime());
    this.doSetValue("cmi.session_time", sesstime);
    this.doCommit();
}

///////////////////////////////////////
// AICC LmsCom object defintion
///////////////////////////////////////
function LmsComAICC(aicc_url, aicc_sid) {
    this.allow_launch = false;

    this.aicc_url = aicc_url;
    this.aicc_sid = aicc_sid;
    this.app = document.applets.GetHTTPPostData;

    this.object_type_name = "LmsComAICC";
}

LmsComAICC.prototype = new LmsComBase();
LmsComAICC.prototype.constructor = LmsComScorm12;
LmsComAICC.prototype.BaseClass = LmsComBase.prototype;

LmsComAICC.prototype.Begin = function () {
    LmsComAICC.prototype.BaseClass.Begin.call(this);

    //Initalizes communication with the LMS.
    var fname = "LmsComAICC.Begin"
    lmslog.addEntry(0, fname, "", "Start");

    this.hacpGetparam();

    lmslog.addEntry(0, fname, "", "about to log paramvalues");
}

LmsComAICC.prototype.End = function () {
    LmsComAICC.prototype.BaseClass.End.call(this);

    var fname = "LmsComAICC.End";
    lmslog.addEntry(0, fname, "", "Start");

    if (!this.allow_launch)
        return false;

    this.allow_launch = false;

    var NewAiccData = this.hacpGetpostdata();
    var params = "command=putparam&version=" + LmsConfig.AiccVersion + "&session_id=" + this.aicc_sid + "&aicc_data=" + escape(NewAiccData) + "&";
    lmslog.addEntry(0, fname, "params", params);
    var strData = this.app.GetData(unescape(this.aicc_url), params)
    lmslog.addEntry(0, fname, "strData", strData);
    params = "version=" + LmsConfig.AiccVersion + "&command=ExitAU&session_id=" + this.aicc_sid + "&";
    lmslog.addEntry(0, fname, "params", params);
    strData = this.app.GetData(unescape(this.aicc_url), params)
    lmslog.addEntry(0, fname, "strData", strData);
}

// stolen from lmsfunctions.js
var closingAmp = true;  // huh?

LmsComAICC.prototype.hacpGetparam = function () {
    //AICC - Gets startup parameters from the LMS
    var fname = "hacpGetparam";
    lmslog.addEntry(0, fname, "", "Start");
    var strData = "";
    var params;
    params = "version=" + LmsConfig.AiccVersion + "&command=GetParam&session_id=" + this.aicc_sid;
    if (closingAmp)
        params = params + "&";
    lmslog.addEntry(0, fname, "params", params);
    strData = this.app.GetData(unescape(this.aicc_url), params)
    lmslog.addEntry(0, fname, "strData", strData);
    var lessonStatus;
    var lessonFlag;
    var ErrorNum;
    var ErrorText;
    var IsValid = false;
    strData += " ";
    var strArgs = strData.split("\r");
    for (var i = 0; i < strArgs.length; i++) {
        var strArg = strArgs[i];
        var tag = trimValue(strArg.substring(0, strArg.indexOf("=")));
        var val = trimValue(strArg.substring(strArg.indexOf("=") + 1));
        if (tag.toLowerCase() == "error") {
            ErrorNum = val;
            IsValid = true;
        }
        if (tag.toLowerCase() == "error_text") {
            ErrorText = val;
        }
        if (tag.toLowerCase() == "aicc_data") {
            this.aicc_data = strData.substring(strData.indexOf(strArg.substring(0, strArg.indexOf("="))) + strArg.substring(0, strArg.indexOf("=")).length + 1);
            IsValid = true;
        }
    }
    if (IsValid) {
        if (ErrorNum == 0) {
            // successful
            var CoreData;
            CoreData = get_group_content("core", this.aicc_data);
            var strArgs = CoreData.split("\r");
            for (var i = 0; i < strArgs.length; i++) {
                var strArg = strArgs[i];
                var tag = trimValue(strArg.substring(0, strArg.indexOf("=")));
                var val = trimValue(strArg.substring(strArg.indexOf("=") + 1));
                if (tag.toLowerCase() == "student_id") {
                    this.student_id = val;
                }
                if (tag.toLowerCase() == "student_name") {
                    this.student_name = val;
                    //					this.splitStudentname(val);				
                }
                if (tag.toLowerCase() == "lesson_status") {
                    this.lesson_status = val.toLowerCase().charAt(0);
                    if (val.indexOf(",") != -1)
                        this.lesson_flag = trimValue(val.substring(val.indexOf(",") + 1)).toLowerCase();
                    //map abreviated flags
                    if (this.lesson_status == "p")
                        this.lesson_status = LMS_PASSED;
                    if (this.lesson_status == "c")
                        this.lesson_status = LMS_COMPLETED;
                    if (this.lesson_status == "f")
                        this.lesson_status = LMS_FAILED;
                    if (this.lesson_status == "i")
                        this.lesson_status = LMS_INCOMPLETE;
                    if (this.lesson_status == "n")
                        this.lesson_status = LMS_NOT_ATTEMPTED;
                    this.original_lesson_status = this.lesson_status;
                }
                if (tag.toLowerCase() == "lesson_location") {
                    this.lesson_location = val;
                }
                if (tag.toLowerCase() == "credit") {
                    this.credit = val;
                }
                if (tag.toLowerCase() == "score") {
                    this.score = val;
                }
                if (tag.toLowerCase() == "time") {
                    this.time = val;
                }
            }
            if (this.lesson_status == LMS_INCOMPLETE ||
			    this.lesson_status == LMS_COMPLETED ||
			    this.lesson_status == LMS_PASSED ||
			    this.lesson_status == LMS_FAILED
			    ) {
                this.lesson_data = trimValue(get_group_content("core_lesson", this.aicc_data));
            }
            else {
                this.lesson_data = "";
            }
            this.core_vendor = trimValue(get_group_content("core_vendor", this.aicc_data));
            //startTimer();
            this.allow_launch = true;
        }
        else {
            // unsuccessful, display error and do not launch
            alert(R_error_unexp + ErrorText);
            lmslog.addEntry(0, fname, "", "Unable to continue because of the following error: " + ErrorText);
        }
    }
    else {
        alert(R_error_svr + unescape(this.aicc_url) + "\r\r - " + strData);
        lmslog.addEntry(0, fname, "", "Unable to post to server " + unescape(this.aicc_url) + " - " + strData);
    }
}

LmsComAICC.prototype.hacpGetpostdata = function () {
    //AICC - Builds the AICC message string for passing to the LMS
    var fname = "hacpGetpostdata";
    lmslog.addEntry(0, fname, "", "Start");
    var NewAiccData = "";
    NewAiccData = "[CORE]\r\n";
    NewAiccData += "Lesson_Location=" + "\r\n";
    var lesson_status = this.getReportedLessonStatus();
    if (lesson_status === LMS_NOT_ATTEMPTED)
        lesson_status = this.original_lesson_status;
    if (this.lesson_status === LMS_INCOMPLETE) {
        NewAiccData += "Lesson_Status=" + lesson_status + ", suspend\r\n";
    }
    else {
        NewAiccData += "Lesson_Status=" + lesson_status + "\r\n";
    }
    lmslog.addEntry(0, fname, "is_assess", this.is_assess);
    if (this.score !== "") {
        NewAiccData += "Score=" + this.score + "\r\n";
    } else {
        NewAiccData += "Score=\r\n";
    }
    NewAiccData += "Time=" + this.computeTime(this.start_date, this.end_date) + "\r\n";
    NewAiccData += "[CORE_LESSON]\r\n";
    NewAiccData += this.lesson_data + "\r\n";
    lmslog.addEntry(0, fname, "NewAiccData", NewAiccData);
    return NewAiccData;
}

function get_group_content(section, buffer) {
    var contents = "";
    var strArgs = buffer.split("\r");
    var foundSection = false;
    for (var i = 0; i < strArgs.length; i++) {
        var line = trimValue(strArgs[i]);
        if (line.substr(0, 1) == "[") {
            if (line.toLowerCase().indexOf("[" + section.toLowerCase() + "]") >= 0) {
                foundSection = true;
            }
            else {
                foundSection = false;
            }
        }
        else {
            if (foundSection) {
                contents += line + "\r\n";
            }
        }
    }
    return contents;
}

function trimValue(Val) {
    var strval;
    var startPos = 0;
    var endPos = Val.length;
    for (var i = 0; i < Val.length; i++) {
        // space, tab, lf, cr
        if ((Val.substr(i, 1) != " ") && (Val.substr(i, 1) != "\u0009") && (Val.substr(i, 1) != "\u000A") && (Val.substr(i, 1) != "\u000D")) {
            startPos = i;
            break;
        }
    }
    if (i == Val.length)
        return "";
    for (var i = Val.length - 1; i > 0; i--) {
        // space, tab, lf, cr
        if ((Val.substr(i, 1) != " ") && (Val.substr(i, 1) != "\u0009") && (Val.substr(i, 1) != "\u000A") && (Val.substr(i, 1) != "\u000D")) {
            endPos = i;
            break;
        }
    }
    if (i == 0)
        endPos = 0;
    return Val.substring(startPos, endPos + 1);
}

/* Indicate if LMS connection is live */
LmsComAICC.prototype.IsConnected = function () {
    return true;    // what does it mean to be disconnected from an AICC LMS?
}

///////////////////////////////////////
// Cookie based LmsCom object defintion
///////////////////////////////////////
function LmsComCookie() {
    this.allow_launch = false;

    this.object_type_name = "LmsComCookie";
}

LmsComCookie.prototype = new LmsComBase();
LmsComCookie.prototype.constructor = LmsComCookie;
LmsComCookie.prototype.BaseClass = LmsComBase.prototype;

LmsComCookie.prototype.Begin = function () {
    LmsComCookie.prototype.BaseClass.Begin.call(this);
    /*
    if (this.toc_hash = window.toc_hash) {  // assignment intended
    var c = new Cookie(document, "Bookmark_" + this.toc_hash, 30);
    c.Load();
    this.lesson_location = c.Location;
    }
    */
}

LmsComCookie.prototype.End = function () {
    LmsComCookie.prototype.BaseClass.End.call(this);
    /*
    if (this.toc_hash) {
    var c = new Cookie(document, "Bookmark_" + this.toc_hash, 30);
    c.Load();
    c.Location = this.lesson_location;
    c.Store();
    }
    */
}

// Get current bookmark. This is only needed for a TOC that is called via lmstart
// but not from an LMS. If you open a Big SCO's concept from kp.html and launch
// it, the Big SCO toc will get an lmscombase from the lmstart, but the lmstart
// page doesn't have the toc_hash, so it can't get the bookmark.
// Note that "view outline" from a normal concept does not need this. It replaces
// the lmstart page with the toc, so the toc will end up with an lmscomcookie of
// its own.
/*
LmsComCookie.prototype.GetBookmark = function (toc_hash) {
if (this.toc_hash = toc_hash) { // assignment intended
var c = new Cookie(document, "Bookmark_" + this.toc_hash, 30);
c.Load();
this.lesson_location = c.Location;
}
return parseInt(this.lesson_location, 10);
}
*/

///////////////////////////////////////
//
// LmsStatus object defintions
//
///////////////////////////////////////

/* The following are a seriers of objects 
used to communicate the learning
asset runtime state with the peristence
structure used by the LmsCom object */

///////////////////////////////////////
// Basic status
///////////////////////////////////////

/* Really basic status - use by documents
like concepts in the TOC */
function LmsBasicStatus() {
    this.status = LMS_NOT_ATTEMPTED;
}

LmsBasicStatus.prototype.getStatus = function () {
    return this.status;
}

LmsBasicStatus.prototype.setStatus = function (status) {
    this.status = status;
}

LmsBasicStatus.prototype.Save = function (lmscom) {
    lmscom.lesson_status = this.status;
}

///////////////////////////////////////
// Topic status
///////////////////////////////////////
LmsTopicStatus.prototype = new LmsBasicStatus();
LmsTopicStatus.prototype.constructor = LmsTopicStatus;
LmsTopicStatus.prototype.BaseClass = LmsBasicStatus.prototype;

function LmsTopicStatus() {
    this.score = "";
    this.passed = false;
    this.modes = new Array();
    this.modes["S"] = new Mode("S");
    this.modes["T"] = new Mode("T");
    this.modes["K"] = new Mode("K");
    this.modes["D"] = new Mode("D");
    this.modes["P"] = new Mode("P");
    this.modes["E"] = new Mode("E");

    this.anylaunched = false;  // any mode launched this attempt?
}

LmsTopicStatus.prototype.Save = function (lmscom) {
    var fname = "SaveTopicStatus";

    lmscom.lesson_data = lmscom.bigsco ? "" : this.getStatusstring();
    lmscom.lesson_status = this.getLMSStatus();
    lmscom.score = this.getScore();
}

LmsTopicStatus.prototype.setModeavail = function (m, a) {
    this.modes[m].avail = a;
}

LmsTopicStatus.prototype.getModeavail = function (m) {
    return this.modes[m].avail;
}

LmsTopicStatus.prototype.setModestatus = function (m, s) {
    if (this.modes[m].avail)
        this.modes[m].complete = s;
    else
        lmslog.addEntry(0, "setModestatus", "", "Invalid call of setModestatus");
}

LmsTopicStatus.prototype.getModestatus = function (m) {
    return this.modes[m].complete;
}

LmsTopicStatus.prototype.setRequiredMode = function (lmsModes, playerModes) {
    if (GetTopLevelLmsMode() == "LMS")
        this.requiredMode = this._getRequiredMode(lmsModes);
    else
        this.requiredMode = this._getRequiredMode(playerModes);
}

LmsTopicStatus.prototype._getRequiredMode = function (modes) {
    var modeorder = "EKTSPD";
    for (var i = 0; i < modeorder.length; i++) {
        if (modes[modeorder.charAt(i)])
            return modeorder.charAt(i);
    }
    return "None"
}

LmsTopicStatus.prototype.GetRequiredMode = function () {
    return this.requiredMode;
}

LmsTopicStatus.prototype.initTopicstat = function (s) {
    var loopVar;
    var fname = "initTopicstat";
    lmslog.addEntry(0, fname, "", "Start");
    lmslog.addEntry(0, fname, "s string", s);

    lmslog.addEntry(0, fname, "s.length", s.length);
    if (s.length != 0) {
        //split the tracking string
        var f = s.split(",");
        for (loopVar = 0; loopVar <= f.length - 1; loopVar++) {
            lmslog.addEntry(0, fname, "f[" + loopVar + "]", f[loopVar]);
            if (f[loopVar].charAt(1) == "=") {
                this.modes[f[loopVar].charAt(0)].complete = this.modeIscomplete(f[loopVar].substr(2, 1));
            }
            else if (f[loopVar].substr(0, 5) == "PASS=") {
                var flag = f[loopVar].substr(5, 1);
                if (flag == "0")
                    this.passed = false;
                else
                    this.passed = true;
            }
            else if (f[loopVar].substr(0, 6) == "SCORE=") {
                this.score = f[loopVar].substr(6);
            }
        }
    }
}

LmsTopicStatus.prototype.clearTopicstat = function () {
    this.score = "";
    this.passed = false;
    for (var m in this.modes)
        this.modes[m].complete = false;
}

LmsTopicStatus.prototype.getStatusstring = function () {
    var fname = "get_statusstring";
    lmslog.addEntry(0, fname, "", "Start");
    var dataString = "";
    for (x in this.modes) {
        if (dataString.length != 0)
            dataString += ",";
        dataString += this.modes[x].id + "=" + (this.modes[x].complete ? "C" : "I");
    }
    /*if (this.modes["E"].complete) {
    dataString += ",PASS=" + (this.passed ? "1" : "0");
    } else*/
    if (this.modes["K"].complete && this.isScored) {
        dataString += ",PASS=" + (this.passed ? "1" : "0") + ",SCORE=" + this.score;
    }
    lmslog.addEntry(0, fname, "dataString", dataString);
    return dataString;
}

LmsTopicStatus.prototype.getStatus = function () {
    var itemstatus = "";
    if (this.isComplete()) {
        //topic is complete
        // NB: Test for avail is still correct here. We want to return "C" to 
        // lmsui if knowit unavailable, even if topic was passed when launched in
        // UT mode.
        if (/*this.modes["E"].avail ||*/(this.modes["K"].avail && this.isScored)) {
            if (this.passed) {
                itemstatus = LMS_PASSED;
            }
            else {
                itemstatus = LMS_FAILED;
            }
        } else {
            itemstatus = LMS_COMPLETED;
            if (this.savedStatus == "P" || this.savedStatus == "F")
                itemstatus = this.savedStatus;
        }
    } else {
        //topic is not complete
        itemstatus = LMS_INCOMPLETE;
        if (this.savedStatus == "P" || this.savedStatus == "F" || this.savedStatus == "C")
            itemstatus = Stat2Lms(this.savedStatus);
    }
    return itemstatus;
}

// Reports Not Attempted for a completed topic where no mode has been launched.
// This keep us from reporting an attempt if the user is just browsing
// the tree and doesn't do anything.
LmsTopicStatus.prototype.getLMSStatus = function () {
    if (this.isComplete() && !this.anylaunched)
        return LMS_NOT_ATTEMPTED;
    return this.getStatus();
}

LmsTopicStatus.prototype.getScore = function () {
    return this.score;
}

// Is considered complete if either the required
// mode is taken or a mode that allows the users
// to demonstrate more knowledge than the required mode
// has been taken.
// From "Play Mode Filtering in LMS"
LmsTopicStatus.prototype.isComplete = function () {
    var fname = "is_complete";
    lmslog.addEntry(0, fname, "", "Start");
    var iscomp = false;

    // Topic has no modes hance no required mode,
    // is considered complete just by visiting it.
    if (this.requiredMode === "None") {
        iscomp = true;
    } else {
        var modeorder = ["E", "K", "T", "S", "P", "D"];
        for (i = 0; i < modeorder.length; i++) {
            if (this.modes[modeorder[i]].complete) iscomp = true;
            if (modeorder[i] === this.requiredMode)
                break
        }
    }
    lmslog.addEntry(0, fname, "iscomp", iscomp);
    return iscomp;
}

LmsTopicStatus.prototype.modeIscomplete = function (f) {
    var ret = false;
    var fname = "modeIscomplete";
    lmslog.addEntry(0, fname, "", "Start");
    if (f == "C")
        ret = true;
    else if (f == "I")
        ret = false;
    lmslog.addEntry(0, fname, "ret", ret);
    return ret;
}

LmsTopicStatus.prototype.isRequired = function (m) {
    return this.requiredMode === m;
}

// holds the status of a single mode launch of a topic
// pretty much duplicates the code in TopicStatus so if topic mode launched
// standalone (UT mode) it can write back to kpath coordinated with a kpath
// launch of the topic
LmsTopicLaunchStatus.prototype = new LmsTopicStatus();
LmsTopicLaunchStatus.prototype.constructor = LmsTopicStatus;
LmsTopicLaunchStatus.prototype.BaseClass = LmsTopicStatus.prototype;

function LmsTopicLaunchStatus(mode) {
    this.mode = this.modes[mode];
    this.score = "";
    this.passed = false;

    this.anylaunched = true;
}

LmsTopicLaunchStatus.prototype.Save = function (lmscom) {
    var fname = "SaveTopicLaunchStatus";

    // serialize state to report back to kpath in UT mode; LMS mode will ignore
    // this and use the mode completion flag for roll-up    
    this.BaseClass.Save.call(this, lmscom);
}

LmsTopicLaunchStatus.prototype._getRequiredMode = function (modes) {
    var modeorder = "EKTSPD";
    for (var i = 0; i < modeorder.length; i++) {
        if (modes.indexOf(modeorder.charAt(i)) != -1)
            return modeorder.charAt(i);
    }
    return "None"
}

// returns result when topic is used in an assessment
LmsTopicLaunchStatus.prototype.getResult = function () {
    return this.passed ? "correct" : "incorrect";
}
LmsTopicLaunchStatus.prototype.getQuestionType = function () {
    return "other";
}
LmsTopicLaunchStatus.prototype.getLearnerResponse = function () {
    return "";
}

//////////////////////////////////////////
// Mode object definition
function Mode(mid) {
    this.avail = false;
    this.complete = false;
    this.id = mid;
}

///////////////////////////////////////
// Question status
///////////////////////////////////////
LmsQuestionStatus.prototype = new LmsBasicStatus();
LmsQuestionStatus.prototype.constructor = LmsQuestionStatus;
LmsQuestionStatus.prototype.BaseClass = LmsBasicStatus.prototype;

function LmsQuestionStatus() {
    this.question_type = null;
    this.learner_response = null;
    this.result = null;
}

LmsQuestionStatus.prototype.Save = function (lmscom) {
    lmscom.lesson_status = this.status;
    lmscom.lesson_data = Lms2Stat(this.getStatus());
}

LmsQuestionStatus.prototype.getStatus = function () {
    return this.status === LMS_NOT_ATTEMPTED ? this.savedStatus : this.status;
}

/* get/set question type */
LmsQuestionStatus.prototype.getQuestionType = function () {
    return this.question_type;
}

LmsQuestionStatus.prototype.setQuestionType = function (qtype) {
    return this.question_type = qtype;
}

/* get/set Learner Response */
LmsQuestionStatus.prototype.getLearnerResponse = function () {
    return this.learner_response;
}

LmsQuestionStatus.prototype.setLearnerResponse = function (lresp) {
    return this.learner_response = lresp;
}

LmsQuestionStatus.prototype.getResult = function () {
    return this.result;
}

LmsQuestionStatus.prototype.setResult = function (result) {
    return this.result = result;
}

///////////////////////////////////////
// Assessment status
///////////////////////////////////////
LmsAssessmentStatus.prototype = new LmsBasicStatus();
LmsAssessmentStatus.prototype.constructor = LmsAssessmentStatus;
LmsAssessmentStatus.prototype.BaseClass = LmsBasicStatus.prototype;

function LmsAssessmentStatus() {
    this.score = "";
    this.questionstatus = new Array();
    this.stateDiscarded = false;    // saved state was discarded due to change in assessment
}

LmsAssessmentStatus.prototype.Save = function (lmscom) {
    lmscom.lesson_status = this.status;

    if (this.status != LMS_INCOMPLETE &&
        this.status != LMS_NOT_ATTEMPTED)
        lmscom.score = this.score;
    else
        lmscom.score = "";

    var str = "";
    if (!lmscom.bigsco)
        str = this.hash.length + "@" + this.hash;
    // if a new attempt and we didn't do anything, keep old saved status    
    str += this.status == LMS_NOT_ATTEMPTED ? this.savedStatus : Lms2Stat(this.status);
    for (var i = 0; i < this.questionstatus.length; i++)
        str += this.questionstatus[i];
    lmscom.lesson_data = str;
}

LmsAssessmentStatus.prototype.getStatus = function () {
    return this.status === LMS_NOT_ATTEMPTED ? Stat2Lms(this.savedStatus) : this.status;
}

LmsAssessmentStatus.prototype.getLMSStatus = function () {
    return this.status;
}
/* get/set Learner Response */
LmsAssessmentStatus.prototype.getScore = function () {
    return this.score;
}

LmsAssessmentStatus.prototype.setScore = function (score) {
    return this.score = score;
}

///////////////////////////////////////
// TOC status
///////////////////////////////////////
LmsTOCStatus.prototype = new LmsBasicStatus();
LmsTOCStatus.prototype.constructor = LmsTOCStatus;
LmsTOCStatus.prototype.BaseClass = LmsBasicStatus.prototype;

function LmsTOCStatus() {
}

LmsTOCStatus.prototype.getStatus = function () {
    return Stat2Lms(this.getTocState().GetStatus(0));
}

LmsTOCStatus.prototype.Save = function (lmscom) {
    lmscom.lesson_status = this.getStatus();

    var tocstat = this.getTocState();
    lmscom.lesson_data = tocstat.SerializeTOC();
}

/* get/set the state structure for the entire
TOC */
LmsTOCStatus.prototype.getTocState = function () {
    return this.tocstate;
}

LmsTOCStatus.prototype.setTocState = function (tocstate) {
    return this.tocstate = tocstate;
}

function NodeState() {
    this.Status = 'N';
    this.Score = null;
    this.ChildrenStatus = "";
}

/* class that holds the state of the tree */
function TOCState(count, tocversion) {
    this.NodeCounter = count;
    this.TocVersion = tocversion;

    this.InitInLookupTable();
}

/* sets the status of the outline element based on its index */
TOCState.prototype.SetStatus = function (index, status) {
    if (!this.LookUpTable[index])
        this.LookUpTable[index] = new NodeState();
    this.LookUpTable[index].Status = status;
}

/* gets the status of the outline element based on its index */
TOCState.prototype.GetStatus = function (index) {
    return this.LookUpTable[index].Status;
}

/* sets the score of the outline element based on its index */
TOCState.prototype.SetScore = function (index, score) {
    if (!this.LookUpTable[index])
        this.LookUpTable[index] = new NodeState();

    this.LookUpTable[index].Score = score;
}

/* gets the score of the outline element based on its index */
TOCState.prototype.GetScore = function (index) {
    return this.LookUpTable[index].Score;
}

/* sets the score of the outline element based on its index */
TOCState.prototype.SetChildren = function (index, ChildrenStatus) {
    if (!this.LookUpTable[index])
        this.LookUpTable[index] = new NodeState();

    this.LookUpTable[index].ChildrenStatus = ChildrenStatus;
}

/* gets the score of the outline element based on its index */
TOCState.prototype.GetChildren = function (index) {
    return this.LookUpTable[index].ChildrenStatus;
}

/* Deserializes the persisted state (str) into the TOC XML
outline structure */
TOCState.prototype.DeserializeTOC = function (str) {
    var count = 0;
    var version;

    var index = str.indexOf("@");
    var count;

    if (index > 0) {
        count = parseInt(str.substring(0, index));
        version = str.substring(index + 1, index + count + 1);
    }
    else
        return;

    /* if the TOC has changed since last 
    time data was persisted, throw away the 
    persisted data */
    if (version != this.TocVersion)
        return;

    var statusstr = str.substring(index + count + 2);

    index = statusstr.indexOf("@");
    if (index > 0) {
        count = parseInt(statusstr.substring(0, index));
        statusstr = statusstr.substring(index + 1, index + count + 1);

        /* if the status string isn't equal to the 
        count we stored for it,then the string got 
        truncated by the LMS because it was too big
        so throw away the data */
        if (statusstr.length != count)
            return;
    }
    else
        return;

    statusstr = this.RLESDecode(statusstr);
    str = this.DeserializeLookUpTable(statusstr);
}

/* Deserializes the persisted state (str) of just the tree portion 
of the outline into the XML outline structure */
TOCState.prototype.DeserializeLookUpTable = function (str) {
    var count = 0;
    var score = "";

    for (var i = 0; i < str.length; i++) {
        var status = str.charAt(i);
        this.SetStatus(count, status);

        score = "";
        while (i < str.length - 1 && str.charAt(i + 1) >= "0" && str.charAt(i + 1) <= "9") {
            i++;
            score += str.charAt(i);
        }

        if (score.length > 0)
            this.SetScore(count, parseInt(score));

        if (i < str.length - 1 && str.charAt(i + 1) == "{") {
            var j = str.indexOf("}", i + 2);
            this.SetChildren(count, str.substring(i + 2, j));
            i = j;
        }

        count++;
    }
}

//this.TocVersion.length
TOCState.prototype.SerializeTOC = function () {
    var statusstr = this.RLESEncode(this.SerializeLookupTable());
    return this.TocVersion.length + "@" + this.TocVersion + " " + statusstr.length + "@" + statusstr;
}

TOCState.prototype.SerializeLookupTable = function () {
    var str = '';

    for (var i = 0; i < this.NodeCounter; i++) {

        var status = this.LookUpTable[i].Status;
        var score = this.LookUpTable[i].Score;
        var childrenstatus = this.LookUpTable[i].ChildrenStatus;

        if (!status) status = "N";

        str += status;
        //        if (score !== null)
        //            str += score;

        if (childrenstatus)
            str += "{" + childrenstatus + "}";
    }

    return str;
}

TOCState.prototype.InitInLookupTable = function () {
    this.LookUpTable = new Array();

    for (var i = 0; i < this.NodeCounter; i++) {
        this.LookUpTable[i] = new NodeState();
    }
    this.SetStatus(0, "I");
}

/* Run lenght encode (RLE) the string to compress the storage */
TOCState.prototype.RLESEncode = function (str) {
    var last = '';
    var run = 0;
    var outstr = '';

    last = str.charAt(0);
    run = 1;

    for (var i = 1; i < str.length; i++) {
        if (str.charAt(i) == last) {
            run++;
        }
        else {
            if (run > 2) {
                outstr += "#";
                outstr += run;
                outstr += last;
            }
            else {
                outstr += str.substring(i - run, i)
            }

            last = str.charAt(i);
            run = 1;
        }
    }

    if (run > 2) {
        outstr += "#";
        outstr += run;
        outstr += last;
    }
    else {
        outstr += str.substring(i - run, i)
    }

    return outstr;
}

/* Run lenght decode (RLE) the string */
TOCState.prototype.RLESDecode = function (str) {
    var outstr = '';
    var runcountstr = '';
    var runcount;

    for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) == '#') {
            runcountstr = '';
            i++;
            while (str.charAt(i) >= "0" && str.charAt(i) <= "9") {
                runcountstr += str.charAt(i);
                i++;
            }

            runcount = parseInt(runcountstr);
            for (var j = 0; j < runcount; j++)
                outstr += str.charAt(i);
        }
        else
            outstr += str.charAt(i);
    }

    return outstr;
}

function Lms2Stat(lmsStatus) {
    return lmsStatus.charAt(0).toUpperCase();
}

function Stat2Lms(status) {
    return [LMS_PASSED, LMS_FAILED, LMS_COMPLETED, LMS_INCOMPLETE, LMS_NOT_ATTEMPTED]["PFCIN".indexOf(status)];
}
/////////////////////
// LogEntry object //
/////////////////////

function LogEntry(startdate, ltype, funcname, varname, msgval) {
    this.logType = ltype;
    this.funcName = funcname;
    this.varName = varname;
    this.msgValue = msgval;
    this.dateTime = new Date().getTime() - startdate;   //Store the entry time in millisecs after the log started
    //alert(this.toString());
}

LogEntry.prototype.GetTableRow = function (i) {
    var typeMsg = "Info";
    var color = "#006600";

    if (this.logType === 1) {
        typeMsg = "LMS Comm";
        color = "#000033";
    }

    var varName = this.varName;
    if (varName === "") { varName = "&nbsp;"; }

    var msgValue = this.msgValue;
    if (msgValue === "") { msgValue = "&nbsp;"; }

    var html = "<tr>";
    html += "<td align='right'>" + (this.dateTime / 1000) + "</td>";
    html += "<td style='color:" + color + ";'>" + this.funcName + "</td>";
    html += "<td>" + varName + "</td>";
    html += "<td>" + msgValue + "</td>";
    html += "</tr>";

    return html;
}


////////////////
// Log object //
////////////////
function Log(active) {
    this.traceWindow = null;
    this.logArray = new Array();
    this.enabled = active;
    this.startDateTime = new Date();
    this.changed = true;    // Flag for letting external parties know when the log has changed
    this.windowReady = false;
    this.startLog();
}

Log.prototype.startLog = function () {
    if (this.enabled) {
        //this.log_string += "<table border='1'><tr><td>Type</td><td>Function</td><td>Variable</td><td>Message</td></tr>";
        this.addEntry(0, "initLog", "", "Log Intialized");
        this.openTraceWindow();
    }
}

Log.prototype.addEntry = function (ltype, funcname, varname, msgval) {
    if (this.enabled) {
        this.logArray.push(new LogEntry(this.startDateTime.getTime(), ltype, funcname, varname, msgval));
        this.changed = true;
        if (this.traceWindow && this.windowReady)
            this.traceWindow.UpdateTraceStack();
    }
}

Log.prototype.writeLog = function (sortOrder, traceLength) {
    var t = traceLength;
    if (t > this.logArray.length || t == 0) {
        t = this.logArray.length;
    }

    var html = "<table width='600'>";
    html += "<tr>";
    html += "<th colspan=4>Session start: " + this.startDateTime + "</th>";
    html += "</tr>";

    html += "<tr>";
    html += "<th>time</th>";
    html += "<th>function</th>";
    html += "<th>variable</th>";
    html += "<th>message</th>";
    html += "</tr>";

    var logEntry;
    if (sortOrder == 0) {
        for (var i = this.logArray.length - t; i < this.logArray.length; i++) {
            logEntry = this.logArray[i];
            html += logEntry.GetTableRow(i);
        }
    } else {
        for (var i = this.logArray.length - 1; i >= this.logArray.length - t; i--) {
            logEntry = this.logArray[i];
            html += logEntry.GetTableRow(i);
        }
    }
    html += "</table>";

    this.changed = false;   // Reset the changed flag
    this.windowReady = true;    // window initiates first call to writelog, so we know we're up
    return html;
}

Log.prototype.writeDetails = function (i) {
    return this.logArray[i].GetDetails();
}

Log.prototype.openTraceWindow = function () {
    if (this.traceWindow == null) {
        this.changed = true;
        this.traceWindow = window.open(lms_path + "html/lmsdebug.html", "_blank");
    }
}

/* lms_init.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

// javascript include area

/*
if (typeof lms_path == 'undefined')
lms_path = "../../../";

document.write('<script type="text/javascript" src="' + lms_path + 'kpsettings.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/scormoptions.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/lmsoptions.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/lmsapplet.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/lmsresource.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/lmscomfactory.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/lmscom.js"></script>');
document.write('<script type="text/javascript" src="' + lms_path + 'js/escape.js"></script>');



<script type="text/javascript" src="kpsettings.js"></script>
<script type="text/javascript" src="js/scormoptions.js"></script>
<script type="text/javascript" src="js/lmsoptions.js"></script>
<script type="text/javascript" src="js/lmsapplet.js"></script>
<script type="text/javascript" src="js/lmsresource.js"></script>
<script type="text/javascript" src="js/lmscomfactory.js"></script>
<script type="text/javascript" src="js/lmscom.js"></script>
<script type="text/javascript" src="js/escape.js"></script>


*/

// launch mode determination

var _lmsMode = null;          // LMS, KPT, Cookie or undefined

var _lmsParser = null;

function InitLmsMode(source) {
    if (_lmsParser == null) {
        _lmsParser = new UrlParser();
        _lmsParser.Parse();

        // direct launch
        if (source == "player") {
            if (_lmsParser.GetParameter("directlaunch") != null) {
                _lmsMode = (Kpath_launch == true ? "KPT" : "Cookie");
            }
        }

        // lmstart
        else if (source == "lmstart") {
            if (_lmsParser.GetParameter("toc") != null) {
                // _lmsMode = null;
            }
            else if (_lmsParser.GetParameter("dhtml") != null) {
                _lmsMode = (Kpath_launch == true ? "KPT" : "Cookie");
            }
            else {
                _lmsMode = "LMS";
            }
        }

        // toc
        else if (source == "toc") {
            if (_lmsParser.GetParameter("sco") == null) {
                _lmsMode = (Kpath_launch == true ? "KPT" : "Cookie");
            }
        }

        else {
            alert(R_undefined_lms_source);
        }
    }
}

function GetTopLevelLmsMode() {
    return _GetTopLevelLmsMode(this);
}

function _GetTopLevelLmsMode(w) {
    var m = w._lmsMode;
    if (m == null) {
        return _GetTopLevelLmsMode(w.lms_store.parentW);
    }
    return m;
}

// common lms callback functionality

var lms_initialized = false;

var lms_store;

var lmslog;

// lms_InitPage()
// called from onLoad event
function lms_InitPage(childIndex, parentW, cguid, callbackfunction) {
    if (lms_initialized == true) {
        setTimeout(callbackfunction, 1);
        return;
    }
    __Ialert("lms_InitPage called with parameters:" + childIndex + "," + parentW + "," + cguid + "," + callbackfunction);

    lms_store = { window: window,
        childIndex: childIndex,
        parentW: parentW,
        cguid: cguid,
        callbackfunction: callbackfunction
    };

    if (!parentW || parentW.closed) {
        lmslog = new Log(LmsConfig.DebugMode);
        InitializeLmsCom();
        InsertRuntimeAPI(lms_LoadRuntimeComplete);
    } else {
        if (!parentW.lms_initialized) return; // handle funky refresh handling of Firefox
        lmslog = parentW.lmslog;
        setTimeout(lms_LoadRuntimeComplete, 1);
    }
}

function lms_LoadRuntimeComplete() {
    __Ialert("lms_LoadRuntimeComplete() called");
    if (lms_store.parentW && !lms_store.parentW.closed) {
        lms_store.parentW.GetChildLmsCom(lms_store);
    } else if (!lms_store.parentW && !lms_store.cguid && !window.bigScoItemCount) { // launching a non-bigsco toc
        // NB: window.bigScoItemCount will only be defined in the lmstart page of a big sco
        document.LmsCom = PlayerConfig.EnableCookies ? new LmsComCookie() : new LmsComBase();
    } else {
        CheckForLMSAPI();
        document.LmsCom = _GlobalLmsComFactory.CreateLmsCom();
    }
    var lmscom = document.LmsCom;

    lmscom.guid = lms_store.cguid;
    lmscom.owner = window;
    lmscom.LoadAPIAdapter(lms_LoadAdapterComplete);
}

// lms_UpdateUI()
// called from first level assets to update the UI status bar
function lms_UpdateUI(status) {
    try {
        if (parent && parent.updateUI)
            parent.updateUI(status);
    } catch (e) { }
}

// lms_ClosePage()
// called from onUnload event
var hasClosed = false;
function lms_ClosePage(callClose) {
    __Ialert("lms_ClosePage() called");
    if (hasClosed == true)
        return;
    hasClosed = true;
    var lmscom = document.LmsCom;
    if (!lmscom || !lmscom.session_active)
        return;
    var childlmscom = lmscom.child;
    if (childlmscom && childlmscom.session_active && childlmscom.owner && !childlmscom.owner.closed)
        childlmscom.owner.lms_ClosePage(true);
    childlmscom = lmscom.ancillaryChild;    // close see also trail, if any
    if (childlmscom && childlmscom.session_active && childlmscom.owner && !childlmscom.owner.closed)
        childlmscom.owner.lms_ClosePage(true);
    if (window._closePage)
        _closePage();   // do any asset specific stuff
    if (lmscom.session_active) {    // test if our twin (lmstart/lmsui) snuck in (FF)
        lmscom.SaveStatus();
        lmscom.End();
        lmscom.NotifyParent();
    }
    if (callClose)
        window.close();
}

// connection drop
function lms_ConnectionLost(errText) {
    if (window.ConnectionLostEvent)
        ConnectionLostEvent(errText);
    if (lms_store.parentW && !lms_store.parentW.closed)
        lms_store.parentW.lms_ConnectionLost(errText);
}

function lms_IsConnected() {
    var lmscom = document.LmsCom;
    if (lmscom)
        return lmscom.IsConnected();
    return false;
}

// KPath logout
function lms_IsKPathLogoutAvailable() {
    return !!window.Kpath_logout_available;
}

function _logout(closeWindow) {
    if (lms_store.parentW && !lms_store.parentW.closed && lms_store.parentW._logout) {
        lms_store.parentW._logout(false);
    } else if (window.Kpath_logout_URL) {
        if (GetTopLevelLmsMode() == "LMS") {
            window.parent.parent.location.replace(Kpath_logout_URL);
        } else if (closeWindow) {   // need to logout through the opener window
            if (window.opener && !window.opener.closed) {
                window.opener.location.replace(Kpath_logout_URL);
                window.close();
            } else {    // if no opener available, must logout through full screen topic window
                window.location.replace(Kpath_logout_URL);
            }
        } else {
            window.location.replace(Kpath_logout_URL);
        }
    }
}

// user profile (so it is accessible from everywhere)
function lms_IsUserProfileAvailable() {
    __alert("lms_IsUserProfileAvailable() called");
    if (GetTopLevelLmsMode() !== "KPT")
        return false;
    return document.LmsCom.doGetUPKValue("upk.anonymous") == "0";
}

function lms_GetUserProfileUrl() {
    __alert("lms_GetUserProfileUrl() called");
    if (Kpath_launch == false)
        return "";
    return Kpath_profile_URL + "?UPKLaunch=true";
}

function GetNoSound() {
    if (lms_store.parentW && !lms_store.parentW.closed)
        return lms_store.parentW.GetNoSound();
    else
        return lms_store.noSound;
}

function SetNoSound(value) {
    lms_store.noSound = value;
}

// lms callback trace functions

var _lms_show_all_alert = false;

function __alert(s) {
    if (_lms_show_alert || _lms_show_all_alert)
        alert(s + "\nfile: " + _lms_module_name);
}

function __Ialert(s) {
    if (_lms_show_alert || _lms_show_Ialert || _lms_show_all_alert)
        alert(s + "\nfile: " + _lms_module_name);
}
/* playerlaunch.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

var doItplayerWindow = null;

function LaunchDoIt(url, params) {
    var popupVersion = false;
    var _params = params;

    var run = true;
    if (doItplayerWindow) {
        if (!doItplayerWindow.closed)
            run = false;
    }

    if (run) {
        if (upk.browserInfo.isExplorer()) {
            try {
                function IsWindowPositioningRestricted() {
                    var p = window.createPopup();
                    p.show(1, 1, 1, 1);
                    var r = p.document.parentWindow.screenTop == 1;
                    p.hide();
                    return !r;
                }

                if (!IsWindowPositioningRestricted() && !upk.browserInfo.isIE10Modern()) {
                    var safeuri = false;
                    if (_params.substr(0, 3) == "su=") {
                        _params = Escape.SafeUriUnEscape(_params.substr(3));
                        safeuri = true;
                    }
                    _params += "&popup=true";
                    if (safeuri) {
                        _params = "su=" + Escape.SafeUriEscape(_params);
                    }
                    popupVersion = true;
                }
            } catch (e) {
            }
        }

        if (popupVersion) {
//            if (IsIE9()) {url = url + "topicgc.html"; }
//            else {url = url + "topicgcx.html"; }
            url = url + "topicgc.html";
            var url2 = typeof (urlParser) == "undefined" ? url + "?" + _params : urlParser.GetCorrectUrl(url + "?" + _params);
            doItplayerWindow = window.open(url2, "", "toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,left=1500");
        }
        else {
            url = url + "topicgcx.html";
            if (upk.browserInfo.isExplorer()) {
                var appVerArray = navigator.appVersion.split(";");
                var appVer = appVerArray[1];
                appVer = appVer.substr(6)
                appVer = parseFloat(appVer);
            }
            var LeftPos = upk.browserInfo.isSafari() ? screen.availWidth - 361 : screen.availWidth - 290;
            var TopPos = screen.availHeight - 450;
            var popWidth = upk.browserInfo.isSafari() ? 346 : 275;
            var popHeight = 400;
            if (PlayerConfig.EnableCookies) {
                GICookie = new Cookie(document, "GICookie", 365, "/", null, null)
                if (GICookie.Load()) {
                	if (GICookie["Cleft"] >= 0 && GICookie["Ctop"] >= 0 && parseInt(GICookie["Cleft"]) + parseInt(GICookie["Cwidth"]) < screen.availWidth && GICookie["Ctop"] < screen.availHeight) {
                        LeftPos = parseInt(GICookie["Cleft"]);
                        TopPos = parseInt(GICookie["Ctop"]);
                        popWidth = parseInt(GICookie["Cwidth"]);
                        popHeight = parseInt(GICookie["Cheight"]);
                    }
                }
            }
            var url2 = typeof (urlParser) == "undefined" ? url + "?" + _params : urlParser.GetCorrectUrl(url + "?" + _params);
            doItplayerWindow = window.open(url2, "", "toolbar=0,scrollbars=0,location=1,statusbar=0,menubar=0,resizable=1,left=" + LeftPos + ",top=" + TopPos + ",width=" + popWidth + ",height=" + popHeight);
        }
    }
    else {
        alert(R_toc_doit_err);
    }
}


/* sound.js */
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved. 
--*/

// -----------------------------------------------------------------------------
// Globals
// Version of Flash required
var requiredFlashVersion = "9.0.124";

var _name = "";
var _asyn = false;
var _fire = false;
var _knowpalyer = false;
// -----------------------------------------------------------------------------
// -->

/*
if (navigator.platform == "MacPPC" && navigator.userAgent.indexOf("Safari") >= 0) {
requiredFlashVersion = "7.0.14";
}
*/

var bPlayerIsAvailable = false;
var useAudioTag = false;
var useFlash = false;

//////////////////////////////////////////////////////////////////////////////////////////////////////

// document.write("<div id='fplayer'></div>"); NEED TO BE DEFINED IN HTML NEXT TO THE BODY TAG

var hasRequestedVersion;
var _fPlayerPath = "";
var soundjs_initialized = false;

function SoundjsInit() {
    if (soundjs_initialized == true)
        return;
    soundjs_initialized = true;
    var k = document.getElementById("fplayer");
    if (k) {
        // Bug 16683852 - ipad - pdf concept does not appear for the first time
        if (typeof assetType === 'undefined')
            k.innerHTML = "<audio id='upkaudio' onended='AudioEnded();' onerror='AudioError();' oncanplay='AudioLoaded()' style='display: none;'><Source type='audio/mpeg'></audio>";
    }

    /* This hack is to deal with a bug on iOS5.
    We found that sometimes we would request sound to 
    start playing after changing the source and it would
    never start playing.  When that happens, loadstart event
    fires but the durationchange does not.   So we use
    that fact to restart the play request.  */
    if (upk.browserInfo.isiOS5() && typeof assetType === 'undefined') {
        getAPlayer().addEventListener("loadstart", SoundPlayer_OnLoadStart);
        getAPlayer().addEventListener("durationchange", SoundPlayer_OnDurationChange);
    }

    hasRequestedVersion = swfobject.hasFlashPlayerVersion(requiredFlashVersion);
    try {
        _fPlayerPath = (_webpage_ == true ? "../../../../" : "../../../");
    }
    catch (e) { _fPlayerPath = "../../../" };

    SupportAAC();

    CheckAndEnableSound();
}



function SoundPlayer_OnLoadStart() {
    if (SoundPlayerObj.LoadStartTimer) clearInterval(SoundPlayerObj.LoadStartTimer);

    if (getAPlayer().src)
        SoundPlayerObj.LoadStartTimer = setInterval("SoundPlayer_Started()", 3000);
}

function SoundPlayer_OnDurationChange() {
    if (SoundPlayerObj.LoadStartTimer) {
        clearInterval(SoundPlayerObj.LoadStartTimer);
        SoundPlayerObj.LoadStartTimer = 0;
    }
}

function SoundPlayer_Started() {
    /* must reset source */
    getAPlayer().src = getAPlayer().src;
    getAPlayer().play();
}
/* end hack */


function SupportAAC() {
    if (upk.browserInfo.isiOS()) {
        useAudioTag = true;
        bPlayerIsAvailable = true;
        if (PlayerConfig.AACIsAvailable == true)
            return true;
    }
    return false;
}

function CheckAndEnableSound() {
    var k = false;
    try {
        k = soundIsPublished();
    }
    catch (e) {
        k = false;
    }
    if (k == true) {
        if (hasRequestedVersion && !IsTouchDevice() && bPlayerIsAvailable == false && UserPrefs.PlayAudio != 'none') {
            swfobject.embedSWF(_fPlayerPath + "audio/fplayer.swf", "fplayer", "1", "1", requiredFlashVersion, null, null, null, null, onLoadFlash);
            return;
        }
    }
}

function onLoadFlash(e) {
    if (e.success == true) {
        useFlash = true;
        bPlayerIsAvailable = true;
    }
    document.getElementById("fplayer").style.position = "absolute";
    document.getElementById("fplayer").style.top = "0px";
    document.getElementById("fplayer").style.left = "0px";
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

function AreCookiesEnabled() {
    if (PlayerConfig.EnableCookies == false)
        return false;
    var tmpcookie = new Date();
    chkcookie = (tmpcookie.getTime() + '');
    document.cookie = "chkcookie=" + chkcookie + "; path=/";
    return ((document.cookie.indexOf(chkcookie, 0)) < 0 ? false : true);
}

function Check_Flash(exported, audioPref) {
    if (exported == false)
        return true;
    if (SupportAAC() == true)
        return true;
    if (hasRequestedVersion == false) {
        if (audioPref != "none") {
            return false;
        }
    }
    return true;
}

function getFPlayer() {
    return document.getElementById("fplayer");
}

function getAPlayer() {
    return document.getElementById("upkaudio");
}

function Sound_Init(exported, audioPref, closerFunction, newwindow, path) {
    SoundjsInit();
    if (Check_Flash(exported, audioPref) == true)
        return true;

    if (!SupportAAC() && upk.browserInfo.isiOS())
        return true;

    var _path = "../../../";
    if (path != undefined)
        _path = path;
    if (closerFunction != null)
        eval(closerFunction);
    sw = (screen.width - 640) / 2;
    sh = (screen.height - 480) / 2;
    if (newwindow == null)
        newwindow = true;
    KeepAlive_DoNotSendClose();
    if (newwindow == true)
        window.open(_path + "html/getflash.html?url=" + Escape.MyEscape(this.location.href) + "&newwindow", "", "top=" + sh + ", left=" + sw + ", width=640, height=480, resizable=1,toolbar=1,scrollbars=1,location=1,statusbar=1,menubar=1,fullscreen=0");
    else if (newwindow == "parent") // windowed player
        setTimeout('parent.location.replace("' + _path + 'html/getflash.html?url=' + Escape.MyEscape(parent.location.href) + '")', 10);
    else
        setTimeout('this.location.replace("' + _path + 'html/getflash.html?url=' + Escape.MyEscape(this.location.href) + '")', 10);
    return false;
}

function SoundPlayerClass() {
    this.TopicPath = unescape(window.location.href);
    while (this.TopicPath.indexOf('\\') != -1)
        this.TopicPath = this.TopicPath.replace('\\', '/');

    var i = this.TopicPath.indexOf("?");
    if (i >= 0)
        this.TopicPath = this.TopicPath.substr(0, i);
    i = this.TopicPath.lastIndexOf("/");
    this.TopicPath = this.TopicPath.substr(0, i + 1);

    this.RootPath = this.TopicPath;
    for (var j = 0; j <= 3; j++) {
        i = this.RootPath.lastIndexOf("/");
        if (i != -1)
            this.RootPath = this.RootPath.substr(0, i);
    };
    this.RootPath = this.RootPath + '/';
    this.SoundPath = this.TopicPath;
    this.AudioPath = resolveUri(this.TopicPath, "../../../audio/");
    this.Volume = 100;

    /* iOS 6.1/5.1 hack to track whether we think sound
    is playing */
    this.LoadStartTimer = 0;
    this.PlayCheckerTimer = 0;
}

function resolveUri(s1, s2) {
    return (s1 + s2);
}

SoundPlayerClass.prototype.ChangeFileSuffix = function (sndfile) {
    var n = sndfile.lastIndexOf(".mp3");
    if (n == sndfile.length - 4)
        return sndfile;
    var s = sndfile.substr(0, sndfile.length - 4);
    if (PlayerConfig.AACIsAvailable || upk.browserInfo.isiOS())
        return s + ".m4a";
    if (useFlash)
        return s + ".flv";
    alert("sound - file extension error");
}

SoundPlayerClass.prototype.Play = function (sndfile, audiofile, templatefile, asyncron) {
    if (useFlash) {
        var fplayer = getFPlayer();
        if (fplayer) {
            fplayer.style.top = getScrollTop() + "px";
            fplayer.style.left = getScrollLeft() + "px";
        }
    }

    if (!audiofile)
        S_SetFrameState("S");

    var frameState = S_GetFrameState();
    if (!asyncron)
        asyncron = false;

    if (!bPlayerIsAvailable) {
        if (asyncron == false) {
            if (frameState != "D")
                S_SetFrameState("D");
            OnErrorPlaySound();
        }
        return;
    }

    if (!templatefile)
        templatefile = false;
    if (templatefile == true) {
        if (asyncron == false)
            OnEndPlaySound();
        return;
    }

    if (sndfile.length == 0) {
        if (asyncron == false) {
            if (frameState != "D")
                S_SetFrameState("D");
            OnErrorPlaySound();
        }
        return;
    }

    if (sndfile.substr(sndfile.length - 4) == ".ASX") {
        var d = sounds[sndfile].duration.split(":");
        try {
            _lastAudioFileSize = parseInt(d[0]) * 60 * 60 + parseInt(d[1]) * 60 + parseFloat(d[2]);
        }
        catch (e) {
            _lastAudioFileSize = 0;
        }
        sndfile = sounds[sndfile].flist[0];
    };

    SoundPlayer_Stop();
    if (sndfile.length == 0) {
        if (asyncron == false) {
            if (frameState != "D")
                S_SetFrameState("D");
            OnErrorPlaySound();
        }
        return;
    }

    fname = (audiofile ? resolveUri(this.AudioPath, sndfile) : resolveUri(this.SoundPath, sndfile));

    _name = this.ChangeFileSuffix(fname);
    _asyn = asyncron;
    _fire = true;
    if (useFlash) {
        if (_knowpalyer == true) {
            setTimeout("SoundPlayer_Open(\"" + _name + "\"," + asyncron + ")", 120);
        }
    }
    else if (useAudioTag) {
        setTimeout("SoundPlayer_Open(\"" + _name + "\"," + asyncron + ")", 120);
    }
}

SoundPlayerClass.prototype.Stop = function (noTimeout) {
    if (bPlayerIsAvailable) {
        if (!noTimeout)
            setTimeout("SoundPlayer_Stop()", 10);
        else
            SoundPlayer_Stop();
    };
}

SoundPlayerClass.prototype.Pause = function () {
    try {
        if (bPlayerIsAvailable) {
            if (useFlash)
                getFPlayer().SoundPause();
            if (useAudioTag)
                getAPlayer().pause();
        }
    }
    catch (e) { };
}

SoundPlayerClass.prototype.Resume = function () {
    if (!InWebpage()) {
        if (getLastSoundFileName() != getActualSoundFileName())
            return;
    }
    try {
        if (bPlayerIsAvailable) {
            if (useFlash)
                getFPlayer().SoundPlay();
            if (useAudioTag)
                getAPlayer().play();
        }
    }
    catch (e) { };
}

SoundPlayerClass.prototype.InitAudioPlayer = function () {
    if (bPlayerIsAvailable) {
        if (useAudioTag) {
            getAPlayer().src = this.AudioPath + "empty.m4a";
            getAPlayer().play();
        }
    }
}

SoundPlayerClass.prototype.IsAvailable = function () {
    return bPlayerIsAvailable;
};

SoundPlayerClass.prototype.SetSoundPath = function (s) {
    if (s.length > 0)
        this.SoundPath = s;
};

SoundPlayerClass.prototype.SetVolume = function (t) {   //  0 <= t <= 100
    if (t == null)
        t = this.Volume;
    else
        this.Volume = t;
    if (useFlash) {
        try {
            getFPlayer().SetSoundVolume(t / 100);
        }
        catch (e) { };
    }
    if (useAudioTag) {
        try {
            getAPlayer().volume = (t / 100);
        }
        catch (e) { };
    }
}

function InWebpage() {
    if (typeof (_webpage_) === "undefined")
        return false;
    return _webpage_;
}

function SoundPlayer_EndCheck() {
    var htmlaudio = getAPlayer();
    if (htmlaudio.ended && SoundPlayerObj.PlayCheckerTimer) {
        setTimeout(function () {
            if (SoundPlayerObj.PlayCheckerTimer)
                SoundComplete(false);
        },
         50);
    }
}

var _lastAsyncronFile = false;
var _lastAudioFile = "";
var _lastFlashTime = -1;
var _lastAudioFileSize = 0;
var _lastFileName = "";

function clearLastSoundFileName() {
    _lastFileName = "";
}

function getLastSoundFileName() {
    return _lastFileName.substr(_lastFileName.lastIndexOf('/') + 1);
}

function getActualSoundFileName() {
    try {
        return sounds[showActObj.id.substr(1) + ".ASX"].flist[0];
    }
    catch (e) {
        return "";
    }
}

function SoundPlayer_Open(fname, asyncron) {
    if (fname.length > 0)
        _lastFileName = fname;
    try {
        if (fname.length > 0 && asyncron == true)
            _lastAsyncronFile = true;
        if (timelineDescriptor.valid && timelineDescriptor.type != "narration") {
            throw "";
        }
        if (useFlash) {
            audio_loading = true;
            _lastFlashTime = -1;
            getFPlayer().SetSoundFile(fname);
            getFPlayer().SoundPlay();
            if (timelineDescriptor.valid && timelineDescriptor.type == "narration") {
                SoundFPlayer_SetTime();
                return;
            }
            audio_loading = false;
        }
        if (useAudioTag) {
            audio_loading = true;
            getAPlayer().pause();
            if (_lastAudioFile == fname) {
                AudioLoaded();
            }
            else {
                getAPlayer().src = fname;
                CLog(fname + " - " + _lastAudioFile + " play");
            }
            _lastAudioFile = fname;
        }
        SoundPlayerObj.SetVolume();
        if (upk.browserInfo.isiOS()) {
            if (SoundPlayerObj.PlayCheckerTimer)
                clearInterval(SoundPlayerObj.PlayCheckerTimer);
            SoundPlayerObj.PlayCheckerTimer = setInterval("SoundPlayer_EndCheck()", 500);
        }
    }
    catch (e) {
        S_SetFrameState("D");
        if (asyncron == false)
            OnErrorPlaySound();
    }
}

function SoundFPlayer_SetTime() {
    getFPlayer().SoundPause();
    getFPlayer().SoundSeek(timelineDescriptor.resttime / 1000);
    var d = Math.abs(timelineDescriptor.resttime / 1000 - getFPlayer().Time());
    if (d < 0.3) {
        getFPlayer().SoundPlay();
        audio_loading = false;
        return;
    }
    setTimeout("SoundFPlayer_SetTime()", 300);
}

function SoundAPlayer_SetTime() {
    if (audio_seeking == false)
        return;
    if (audio_counter > 100) {
        setTimeout("AudioReload();", 100);
        return;
    }
    audio_counter++;
    var resttime = 0;
    if (timelineDescriptor.valid == true && timelineDescriptor.type == "narration") {
        resttime = timelineDescriptor.resttime / 1000;
        if (resttime > _lastAudioFileSize - 1) {
            getAPlayer().pause();
            SoundComplete();
            CLog("nextframe");
            return;
        }
        if (resttime < 0)
            resttime = 0;
    }
    try {
        getAPlayer().currentTime = resttime;
    }
    catch (e) {
        setTimeout("SoundAPlayer_SetTime()", 300);
    }
    var ct = getAPlayer().currentTime;
    var d = Math.abs(ct - resttime);
    try {
        CLog("d: " + d + " " + ct + " " + resttime + " " + _lastAudioFileSize + " " + showScreen);
    }
    catch (e) {
        CLog("d: " + d + " " + ct + " " + resttime + " " + _lastAudioFileSize);
    }
    if (d < 0.3) {
        audio_seeking = false;
        CLog("play...");
        getAPlayer().play();
    }
    else {
        setTimeout("SoundAPlayer_SetTime()", 300);
    }
}

function SoundIsLocked() {
    return (audio_loading == true || audio_seeking == true);
}

function SoundPlayer_Stop() {
    try {
        if (SoundPlayerObj.PlayCheckerTimer) {
            clearInterval(SoundPlayerObj.PlayCheckerTimer);
            SoundPlayerObj.PlayCheckerTimer = 0;
        }
        _lastAsyncronFile = false;
        if (useFlash)
            getFPlayer().SoundStop();
        if (useAudioTag) {
            getAPlayer().pause();
        }
    }
    catch (e) { }
}

function SoundPlayer_GetTime() {
    var sfile = getLastSoundFileName();
    var id = showActObj.id.substr(1);
    var s2file = sounds[id + '.ASX'].flist[0];
    if (sfile.length > 0 && sfile != s2file) {
        return { s: sfile, t: NaN };
    }
    var fTime = 0;
    if (useAudioTag) {
        fTime = getAPlayer().currentTime * 1000;
    }
    if (useFlash) {
        var fTime = getFPlayer().Time() * 1000;
    }
    if (fTime == 0 && _lastFlashTime >= 0)
        fTime = _lastFlashTime;
    else
        _lastFlashTime = fTime;
    return { s: sfile, t: fTime };
}

function OnFlashLoad() {
    if (_fire == true) setTimeout("SoundPlayer_Open(\"" + _name + "\"," + _asyn + ")", 20);
    _fire_ = false;
    _knowpalyer = true;
}

function SoundComplete(error) {
    if (InWebpage()) {
        if (error)
            OnErrorPlaySound();
        else
            OnEndPlaySound();
        return;
    }
    if (SoundPlayerObj.PlayCheckerTimer) {
        clearInterval(SoundPlayerObj.PlayCheckerTimer);
        SoundPlayerObj.PlayCheckerTimer = 0;
    }
    if (_lastAsyncronFile) {
        _lastAsyncronFile = false;
        return;
    }
    if (useAudioTag) {
        if (error) {
            S_SetFrameState("D");
            OnErrorPlaySound();
        }
        else {
            if (typeof (animObject) != "undefined") {
                if (animObject) {
                    if (fusionmode == true && animObject.timeout == DELAY_INFINITE * 100) {
                        if (animObject.showbubble == false)
                            animObject.timeout = 0;
                    }
                    else {
                        animObject.timeout = 0;
                    }
                }
            }
            OnEndPlaySound();
        }
    }
    if (useFlash) {
        s = getFPlayer().SoundState();
        if (s == "notfoundfile") {
            S_SetFrameState("D");
            OnErrorPlaySound();
        }
        else if (s == "complete") {
            if (typeof (animObject) != "undefined") {
                if (animObject) {
                    if (fusionmode == true && animObject.timeout == DELAY_INFINITE * 100) {
                        if (animObject.showbubble == false)
                            animObject.timeout = 0;
                    }
                    else {
                        animObject.timeout = 0;
                    }
                }
            }
            OnEndPlaySound();
        }
    }
}

function AudioEnded() {
    var a = getAPlayer();
    CLog(a.src + " done...");
    if (a.src.indexOf("empty.m4a") >= 0)
        return;
    SoundComplete(false);
}

function AudioError() {
    var a = getAPlayer();
    if (a == null)
        return;
    if (a.src == "")
        return;
    if (a.src.indexOf("empty.m4a") >= 0)
        return;
    CLog(a.src + " error...");
    SoundComplete(true);
}

var audio_loading = false;
var audio_seeking = false;
var audio_counter = 0;

function AudioReload() {
    audio_loading = true;
    getAPlayer().pause();
    getAPlayer().src = _lastAudioFile;
    CLog(fname + " - " + _lastAudioFile + " replay");
}

function AudioLoaded() {
    CLog("AudioLoaded");
    if (audio_loading == true) {
        CLog("AudioLoaded true");
        audio_loading = false;
        audio_counter = 0;
        getAPlayer().pause();
        audio_seeking = true;
        SoundAPlayer_SetTime();
    }
}

function S_GetFrameState() {
    try {
        return upk.Timeline.GetFrameState();
    }
    catch (e) { return ""; }
}

function S_SetFrameState(s) {
    try {
        upk.Timeline.SetFrameState(s);
    }
    catch (e) { }
}

function TimelineDescriptor(valid, frameid, timelineindex, narration, animation, resttime) {
    this.valid = valid;
    if (valid) {
        this.frameid = frameid;
        this.timelineindex = timelineindex;
        this.narration = narration;
        this.animation = animation;
        this.resttime = resttime;
        this.type = "narration";
        if (resttime >= narration)
            this.type = "animationstart";
        if (resttime >= narration + (animation / 2))
            this.type = "nextframe";
    }
}

var timelineDescriptor = new TimelineDescriptor(false, "", 0, 0, 0, 0);
var SoundPlayerObj = new SoundPlayerClass();

var clog_enabled = false;

function CLog(s, force) {
    if (clog_enabled || force == true) {
        if (console !== undefined)
            console.log(s);
    }
}

/* ctxhelper.js */
/// <reference path="jquery-1.4.1-vsdoc.js" />

var upk = upk || {};

$.extend(true, upk, {
	contextHelper: function () {
		var _this = this;
		var _parentContextHelper = null;
		
		var currentCtx, prevCtx;

		_this.SetContext = function (ctx, sub) {
			if (_parentContextHelper) { _parentContextHelper.SetContext(ctx, sub); }
			else {
				//alert(window.location + ", ctx:" + ctx + ", sub:" + sub);
				prevCtx = currentCtx;
				currentCtx = { "view": ctx, "subview": sub };
				ias.SetContext(currentCtx);
			}
			return;
		}

		_this.SetNamespace = function (ns) {
			if (!_parentContextHelper) {
				//alert(window.location + ", Namespace:" + ns);
				ias.SetNamespace(ns);
			}
			return;
		}

		_this.AddDiscoveryCddUrl = function (url) {
			if (!_parentContextHelper) {
				ias.AddDiscoveryCddUrl(url);
			}
			return;
		}

		_this.SetPrevContext = function () {
			if (_parentContextHelper) { _parentContextHelper.SetPrevContext(); }
			else {
				currentCtx = prevCtx;
				ias.SetContext(currentCtx);
			}
		}

		try {
			if (self != top && typeof parent.ctxHelper === "object") {
				_parentContextHelper = parent.ctxHelper;
			}
		} catch(e){}

		return _this;
	}
})

window.ctxHelper = new upk.contextHelper();
if (window.ctxHelper instanceof upk.contextHelper) {
}

/* iashelper.js */
//* <XBuild version="12.1.0-release,browser.all,playerscripts-1"/>
//* <BaseDir path="C:/BuildRoot/Engineering/trunk/TargetApps/BrowserAppsBuild/Build/Source/PlayerScripts/"/>
//* <FileRef type="source" path="iashelper.js" time="2013-10-14T02:01:18"/>
//* <FileRef type="reference" path="../IAS-SDK/sources/ias.js" time="2014-01-23T03:01:42"/>


//* <FileBegin path="iashelper.js"/>
//x /// <reference path="../IAS-SDK/sources/ias.js"/>

//* <FileBegin path="../IAS-SDK/sources/ias.js"/>
window['ias'] = (function (win) { // ../IAS-SDK/sources/ias.js: 1

    var nul = null; // ../IAS-SDK/sources/ias.js: 3
    var namespaceString = nul; // ../IAS-SDK/sources/ias.js: 4
    var contextString = nul; // ../IAS-SDK/sources/ias.js: 5
    var contextObject = {}; // ../IAS-SDK/sources/ias.js: 6
    var contextStack = [contextObject]; // ../IAS-SDK/sources/ias.js: 7
    var tagsObject = {}; // ../IAS-SDK/sources/ias.js: 8
    var tagsString = nul; // ../IAS-SDK/sources/ias.js: 9
    var discoveryCddUrls = []; // ../IAS-SDK/sources/ias.js: 10
    var applicableCddUrls = []; // ../IAS-SDK/sources/ias.js: 11

    function Clone(obj) { // ../IAS-SDK/sources/ias.js: 13
        var nobj = {}; // ../IAS-SDK/sources/ias.js: 14
        if (obj != nul) { // ../IAS-SDK/sources/ias.js: 15
            for (var m in obj) { // ../IAS-SDK/sources/ias.js: 16
                var v = obj[m]; // ../IAS-SDK/sources/ias.js: 17
                if (v != nul) // ../IAS-SDK/sources/ias.js: 18
                    nobj[m] = v; // ../IAS-SDK/sources/ias.js: 19
            } // ../IAS-SDK/sources/ias.js: 20
        } // ../IAS-SDK/sources/ias.js: 21
        return nobj; // ../IAS-SDK/sources/ias.js: 22
    } // ../IAS-SDK/sources/ias.js: 23

    function SetNamespace(ns) { // ../IAS-SDK/sources/ias.js: 25
        namespaceString = ns; // ../IAS-SDK/sources/ias.js: 26
    } // ../IAS-SDK/sources/ias.js: 27

    function SetContext(context) { // ../IAS-SDK/sources/ias.js: 29
        contextObject = Clone(context); // ../IAS-SDK/sources/ias.js: 30
        contextStack[contextStack.length - 1] = contextObject; // ../IAS-SDK/sources/ias.js: 31
        contextString = nul; // ../IAS-SDK/sources/ias.js: 32
    } // ../IAS-SDK/sources/ias.js: 33

    function SetContextPart(name, value) { // ../IAS-SDK/sources/ias.js: 35
        if (value != nul) // ../IAS-SDK/sources/ias.js: 36
            contextObject[name] = value; // ../IAS-SDK/sources/ias.js: 37
        else delete contextObject[name]; // ../IAS-SDK/sources/ias.js: 38
        contextString = nul; // ../IAS-SDK/sources/ias.js: 39
    } // ../IAS-SDK/sources/ias.js: 40

    function PushContext(context) { // ../IAS-SDK/sources/ias.js: 42
        contextObject = Clone(context); // ../IAS-SDK/sources/ias.js: 43
        contextStack.push(contextObject); // ../IAS-SDK/sources/ias.js: 44
        contextString = nul; // ../IAS-SDK/sources/ias.js: 45
    } // ../IAS-SDK/sources/ias.js: 46

    function PopContext() { // ../IAS-SDK/sources/ias.js: 48
        contextStack.pop(); // ../IAS-SDK/sources/ias.js: 49
        if (!contextStack.length) // ../IAS-SDK/sources/ias.js: 50
            contextStack.push({}); // ../IAS-SDK/sources/ias.js: 51
        contextObject = contextStack[contextStack.length - 1]; // ../IAS-SDK/sources/ias.js: 52
        contextString = nul; // ../IAS-SDK/sources/ias.js: 53
    } // ../IAS-SDK/sources/ias.js: 54

    function ResetContext(context) { // ../IAS-SDK/sources/ias.js: 56
        contextStack = []; // ../IAS-SDK/sources/ias.js: 57
        PushContext(context); // ../IAS-SDK/sources/ias.js: 58
    } // ../IAS-SDK/sources/ias.js: 59

    function SetTags(tags) { // ../IAS-SDK/sources/ias.js: 61
        for (var m in tags) // ../IAS-SDK/sources/ias.js: 62
            SetTag(m, tags[m]); // ../IAS-SDK/sources/ias.js: 63
    } // ../IAS-SDK/sources/ias.js: 64

    function SetTag(name, value) { // ../IAS-SDK/sources/ias.js: 66
        if (value != nul) // ../IAS-SDK/sources/ias.js: 67
            tagsObject[name] = value; // ../IAS-SDK/sources/ias.js: 68
        else delete tagsObject[name]; // ../IAS-SDK/sources/ias.js: 69
        tagsString = nul; // ../IAS-SDK/sources/ias.js: 70
    } // ../IAS-SDK/sources/ias.js: 71

    function ResetTags(tags) { // ../IAS-SDK/sources/ias.js: 73
        tagsObject = Clone(tags); // ../IAS-SDK/sources/ias.js: 74
        tagsString = nul; // ../IAS-SDK/sources/ias.js: 75
    } // ../IAS-SDK/sources/ias.js: 76

    function GetDiscoveryCddUrls() { // ../IAS-SDK/sources/ias.js: 78
        return (discoveryCddUrls.length? discoveryCddUrls: nul); // ../IAS-SDK/sources/ias.js: 79
    } // ../IAS-SDK/sources/ias.js: 80

    function GetApplicableCddUrls() { // ../IAS-SDK/sources/ias.js: 82
        return (applicableCddUrls.length? applicableCddUrls: nul); // ../IAS-SDK/sources/ias.js: 83
    } // ../IAS-SDK/sources/ias.js: 84

    function AddDiscoveryCddUrl(url) { // ../IAS-SDK/sources/ias.js: 86
        discoveryCddUrls.push(url); // ../IAS-SDK/sources/ias.js: 87
    } // ../IAS-SDK/sources/ias.js: 88

    function AddApplicableCddUrl(url) { // ../IAS-SDK/sources/ias.js: 90
        applicableCddUrls.push(url); // ../IAS-SDK/sources/ias.js: 91
    } // ../IAS-SDK/sources/ias.js: 92

    function GetNamespace() { // ../IAS-SDK/sources/ias.js: 94
        return namespaceString; // ../IAS-SDK/sources/ias.js: 95
    } // ../IAS-SDK/sources/ias.js: 96

    function GetContext() { // ../IAS-SDK/sources/ias.js: 98
        if (contextString == nul) // ../IAS-SDK/sources/ias.js: 99
            contextString = EncodeParts(contextObject); // ../IAS-SDK/sources/ias.js: 100
        return contextString; // ../IAS-SDK/sources/ias.js: 101
    } // ../IAS-SDK/sources/ias.js: 102

    function GetTags() { // ../IAS-SDK/sources/ias.js: 104
        if (tagsString == nul) // ../IAS-SDK/sources/ias.js: 105
            tagsString = EncodeParts(tagsObject,true); // ../IAS-SDK/sources/ias.js: 106
        return tagsString; // ../IAS-SDK/sources/ias.js: 107
    } // ../IAS-SDK/sources/ias.js: 108

    function IsArray(obj) { // ../IAS-SDK/sources/ias.js: 110
        return !!(obj && obj.push && obj.sort); // ../IAS-SDK/sources/ias.js: 111
    } // ../IAS-SDK/sources/ias.js: 112

    function EncodePart(name, value) { // ../IAS-SDK/sources/ias.js: 114
        return encodeURIComponent(name) + '=' + encodeURIComponent(value); // ../IAS-SDK/sources/ias.js: 115
    } // ../IAS-SDK/sources/ias.js: 116

    function EncodePart_NE(name, value) { // ../IAS-SDK/sources/ias.js: 118
        return encodeURIComponent(name) + ((value == '')? '': ('=' + encodeURIComponent(value))); // ../IAS-SDK/sources/ias.js: 119
    } // ../IAS-SDK/sources/ias.js: 120

    function EncodeParts(obj, noempty) { // ../IAS-SDK/sources/ias.js: 122
        var encodePart = noempty ? EncodePart_NE : EncodePart; // ../IAS-SDK/sources/ias.js: 123
        var parts = []; // ../IAS-SDK/sources/ias.js: 124
        for (var name in obj) { // ../IAS-SDK/sources/ias.js: 125
            var value = obj[name]; // ../IAS-SDK/sources/ias.js: 126
            if (IsArray(value)) { // ../IAS-SDK/sources/ias.js: 127
                for (var i = 0; i < value.length; ++i) { // ../IAS-SDK/sources/ias.js: 128
                    parts.push(encodePart(name,value[i])); // ../IAS-SDK/sources/ias.js: 129
                } // ../IAS-SDK/sources/ias.js: 130
            } // ../IAS-SDK/sources/ias.js: 131
            else if (value != nul) { // ../IAS-SDK/sources/ias.js: 132
                parts.push(encodePart(name, value)); // ../IAS-SDK/sources/ias.js: 133
            } // ../IAS-SDK/sources/ias.js: 134
        } // ../IAS-SDK/sources/ias.js: 135
        return parts.join(';'); // ../IAS-SDK/sources/ias.js: 136
    } // ../IAS-SDK/sources/ias.js: 137

    var ias = window['ias'] || {}; // ../IAS-SDK/sources/ias.js: 139

    ias['SetNamespace'] = SetNamespace; // ../IAS-SDK/sources/ias.js: 141
    ias['SetContext'] = SetContext; // ../IAS-SDK/sources/ias.js: 142
    ias['SetContextPart'] = SetContextPart; // ../IAS-SDK/sources/ias.js: 143
    ias['ResetContext'] = ResetContext; // ../IAS-SDK/sources/ias.js: 144
    ias['SetTag'] = SetTag; // ../IAS-SDK/sources/ias.js: 145
    ias['SetTags'] = SetTags; // ../IAS-SDK/sources/ias.js: 146
    ias['ResetTags'] = ResetTags; // ../IAS-SDK/sources/ias.js: 147
    ias['PushContext'] = PushContext; // ../IAS-SDK/sources/ias.js: 148
    ias['PopContext'] = PopContext; // ../IAS-SDK/sources/ias.js: 149
    ias['AddDiscoveryCddUrl'] = AddDiscoveryCddUrl; // ../IAS-SDK/sources/ias.js: 150
    ias['AddApplicableCddUrl'] = AddApplicableCddUrl; // ../IAS-SDK/sources/ias.js: 151

    win['UPK_GetNamespace'] = GetNamespace; // ../IAS-SDK/sources/ias.js: 153
    win['UPK_GetContext'] = GetContext; // ../IAS-SDK/sources/ias.js: 154
    win['UPK_GetTags'] = GetTags; // ../IAS-SDK/sources/ias.js: 155
    win['UPK_GetDiscoveryCddUrls'] = GetDiscoveryCddUrls; // ../IAS-SDK/sources/ias.js: 156
    win['UPK_GetApplicableCddUrls'] = GetApplicableCddUrls; // ../IAS-SDK/sources/ias.js: 157

    return ias; // ../IAS-SDK/sources/ias.js: 159

})(window); // ../IAS-SDK/sources/ias.js: 161

//* <FileEnd path="../IAS-SDK/sources/ias.js"/>


ias['SetTag']('upk-trait-nohelp', ''); // iashelper.js: 3

//* <FileEnd path="iashelper.js"/>

/* tascriptsintoc.js */
//* <XBuild version="12.1.0-release,browser.all,playerscripts-1"/>
//* <BaseDir path="C:/BuildRoot/Engineering/trunk/TargetApps/BrowserAppsBuild/Build/Source/PlayerScripts/"/>
//* <FileRef type="source" path="tascriptsintoc.js" time="2013-10-16T02:01:11"/>
//* <FileRef type="reference" path="../Include/Tools/XdTransfer.js" time="2014-03-04T03:01:09"/>
//* <FileRef type="reference" path="../Include/Tools/Trace.js" time="2013-09-20T02:01:03"/>
//* <FileRef type="reference" path="../Include/Tools/Json.js" time="2013-09-20T02:01:03"/>
//* <FileRef type="reference" path="../Include/Tools/Main.js" time="2012-09-24T02:01:07"/>
//* <FileRef type="reference" path="../Include/Tools/Browser.js" time="2014-03-11T00:01:18"/>
//* <FileRef type="reference" path="../Include/Tools/TraceBase.js" time="2014-02-06T03:01:35"/>
//* <FileRef type="reference" path="../Include/CoreScripts/GatewayHelper.js" time="2013-10-16T02:01:11"/>
//* <FileRef type="reference" path="../Include/Tools/Utility.js" time="2013-09-26T02:01:27"/>
//* <FileRef type="reference" path="../Include/CoreScripts/Escape.js" time="2013-09-03T02:01:16"/>
//* <FileRef type="reference" path="../../../../../Core_DotNet/Player/root/js/escape.js" time="2013-09-16T02:01:49"/>
//* <FileRef type="reference" path="../Include/CoreScripts/SmartMatch.js" time="2014-01-27T06:47:49"/>
//* <FileRef type="reference" path="../Include/Tools/Dump.js" time="2013-09-24T02:01:16"/>
//* <FileRef type="reference" path="../Include/Tools/Base.js" version="1" time="2014-01-22T03:01:33"/>
//* <FileRef type="reference" path="../Include/Tools/Sanity.js" time="2012-03-24T14:59:20"/>
//* <FileRef type="reference" path="../Include/Tools/Fail.js" time="2014-03-11T00:01:18"/>
//* <FileRef type="reference" path="../Include/Tools/Error.js" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Common/ConfigData.js" time="2013-10-14T02:01:18"/>
//* <FileRef type="reference" path="../Include/Tools/ConfigNode.js" time="2013-10-04T02:01:17"/>
//* <FileRef type="reference" path="../Include/Tools/Assert.js" time="2014-03-11T00:01:18"/>
//* <FileRef type="reference" path="../Include/Tools/HashMap.js" version="1" time="2013-07-22T02:00:56"/>
//* <FileRef type="reference" path="../Include/Tools/AjaxRequest.js" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Tools/UniqueId.js" time="2012-03-24T14:59:20"/>
//* <FileRef type="reference" path="../Include/Common/ConfigDefaults.js" time="2013-09-18T02:01:00"/>
//* <FileRef type="reference" path="../Include/Common/ApplicationData.js" time="2013-09-18T02:01:00"/>
//* <FileRef type="reference" path="../Include/Common/UpkMeta.js" time="2014-01-23T03:01:42"/>
//* <FileRef type="reference" path="../Include/Tools/Array.js" version="1" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Tools/Url.js" time="2014-01-21T03:01:29"/>
//* <FileRef type="reference" path="../Include/Tools/String.js" time="2012-03-24T14:59:20"/>
//* <FileRef type="reference" path="../Include/Tools/Dom.js" time="2013-10-28T02:01:23"/>
//* <FileRef type="reference" path="../Include/Tools/Time.js" time="2012-03-24T14:59:20"/>
//* <FileRef type="reference" path="../Include/Tools/WindowUtils.js" time="2014-02-06T03:01:35"/>
//* <FileRef type="reference" path="../Include/Tools/Events.js" time="2013-10-14T02:01:18"/>
//* <FileRef type="reference" path="../Include/Tools/Cookie.js" time="2013-09-26T02:01:27"/>
//* <FileRef type="reference" path="../Include/Tools/RawQuery.js" time="2014-03-11T00:01:18"/>
//* <FileRef type="reference" path="../Include/Common/ApplicationInfo.js" time="2013-11-25T03:01:36"/>
//* <FileRef type="reference" path="../Include/Application/ApplicationMap.js" time="2013-09-18T02:01:00"/>
//* <FileRef type="reference" path="../Include/Application/ApplicationBase.js" time="2013-12-09T03:01:28"/>
//* <FileRef type="reference" path="../Include/Common/ContextPart.js" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Common/ContextType.js" time="2013-11-11T03:01:31"/>
//* <FileRef type="reference" path="../Include/Common/PartDescriptor.js" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Common/ApplicationFeature.js" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Application/ApplicationContext.js" time="2013-11-29T03:01:29"/>
//* <FileRef type="reference" path="../Include/Tools/Html.js" time="2013-07-19T02:00:48"/>
//* <FileRef type="reference" path="../Include/Application/ApplicationType.js" time="2012-03-24T14:59:19"/>
//* <FileRef type="reference" path="../Include/Tools/DomTable.js" time="2013-10-16T02:01:11"/>


//* <FileBegin path="tascriptsintoc.js"/>

var XdTransfer = (function() { // tascriptsintoc.js: 2
//x     ///<reference path="../Include/Tools/XdTransfer.js"/>
//x     ///<reference path="../Include/CoreScripts/GatewayHelper.js"/>    //messaging, like diagnostics, title
//x     ///<reference path="../Include/CoreScripts/SmartMatch.js"/>   //smartmatch search process

//* <FileBegin path="../Include/Tools/XdTransfer.js"/>
//x /// <reference path="Trace.js"/>
//x /// <reference path="Json.js"/>

//* <FileBegin path="../Include/Tools/Trace.js"/>
//x //: <if xconfig="Debug,Trace"/>
//x /// <reference path="TraceBase.js"/>
//x 
//x Trace.Object = function(group, value, name) {
//x     _Trace.Log(group, (name ? (name + ' = ') : '') + Json.EncodeObject(value));
//x }
//x 
//x TraceIf.Object = function(condition, group, value, name) {
//x     if (condition)
//x         _Trace.Log(group, (name ? (name + ' = ') : '') + Json.EncodeObject(value));
//x }
//x 
//x //: <end/>

//* <FileEnd path="../Include/Tools/Trace.js"/>


//* <FileBegin path="../Include/Tools/Json.js"/>
//x /// <reference path="Main.js"/>
//x /// <reference path="Browser.js"/>
//x /// <reference path="TraceBase.js"/>

//* <FileBegin path="../Include/Tools/Main.js"/>
//x //: Don't add references in this file!

//x //: <if xconfig="Ignore"/>
//x function TYPEDEF(name_eq_new_TypeName) {
//x     /// <summary>Enable IntelliSense for an arbitrary object: TYPEDEF(name = new TypeName());</summary>
//x }
//x //: <end/>

function NameOf(name) { // ../Include/Tools/Main.js: 9
    return ((name != null) ? '"' + name + '"' : '(null)'); // ../Include/Tools/Main.js: 10
} // ../Include/Tools/Main.js: 11

function TypeOf(value) { // ../Include/Tools/Main.js: 13
    if (value == null) // ../Include/Tools/Main.js: 14
        return ((value === void 0) ? 'undefined' : 'null'); // ../Include/Tools/Main.js: 15
    var type = typeof value; // ../Include/Tools/Main.js: 16
    //Gyuri issue 1
    //See below
    if (IsArray(value)) { // ../Include/Tools/Main.js: 19
        return 'object Array'; // ../Include/Tools/Main.js: 20
    } // ../Include/Tools/Main.js: 21
    if (type != 'object' || value.constructor == null || value.constructor.toString == null) // ../Include/Tools/Main.js: 22
        return type; // ../Include/Tools/Main.js: 23
    var result = /function\s+([^\(]*)\(/.exec(value.constructor.toString()); // ../Include/Tools/Main.js: 24
    return (type + ((result && result.length > 1 && result[1].length > 0) ? ' ' + result[1] : '')); // ../Include/Tools/Main.js: 25
} // ../Include/Tools/Main.js: 26

function IsNullOrString(obj) { // ../Include/Tools/Main.js: 28
    return ((obj == null) || (typeof obj == 'string') || (obj instanceof String)); // ../Include/Tools/Main.js: 29
} // ../Include/Tools/Main.js: 30

function IsNullOrNumber(obj) { // ../Include/Tools/Main.js: 32
    return ((obj == null) || (typeof obj == 'number') || (obj instanceof Number)); // ../Include/Tools/Main.js: 33
} // ../Include/Tools/Main.js: 34

function IsNullOrBoolean(obj) { // ../Include/Tools/Main.js: 36
    return ((obj == null) || (typeof obj == 'boolean') || (obj instanceof Boolean)); // ../Include/Tools/Main.js: 37
} // ../Include/Tools/Main.js: 38

function IsNullOrRegExp(obj) { // ../Include/Tools/Main.js: 40
    return ((obj == null) || (obj instanceof RegExp)); // ../Include/Tools/Main.js: 41
} // ../Include/Tools/Main.js: 42

function IsNullOrArray(obj) { // ../Include/Tools/Main.js: 44
    return ((obj == null) || IsArray(obj)); // ../Include/Tools/Main.js: 45
} // ../Include/Tools/Main.js: 46

function IsNullOrInstanceOf(obj, type) { // ../Include/Tools/Main.js: 48
    return ((obj == null) || (obj instanceof type)); // ../Include/Tools/Main.js: 49
} // ../Include/Tools/Main.js: 50

function IsUndefined(obj) { // ../Include/Tools/Main.js: 52
    return (typeof (obj) == 'undefined'); // ../Include/Tools/Main.js: 53
} // ../Include/Tools/Main.js: 54

function IsString(obj) { // ../Include/Tools/Main.js: 56
    return ((typeof obj == 'string') || (typeof obj == 'object' && obj.constructor === String)); // ../Include/Tools/Main.js: 57
} // ../Include/Tools/Main.js: 58

function IsNumber(obj) { // ../Include/Tools/Main.js: 60
    return ((typeof obj == 'number') || (typeof obj == 'object' && obj.constructor === Number)); // ../Include/Tools/Main.js: 61
} // ../Include/Tools/Main.js: 62

function IsBoolean(obj) { // ../Include/Tools/Main.js: 64
    return ((typeof obj == 'boolean') || (typeof obj == 'object' && obj.constructor === Boolean)); // ../Include/Tools/Main.js: 65
} // ../Include/Tools/Main.js: 66

//Gyuri issue 1, use other function to determine whether the actual object is an array
//Firefox gives error for an array created in the chrome environment
//Permission denied for <http://www.google.hu> to get property Array.constructor from <>.
/*
function IsArray(obj) {
return (obj != null) && (obj.constructor === Array);
}
*/ // ../Include/Tools/Main.js: 75
function IsArray(obj) { // ../Include/Tools/Main.js: 76
    return (typeof (obj) == 'object' && (obj.join != void 0) && (obj.push != void 0) && (obj.length != void 0)); // ../Include/Tools/Main.js: 77
} // ../Include/Tools/Main.js: 78


function IsFunction(obj) { // ../Include/Tools/Main.js: 81
    return (typeof obj == 'function') || ((obj != null) && (obj.constructor === Function)); // ../Include/Tools/Main.js: 82
} // ../Include/Tools/Main.js: 83

//TODO: Matyi: Ez mifele allat???
//Gyuri: olyanfajta, amit a YUI is használ...
//Matyi: :)
/*
    isObject: function(o) {
return (o && (typeof o === 'object' || L.isFunction(o))) || false;
    },
    isFunction: function(o) {
        return (typeof o === 'function') || Object.prototype.toString.apply(o) === '[object Function]';
    },    
*/     // ../Include/Tools/Main.js: 95

function IsObject(obj) { // ../Include/Tools/Main.js: 97
    return ((typeof (obj) == 'object' || IsFunction(obj)) && obj != null); // ../Include/Tools/Main.js: 98
} // ../Include/Tools/Main.js: 99

function IsInstanceOf(obj, type) { // ../Include/Tools/Main.js: 101
    return (obj instanceof type); // ../Include/Tools/Main.js: 102
} // ../Include/Tools/Main.js: 103

function IsHash(obj) { // ../Include/Tools/Main.js: 105
    return ( // ../Include/Tools/Main.js: 106
        (obj != null) && // ../Include/Tools/Main.js: 107
        (typeof obj == 'object') && // ../Include/Tools/Main.js: 108
        (obj.constructor !== String) && // ../Include/Tools/Main.js: 109
        (obj.constructor !== Number) && // ../Include/Tools/Main.js: 110
        (obj.constructor !== Boolean) && // ../Include/Tools/Main.js: 111
        (obj.constructor !== Array) && // ../Include/Tools/Main.js: 112
        (obj.constructor !== Date) // ../Include/Tools/Main.js: 113
    ); // ../Include/Tools/Main.js: 114
} // ../Include/Tools/Main.js: 115

function IsEmpty(obj) { // ../Include/Tools/Main.js: 117
    return (!obj || !obj.length); // ../Include/Tools/Main.js: 118
} // ../Include/Tools/Main.js: 119

function IsEmptyObject(obj) { // ../Include/Tools/Main.js: 121
    if (obj == null) { // ../Include/Tools/Main.js: 122
        return true; // ../Include/Tools/Main.js: 123
    } // ../Include/Tools/Main.js: 124
    for (var _ in obj) { // ../Include/Tools/Main.js: 125
        return false; // ../Include/Tools/Main.js: 126
    } // ../Include/Tools/Main.js: 127
    return true; // ../Include/Tools/Main.js: 128
} // ../Include/Tools/Main.js: 129
//* <FileEnd path="../Include/Tools/Main.js"/>


//* <FileBegin path="../Include/Tools/Browser.js"/>
//x /// <reference path="Main.js"/>

function IsMobileDevice() { // ../Include/Tools/Browser.js: 3
    if (IsTouchDevice() && Browser.IsSafari()) { // ../Include/Tools/Browser.js: 4
        return true; // ../Include/Tools/Browser.js: 5
    } // ../Include/Tools/Browser.js: 6
    return false; // ../Include/Tools/Browser.js: 7
} // ../Include/Tools/Browser.js: 8

function IsTouchDevice() { // ../Include/Tools/Browser.js: 10
    if (Browser.IsChrome()) { // ../Include/Tools/Browser.js: 11
        return false; // ../Include/Tools/Browser.js: 12
    } // ../Include/Tools/Browser.js: 13
    return (window['Touch'] || window.navigator['msMaxTouchPoints']); // ../Include/Tools/Browser.js: 14
} // ../Include/Tools/Browser.js: 15

//complex detection + version
/*
function GetBrowser() {
    var ua = navigator.userAgent, tem,
    M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*([\d\.]+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+(\.\d+)?)/g.exec(ua) || [];
        return 'IE ' + (tem[1] || '');
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    if ((tem = ua.match(/version\/([\.\d]+)/i)) != null) M[2] = tem[1];
    return M.join(' ');
};
*/ // ../Include/Tools/Browser.js: 30

//calling execScript once on a window object causes the eval method magically to reappear, if it was disappeared before
function ForceEval(obj) { // ../Include/Tools/Browser.js: 33
    if (Browser.IsIE()) { // ../Include/Tools/Browser.js: 34
        if (IsObject(obj) && IsFunction(obj.eval)) { // ../Include/Tools/Browser.js: 35
            if (IsObject(obj.execScript)) { // ../Include/Tools/Browser.js: 36
                obj.execScript('null'); // ../Include/Tools/Browser.js: 37
            } // ../Include/Tools/Browser.js: 38
        } // ../Include/Tools/Browser.js: 39
    } // ../Include/Tools/Browser.js: 40
} // ../Include/Tools/Browser.js: 41

//x //: <if xconfig="Browser.IE*,Browser.All"/>

function IE_ConvertVBArrayToArray(obj) { // ../Include/Tools/Browser.js: 45
    return ((obj == null) ? null : (obj['toArray']? obj['toArray'](): obj)); // ../Include/Tools/Browser.js: 46
} // ../Include/Tools/Browser.js: 47

//x //: <end/>

var _BrowserType = { // ../Include/Tools/Browser.js: 51
    Unknown: -1, // ../Include/Tools/Browser.js: 52
    MicrosoftInternetExplorer: 1, // ../Include/Tools/Browser.js: 53
    MozillaFirefox: 2, // ../Include/Tools/Browser.js: 54
    GoogleChrome: 3, // ../Include/Tools/Browser.js: 55
    Safari: 4 // ../Include/Tools/Browser.js: 56
}; // ../Include/Tools/Browser.js: 57

var _Browser = { // ../Include/Tools/Browser.js: 59
    Type: 0, // ../Include/Tools/Browser.js: 60
    //TODO: Matyi: Removed, not really needed
    /*
    Version: void 0,
    GetVersionFn: [
        function() {
            var agent = navigator.userAgent;
            var tokenBegin = agent.indexOf('MSIE ');
            if (tokenBegin != -1) {
                tokenBegin += 5;
                var tokenEnd = agent.indexOf(';', tokenBegin);
                if (tokenEnd != -1)
                    return Number(agent.substr(tokenBegin, tokenEnd - tokenBegin));
            }
            return -1;
        },
        null,
        null
    ],
    */ // ../Include/Tools/Browser.js: 79
    _: void 0 // ../Include/Tools/Browser.js: 80
}; // ../Include/Tools/Browser.js: 81

var Browser = { // ../Include/Tools/Browser.js: 83
    IsIE: function() { // ../Include/Tools/Browser.js: 84
        return Browser.IsType(_BrowserType.MicrosoftInternetExplorer); // ../Include/Tools/Browser.js: 85
    }, // ../Include/Tools/Browser.js: 86
    IsFirefox: function() { // ../Include/Tools/Browser.js: 87
        return Browser.IsType(_BrowserType.MozillaFirefox); // ../Include/Tools/Browser.js: 88
    }, // ../Include/Tools/Browser.js: 89
    IsChrome: function() { // ../Include/Tools/Browser.js: 90
        return Browser.IsType(_BrowserType.GoogleChrome); // ../Include/Tools/Browser.js: 91
    }, // ../Include/Tools/Browser.js: 92
    IsSafari: function() { // ../Include/Tools/Browser.js: 93
        return Browser.IsType(_BrowserType.Safari); // ../Include/Tools/Browser.js: 94
    }, // ../Include/Tools/Browser.js: 95
    IsType: function(browserType) { // ../Include/Tools/Browser.js: 96
        return _Browser.Type ? _Browser.Type == browserType : Browser.Detect(browserType); // ../Include/Tools/Browser.js: 97
    }, // ../Include/Tools/Browser.js: 98
    Detect: function(browserType) { // ../Include/Tools/Browser.js: 99
        if (/MSIE|Trident\//.test(navigator.userAgent))  // ../Include/Tools/Browser.js: 100
        //IE9=Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)
        //IE11=Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko
            _Browser.Type = _BrowserType.MicrosoftInternetExplorer; // ../Include/Tools/Browser.js: 103
        else if (navigator.userAgent.indexOf('Firefox') != -1) // ../Include/Tools/Browser.js: 104
        //Mozilla/5.0 (Windows NT 6.1; WOW64; rv:26.0) Gecko/20100101 Firefox/26.0
            _Browser.Type = _BrowserType.MozillaFirefox; // ../Include/Tools/Browser.js: 106
        else if (navigator.userAgent.indexOf('Chrome') != -1) // ../Include/Tools/Browser.js: 107
        //Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36
            _Browser.Type = _BrowserType.GoogleChrome; // ../Include/Tools/Browser.js: 109
        else if (/Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor)) // ../Include/Tools/Browser.js: 110
        //Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.57.2 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2
            _Browser.Type = _BrowserType.Safari; // ../Include/Tools/Browser.js: 112
        else _Browser.Type = _BrowserType.Unknown; // ../Include/Tools/Browser.js: 113
        return (_Browser.Type == browserType); // ../Include/Tools/Browser.js: 114
    } // ../Include/Tools/Browser.js: 115
}; // ../Include/Tools/Browser.js: 116


//* <FileEnd path="../Include/Tools/Browser.js"/>


//* <FileBegin path="../Include/Tools/TraceBase.js"/>
//x //: <if xconfig="Debug,Trace"/>
//x /// <reference path="Error.js"/>
//x /// <reference path="Browser.js"/>
//x 
//x var _Trace = {
//x     _Filters: [],
//x     _Enabled: null,
//x     _SourceLines: [],
//x     _SourceOffset: 0,
//x     _LastEnabled: true,
//x     _Output: 'console',
//x     _Window: null,
//x     _SourceName: '',
//x     _TestGroup: function(group) {
//x         var filters = _Trace._Filters;
//x         var result = !filters.length;
//x         for (var i = 0, n = filters.length; i < n; ++i) {
//x             if (filters[i][0].test(group))
//x                 result = filters[i][1];
//x         }
//x         return result;
//x     },
//x     _CreateRegExp: function(filter) {
//x         if (filter == null)
//x             return new RegExp('.?');
//x         if (!/^[\w\-\.\*,]*$/.test(filter))
//x             throw new ArgumentError('Trace: Invalid filter "' + filter + '". Valid characters: [A-Za-z0-9_\-\.,].');
//x         return new RegExp('^(?:.*,)?(?:' + filter.replace(/\./g, '\\.').replace(/\*/g, '.*').replace(/,/g, '|') + ')(?:\\.[^,]*)?(,?:.*)?$');
//x     },
//x     _CreateMessage: function(group, message) {
//x         return ('[' + (_Trace._SourceName ? _Trace._SourceName + '/' : '') + (group || '*') + ']' + ((message == void 0) ? '' : ': ' + message));
//x     },
//x     _GetConsole: function() {
//x         var win = _Trace._Window || window;
//x         var console = win['console'] || null;
//x         if (console) {
//x             if (typeof win['content'] != 'object') {
//x                 return console;
//x             }
//x         }
//x         //: <if xconfig="SmartHelp"/>
//x         //: <if xconfig="Browser.FF*"/>
//x         try {
//x             if (typeof win['content'] == 'object' &&
//x             typeof win['content']['wrappedJSObject'] == 'object')
//x                 console = win['content']['wrappedJSObject']['console'] || null;
//x         }
//x         catch (xe) { }
//x         //: <end/>
//x         //: <end/>
//x         return console;
//x     },
//x     Output: function(output) {
//x         _Trace._Output = output;
//x     },
//x     SetWindow: function(win, sourceName) {
//x         _Trace._Window = win;
//x         _Trace._SourceName = sourceName || '';
//x     },
//x     Log: function(group, message) {
//x         var enabled = _Trace.TestGroup(group);
//x         if (enabled || _Trace._LastEnabled) {
//x             _Trace._LastEnabled = enabled;
//x             if (_Trace._Output == 'console') {
//x                 if (window.location.protocol && window.location.protocol.substr(0, 4).toLowerCase() == 'http' || Browser.IsIE()) {
//x                     var console = _Trace._GetConsole();
//x                     if (console && console['log'])
//x                         console['log'](enabled ? _Trace._CreateMessage(group, message) : '... NoTrace ...');
//x                 }
//x                 else {
//x                     if (Browser.IsFirefox()) {
//x                         var _group = 'HTML';
//x                         var _message = (group || '*') + ' : ' + ((message == void 0) ? '' : message);
//x                         try {
//x                             if ('createEvent' in document) {
//x                                 var element = document.getElementById('ODTraceMessageId');
//x                                 if (!element) {
//x                                     element = document.createElement('ODTraceMessage');
//x                                     element.setAttribute('id', 'ODTraceMessageId');
//x                                     if (document.documentElement != null)
//x                                         document.documentElement.appendChild(element);
//x                                 }
//x 
//x                                 element.setAttribute('msg', _message);
//x                                 element.setAttribute('ids', _group);
//x                                 var ev = document.createEvent('Events');
//x                                 ev.initEvent('ODTraceEvent', true, false);
//x                                 element.dispatchEvent(ev);
//x                             }
//x                         }
//x                         catch (e) { }
//x                     }
//x                 }
//x             }
//x             else if (_Trace._Output == 'viewer') {
//x                 var _group = 'HTML';
//x                 var _message = (group || '*') + ' : ' + ((message == void 0) ? '' : message);
//x                 if (Browser.IsIE()) {
//x                     try {
//x                         var viewer = new ActiveXObject('ODTraceCom.ODTrace');
//x                         if (viewer) {
//x                             viewer.Write(_group, _message);
//x                         }
//x                     }
//x                     catch (e) { }
//x                 }
//x             }
//x         }
//x     },
//x     Error: function(group, message) {
//x         _Trace.Log(group, message);
//x         var console = _Trace._GetConsole();
//x         if (console && console['error'])
//x             console['error'](_Trace._CreateMessage(group, message));
//x     },
//x     Warning: function(group, message) {
//x         _Trace.Log(group, message);
//x         var console = _Trace._GetConsole();
//x         if (console && console['warn'])
//x             console['warn'](_Trace._CreateMessage(group, message));
//x     },
//x     AddFilter: function(filter, type) {
//x         _Trace._Filters.push([_Trace._CreateRegExp(filter || null), type]);
//x         _Trace._Enabled = null;
//x     },
//x     ResetFilters: function() {
//x         _Trace._Filters = [];
//x         _Trace._Enabled = null;
//x     },
//x     TestGroup: function(group) {
//x         if (group == null)
//x             group = '';
//x         if (_Trace._Enabled == null)
//x             _Trace._Enabled = {};
//x         var isEnabled;
//x         if ((isEnabled = _Trace._Enabled[group]) != void 0)
//x             return isEnabled;
//x         _Trace._Enabled[group] = isEnabled = _Trace._TestGroup(group);
//x         return isEnabled;
//x     },
//x     _CaptureFileSource: function(fileName) {
//x         if (!/.js$/i.test(fileName))
//x             return false;
//x         if (typeof (AjaxRequest) != 'undefined') {
//x             setTimeout(
//x                 function() {
//x                     new AjaxRequest(fileName, {
//x                         'asynchronous': true,
//x                         'OnDone': function(arq) {
//x                             try {
//x                                 var text = arq.request.responseText || '';
//x                                 _Trace._SourceOffset = -1;
//x                                 _Trace._SourceLines = text.split('\n');
//x                             }
//x                             catch (xe) {
//x                             }
//x                         }
//x                     });
//x                 },
//x                 10
//x             );
//x         }
//x         return true;
//x     },
//x     _CaptureEvalSource: function(entryPoint) {
//x         if (/^OnDemand_IPXFF_JScriptManager_Eval\("window\.OraUpk=\{\}/.test(entryPoint))
//x             _Trace._SourceOffset = 16;
//x         else if (/^\("window\.OraUpk=\{\}/.test(entryPoint))
//x             _Trace._SourceOffset = 13;
//x         else if (/^_firebugInjectedEvaluate\("with\(_FirebugCommandLine\)/.test(entryPoint))
//x             _Trace._SourceOffset = -71;
//x         else return false;
//x         ++_Trace._SourceOffset;
//x         _Trace._SourceLines = entryPoint.split('\\n');
//x         return true;
//x     },
//x     Initialize: function() {
//x         //: <if xconfig="Browser.All,Browser.FF*"/>
//x         //: <if-not xconfig="Browser.FF*"/>
//x         if (Browser.IsFirefox()) {
//x             //: <end/>
//x             var xe = new Error();
//x             //: <if xconfig="Ignore"/>
//x             (function(xe) {
//x                 _Trace.Log('Trace.Initialize', 'fileName: ' + xe.fileName + ', lineNumber: ' + xe.lineNumber);
//x                 var lines = xe.stack.split('\n');
//x                 for (var i = 0; i < lines.length; ++i) {
//x                     _Trace.Log('Trace.Initialize', 'stack[' + i + ']: ' + xe.stack);
//x                 }
//x             })(xe);
//x             //: <end/>
//x             if (!(xe.fileName && _Trace._CaptureFileSource(xe.fileName)) && xe.stack) {
//x                 var stackFrames = xe.stack.split('\n');
//x                 if (stackFrames.length >= 2) {
//x                     // var console = _Trace._GetConsole();
//x                     // var firebugVer = (console && console['firebug']) || null;
//x                     // firebugVer == "1.6.2"
//x                     _Trace._CaptureEvalSource(stackFrames.pop()) || _Trace._CaptureEvalSource(stackFrames.pop());
//x                 }
//x             }
//x             //: <if-not xconfig="Browser.FF*"/>
//x         }
//x         //: <end/>
//x         //: <end/>
//x     }
//x };
//x 
//x function Trace(group, message) {
//x     _Trace.Log(group, message);
//x }
//x 
//x Trace.Allow = function(filter) {
//x     _Trace.AddFilter(filter, true);
//x }
//x 
//x Trace.Deny = function(filter) {
//x     _Trace.AddFilter(filter, false);
//x }
//x 
//x Trace.Output = function(output) {
//x     _Trace.Output(output);
//x }
//x 
//x Trace.SetWindow = function(win, sourceName) {
//x     _Trace.SetWindow(win, sourceName);
//x }
//x 
//x Trace.Reset = function() {
//x     _Trace.ResetFilters();
//x }
//x 
//x Trace.Warning = function(group, message) {
//x     _Trace.Warning(group, message);
//x }
//x 
//x Trace.Error = function(group, message) {
//x     _Trace.Error(group, message);
//x }
//x 
//x Trace.Exception = function(group, xe, droppedFrames) {
//x     var message = 'Exception: ' + ((xe && xe.message) || 'UNKNOWN');
//x     //: <if xconfig="Browser.All,Browser.FF*"/>
//x     if (xe.stack) {
//x         try {
//x             var stackFrames = xe.stack.split('\n');
//x             while (stackFrames.length) {
//x                 var entryPoint = stackFrames.pop();
//x                 if (!/^_firebugInjectedEvaluate/.test(entryPoint)) {
//x                     stackFrames.push(entryPoint);
//x                     break;
//x                 }
//x             }
//x             droppedFrames = (droppedFrames || 0);
//x             for (var i = droppedFrames, n = stackFrames.length; i < n; ++i) {
//x                 var stackFrame = stackFrames[i] || '(unknown)';
//x                 var locationPos = stackFrame.lastIndexOf('@');
//x                 var call = (locationPos == -1) ? stackFrame : stackFrame.substr(0, locationPos);
//x                 var callLocation = stackFrame.substr(locationPos + 1);
//x                 if (locationPos != -1) {
//x                     var linePos = callLocation.lastIndexOf(':');
//x                     if (linePos != -1) {
//x                         var line = Number(callLocation.substr(linePos + 1)) + _Trace._SourceOffset;
//x                         if (line >= 0 && line < _Trace._SourceLines.length) {
//x                             var sourceLine = _Trace._SourceLines[line];
//x                             var commentPos = sourceLine.lastIndexOf('//');
//x                             callLocation = (commentPos == -1) ? sourceLine : sourceLine.substr(commentPos);
//x                             if (/\\r$/.test(callLocation))
//x                                 callLocation = callLocation.substr(0, callLocation.length - 2);
//x                         }
//x                     }
//x                 }
//x                 message += '\n  ' + call + ': ' + callLocation;
//x             }
//x         }
//x         catch (xe2) {
//x             FailAlert(xe2.message);
//x         }
//x     }
//x     //: <end/>
//x     _Trace.Error(group, message);
//x }
//x 
//x function TraceIf(condition, group, message) {
//x     if (condition)
//x         _Trace.Log(group, message);
//x }
//x 
//x TraceIf.Warning = function(condition, group, message) {
//x     if (condition)
//x         _Trace.Warning(group, message);
//x }
//x 
//x /// <reference path="../NoTrace.js"/>
//x 
//x _Trace.Initialize();
//x 
//x //: <end/>

//* <FileEnd path="../Include/Tools/TraceBase.js"/>


// Author: Csaba Márton <csaba.marton@oracle.com>
// Version: 0.9.0
// 
// Supported browsers: IE 7+, Firefox 1.5+, Chrome 4+.
// Other browsers were not tested.
//
// Documentation: http://image.hu.oracle.com/matyi/js-encoding/
//
// JSON
// ====
//
// The JSON decoder is RFC 4627 compliant and passes JSON.org's
// JSON checker test suite: http://www.json.org/JSON_checker/test.zip
//
// The JSON encoder is RFC 4627 and ECMA-262 compliant with the 
// modification that Json.EncodeObject will not throw TypeError if 
// it contains a cyclic reference; it will return undefined instead. 
// Json.DecodeObject will also return undefined if an error occurs.
//
//   RFC 4627: The application/json Media Type for JavaScript Object Notation 
//   http://www.ietf.org/rfc/rfc4627.txt
//
//   ECMA-262: ECMAScript Language Specification, 5th Edition, December 2009
//   http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-262.pdf
//

// IMPORTANT NOTE: Because PRIMAP6 implemented non-standard toJSON functions the 
// toJSON function function call was removed from this implementation. For this 
// reason the native implementation will be always tested to be valid.

var _Json = { // ../Include/Tools/Json.js: 35
    Indent: '  ' // ../Include/Tools/Json.js: 36
}; // ../Include/Tools/Json.js: 37

var Json = { // ../Include/Tools/Json.js: 39
    EncodeObject: function(obj, indent) { // ../Include/Tools/Json.js: 40
        try { return JSON.stringify(obj, null, (indent ? _Json.Indent : null)); } // ../Include/Tools/Json.js: 41
        catch (xe) { if (typeof TypeError == 'undefined' || !xe || xe.constructor !== TypeError) throw xe; } // ../Include/Tools/Json.js: 42
    }, // ../Include/Tools/Json.js: 43
    DecodeObject: function(str) { // ../Include/Tools/Json.js: 44
        if (str != null) // ../Include/Tools/Json.js: 45
            try { return JSON.parse(str); } catch (xe) { // ../Include/Tools/Json.js: 46
//(ignore)//                 Trace.Exception('Json.DecodeObject', xe); // ../Include/Tools/Json.js: 47
            } // ../Include/Tools/Json.js: 48
    } // ../Include/Tools/Json.js: 49
}; // ../Include/Tools/Json.js: 50

function _Json_Emulate() { // ../Include/Tools/Json.js: 52
    var xt = /[^",:\{\}\[\] \t\r\n]|"""|"[ \t\r\n]+"]|[\}\]][ \t\r\n]*[:\{\[]|[\{\[][ \t\r\n]*[,:]|[,:][ \t\r\n]*[,:\}\]]/; // compliance test
    var xn = /"(?:[^"\\\x00-\x1F]|\\["\\\/bnfrt]|\\u[0-9a-fA-F]{4})*"|null|true|false|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+\-]?[0-9]+)?/g; // tokens regexp
    var innerException = new Error(''); // ../Include/Tools/Json.js: 55
    function _u(n) { // ../Include/Tools/Json.js: 56
        var c = n.toString(16); // ../Include/Tools/Json.js: 57
        switch (c.length) { // ../Include/Tools/Json.js: 58
            case 1: return '\\u000' + c; // ../Include/Tools/Json.js: 59
            case 2: return '\\u00' + c; // ../Include/Tools/Json.js: 60
            case 3: return '\\u0' + c; // ../Include/Tools/Json.js: 61
            case 4: return '\\u' + c; // ../Include/Tools/Json.js: 62
        } // ../Include/Tools/Json.js: 63
        return '?'; // ../Include/Tools/Json.js: 64
    } // ../Include/Tools/Json.js: 65
    var _f = IsFunction; // ../Include/Tools/Json.js: 66
    var _c; // contains(array, item) or cyclic
    var _i; // indexOf(array, item)
    (function() { // ../Include/Tools/Json.js: 69
        try { // ../Include/Tools/Json.js: 70
            if (typeof [].indexOf == 'function' && [1, 2, 3, 4].indexOf(3) == 2) { // ../Include/Tools/Json.js: 71
                _c = function(a, o) { return (a.indexOf(o) != -1); }; // ../Include/Tools/Json.js: 72
                _i = function(a, o) { return a.indexOf(o); }; // ../Include/Tools/Json.js: 73
                return; // ../Include/Tools/Json.js: 74
            } // ../Include/Tools/Json.js: 75
        } // ../Include/Tools/Json.js: 76
        catch (ex) { }; // ../Include/Tools/Json.js: 77
        _c = function(a, o) { for (var i = 0, n = a.length; i < n; ++i) { if (a[i] === o) return true; } return false; }; // ../Include/Tools/Json.js: 78
        _i = function(a, o) { for (var i = 0, n = a.length; i < n; ++i) { if (a[i] === o) return i; } return -1; }; // ../Include/Tools/Json.js: 79
    })(); // ../Include/Tools/Json.js: 80
    var ae = '????????btn?fr??????????????????'; // 0x00..0x1F escape abreviation
    function _q(o) { // quote_string(input)
        return ('"' + String(o) // ../Include/Tools/Json.js: 83
              .replace(/(["\\])/g, "\\$1") // ../Include/Tools/Json.js: 84
              .replace(/([\x00-\x1F])/g, function(c) { // ../Include/Tools/Json.js: 85
                  var n = c.charCodeAt(0); // ../Include/Tools/Json.js: 86
                  var x = ae.charAt(n); // ../Include/Tools/Json.js: 87
                  return (x == '?' ? _u(n) : '\\' + x); // ../Include/Tools/Json.js: 88
              }) + '"'); // ../Include/Tools/Json.js: 89
    } // ../Include/Tools/Json.js: 90
    function _2(v) { // pad_to_2_digits(value) - pad decimals less than 9 with one zero. the input is guaranteed to be positive or zero
        return ((v < 10) ? '0' + v : v); // ../Include/Tools/Json.js: 92
    } // ../Include/Tools/Json.js: 93
    function _s(o, c, k) { // stringify(object, stack, key)
        // object is not undefined, null or function
        var t = typeof o; // ../Include/Tools/Json.js: 96
        // Matyi: The following lines were removed from standard implementation because PRIMAP6 implemented non-standard toJSON functions
        // if (t == 'object' && _f(o.toJSON)) {
        //     o = o.toJSON(k);
        //     t = typeof o;
        // }
        if (t != 'object') { // ../Include/Tools/Json.js: 102
            if (t == 'string') return _q(o); // ../Include/Tools/Json.js: 103
            if (t == 'number') return (isFinite(o) ? String(o) : 'null'); // ../Include/Tools/Json.js: 104
            if (t == 'boolean') return (o ? 'true' : 'false'); // ../Include/Tools/Json.js: 105
            return; // ../Include/Tools/Json.js: 106
        } // ../Include/Tools/Json.js: 107
        if (o === null) return 'null'; // ../Include/Tools/Json.js: 108
        if (o.constructor === String) return _q(o); // ../Include/Tools/Json.js: 109
        if (o.constructor === Number) return (isFinite(o) ? String(o) : 'null'); // ../Include/Tools/Json.js: 110
        if (o.constructor === Boolean) return (o ? 'true' : 'false'); // ../Include/Tools/Json.js: 111
        if (o.constructor === Date) return ''.concat(o.getUTCFullYear(), '-', _2(o.getUTCMonth()), '-', _2(o.getUTCDate()), 'T', _2(o.getUTCHours()), ':', _2(o.getUTCMinutes()), ':', _2(o.getUTCSeconds()), 'Z'); // ../Include/Tools/Json.js: 112
        if (o.constructor === Function) return; // ../Include/Tools/Json.js: 113
        if (_c(c, o)) throw innerException; // ensure no circular references
        var a = []; // ../Include/Tools/Json.js: 115
        c.push(o); // ../Include/Tools/Json.js: 116
        if (o.constructor === Array) { // ../Include/Tools/Json.js: 117
            for (var i = 0, n = o.length; i < n; ++i) { // ../Include/Tools/Json.js: 118
                var v1 = o[i]; // ../Include/Tools/Json.js: 119
                if (v1 == null || _f(v1)) // ../Include/Tools/Json.js: 120
                    a.push('null'); // ../Include/Tools/Json.js: 121
                else a.push(_s(v1, c, String(i))); // ../Include/Tools/Json.js: 122
            } // ../Include/Tools/Json.js: 123
            c.pop(); // ../Include/Tools/Json.js: 124
            return ('[' + a.join() + ']'); // ../Include/Tools/Json.js: 125
        } // ../Include/Tools/Json.js: 126
        for (var m in o) { // ../Include/Tools/Json.js: 127
            var v2 = o[m]; // ../Include/Tools/Json.js: 128
            if (v2 == null || _f(v2)) { // ../Include/Tools/Json.js: 129
                if (v2 === null) // ../Include/Tools/Json.js: 130
                    a.push(_q(m) + ':null'); // ../Include/Tools/Json.js: 131
            } // ../Include/Tools/Json.js: 132
            else if ((v2 = _s(v2, c, m)) != null) // ../Include/Tools/Json.js: 133
                a.push(_q(m) + ':' + v2); // ../Include/Tools/Json.js: 134
        } // ../Include/Tools/Json.js: 135
        c.pop(); // ../Include/Tools/Json.js: 136
        return ('{' + a.join() + '}'); // ../Include/Tools/Json.js: 137
    } // ../Include/Tools/Json.js: 138
    Json.EncodeObject = function(o) { // ../Include/Tools/Json.js: 139
        if (o == null || _f(o)) { // ../Include/Tools/Json.js: 140
            if (o === null) // ../Include/Tools/Json.js: 141
                return 'null'; // ../Include/Tools/Json.js: 142
            return; // ../Include/Tools/Json.js: 143
        } // ../Include/Tools/Json.js: 144
        try { return _s(o, [], ''); } catch (ex) { if (ex !== innerException) throw ex; }; // ../Include/Tools/Json.js: 145
    }; // ../Include/Tools/Json.js: 146
    Json.DecodeObject = function(s) { // ../Include/Tools/Json.js: 147
        try { // ../Include/Tools/Json.js: 148
            if ((s != null) && !xt.test(s.replace(xn, '""'))) // ../Include/Tools/Json.js: 149
                return eval('(' + s + ')'); // ../Include/Tools/Json.js: 150
        } // ../Include/Tools/Json.js: 151
        catch (ex) { } // ../Include/Tools/Json.js: 152
    }; // ../Include/Tools/Json.js: 153
} // ../Include/Tools/Json.js: 154

function _Json_CheckImplementation() { // ../Include/Tools/Json.js: 156
    if ((typeof (window['JSON']) != 'undefined') && (typeof (JSON.stringify && JSON.parse) != 'undefined')) { // ../Include/Tools/Json.js: 157
        try { // ../Include/Tools/Json.js: 158
            var xo = { a: "", b: 0.1, c: null, d: true, e: false, f: new Array([new Object(), { g: function() { return 1; }, h: 1 }, new Function("return 0;"), function() { return 1; }, 1]) }; // ../Include/Tools/Json.js: 159
            var xs = '{"a":"","b":0.1,"c":null,"d":true,"e":false,"f":[[{},{"h":1},null,null,1]]}'; // ../Include/Tools/Json.js: 160
            var sxo = JSON.stringify(xo); // ../Include/Tools/Json.js: 161
            if ((sxo == xs) && (sxo == JSON.stringify(JSON.parse(xs))) && (/2345-12-23T12:34:56(?:\.789[0]*)?Z/.test(JSON.stringify(new Date(Date.UTC(2345, 11, 23, 12, 34, 56, 789)))))) { // ../Include/Tools/Json.js: 162
                return; // ../Include/Tools/Json.js: 163
            } // ../Include/Tools/Json.js: 164
        } // ../Include/Tools/Json.js: 165
        catch (ex) { } // ../Include/Tools/Json.js: 166
    } // ../Include/Tools/Json.js: 167
    _Json_Emulate(); // ../Include/Tools/Json.js: 168
} // ../Include/Tools/Json.js: 169

_Json_CheckImplementation(); // ../Include/Tools/Json.js: 171

//* <FileEnd path="../Include/Tools/Json.js"/>


var _XdTransfer = { // ../Include/Tools/XdTransfer.js: 4
    Listeners: null, // ../Include/Tools/XdTransfer.js: 5
    MessageReceived: function(event) { // ../Include/Tools/XdTransfer.js: 6
        var message = Json.DecodeObject(event.data); // ../Include/Tools/XdTransfer.js: 7
        if (message && (message.length == 2) && /^oraupk-/.test(message[0])) { // ../Include/Tools/XdTransfer.js: 8
            var messageName = message[0]; // ../Include/Tools/XdTransfer.js: 9
            var messageData = message[1]; // ../Include/Tools/XdTransfer.js: 10
            var source = event.source; // ../Include/Tools/XdTransfer.js: 11
            var origin = event.origin; // ../Include/Tools/XdTransfer.js: 12
//(ignore)//             Trace('_XdTransfer.MessageReceived', 'origin=' + event.origin + ', message=' + messageName + ', data=' + Json.EncodeObject(messageData)); // ../Include/Tools/XdTransfer.js: 13
            var tempArray = _XdTransfer.Listeners.slice(0); // ../Include/Tools/XdTransfer.js: 14
            for (var i = 0; i < tempArray.length; ++i) { // ../Include/Tools/XdTransfer.js: 15
                try { // ../Include/Tools/XdTransfer.js: 16
                    tempArray[i](messageName, messageData, source, origin); // ../Include/Tools/XdTransfer.js: 17
                } // ../Include/Tools/XdTransfer.js: 18
                catch (xe) { // ../Include/Tools/XdTransfer.js: 19
//(ignore)//                     Trace.Exception('_XdTransfer.MessageReceived.callback', xe); // ../Include/Tools/XdTransfer.js: 20
                } // ../Include/Tools/XdTransfer.js: 21
            } // ../Include/Tools/XdTransfer.js: 22
        } // ../Include/Tools/XdTransfer.js: 23
    } // ../Include/Tools/XdTransfer.js: 24
}; // ../Include/Tools/XdTransfer.js: 25

var XdTransfer = { // ../Include/Tools/XdTransfer.js: 27
    AddListener: function(targetWin, callback) { // ../Include/Tools/XdTransfer.js: 28
        if (!_XdTransfer.Listeners) { // ../Include/Tools/XdTransfer.js: 29
            _XdTransfer.Listeners = []; // ../Include/Tools/XdTransfer.js: 30
            AddListener(targetWin, 'message', _XdTransfer.MessageReceived); // ../Include/Tools/XdTransfer.js: 31
        } // ../Include/Tools/XdTransfer.js: 32
        _XdTransfer.Listeners.push(callback); // ../Include/Tools/XdTransfer.js: 33
    }, // ../Include/Tools/XdTransfer.js: 34
    PostMessage: function(targetWin, messageName, messageData) { // ../Include/Tools/XdTransfer.js: 35
        if (messageData === void 0) // ../Include/Tools/XdTransfer.js: 36
            messageData = null; // ../Include/Tools/XdTransfer.js: 37
//(ignore)//         Trace('XdTransfer.PostMessage', 'name=' + messageName + ', data=' + Json.EncodeObject(messageData)); // ../Include/Tools/XdTransfer.js: 38
        var message = [messageName, messageData]; // ../Include/Tools/XdTransfer.js: 39
        targetWin.postMessage(Json.EncodeObject(message), "*"); // ../Include/Tools/XdTransfer.js: 40
    }, // ../Include/Tools/XdTransfer.js: 41
    SetProxy: function (parentWin, childWin) { // ../Include/Tools/XdTransfer.js: 42
        function messageReceived_P2C(event) { // ../Include/Tools/XdTransfer.js: 43
            var message = Json.DecodeObject(event.data); // ../Include/Tools/XdTransfer.js: 44
            if (message && (message.length == 2) && /^oraupk-/.test(message[0])) { // ../Include/Tools/XdTransfer.js: 45
                childWin.postMessage(event.data, "*"); // ../Include/Tools/XdTransfer.js: 46
            } // ../Include/Tools/XdTransfer.js: 47
        } // ../Include/Tools/XdTransfer.js: 48
        function messageReceived_C2P(event) { // ../Include/Tools/XdTransfer.js: 49
            var message = Json.DecodeObject(event.data); // ../Include/Tools/XdTransfer.js: 50
            if (message && (message.length == 2) && /^oraupk-/.test(message[0])) { // ../Include/Tools/XdTransfer.js: 51
                parentWin.postMessage(event.data, "*"); // ../Include/Tools/XdTransfer.js: 52
            } // ../Include/Tools/XdTransfer.js: 53
        } // ../Include/Tools/XdTransfer.js: 54
        if (parentWin.addEventListener) { // ../Include/Tools/XdTransfer.js: 55
            parentWin.addEventListener('message', messageReceived_P2C, false); // ../Include/Tools/XdTransfer.js: 56
            childWin.addEventListener('message', messageReceived_C2P, false); // ../Include/Tools/XdTransfer.js: 57
        } // ../Include/Tools/XdTransfer.js: 58
        else { // ../Include/Tools/XdTransfer.js: 59
            parentWin['attachEvent']('onmessage', messageReceived_P2C); // ../Include/Tools/XdTransfer.js: 60
            childWin['attachEvent']('onmessage', messageReceived_C2P); // ../Include/Tools/XdTransfer.js: 61
        } // ../Include/Tools/XdTransfer.js: 62
    } // ../Include/Tools/XdTransfer.js: 63
}; // ../Include/Tools/XdTransfer.js: 64

//* <FileEnd path="../Include/Tools/XdTransfer.js"/>


//* <FileBegin path="../Include/CoreScripts/GatewayHelper.js"/>
//x /// <reference path="../Tools/Utility.js"/>
//x /// <reference path="../CoreScripts/Escape.js"/>
//x /// <reference path="../Tools/Json.js"/>
//x /// <reference path="../Tools/XdTransfer.js"/>
//x /// <reference path="../Tools/Trace.js"/>

//* <FileBegin path="../Include/Tools/Utility.js"/>
//x /// <reference path="Browser.js"/>
var Utility = { // ../Include/Tools/Utility.js: 2
    WriteScript: function(obj, src) { // ../Include/Tools/Utility.js: 3
        var headID = obj.document.getElementsByTagName('head')[0]; // ../Include/Tools/Utility.js: 4
        var newScript = obj.document.createElement('script'); // ../Include/Tools/Utility.js: 5
        newScript.type = 'text/javascript'; // ../Include/Tools/Utility.js: 6
        newScript.src = src; // ../Include/Tools/Utility.js: 7
        headID.appendChild(newScript); // ../Include/Tools/Utility.js: 8
    }, // ../Include/Tools/Utility.js: 9
    AccessGranted: function(obj) { // ../Include/Tools/Utility.js: 10
        try { // ../Include/Tools/Utility.js: 11
            if (IsObject(obj) && IsObject(obj.location) && IsString(obj.location.href)) { // ../Include/Tools/Utility.js: 12
                return true; // ../Include/Tools/Utility.js: 13
            } // ../Include/Tools/Utility.js: 14
        } // ../Include/Tools/Utility.js: 15
        catch (e) { // ../Include/Tools/Utility.js: 16
            //Access denied if exception occurs
        } // ../Include/Tools/Utility.js: 18
        return false; // ../Include/Tools/Utility.js: 19
    }, // ../Include/Tools/Utility.js: 20
    CreateScript: function(id, src) { // ../Include/Tools/Utility.js: 21
        var head = document.getElementsByTagName('head')[0]; // ../Include/Tools/Utility.js: 22
        var newScript = document.createElement('script'); // ../Include/Tools/Utility.js: 23
        newScript.type = 'text/javascript'; // ../Include/Tools/Utility.js: 24
        newScript.src = src; // ../Include/Tools/Utility.js: 25
        newScript.setAttribute('id', id); // ../Include/Tools/Utility.js: 26
        head.appendChild(newScript); // ../Include/Tools/Utility.js: 27
    }, // ../Include/Tools/Utility.js: 28
    ModifyScript: function(id, src) { // ../Include/Tools/Utility.js: 29
        var sc = document.getElementById(id); // ../Include/Tools/Utility.js: 30
        if (sc) { // ../Include/Tools/Utility.js: 31
            sc.parentNode.removeChild(sc); // ../Include/Tools/Utility.js: 32
        } // ../Include/Tools/Utility.js: 33
        Utility.CreateScript(id, src); // ../Include/Tools/Utility.js: 34
    }, // ../Include/Tools/Utility.js: 35
    ExecuteScript: function(id, src) { // ../Include/Tools/Utility.js: 36
        if (document.getElementById(id) == null) { // ../Include/Tools/Utility.js: 37
            Utility.CreateScript(id, src); // ../Include/Tools/Utility.js: 38
        } // ../Include/Tools/Utility.js: 39
        else { // ../Include/Tools/Utility.js: 40
            Utility.ModifyScript(id, src); // ../Include/Tools/Utility.js: 41
        } // ../Include/Tools/Utility.js: 42
    }, // ../Include/Tools/Utility.js: 43

    ParseURL: function(url) { // ../Include/Tools/Utility.js: 45
        var a = document.createElement('a'); // ../Include/Tools/Utility.js: 46
        a.href = url; // ../Include/Tools/Utility.js: 47
        return { // ../Include/Tools/Utility.js: 48
            source: url, // ../Include/Tools/Utility.js: 49
            protocol: a.protocol.replace(':', ''), // ../Include/Tools/Utility.js: 50
            host: a.hostname, // ../Include/Tools/Utility.js: 51
            port: a.port, // ../Include/Tools/Utility.js: 52
            query: a.search, // ../Include/Tools/Utility.js: 53
            params: (function() { // ../Include/Tools/Utility.js: 54
                var ret = {}, // ../Include/Tools/Utility.js: 55
                    seg = a.search.replace(/^\?/, '').split('&'), // ../Include/Tools/Utility.js: 56
                    len = seg.length, i = 0, s; // ../Include/Tools/Utility.js: 57
                for (; i < len; i++) { // ../Include/Tools/Utility.js: 58
                    if (!seg[i]) { continue; } // ../Include/Tools/Utility.js: 59
                    s = seg[i].split('='); // ../Include/Tools/Utility.js: 60
                    ret[s[0]] = s[1]; // ../Include/Tools/Utility.js: 61
                } // ../Include/Tools/Utility.js: 62
                return ret; // ../Include/Tools/Utility.js: 63
            })(), // ../Include/Tools/Utility.js: 64
            file: (a.pathname.match(/\/([^\/?#]+)$/i) || [, ''])[1], // ../Include/Tools/Utility.js: 65
            hash: a.hash.replace('#', ''), // ../Include/Tools/Utility.js: 66
            path: a.pathname.replace(/^([^\/])/, '/$1'), // ../Include/Tools/Utility.js: 67
            relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [, ''])[1], // ../Include/Tools/Utility.js: 68
            segments: a.pathname.replace(/^\//, '').split('/') // ../Include/Tools/Utility.js: 69
        }; // ../Include/Tools/Utility.js: 70
    }, // ../Include/Tools/Utility.js: 71

    GetContentWidth: function() { // ../Include/Tools/Utility.js: 73
        var cw = 0; // ../Include/Tools/Utility.js: 74
        if (window.innerWidth) { // ../Include/Tools/Utility.js: 75
            cw = window.innerWidth; // ../Include/Tools/Utility.js: 76
        } // ../Include/Tools/Utility.js: 77
        else if (document.documentElement.clientWidth) { // ../Include/Tools/Utility.js: 78
            cw = document.documentElement.clientWidth; // ../Include/Tools/Utility.js: 79
        } // ../Include/Tools/Utility.js: 80
        else if (document.body.clientWidth) { // ../Include/Tools/Utility.js: 81
            cw = document.body.clientWidth; // ../Include/Tools/Utility.js: 82
        } // ../Include/Tools/Utility.js: 83
        return cw; // ../Include/Tools/Utility.js: 84
    }, // ../Include/Tools/Utility.js: 85

    GetContentHeight: function() { // ../Include/Tools/Utility.js: 87
        var ch = 0; // ../Include/Tools/Utility.js: 88
        if (window.innerHeight) { // ../Include/Tools/Utility.js: 89
            ch = window.innerHeight; // ../Include/Tools/Utility.js: 90
        } // ../Include/Tools/Utility.js: 91
        else if (document.documentElement.clientHeight) { // ../Include/Tools/Utility.js: 92
            ch = document.documentElement.clientHeight; // ../Include/Tools/Utility.js: 93
        } // ../Include/Tools/Utility.js: 94
        else if (document.body.clientHeight) { // ../Include/Tools/Utility.js: 95
            ch = document.body.clientHeight; // ../Include/Tools/Utility.js: 96
        } // ../Include/Tools/Utility.js: 97
        return ch; // ../Include/Tools/Utility.js: 98
    }, // ../Include/Tools/Utility.js: 99

    SetFrameSize: function(id) { // ../Include/Tools/Utility.js: 101
        var fr = document.getElementById(id); // ../Include/Tools/Utility.js: 102
        if (fr) { // ../Include/Tools/Utility.js: 103
            var ch = Utility.GetContentHeight(); // ../Include/Tools/Utility.js: 104
            var cw = Utility.GetContentWidth(); // ../Include/Tools/Utility.js: 105
            fr.style.height = ch + 'px'; // ../Include/Tools/Utility.js: 106
            fr.style.width = cw + 'px'; // ../Include/Tools/Utility.js: 107
//(ignore)//             Trace('Utility.SetFrameSize', 'id = ' + id + ' ch = ' + ch + ' cw = ' + cw); // ../Include/Tools/Utility.js: 108
        } // ../Include/Tools/Utility.js: 109
    } // ../Include/Tools/Utility.js: 110
} // ../Include/Tools/Utility.js: 111

//* <FileEnd path="../Include/Tools/Utility.js"/>


//* <FileBegin path="../Include/CoreScripts/Escape.js"/>
//x /// <reference path="../../../../../../Core_DotNet/Player/root/js/escape.js"/>

//* <FileBegin path="../../../../../Core_DotNet/Player/root/js/escape.js"/>
/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/ // ../../../../../Core_DotNet/Player/root/js/escape.js: 3

var Escape = (function() // ../../../../../Core_DotNet/Player/root/js/escape.js: 5
{ // ../../../../../Core_DotNet/Player/root/js/escape.js: 6
	//*****************************************************************
	//Safe Escape/UnEscape support

	var SafeUri_EscapeCharacter = '/'; // ../../../../../Core_DotNet/Player/root/js/escape.js: 10

	var SafeUri_UnsafeCharacters = ['<', '>', '"', '\'', '%', ';', '(', ')', '&', '+']; // ../../../../../Core_DotNet/Player/root/js/escape.js: 12
	
	return { // ../../../../../Core_DotNet/Player/root/js/escape.js: 14
		SafeUriEscape: function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 15
			return __Escape(s, 1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 16
		}, // ../../../../../Core_DotNet/Player/root/js/escape.js: 17

		SafeUriUnEscape: function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 19
			return __UnEscape(s, 1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 20
		}, // ../../../../../Core_DotNet/Player/root/js/escape.js: 21


	//*****************************************************************
	// Simple Escape/UnEscape support

		MyEscape: function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 27
			return __Escape(s, 0); // ../../../../../Core_DotNet/Player/root/js/escape.js: 28
		}, // ../../../../../Core_DotNet/Player/root/js/escape.js: 29

		MyUnEscape: function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 31
			return __UnEscape(s, 0); // ../../../../../Core_DotNet/Player/root/js/escape.js: 32
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 33
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 34

	//*****************************************************************
	// private

	function __Escape(s, safe) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 39
		var snew = ""; // ../../../../../Core_DotNet/Player/root/js/escape.js: 40
		for (var i = 0; i < s.length; i++) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 41
			var ss = s.substr(i, 1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 42
			if (safe == 0 ? __Normal_Contains(ss) : !__SafeUri_Contains(ss)) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 43
				snew += ss; // ../../../../../Core_DotNet/Player/root/js/escape.js: 44
			} // ../../../../../Core_DotNet/Player/root/js/escape.js: 45
			else { // ../../../../../Core_DotNet/Player/root/js/escape.js: 46
				ss = s.charCodeAt(i); // ../../../../../Core_DotNet/Player/root/js/escape.js: 47
				var a = "0000" + ss.toString(16).toUpperCase(); // ../../../../../Core_DotNet/Player/root/js/escape.js: 48
				snew += (safe == 0 ? "$" : SafeUri_EscapeCharacter) + a.substr(a.length - 4); // ../../../../../Core_DotNet/Player/root/js/escape.js: 49
			} // ../../../../../Core_DotNet/Player/root/js/escape.js: 50
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 51
		return snew; // ../../../../../Core_DotNet/Player/root/js/escape.js: 52
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 53

	function __UnEscape(s, safe) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 55
		var snew = ""; // ../../../../../Core_DotNet/Player/root/js/escape.js: 56
		var bEscape = false; // ../../../../../Core_DotNet/Player/root/js/escape.js: 57
		for (var i = 0; i < s.length; i++) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 58
			var ss; // ../../../../../Core_DotNet/Player/root/js/escape.js: 59
			if (bEscape) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 60
				ss = s.substr(i, 4); // ../../../../../Core_DotNet/Player/root/js/escape.js: 61
				snew += String.fromCharCode(parseInt("0x" + ss)); // ../../../../../Core_DotNet/Player/root/js/escape.js: 62
				i += 3; // ../../../../../Core_DotNet/Player/root/js/escape.js: 63
				bEscape = false; // ../../../../../Core_DotNet/Player/root/js/escape.js: 64
			} // ../../../../../Core_DotNet/Player/root/js/escape.js: 65
			else { // ../../../../../Core_DotNet/Player/root/js/escape.js: 66
				ss = s.substr(i, 1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 67
				if (ss == (safe == 0 ? '$' : SafeUri_EscapeCharacter)) // ../../../../../Core_DotNet/Player/root/js/escape.js: 68
					bEscape = true; // ../../../../../Core_DotNet/Player/root/js/escape.js: 69
				else // ../../../../../Core_DotNet/Player/root/js/escape.js: 70
					snew += ss; // ../../../../../Core_DotNet/Player/root/js/escape.js: 71
			} // ../../../../../Core_DotNet/Player/root/js/escape.js: 72
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 73
		return snew; // ../../../../../Core_DotNet/Player/root/js/escape.js: 74
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 75

	function __Normal_Contains(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 77
		return ((s >= '0' && s <= '9') || (s >= 'a' && s <= 'z') || (s >= 'A' && s <= 'Z')); // ../../../../../Core_DotNet/Player/root/js/escape.js: 78
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 79

	function __SafeUri_Contains(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 81
		var l = SafeUri_UnsafeCharacters.length; // ../../../../../Core_DotNet/Player/root/js/escape.js: 82
		for (var i = 0; i < l; i++) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 83
			if (s == SafeUri_UnsafeCharacters[i]) // ../../../../../Core_DotNet/Player/root/js/escape.js: 84
				return true; // ../../../../../Core_DotNet/Player/root/js/escape.js: 85
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 86
		if (s == SafeUri_EscapeCharacter) // ../../../../../Core_DotNet/Player/root/js/escape.js: 87
			return true; // ../../../../../Core_DotNet/Player/root/js/escape.js: 88
		return false; // ../../../../../Core_DotNet/Player/root/js/escape.js: 89
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 90

})(); // ../../../../../Core_DotNet/Player/root/js/escape.js: 92

////////////////////////////////////////////////////////////////////////////////////////
// UrlParser object

/** @constructor */ // ../../../../../Core_DotNet/Player/root/js/escape.js: 97
function UrlParser() { // ../../../../../Core_DotNet/Player/root/js/escape.js: 98
	this.params = new Array(); // ../../../../../Core_DotNet/Player/root/js/escape.js: 99
	this.safemode = false; // ../../../../../Core_DotNet/Player/root/js/escape.js: 100
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 101

UrlParser.prototype.Clone = function() { // ../../../../../Core_DotNet/Player/root/js/escape.js: 103
	var url = new UrlParser(); // ../../../../../Core_DotNet/Player/root/js/escape.js: 104
	url.params = new Array(); // ../../../../../Core_DotNet/Player/root/js/escape.js: 105
	url.safemode = this.safemode; // ../../../../../Core_DotNet/Player/root/js/escape.js: 106
	for (var k in this.params) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 107
		var v = this.params[k]; // ../../../../../Core_DotNet/Player/root/js/escape.js: 108
		if (v == null) // ../../../../../Core_DotNet/Player/root/js/escape.js: 109
			continue; // ../../../../../Core_DotNet/Player/root/js/escape.js: 110
		url.params[k] = this.params[k]; // ../../../../../Core_DotNet/Player/root/js/escape.js: 111
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 112
	return url; // ../../../../../Core_DotNet/Player/root/js/escape.js: 113
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 114

UrlParser.prototype.Parse = function() { // ../../../../../Core_DotNet/Player/root/js/escape.js: 116
	var strArgs; // ../../../../../Core_DotNet/Player/root/js/escape.js: 117
	var strArg; // ../../../../../Core_DotNet/Player/root/js/escape.js: 118
	var ss = document.location.hash.substring(1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 119
	strArgs = ss.split("&"); // ../../../../../Core_DotNet/Player/root/js/escape.js: 120
	if (strArgs.length == 0 || strArgs[0] == "") { // ../../../../../Core_DotNet/Player/root/js/escape.js: 121
		ss = document.location.search.substring(1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 122
		strArgs = ss.split("&"); // ../../../../../Core_DotNet/Player/root/js/escape.js: 123
	}; // ../../../../../Core_DotNet/Player/root/js/escape.js: 124
	if (strArgs.length > 0) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 125
		if (strArgs[0].toLowerCase().substr(0, 3) == "su=") { // ../../../../../Core_DotNet/Player/root/js/escape.js: 126
			this.safemode = true; // ../../../../../Core_DotNet/Player/root/js/escape.js: 127
			strArgs = strArgs[0].substr(3); // ../../../../../Core_DotNet/Player/root/js/escape.js: 128
			strArgs = Escape.SafeUriUnEscape(strArgs); // ../../../../../Core_DotNet/Player/root/js/escape.js: 129
			strArgs = strArgs.split("&"); // ../../../../../Core_DotNet/Player/root/js/escape.js: 130
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 131
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 132
	for (var i = 0; i < strArgs.length; i++) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 133
		strArg = (strArgs[i]); // ../../../../../Core_DotNet/Player/root/js/escape.js: 134
		if (strArg.length == 0) // ../../../../../Core_DotNet/Player/root/js/escape.js: 135
			continue; // ../../../../../Core_DotNet/Player/root/js/escape.js: 136
		var param = strArg.split("="); // ../../../../../Core_DotNet/Player/root/js/escape.js: 137
		if (param.length == 2) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 138
			this.params[param[0].toLowerCase()] = param[1]; // ../../../../../Core_DotNet/Player/root/js/escape.js: 139
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 140
		else if (param.length < 2) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 141
			this.params[param[0].toLowerCase()] = ""; // ../../../../../Core_DotNet/Player/root/js/escape.js: 142
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 143
		else { // ../../../../../Core_DotNet/Player/root/js/escape.js: 144
			this.params[param[0].toLowerCase()] = strArg.substr(param[0].length + 1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 145
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 146
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 147
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 148

UrlParser.prototype.GetSafeMode = function() { // ../../../../../Core_DotNet/Player/root/js/escape.js: 150
	return this.safemode; // ../../../../../Core_DotNet/Player/root/js/escape.js: 151
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 152

UrlParser.prototype.SetSafeMode = function(k) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 154
	this.safemode = k; // ../../../../../Core_DotNet/Player/root/js/escape.js: 155
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 156

UrlParser.prototype.GetParameter = function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 158
	return this.params[s.toLowerCase()]; // ../../../../../Core_DotNet/Player/root/js/escape.js: 159
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 160

UrlParser.prototype.AddParameter = function(s, v) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 162
	this.params[s.toLowerCase()] = v; // ../../../../../Core_DotNet/Player/root/js/escape.js: 163
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 164

UrlParser.prototype.RemoveParameter = function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 166
	this.params[s.toLowerCase()] = null; // ../../../../../Core_DotNet/Player/root/js/escape.js: 167
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 168

UrlParser.prototype.ClearParameterList = function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 170
	this.params = null; // ../../../../../Core_DotNet/Player/root/js/escape.js: 171
	this.params = new Array(); // ../../../../../Core_DotNet/Player/root/js/escape.js: 172
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 173

UrlParser.prototype.BuildParameterList = function(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 175
	var s = ""; // ../../../../../Core_DotNet/Player/root/js/escape.js: 176
	var first = true; // ../../../../../Core_DotNet/Player/root/js/escape.js: 177
	for (var k in this.params) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 178
		var v = this.params[k]; // ../../../../../Core_DotNet/Player/root/js/escape.js: 179
		if (v == null) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 180
			continue; // ../../../../../Core_DotNet/Player/root/js/escape.js: 181
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 182
		if (first == false) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 183
			s += "&"; // ../../../../../Core_DotNet/Player/root/js/escape.js: 184
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 185
		first = false; // ../../../../../Core_DotNet/Player/root/js/escape.js: 186
		if (v.length == 0) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 187
			s += k; // ../../../../../Core_DotNet/Player/root/js/escape.js: 188
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 189
		else { // ../../../../../Core_DotNet/Player/root/js/escape.js: 190
			s += k + "=" + this.params[k]; // ../../../../../Core_DotNet/Player/root/js/escape.js: 191
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 192
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 193
	if (this.safemode) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 194
		s = "su=" + Escape.MyEscape(s); // ../../../../../Core_DotNet/Player/root/js/escape.js: 195
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 196
	return s; // ../../../../../Core_DotNet/Player/root/js/escape.js: 197
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 198

UrlParser.prototype.GetCorrectUrl = function(url, nosu) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 200
	if (!this.safemode) { return url; } // ../../../../../Core_DotNet/Player/root/js/escape.js: 201
	var strArgs; // ../../../../../Core_DotNet/Player/root/js/escape.js: 202
	var k = url.indexOf("#"); // ../../../../../Core_DotNet/Player/root/js/escape.js: 203
	if (k == -1) { k = url.indexOf("?") } // ../../../../../Core_DotNet/Player/root/js/escape.js: 204
	if (k >= 0) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 205
		var paramss = url.substring(k + 1); // ../../../../../Core_DotNet/Player/root/js/escape.js: 206
		strArgs = paramss.split("&"); // ../../../../../Core_DotNet/Player/root/js/escape.js: 207
		if (strArgs[0].toLowerCase().substr(0, 3) == "su=") { // ../../../../../Core_DotNet/Player/root/js/escape.js: 208
			return url; // ../../../../../Core_DotNet/Player/root/js/escape.js: 209
		} // ../../../../../Core_DotNet/Player/root/js/escape.js: 210
		var ss = url.substring(0, k + 1) + "su=" + Escape.SafeUriEscape(paramss); // ../../../../../Core_DotNet/Player/root/js/escape.js: 211
		return ss; // ../../../../../Core_DotNet/Player/root/js/escape.js: 212
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 213
	else { // ../../../../../Core_DotNet/Player/root/js/escape.js: 214
		return url + (nosu ? "" : "?su="); // ../../../../../Core_DotNet/Player/root/js/escape.js: 215
	} // ../../../../../Core_DotNet/Player/root/js/escape.js: 216
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 217

function UnescapeQuotes(s) { // ../../../../../Core_DotNet/Player/root/js/escape.js: 219
	return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'); // ../../../../../Core_DotNet/Player/root/js/escape.js: 220
} // ../../../../../Core_DotNet/Player/root/js/escape.js: 221

//* <FileEnd path="../../../../../Core_DotNet/Player/root/js/escape.js"/>


//* <FileEnd path="../Include/CoreScripts/Escape.js"/>


function GetTitle() { // ../Include/CoreScripts/GatewayHelper.js: 7
    var title = document.title; // ../Include/CoreScripts/GatewayHelper.js: 8
    if (!title) { // ../Include/CoreScripts/GatewayHelper.js: 9
        try { // ../Include/CoreScripts/GatewayHelper.js: 10
            //copied from tocfunctions.js in Init_treeloaded()
            if (_sco == false) { // ../Include/CoreScripts/GatewayHelper.js: 12
                var tpref = (UIComponents.TitlePrefix == true ? R_toc_title + " - " : ""); // ../Include/CoreScripts/GatewayHelper.js: 13
                title = tpref + UnescapeQuotes(moduleName); // ../Include/CoreScripts/GatewayHelper.js: 14
            } // ../Include/CoreScripts/GatewayHelper.js: 15
        } // ../Include/CoreScripts/GatewayHelper.js: 16
        catch (e) { } // ../Include/CoreScripts/GatewayHelper.js: 17
    } // ../Include/CoreScripts/GatewayHelper.js: 18
    return title; // ../Include/CoreScripts/GatewayHelper.js: 19
} // ../Include/CoreScripts/GatewayHelper.js: 20

XdTransfer.AddListener(window, function(messageName, messageData) { // ../Include/CoreScripts/GatewayHelper.js: 22
    if (messageName == 'oraupk-gatewayinfo') { // ../Include/CoreScripts/GatewayHelper.js: 23
        if (messageData['debug']) { // ../Include/CoreScripts/GatewayHelper.js: 24
            if (window['Debug']) { // ../Include/CoreScripts/GatewayHelper.js: 25
                window['Debug']['is_ta_debug'] = true; // ../Include/CoreScripts/GatewayHelper.js: 26
            } // ../Include/CoreScripts/GatewayHelper.js: 27
        } // ../Include/CoreScripts/GatewayHelper.js: 28
//(ignore)//         Trace('XdTransfer.AddListener', window['Debug']['is_ta_debug']); // ../Include/CoreScripts/GatewayHelper.js: 29
        XdTransfer.PostMessage(window.parent, 'oraupk-playerinfo', { 'title': GetTitle(), 'diagnostics': (window['UserPrefs']['EnableShowDiagnostics'] || (window['Debug'] && window['Debug']['is_ta_debug'])) }); // ../Include/CoreScripts/GatewayHelper.js: 30
    } // ../Include/CoreScripts/GatewayHelper.js: 31
}); // ../Include/CoreScripts/GatewayHelper.js: 32



//* <FileEnd path="../Include/CoreScripts/GatewayHelper.js"/>


//* <FileBegin path="../Include/CoreScripts/SmartMatch.js"/>
//x /// <reference path="../Tools/Main.js"/>
//x /// <reference path="../Tools/Dump.js"/>
//x /// <reference path="../Tools/Base.js"/>
//x /// <reference path="../Tools/Trace.js"/>
//x /// <reference path="../Common/ConfigData.js"/>
//x /// <reference path="../Tools/DomTable.js"/>

//* <FileBegin path="../Include/Tools/Dump.js"/>
//x /// <reference path="../Tools/Json.js"/>

function DumpValue(value) { // ../Include/Tools/Dump.js: 3
    var type = TypeOf(value); // ../Include/Tools/Dump.js: 4
    var str = type; // ../Include/Tools/Dump.js: 5
    if (value != (void 0) && type != '[function]' && type != '[object Function]') { // ../Include/Tools/Dump.js: 6
        var encoded; // ../Include/Tools/Dump.js: 7
        try { encoded = Json.EncodeObject(value); } catch (xe) { } // ../Include/Tools/Dump.js: 8
        str += ':' + ((encoded == void 0) ? '(complex object)' : encoded); // ../Include/Tools/Dump.js: 9
    } // ../Include/Tools/Dump.js: 10
    return str; // ../Include/Tools/Dump.js: 11
} // ../Include/Tools/Dump.js: 12

function Dump(obj) { // ../Include/Tools/Dump.js: 14
    if (obj == null) // ../Include/Tools/Dump.js: 15
        return '(null)'; // ../Include/Tools/Dump.js: 16
    var list = []; // ../Include/Tools/Dump.js: 17
    for (var member in obj) // ../Include/Tools/Dump.js: 18
        list.push(member + '=' + DumpValue(obj[member])); // ../Include/Tools/Dump.js: 19
    return list.join(', '); // ../Include/Tools/Dump.js: 20
} // ../Include/Tools/Dump.js: 21
//* <FileEnd path="../Include/Tools/Dump.js"/>


//* <FileBegin path="../Include/Tools/Base.js"/>
//x /// <reference path="Sanity.js" />

//* <FileBegin path="../Include/Tools/Sanity.js"/>
//x /// <reference path="Fail.js"/>

//* <FileBegin path="../Include/Tools/Fail.js"/>
//x /// <reference path="Trace.js" xconfig="Trace,Debug"/>
//x /// <reference path="Error.js"/>

//* <FileBegin path="../Include/Tools/Error.js"/>
// Don't reference Trace.js in this file

/** @constructor */ // ../Include/Tools/Error.js: 3
function ArgumentError(message) { // ../Include/Tools/Error.js: 4
    this.name = 'ArgumentError'; // ../Include/Tools/Error.js: 5
    this.message = message; // ../Include/Tools/Error.js: 6
    this.toString = function() { return this.message; } // ../Include/Tools/Error.js: 7
} // ../Include/Tools/Error.js: 8

/** @constructor */ // ../Include/Tools/Error.js: 10
function ApplicationError(message) { // ../Include/Tools/Error.js: 11
    this.name = 'ApplicationError'; // ../Include/Tools/Error.js: 12
    this.message = message; // ../Include/Tools/Error.js: 13
    this.toString = function() { return this.message; } // ../Include/Tools/Error.js: 14
} // ../Include/Tools/Error.js: 15

//x //: <if xconfig="Debug,Trace"/>
//x function GetCallStack(droppedFrames) {
//x     var fn = arguments.callee.caller;
//x     if (droppedFrames) {
//x         while (fn && droppedFrames > 0) {
//x             fn = fn.caller;
//x             --droppedFrames;
//x         }
//x     }
//x     var callStack = [];
//x     while (fn) {
//x         var body = fn.toString();
//x         var posEndParam = body.indexOf(')');
//x         var name = body.substr(0, posEndParam + 1);
//x         if (posEndParam != -1) {
//x             var posNewLine = body.indexOf('\n', posEndParam);
//x             if (posNewLine != -1) {
//x                 var line = body.substr(posEndParam + 1, posNewLine - posEndParam - 1);
//x                 var commentPos = line.indexOf('//');
//x                 if (commentPos != -1) {
//x                     var endPos = line.length - ((line[line.length - 1] == '\r') ? 1 : 0);
//x                     var comment = line.substr(commentPos, endPos - commentPos);
//x                     name += ' ' + comment;
//x                 }
//x             }
//x         }
//x         callStack.push(name);
//x         fn = fn.caller;
//x     }
//x     return callStack;
//x }
//x //: <end/>

//* <FileEnd path="../Include/Tools/Error.js"/>


//x //: <if xconfig="Debug"/>
//x var FailMessages = {};
//x var FailAlert = function(message) {
//x     if (FailMessages[message] || (FailMessages[message] == void 0)) {
//x         FailMessages[message] = confirm(message + '\n\nCall stack:\n' + GetCallStack(2).join('\n') + '\n\nIgnore similar messages?');
//x     }
//x };
//x //: <end/>

// It is declared as a var to enable to be hooked
var Fail = function(source, message1, message2, droppedFrames) { // ../Include/Tools/Fail.js: 14
    var body = 'Failed: ' + (message1 ? message1 : '') + ((message1 && message2) ? ', ' : '') + (message2 ? message2 : ''); // ../Include/Tools/Fail.js: 15
    var message = (source ? source + ': ' : '') + body; // ../Include/Tools/Fail.js: 16
//(ignore)//     Trace.Exception(source, new Error(body), (droppedFrames || 0) + 1); // ../Include/Tools/Fail.js: 17
//x     //: <if xconfig="Debug"/>
//x     FailAlert(message);
//x     //: <end/>
    throw new ApplicationError(message); // ../Include/Tools/Fail.js: 21
}; // ../Include/Tools/Fail.js: 22

Fail.NotImplemented = function(source) { // ../Include/Tools/Fail.js: 24
    Fail(source, 'Not implemented.', null, 2); // ../Include/Tools/Fail.js: 25
}; // ../Include/Tools/Fail.js: 26

Fail.Exception = function(source, xe) { // ../Include/Tools/Fail.js: 28
//(ignore)//     Trace.Exception(source, xe, 0); // ../Include/Tools/Fail.js: 29
    Fail(source, 'Exception: ' + xe.message, null, 2); // ../Include/Tools/Fail.js: 30
}; // ../Include/Tools/Fail.js: 31

//* <FileEnd path="../Include/Tools/Fail.js"/>

//x //: <if xconfig="Debug,Trace"/>
//x /// <reference path="Assert.js"/>
//x /// <reference path="Json.js"/>
//x 
//x function DumpValue(value) {
//x     var type = TypeOf(value);
//x     var str = type;
//x     if (value != (void 0) && type != '[function]' && type != '[object Function]') {
//x         var encoded;
//x         try { encoded = Json.EncodeObject(value); } catch (xe) { }
//x         str += ':' + ((encoded == void 0) ? '(complex object)' : encoded);
//x     }
//x     return str;
//x }
//x 
//x function Dump(obj) {
//x     if (obj == null)
//x         return '(null)';
//x     var list = [];
//x     for (var member in obj)
//x         list.push(member + '=' + DumpValue(obj[member]));
//x     return list.join(', ');
//x }
//x 
//x function Called(params) {
//x     var str = 'Called';
//x     if (params != null)
//x         str += ' with: ' + Dump(params);
//x     return str;
//x }
//x 
//x function Returned(params) {
//x     return ('Returned: ' + DumpValue(params));
//x }
//x 
//x function ComplexObject(obj) {
//x     return ((obj != null) ? (function() { }) : obj);
//x }
//x 
//x 
//x //: <end/>

//* <FileEnd path="../Include/Tools/Sanity.js"/>


//<!--Version 1-->

function _ExtendDeepObj(target, key, obj) { // ../Include/Tools/Base.js: 5
    if (targetObj === obj) // ../Include/Tools/Base.js: 6
        return; // ../Include/Tools/Base.js: 7
    var targetObj = target[key]; // ../Include/Tools/Base.js: 8
    if (!IsHash(targetObj)) // ../Include/Tools/Base.js: 9
        target[key] = targetObj = {}; // ../Include/Tools/Base.js: 10
    for (var objKey in obj) { // ../Include/Tools/Base.js: 11
        var value = obj[objKey]; // ../Include/Tools/Base.js: 12
        if (IsHash(value)) // ../Include/Tools/Base.js: 13
            _ExtendDeepObj(targetObj, objKey, value); // ../Include/Tools/Base.js: 14
        else targetObj[objKey] = value; // ../Include/Tools/Base.js: 15
    } // ../Include/Tools/Base.js: 16
} // ../Include/Tools/Base.js: 17

function _ExtendDeepList(target, objs) { // ../Include/Tools/Base.js: 19
    if (target == void 0 || !IsHash(target)) // ../Include/Tools/Base.js: 20
        target = {}; // ../Include/Tools/Base.js: 21
    for (var i = 0, n = objs.length, obj; i < n; ++i) { // ../Include/Tools/Base.js: 22
        obj = objs[i]; // ../Include/Tools/Base.js: 23
        if (IsHash(obj) && target !== obj) { // ../Include/Tools/Base.js: 24
            for (var key in obj) { // ../Include/Tools/Base.js: 25
                var value = obj[key]; // ../Include/Tools/Base.js: 26
                if (IsHash(value)) // ../Include/Tools/Base.js: 27
                    _ExtendDeepObj(target, key, value); // ../Include/Tools/Base.js: 28
                else target[key] = value; // ../Include/Tools/Base.js: 29
            } // ../Include/Tools/Base.js: 30
        } // ../Include/Tools/Base.js: 31
    } // ../Include/Tools/Base.js: 32
    return target; // ../Include/Tools/Base.js: 33
} // ../Include/Tools/Base.js: 34

function _ExtendFlatList(target, objs) { // ../Include/Tools/Base.js: 36
    if (target == void 0 || !IsHash(target)) // ../Include/Tools/Base.js: 37
        target = {}; // ../Include/Tools/Base.js: 38
    for (var i = 0, n = objs.length, obj; i < n; ++i) { // ../Include/Tools/Base.js: 39
        obj = objs[i]; // ../Include/Tools/Base.js: 40
        if (IsHash(obj) && target !== obj) { // ../Include/Tools/Base.js: 41
            for (var key in obj) // ../Include/Tools/Base.js: 42
                target[key] = obj[key]; // ../Include/Tools/Base.js: 43
        } // ../Include/Tools/Base.js: 44
    } // ../Include/Tools/Base.js: 45
    return target; // ../Include/Tools/Base.js: 46
} // ../Include/Tools/Base.js: 47

function Extend(deep) { // ../Include/Tools/Base.js: 49
    if (deep !== !!deep) // ../Include/Tools/Base.js: 50
        return _ExtendFlatList(arguments[0], [].slice.call(arguments, 1)); // ../Include/Tools/Base.js: 51
    if (deep) // ../Include/Tools/Base.js: 52
        return _ExtendDeepList(arguments[1], [].slice.call(arguments, 2)); // ../Include/Tools/Base.js: 53
    return _ExtendFlatList(arguments[1], [].slice.call(arguments, 2)); // ../Include/Tools/Base.js: 54
} // ../Include/Tools/Base.js: 55

function CloneObject(obj) { // ../Include/Tools/Base.js: 57
    return Extend(true, {}, obj); // ../Include/Tools/Base.js: 58
} // ../Include/Tools/Base.js: 59

function CloneHash(obj) { // ../Include/Tools/Base.js: 61
    var result = {}; // ../Include/Tools/Base.js: 62
    for (var m in obj) // ../Include/Tools/Base.js: 63
        result[m] = obj[m]; // ../Include/Tools/Base.js: 64
    return result; // ../Include/Tools/Base.js: 65
} // ../Include/Tools/Base.js: 66

function GetValue(obj, member, def) { // ../Include/Tools/Base.js: 68
    return ((typeof obj[member] == 'undefined') ? def : obj[member]); // ../Include/Tools/Base.js: 69
} // ../Include/Tools/Base.js: 70

function GetNonEmpty(value, def) { // ../Include/Tools/Base.js: 72
    return ((value && value.length) ? value : def); // ../Include/Tools/Base.js: 73
} // ../Include/Tools/Base.js: 74

function RandomInteger(min, max) { // ../Include/Tools/Base.js: 76
    return (min + Math.floor(Math.random() * (max - min + 1))); // ../Include/Tools/Base.js: 77
} // ../Include/Tools/Base.js: 78

function RandomIndex(length) { // ../Include/Tools/Base.js: 80
    return Math.floor(Math.random() * length); // ../Include/Tools/Base.js: 81
} // ../Include/Tools/Base.js: 82

function InRange(value, min, max) { // ../Include/Tools/Base.js: 84
    return (value >= min && value <= max); // ../Include/Tools/Base.js: 85
} // ../Include/Tools/Base.js: 86

function GetInRange(value, min, max) { // ../Include/Tools/Base.js: 88
    return (value > min)? ((value < max)? value: max): min; // ../Include/Tools/Base.js: 89
} // ../Include/Tools/Base.js: 90

function ExtendClass(baseClasses_arguments) { // ../Include/Tools/Base.js: 92
    var baseClasses = [].slice.call(arguments, 0); // ../Include/Tools/Base.js: 93
    var proto = {}; // ../Include/Tools/Base.js: 94
    for (var i = 0, n = baseClasses.length; i < n; ++i) { // ../Include/Tools/Base.js: 95
        var arg_i = baseClasses[i]; // ../Include/Tools/Base.js: 96
        if (arg_i) { // ../Include/Tools/Base.js: 97
            for (var key_i in arg_i) // ../Include/Tools/Base.js: 98
                proto[key_i] = arg_i[key_i]; // ../Include/Tools/Base.js: 99
        } // ../Include/Tools/Base.js: 100
    } // ../Include/Tools/Base.js: 101
    proto.__BaseClasses = baseClasses; // ../Include/Tools/Base.js: 102
    return proto; // ../Include/Tools/Base.js: 103
} // ../Include/Tools/Base.js: 104

function GetPropertyFromPath(obj, key) { // ../Include/Tools/Base.js: 106
    if(!key) // ../Include/Tools/Base.js: 107
        return obj; // ../Include/Tools/Base.js: 108
    try { // ../Include/Tools/Base.js: 109
        var names = key.split('.'); // ../Include/Tools/Base.js: 110
        for (var i = 0, n = names.length; i < n; ++i) { // ../Include/Tools/Base.js: 111
            if (!obj) // ../Include/Tools/Base.js: 112
                return void 0; // ../Include/Tools/Base.js: 113
            obj = obj[names[i]]; // ../Include/Tools/Base.js: 114
        } // ../Include/Tools/Base.js: 115
        return obj; // ../Include/Tools/Base.js: 116
    } // ../Include/Tools/Base.js: 117
    catch (e) { // ../Include/Tools/Base.js: 118
        return void 0; // ../Include/Tools/Base.js: 119
    } // ../Include/Tools/Base.js: 120
}; // ../Include/Tools/Base.js: 121

// Try multiple callbacks, return after the first successfully completed callback.
// If the callback returns a value that converts to boolean false the next callback will be executed.
function Try(callback1, callback2) { // ../Include/Tools/Base.js: 125
    for (var i = 0; i < arguments.length; ++i) { // ../Include/Tools/Base.js: 126
        try { // ../Include/Tools/Base.js: 127
            var result = arguments[i](); // ../Include/Tools/Base.js: 128
            if (result === void 0 || !!result) // ../Include/Tools/Base.js: 129
                return true; // ../Include/Tools/Base.js: 130
        } // ../Include/Tools/Base.js: 131
        catch(xe) { // ../Include/Tools/Base.js: 132
        } // ../Include/Tools/Base.js: 133
    } // ../Include/Tools/Base.js: 134
    return false; // ../Include/Tools/Base.js: 135
} // ../Include/Tools/Base.js: 136

//* <FileEnd path="../Include/Tools/Base.js"/>


//* <FileBegin path="../Include/Common/ConfigData.js"/>
//x /// <reference path="../Tools/ConfigNode.js"/>
//x /// <reference path="../Tools/HashMap.js"/>
//x /// <reference path="../Tools/AjaxRequest.js"/>
//x /// <reference path="ConfigDefaults.js"/>
//x /// <reference path="ApplicationData.js"/>
//x /// <reference path="UpkMeta.js"/>

//* <FileBegin path="../Include/Tools/ConfigNode.js"/>
//x /// <reference path="Base.js"/>
//x /// <reference path="Assert.js"/>

//* <FileBegin path="../Include/Tools/Assert.js"/>
//x //: <if xconfig="Debug,Trace"/>
//x /// <reference path="Fail.js"/>
//x /// <reference path="Main.js"/>
//x 
//x function Assert(source, value, message) {
//x     if (!value)
//x         Fail('Assert.Message', source, message, 2);
//x }
//x     
//x Assert.Condition = function(source, value, name) {
//x     if (!value)
//x         Fail('Assert.Condition', source, NameOf(name) + ' does not hold', 2);
//x };
//x 
//x Assert.True = function(source, value, name) {
//x     if (value !== true)
//x         Fail('Assert.True', source, NameOf(name) + ' is not true', 2);
//x };
//x 
//x Assert.False = function(source, value, name) {
//x     if (value !== false)
//x         Fail('Assert.False', source, NameOf(name) + ' is not false', 2);
//x };
//x 
//x Assert.Null = function(source, value, name) {
//x     if (value != null)
//x         Fail('Assert.Null', source, NameOf(name) + ' is not null', 2);
//x };
//x 
//x Assert.NonNull = function(source, value, name) {
//x     if (value == null)
//x         Fail('Assert.NonNull', source, NameOf(name) + ' is null', 2);
//x };
//x 
//x Assert.Defined = function(source, value, name) {
//x     if (value === void 0)
//x         Fail('Assert.Defined', source, NameOf(name) + ' is undefined', 2);
//x };
//x 
//x Assert.Undefined = function(source, value, name) {
//x     if (value !== void 0)
//x         Fail('Assert.Undefined', source, NameOf(name) + ' is defined', 2);
//x };
//x 
//x Assert.Equals = function(source, value1, value2, name1, name2) {
//x     if (value1 != value2)
//x         Fail('Assert.Equals', source, NameOf(name1) + ' and ' + NameOf(name2) + ' are not equal', 2);
//x };
//x 
//x Assert.Range = function(source, value, minValue, maxValue, name) {
//x     if (value < minValue || value > maxValue)
//x         Fail('Assert.Range', source, NameOf(name) + ' must be in range ' + minValue + ',  ' + maxValue, 2);
//x };
//x 
//x Assert.ArrayIndex = function(source, index, arrayObj, indexName, arrayObjName) {
//x     if (arrayObj == null)
//x         Fail('Assert.ArrayIndex', source, NameOf(arrayObjName) + ' is null', 2);
//x     if (index < 0 || index >= arrayObj.length)
//x         Fail('Assert.ArrayIndex', source, NameOf(indexName) + ' invalid array index ' + index + ' in ' + NameOf(arrayObjName) + ', length = ' + arrayObj.length, 2);
//x };
//x 
//x Assert.Length = function(source, value, length, name) {
//x     if (value == null)
//x         Fail('Assert.Length', source, NameOf(name) + ' is null', 2);
//x     if (value.length != length)
//x         Fail('Assert.Length', source, NameOf(name) + ' must have ' + length + ' elements', 2);
//x };
//x 
//x Assert.MinLength = function(source, value, minLength, name) {
//x     if (value == null)
//x         Fail('Assert.MinLength', source, NameOf(name) + ' is null', 2);
//x     if (value.length < minLength)
//x         Fail('Assert.MinLength', source, NameOf(name) + ' must have at least ' + minLength + ' elements', 2);
//x };
//x 
//x Assert.EqualLength = function(source, value1, value2, name1, name2) {
//x     if (value1 == null)
//x         Fail('Assert.EqualLength', source, NameOf(name1) + ' is null', 2);
//x     if (value2 == null)
//x         Fail('Assert.EqualLength', source, NameOf(name2) + ' is null', 2);
//x     if (value1.length != value2.length)
//x         Fail('Assert.EqualLength', source, NameOf(name1) + ' and ' + NameOf(name2) + ' length is not equal', 2);
//x };
//x 
//x Assert.Identical = function(source, value1, value2, name1, name2) {
//x     if (value1 !== value2)
//x         Fail('Assert.Identical', source, NameOf(name1) + ' and ' + NameOf(name2) + ' are not identical', 2);
//x };
//x 
//x Assert.String = function(source, value, name) {
//x     if (value == null)
//x         Fail('Assert.String', source, NameOf(name) + ' is null', 2);
//x     if (!IsString(value))
//x         Fail('Assert.String', source, NameOf(name) + ' is not a String', 2);
//x };
//x 
//x Assert.Number = function(source, value, name) {
//x     if (value == null)
//x         Fail('Assert.Number', source, NameOf(name) + ' is null', 2);
//x     if (!IsNumber(value))
//x         Fail('Assert.Number', source, NameOf(name) + ' is not a Number', 2);
//x };
//x 
//x Assert.Array = function(source, value, name) {
//x     if (value == null)
//x         Fail('Assert.Array', source, NameOf(name) + ' is null', 2);
//x     if (!IsArray(value))
//x         Fail('Assert.Array', source, NameOf(name) + ' is not an Array', 2);
//x };
//x 
//x Assert.Hash = function(source, value, name) {
//x     if (value == null)
//x         Fail('Assert.Hash', source, NameOf(name) + ' is null', 2);
//x     if (!IsHash(value))
//x         Fail('Assert.Hash', source, NameOf(name) + ' is not a hash Object', 2);
//x };
//x 
//x Assert.InstanceOf = function(source, value, type, name, tname) {
//x     if (!(value instanceof type))
//x         Fail('Assert.InstanceOf', source, NameOf(name) + ' is not instance of ' + NameOf(tname), 2);
//x };
//x 
//x Assert.NullOrNumber = function(source, value, name) {
//x     if (!IsNullOrNumber(value))
//x         Fail('Assert.NullOrNumber', source, NameOf(name) + ' is not a Number', 2);
//x };
//x 
//x Assert.NullOrString = function(source, value, name) {
//x     if (!IsNullOrString(value))
//x         Fail('Assert.NullOrString', source, NameOf(name) + ' is not a String', 2);
//x };
//x 
//x Assert.NullOrArray = function(source, value, name) {
//x     if (!IsNullOrArray(value))
//x         Fail('Assert.NullOrArray', source, NameOf(name) + ' is not an Array', 2);
//x };
//x 
//x Assert.NullOrInstanceOf = function(source, value, type, name, tname) {
//x     if (!IsNullOrInstanceOf(value, type))
//x         Fail('Assert.InstanceOf', source, NameOf(name) + ' is not instance of ' + NameOf(tname), 2);
//x };
//x 
//x Assert.InRange = function(source, value, min, max, name) {
//x     if (!InRange(value, min, max))
//x         Fail('Assert.InRange', source, NameOf(name) + ' is not in range [' + min + ', ' + max + ']', 2);
//x };
//x 
//x Assert.Match = function(source, value, name, regexp, regexpName) {
//x     if (!IsString(value))
//x         Fail('Assert.Match', source, NameOf(name) + ' is not a String', 2);
//x     if (regexp == null)
//x         Fail('Assert.Match', source, NameOf(regexpName) + ' is null', 2);
//x     if (!value.match(regexp))
//x         Fail('Assert.Match', source, NameOf(name) + ' must match ' + NameOf(regexpName), 2);
//x };
//x 
//x Assert.MustOverride = function(source) {
//x     Fail('Assert.MustOverride', source, NameOf(source) + ' must be overriden', 2);
//x };
//x 
//x //: <end/>

//* <FileEnd path="../Include/Tools/Assert.js"/>


/** @constructor */ // ../Include/Tools/ConfigNode.js: 4
function ConfigNode(node, key) { // ../Include/Tools/ConfigNode.js: 5
    this.Node = node; // ../Include/Tools/ConfigNode.js: 6
    this.Key = key; // ../Include/Tools/ConfigNode.js: 7
} // ../Include/Tools/ConfigNode.js: 8

ConfigNode.FindPath = function(node, nameList) { // ../Include/Tools/ConfigNode.js: 10
    if (!node) // ../Include/Tools/ConfigNode.js: 11
        return void 0; // ../Include/Tools/ConfigNode.js: 12
    for (var i = 0, n = nameList.length; i < n; ++i) { // ../Include/Tools/ConfigNode.js: 13
        if ((node = node[nameList[i]]) === void 0) // ../Include/Tools/ConfigNode.js: 14
            return void 0; // ../Include/Tools/ConfigNode.js: 15
    } // ../Include/Tools/ConfigNode.js: 16
    return node; // ../Include/Tools/ConfigNode.js: 17
}; // ../Include/Tools/ConfigNode.js: 18

ConfigNode.FindKey = function(node, key) { // ../Include/Tools/ConfigNode.js: 20
    return ((key && key.length) ? ConfigNode.FindPath(node, key.split('/')) : node); // ../Include/Tools/ConfigNode.js: 21
}; // ../Include/Tools/ConfigNode.js: 22

ConfigNode.CreatePath = function(node, nameList) { // ../Include/Tools/ConfigNode.js: 24
//(ignore)//     Assert.NonNull('ConfigNode.CreatePath', node, 'node'); // ../Include/Tools/ConfigNode.js: 25
    for (var i = 0, n = nameList.length; i < n; ++i) { // ../Include/Tools/ConfigNode.js: 26
        var next = node[nameList[i]]; // ../Include/Tools/ConfigNode.js: 27
        if (next === void 0) { // ../Include/Tools/ConfigNode.js: 28
            while (i < n) { // ../Include/Tools/ConfigNode.js: 29
                node[nameList[i]] = next = {}; // ../Include/Tools/ConfigNode.js: 30
                node = next; // ../Include/Tools/ConfigNode.js: 31
                ++i; // ../Include/Tools/ConfigNode.js: 32
            } // ../Include/Tools/ConfigNode.js: 33
            return node; // ../Include/Tools/ConfigNode.js: 34
        } // ../Include/Tools/ConfigNode.js: 35
//(ignore)//         Assert.Hash('ConfigNode.CreatePath', next, 'node[nameList[i]]'); // ../Include/Tools/ConfigNode.js: 36
        node = next; // ../Include/Tools/ConfigNode.js: 37
    } // ../Include/Tools/ConfigNode.js: 38
    return node; // ../Include/Tools/ConfigNode.js: 39
}; // ../Include/Tools/ConfigNode.js: 40

ConfigNode.CreateKey = function(node, key) { // ../Include/Tools/ConfigNode.js: 42
    return ConfigNode.CreatePath(node, key.split('/')); // ../Include/Tools/ConfigNode.js: 43
}; // ../Include/Tools/ConfigNode.js: 44

ConfigNode.prototype = { // ../Include/Tools/ConfigNode.js: 46
    GetRoot: function() { // ../Include/Tools/ConfigNode.js: 47
        return this.Node; // ../Include/Tools/ConfigNode.js: 48
    }, // ../Include/Tools/ConfigNode.js: 49
    CreateKey: function(key) { // ../Include/Tools/ConfigNode.js: 50
//(ignore)//         Assert.String('ConfigNode.CreateKey', key, 'key'); // ../Include/Tools/ConfigNode.js: 51
        return new ConfigNode(ConfigNode.CreateKey(this.Node, key), this.GetAbsoluteKey(key)); // ../Include/Tools/ConfigNode.js: 52
    }, // ../Include/Tools/ConfigNode.js: 53
    OpenKey: function(key) { // ../Include/Tools/ConfigNode.js: 54
//(ignore)//         Assert.String('ConfigNode.OpenKey', key, 'key'); // ../Include/Tools/ConfigNode.js: 55
//(ignore)//         Assert.NonNull('ConfigNode.OpenKey', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 56
        var node = ConfigNode.FindKey(this.Node, key); // ../Include/Tools/ConfigNode.js: 57
//(ignore)//         Assert('ConfigNode.GetValue', node !== void 0, NameOf(key) + ' does not exists' + (this.Key ? ' at ' + NameOf(this.Key) : '')); // ../Include/Tools/ConfigNode.js: 58
        return new ConfigNode(node, this.GetAbsoluteKey(key)); // ../Include/Tools/ConfigNode.js: 59
    }, // ../Include/Tools/ConfigNode.js: 60
    TryOpenKey: function(key) { // ../Include/Tools/ConfigNode.js: 61
//(ignore)//         Assert.String('ConfigNode.TryOpenKey', key, 'key'); // ../Include/Tools/ConfigNode.js: 62
//(ignore)//         Assert.NonNull('ConfigNode.TryOpenKey', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 63
        var node = ConfigNode.FindKey(this.Node, key); // ../Include/Tools/ConfigNode.js: 64
        return (node? new ConfigNode(node, this.GetAbsoluteKey(key)): null); // ../Include/Tools/ConfigNode.js: 65
    }, // ../Include/Tools/ConfigNode.js: 66
    GetValue: function(name) { // ../Include/Tools/ConfigNode.js: 67
//(ignore)//         Assert.String('ConfigNode.GetValue', name, 'name'); // ../Include/Tools/ConfigNode.js: 68
//(ignore)//         Assert.NonNull('ConfigNode.GetValue', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 69
//(ignore)//         Assert('ConfigNode.GetValue', (this.Node[name] !== void 0), NameOf(name) + ' does not exists' + (this.Key ? ' at ' + NameOf(this.Key) : '')); // ../Include/Tools/ConfigNode.js: 70
        return this.Node[name]; // ../Include/Tools/ConfigNode.js: 71
    }, // ../Include/Tools/ConfigNode.js: 72
    TryGetValue: function(name, defaultValue) { // ../Include/Tools/ConfigNode.js: 73
//(ignore)//         Assert.String('ConfigNode.TryGetValue', name, 'name'); // ../Include/Tools/ConfigNode.js: 74
//(ignore)//         Assert.NonNull('ConfigNode.TryGetValue', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 75
        var value = this.Node[name]; // ../Include/Tools/ConfigNode.js: 76
        return ((value === void 0) ? defaultValue : value); // ../Include/Tools/ConfigNode.js: 77
    }, // ../Include/Tools/ConfigNode.js: 78
    GetValueByKey: function(key) { // ../Include/Tools/ConfigNode.js: 79
//(ignore)//         Assert.NullOrString('ConfigNode.GetValueByKey', key, 'key'); // ../Include/Tools/ConfigNode.js: 80
//(ignore)//         Assert.NonNull('ConfigNode.GetValueByKey', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 81
        var value = ConfigNode.FindKey(this.Node, key); // ../Include/Tools/ConfigNode.js: 82
//(ignore)//         Assert('ConfigNode.GetValue', value !== void 0, NameOf(key) + ' does not exists' + (this.Key ? ' at ' + NameOf(this.Key) : '')); // ../Include/Tools/ConfigNode.js: 83
        return value; // ../Include/Tools/ConfigNode.js: 84
    }, // ../Include/Tools/ConfigNode.js: 85
    TryGetValueByKey: function(key, defaultValue) { // ../Include/Tools/ConfigNode.js: 86
//(ignore)//         Assert.NullOrString('ConfigNode.GetValueByKey', key, 'key'); // ../Include/Tools/ConfigNode.js: 87
//(ignore)//         Assert.NonNull('ConfigNode.GetValueByKey', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 88
        var value = ConfigNode.FindKey(this.Node, key); // ../Include/Tools/ConfigNode.js: 89
        return ((value === void 0) ? defaultValue : value); // ../Include/Tools/ConfigNode.js: 90
    }, // ../Include/Tools/ConfigNode.js: 91
    GetAbsoluteKey: function(key) { // ../Include/Tools/ConfigNode.js: 92
//(ignore)//         Assert.NullOrString('ConfigNode.GetKeyPath', key, 'key'); // ../Include/Tools/ConfigNode.js: 93
        return (this.Key ? (this.Key + (key ? '/' + key : '')) : key); // ../Include/Tools/ConfigNode.js: 94
    }, // ../Include/Tools/ConfigNode.js: 95
    Extend: function(node) { // ../Include/Tools/ConfigNode.js: 96
//(ignore)//         Assert.NonNull('ConfigNode.Extend', node, 'node'); // ../Include/Tools/ConfigNode.js: 97
        if (this.Node == null) // ../Include/Tools/ConfigNode.js: 98
            this.Node = {}; // ../Include/Tools/ConfigNode.js: 99
        Extend(true, this.Node, node); // ../Include/Tools/ConfigNode.js: 100
    }, // ../Include/Tools/ConfigNode.js: 101
    Delete: function(name) { // ../Include/Tools/ConfigNode.js: 102
//(ignore)//         Assert.String('ConfigNode.Delete', name, 'name'); // ../Include/Tools/ConfigNode.js: 103
//(ignore)//         Assert.NonNull('ConfigNode.Delete', this.Node, 'this.Node'); // ../Include/Tools/ConfigNode.js: 104
        delete this.Node[name]; // ../Include/Tools/ConfigNode.js: 105
    } // ../Include/Tools/ConfigNode.js: 106
}; // ../Include/Tools/ConfigNode.js: 107


//* <FileEnd path="../Include/Tools/ConfigNode.js"/>


//* <FileBegin path="../Include/Tools/HashMap.js"/>
//<!--Version 1-->

var HashMap = { // ../Include/Tools/HashMap.js: 3
    FromArray: function(arrayObj, value) { // ../Include/Tools/HashMap.js: 4
        if (value == void 0) // ../Include/Tools/HashMap.js: 5
            value = true; // ../Include/Tools/HashMap.js: 6
        var map = {}; // ../Include/Tools/HashMap.js: 7
        for (var i = 0, n = arrayObj.length; i < n; ++i) { // ../Include/Tools/HashMap.js: 8
            map[arrayObj[i]] = value; // ../Include/Tools/HashMap.js: 9
        } // ../Include/Tools/HashMap.js: 10
        return map; // ../Include/Tools/HashMap.js: 11
    }, // ../Include/Tools/HashMap.js: 12
    AddNewItem: function(hashObj, key, value) { // ../Include/Tools/HashMap.js: 13
        var doesntExists = (hashObj[key] === void 0); // ../Include/Tools/HashMap.js: 14
        if (doesntExists) // ../Include/Tools/HashMap.js: 15
            hashObj[key] = value; // ../Include/Tools/HashMap.js: 16
        return doesntExists; // ../Include/Tools/HashMap.js: 17
    }, // ../Include/Tools/HashMap.js: 18
    Extend: function(hashObj, source) { // ../Include/Tools/HashMap.js: 19
        for (var key in source) { // ../Include/Tools/HashMap.js: 20
            hashObj[key] = source[key]; // ../Include/Tools/HashMap.js: 21
        } // ../Include/Tools/HashMap.js: 22
        return hashObj; // ../Include/Tools/HashMap.js: 23
    }, // ../Include/Tools/HashMap.js: 24
    AddNewItems: function(hashObj, source) { // ../Include/Tools/HashMap.js: 25
        for (var key in source) { // ../Include/Tools/HashMap.js: 26
            if (hashObj[key] === void 0) // ../Include/Tools/HashMap.js: 27
                hashObj[key] = source[key]; // ../Include/Tools/HashMap.js: 28
        } // ../Include/Tools/HashMap.js: 29
    }, // ../Include/Tools/HashMap.js: 30
    GetKeys: function(hashObj) { // ../Include/Tools/HashMap.js: 31
        var keys = []; // ../Include/Tools/HashMap.js: 32
        for (var key in hashObj) // ../Include/Tools/HashMap.js: 33
            keys.push(key); // ../Include/Tools/HashMap.js: 34
        return keys; // ../Include/Tools/HashMap.js: 35
    }, // ../Include/Tools/HashMap.js: 36
    GetValues: function(hashObj) { // ../Include/Tools/HashMap.js: 37
        var values = []; // ../Include/Tools/HashMap.js: 38
        for (var key in hashObj) // ../Include/Tools/HashMap.js: 39
            values.push(hashObj[key]); // ../Include/Tools/HashMap.js: 40
        return values; // ../Include/Tools/HashMap.js: 41
    }, // ../Include/Tools/HashMap.js: 42
    FromKeys: function(hashObj, value) { // ../Include/Tools/HashMap.js: 43
        if (value == void 0) // ../Include/Tools/HashMap.js: 44
            value = true; // ../Include/Tools/HashMap.js: 45
        var map = {}; // ../Include/Tools/HashMap.js: 46
        for (var key in hashObj) { // ../Include/Tools/HashMap.js: 47
            map[key] = value; // ../Include/Tools/HashMap.js: 48
        } // ../Include/Tools/HashMap.js: 49
        return map; // ../Include/Tools/HashMap.js: 50
    }, // ../Include/Tools/HashMap.js: 51
    Equals: function(hashObj1, hashObj2) { // ../Include/Tools/HashMap.js: 52
        if (hashObj1 == null) // ../Include/Tools/HashMap.js: 53
            return (hashObj2 == null); // ../Include/Tools/HashMap.js: 54
        else if (hashObj2 == null) // ../Include/Tools/HashMap.js: 55
            return false; // ../Include/Tools/HashMap.js: 56
        var count = 0; // ../Include/Tools/HashMap.js: 57
        var m; // ../Include/Tools/HashMap.js: 58
        for (m in hashObj1) ++count; // ../Include/Tools/HashMap.js: 59
        for (m in hashObj2) { // ../Include/Tools/HashMap.js: 60
            --count; // ../Include/Tools/HashMap.js: 61
            if (hashObj1[m] != hashObj2[m]) // ../Include/Tools/HashMap.js: 62
                return false; // ../Include/Tools/HashMap.js: 63
        } // ../Include/Tools/HashMap.js: 64
        return (count == 0); // ../Include/Tools/HashMap.js: 65
    }, // ../Include/Tools/HashMap.js: 66
    FindMembers: function(hashObj, memberNames, neededCount) { // ../Include/Tools/HashMap.js: 67
        if (neededCount == void 0) // ../Include/Tools/HashMap.js: 68
            neededCount = memberNames.length; // ../Include/Tools/HashMap.js: 69
//(ignore)//         Assert.Condition('HashMap.FindMembers', neededCount <= memberNames.length, 'neededCount <= memberNames.length'); // ../Include/Tools/HashMap.js: 70
        for (var i = 0, n = memberNames.length; i < n; ++i) { // ../Include/Tools/HashMap.js: 71
            if (typeof (hashObj[memberNames[i]]) != 'undefined') { // ../Include/Tools/HashMap.js: 72
                if (--neededCount == 0) // ../Include/Tools/HashMap.js: 73
                    return true; // ../Include/Tools/HashMap.js: 74
            } // ../Include/Tools/HashMap.js: 75
        } // ../Include/Tools/HashMap.js: 76
        return false; // ../Include/Tools/HashMap.js: 77
    } // ../Include/Tools/HashMap.js: 78

}; // ../Include/Tools/HashMap.js: 80

//* <FileEnd path="../Include/Tools/HashMap.js"/>


//* <FileBegin path="../Include/Tools/AjaxRequest.js"/>
//x /// <reference path="Assert.js"/>
//x /// <reference path="Base.js" />
//x /// <reference path="Json.js" />
//x /// <reference path="UniqueId.js" />
//x /// <reference path="HashMap.js" />

//* <FileBegin path="../Include/Tools/UniqueId.js"/>

var UniqueId = { // ../Include/Tools/UniqueId.js: 2
    _uid: {}, // ../Include/Tools/UniqueId.js: 3
    Next: function(label) { // ../Include/Tools/UniqueId.js: 4
//x         /// <summary>Generate next in sequence of a unique number or label</summary>
//x         /// <param name="label">Sequence name</param>
//x         /// <returns>Number (String when sequence name given)</returns>
//x         /// label = UniqueId.Next('SequenceName');
//x         /// number = UniqueId.Next();  
        var k = ((label == void 0) ? '__uid__' : label); // ../Include/Tools/UniqueId.js: 10
        var v; // ../Include/Tools/UniqueId.js: 11
        if (UniqueId._uid[k] === void 0) // ../Include/Tools/UniqueId.js: 12
            v = UniqueId._uid[k] = 1; // ../Include/Tools/UniqueId.js: 13
        else v = ++UniqueId._uid[k]; // ../Include/Tools/UniqueId.js: 14
        return ((label == void 0) ? v : (label + v)); // ../Include/Tools/UniqueId.js: 15
    }, // ../Include/Tools/UniqueId.js: 16
    Reset: function(label) { // ../Include/Tools/UniqueId.js: 17
//x         /// <summary>Reset sequence counter for a unique numbers or label to zero</summary>
//x         /// <param name="label">Sequence name</param>
//x         /// <returns>Number last used (String last used when sequence name given)</returns>
//x         /// lastUsedLabel = UniqueId.Reset('SequenceName');
//x         /// lastUsedNumber = UniqueId.Reset();  
        var k = ((label == void 0) ? '__uid__' : label); // ../Include/Tools/UniqueId.js: 23
        var v = UniqueId._uid[k] || 0; // ../Include/Tools/UniqueId.js: 24
        UniqueId._uid[k] = 0; // ../Include/Tools/UniqueId.js: 25
        return ((label == void 0) ? v : (label + v)); // ../Include/Tools/UniqueId.js: 26
    } // ../Include/Tools/UniqueId.js: 27
}; // ../Include/Tools/UniqueId.js: 28


//* <FileEnd path="../Include/Tools/UniqueId.js"/>


// AjaxRequest
// ==========================================================================

/** @constructor */ // ../Include/Tools/AjaxRequest.js: 10
function AjaxRequest(url, options) { // ../Include/Tools/AjaxRequest.js: 11
//x /// <summary>
//x ///    Ajax request handling for (IE + Firefox ?) browsers
//x /// </summary>
//x /// <param name="url" type="String">
//x /// </param> 
//x /// <param name="options" type="Object">
//x ///     { [method : GET|POST|HEAD], [parameters : ?], [asynchronous : true|false] }
//x /// </param> 

//(ignore)//     Assert.NonNull('AjaxRequest', url, 'url'); // ../Include/Tools/AjaxRequest.js: 21
    this.url = url; // ../Include/Tools/AjaxRequest.js: 22

    var o = options || {}; // ../Include/Tools/AjaxRequest.js: 24
    this.options = o; // ../Include/Tools/AjaxRequest.js: 25
    this.method = o.method ? o.method.toUpperCase() : 'GET'; // ../Include/Tools/AjaxRequest.js: 26
//(ignore)//     Assert.Match('AjaxRequest', this.method, 'options.method', /^GET$|^POST$|^HEAD$/, 'GET, POST, or HEAD'); // ../Include/Tools/AjaxRequest.js: 27

    //this.asynchronous = !!this.options.asynchronous || false;
    this.asynchronous = !!o.asynchronous; // ../Include/Tools/AjaxRequest.js: 30
    this.contentType = o.contentType || 'application/x-www-form-urlencoded'; // ../Include/Tools/AjaxRequest.js: 31
    this.parameters = HashMap.Extend({}, (o.parameters || {})); // ../Include/Tools/AjaxRequest.js: 32
    if (o.forceGet) // ../Include/Tools/AjaxRequest.js: 33
        this.parameters['_'] = new Date().getTime(); // ../Include/Tools/AjaxRequest.js: 34

    this.id = UniqueId.Next('AjaxRequest'); // ../Include/Tools/AjaxRequest.js: 36
    this.queryParams = AjaxRequest.$CreateQueryString(this.parameters); // ../Include/Tools/AjaxRequest.js: 37
    // when GET, append parameters to URL
    if (this.method != 'POST' && this.queryParams.length > 0) { // ../Include/Tools/AjaxRequest.js: 39
        this.url += ((this.url.indexOf('?') >= 0) ? '&' : '?') + this.queryParams; // ../Include/Tools/AjaxRequest.js: 40
    } // ../Include/Tools/AjaxRequest.js: 41
    // else if (/Konqueror|Safari|KHTML/.test(navigator.userAgent)) params += '&_=';
    this.body = (this.method == 'POST') ? this.queryParams : null; // ../Include/Tools/AjaxRequest.js: 43

    this.request = null; // ../Include/Tools/AjaxRequest.js: 45
    this.aborted = false; // ../Include/Tools/AjaxRequest.js: 46
    this.$completed = false; // ../Include/Tools/AjaxRequest.js: 47

    if (window.XMLHttpRequest) // ../Include/Tools/AjaxRequest.js: 49
        this.request = new XMLHttpRequest(); // ../Include/Tools/AjaxRequest.js: 50
    else if (window['ActiveXObject'] && !(this.request = new ActiveXObject("Msxml2.XMLHTTP"))) // ../Include/Tools/AjaxRequest.js: 51
        this.request = new ActiveXObject("Microsoft.XMLHTTP"); // ../Include/Tools/AjaxRequest.js: 52
    if (!this.request) // ../Include/Tools/AjaxRequest.js: 53
        throw new Error('AjaxRequest, no transport');    // ../Include/Tools/AjaxRequest.js: 54
        
    this.$DoRequest(); // ../Include/Tools/AjaxRequest.js: 56
} // ../Include/Tools/AjaxRequest.js: 57

AjaxRequest.PingUrl = function(url, options) { // ../Include/Tools/AjaxRequest.js: 59
//x /// <summary>
//x ///      Uses AjaxRequest to test HTTP status code
//x /// </summary>
//x /// <param name="url" type="String">
//x /// </param>
//x /// <param name="options" type="Object">
//x ///     { [method : GET|POST|HEAD], [parameters : ?], [asynchronous : true|false] }
//x /// </param> 
//x /// <returns type="Boolean"/>
    var o = options || {}; // ../Include/Tools/AjaxRequest.js: 69
    o.method = 'HEAD'; // ../Include/Tools/AjaxRequest.js: 70
    o.asynchronous = false; // ../Include/Tools/AjaxRequest.js: 71
    return new AjaxRequest(url, o).Success(); // ../Include/Tools/AjaxRequest.js: 72
} // ../Include/Tools/AjaxRequest.js: 73

AjaxRequest.Load = function(url, options) { // ../Include/Tools/AjaxRequest.js: 75
//x /// <summary>
//x ///     Alternate constructor for synchronous AjaxRequest
//x /// </summary>
//x /// <param name="url" type="String">
//x /// </param>
//x /// <param name="options" type="Object">
//x /// </param>
//x /// <returns type="AjaxRequest"/>
    var o = options || {}; // ../Include/Tools/AjaxRequest.js: 84
    o.asynchronous = false; // ../Include/Tools/AjaxRequest.js: 85
    return new AjaxRequest(url, o); // ../Include/Tools/AjaxRequest.js: 86
} // ../Include/Tools/AjaxRequest.js: 87

AjaxRequest.LoadText = function(url, options) { // ../Include/Tools/AjaxRequest.js: 89
//x /// <summary>
//x ///    Uses AjaxRequest to return response content at url
//x /// </summary>
//x /// <param name="url" type="String">
//x /// </param>
//x /// <param name="options" type="Object">
//x ///     { [method : GET|POST|HEAD], [parameters : ?], [asynchronous : true|false] }
//x /// </param> 
//x /// <returns type="String"/>
    return AjaxRequest.Load(url, options).GetResponseText(); // ../Include/Tools/AjaxRequest.js: 99
} // ../Include/Tools/AjaxRequest.js: 100

AjaxRequest.LoadXml = function(url, options) { // ../Include/Tools/AjaxRequest.js: 102
//x /// <summary>
//x ///    Uses AjaxRequest to return response xml content at url
//x /// </summary>
//x /// <param name="url" type="String">
//x /// </param>
//x /// <param name="options" type="Object">
//x ///     { [method : GET|POST|HEAD], [parameters : ?], [asynchronous : true|false] }
//x /// </param> 
//x /// <returns type="Object"/>
    return AjaxRequest.Load(url, options).GetResponseXML(); // ../Include/Tools/AjaxRequest.js: 112
} // ../Include/Tools/AjaxRequest.js: 113

AjaxRequest.LoadJson = function(url, options) { // ../Include/Tools/AjaxRequest.js: 115
//x /// <summary>
//x ///    Uses AjaxRequest to return an object from JSON content at url
//x /// </summary>
//x /// <param name="url" type="String">
//x /// </param>
//x /// <param name="options" type="Object">
//x ///     { [method : GET|POST|HEAD], [parameters : ?], [asynchronous : true|false] }
//x /// </param>
//x /// <returns type="Object"/>
    var json = AjaxRequest.Load(url, options).GetResponseText(); // ../Include/Tools/AjaxRequest.js: 125
    return Json.DecodeObject(json); // ../Include/Tools/AjaxRequest.js: 126
} // ../Include/Tools/AjaxRequest.js: 127


AjaxRequest.States = [ // ../Include/Tools/AjaxRequest.js: 130
    'Unsent',          // 0 
    'Opened',          // 1
    'HeadersReceived', // 2 
    'Loading',         // 3
    'Done'             // 4
]; // ../Include/Tools/AjaxRequest.js: 136

AjaxRequest.Nop = function() { } // maybe someone can explain why this is needed

AjaxRequest.$CreateQueryString = function(params) { // ../Include/Tools/AjaxRequest.js: 140
    if (params == void 0) // ../Include/Tools/AjaxRequest.js: 141
        params = {}; // ../Include/Tools/AjaxRequest.js: 142
    var a = []; // ../Include/Tools/AjaxRequest.js: 143
    for (var key in params) { // ../Include/Tools/AjaxRequest.js: 144
        var value = params[key]; // ../Include/Tools/AjaxRequest.js: 145
        a.push((value == void 0) ? key : key + '=' + encodeURIComponent(String(value))); // ../Include/Tools/AjaxRequest.js: 146
    } // ../Include/Tools/AjaxRequest.js: 147
    return a.join('&'); // ../Include/Tools/AjaxRequest.js: 148
} // ../Include/Tools/AjaxRequest.js: 149

AjaxRequest.prototype.$OnReadyStateChange = function() { // ../Include/Tools/AjaxRequest.js: 151
    if (this.$completed) { // ../Include/Tools/AjaxRequest.js: 152
        return; // ../Include/Tools/AjaxRequest.js: 153
    } // ../Include/Tools/AjaxRequest.js: 154

    var rs = this.request.readyState; // ../Include/Tools/AjaxRequest.js: 156
    var state = AjaxRequest.States[rs]; // ../Include/Tools/AjaxRequest.js: 157

    if (rs == 4) { // ../Include/Tools/AjaxRequest.js: 159
        this.$completed = true; // ../Include/Tools/AjaxRequest.js: 160
    } // ../Include/Tools/AjaxRequest.js: 161

    try { // ../Include/Tools/AjaxRequest.js: 163
        var onState = this.options['On' + state]; // ../Include/Tools/AjaxRequest.js: 164
        if (onState) // ../Include/Tools/AjaxRequest.js: 165
            onState(this); // ../Include/Tools/AjaxRequest.js: 166
    } // ../Include/Tools/AjaxRequest.js: 167
    catch (e) { // ../Include/Tools/AjaxRequest.js: 168
        if (this.options.OnException) // ../Include/Tools/AjaxRequest.js: 169
            this.options.OnException(this, e); // ../Include/Tools/AjaxRequest.js: 170
        else // ../Include/Tools/AjaxRequest.js: 171
            Fail('AjaxRequest.$OnReadyStateChange', e); // ../Include/Tools/AjaxRequest.js: 172
    } // ../Include/Tools/AjaxRequest.js: 173

    if (this.$completed) { // ../Include/Tools/AjaxRequest.js: 175
        // avoid memory leak (IE)
        this.request.onreadystatechange = function() { }; // ../Include/Tools/AjaxRequest.js: 177

        try { // ../Include/Tools/AjaxRequest.js: 179
            var onCompleted = this.options['On' + (this.Success() ? 'Success' : 'Failure')]; // ../Include/Tools/AjaxRequest.js: 180
            if (onCompleted) // ../Include/Tools/AjaxRequest.js: 181
                onCompleted(this); // ../Include/Tools/AjaxRequest.js: 182
        } // ../Include/Tools/AjaxRequest.js: 183
        catch (e) { // ../Include/Tools/AjaxRequest.js: 184
            if (this.options.OnException) { // ../Include/Tools/AjaxRequest.js: 185
                this.options.OnException(this, e); // ../Include/Tools/AjaxRequest.js: 186
            } // ../Include/Tools/AjaxRequest.js: 187
            else { // ../Include/Tools/AjaxRequest.js: 188
                Fail('AjaxRequest.$OnReadyStateChange', 'IE memory leak code', e); // ../Include/Tools/AjaxRequest.js: 189
            } // ../Include/Tools/AjaxRequest.js: 190
        } // ../Include/Tools/AjaxRequest.js: 191
    } // ../Include/Tools/AjaxRequest.js: 192
} // ../Include/Tools/AjaxRequest.js: 193

AjaxRequest.prototype.$DoRequest = function() { // ../Include/Tools/AjaxRequest.js: 195
    try { // ../Include/Tools/AjaxRequest.js: 196
        var myself = this; // ../Include/Tools/AjaxRequest.js: 197
        this.request.onreadystatechange = function() { myself.$OnReadyStateChange(); } // ../Include/Tools/AjaxRequest.js: 198
        this.request.open(this.method, this.url, this.asynchronous); // ../Include/Tools/AjaxRequest.js: 199
        this.$SetHeaders(); // ../Include/Tools/AjaxRequest.js: 200
        this.request.send(this.body); // ../Include/Tools/AjaxRequest.js: 201
        if (!this.asynchronous) myself.$OnReadyStateChange(); // Force ready state 4 for synchronous requests
    } // ../Include/Tools/AjaxRequest.js: 203
    catch (e) { // ../Include/Tools/AjaxRequest.js: 204
        if (this.options.OnException) { // ../Include/Tools/AjaxRequest.js: 205
            this.options.OnException(this, e); // ../Include/Tools/AjaxRequest.js: 206
        } // ../Include/Tools/AjaxRequest.js: 207
        else { // ../Include/Tools/AjaxRequest.js: 208
            Fail('AjaxRequest.$DoRequest', e); // ../Include/Tools/AjaxRequest.js: 209
        } // ../Include/Tools/AjaxRequest.js: 210
    } // ../Include/Tools/AjaxRequest.js: 211
} // ../Include/Tools/AjaxRequest.js: 212

AjaxRequest.prototype.$SetHeaders = function() { // ../Include/Tools/AjaxRequest.js: 214
    var header = { // ../Include/Tools/AjaxRequest.js: 215
        'Accept': 'text/plain, text/javascript, text/html, text/xml, application/xml, */*' // ../Include/Tools/AjaxRequest.js: 216
    }; // ../Include/Tools/AjaxRequest.js: 217

    if (this.method == 'POST') { // ../Include/Tools/AjaxRequest.js: 219
        if (!!this.contentType) // ../Include/Tools/AjaxRequest.js: 220
            header['Content-type'] = this.contentType + '; charset=UTF-8'; // ../Include/Tools/AjaxRequest.js: 221

        // Force "Connection: close" for older Mozilla browsers to work around a bug where 
        // XMLHttpRequest sends an incorrect Content-length header. See Mozilla Bugzilla #246651.
        if (this.request.overrideMimeType && (navigator.userAgent.match(/Gecko\/(\d{4})/) || [0, 2005])[1] < 2005) // ../Include/Tools/AjaxRequest.js: 225
            header['Connection'] = 'close'; // ../Include/Tools/AjaxRequest.js: 226
    } // ../Include/Tools/AjaxRequest.js: 227

    if (!!this.options.header) { // ../Include/Tools/AjaxRequest.js: 229
        for (var m in this.options.header) { // ../Include/Tools/AjaxRequest.js: 230
            header[m] = this.options.header[m]; // ../Include/Tools/AjaxRequest.js: 231
        } // ../Include/Tools/AjaxRequest.js: 232
    } // ../Include/Tools/AjaxRequest.js: 233
    for (var m in header) { // ../Include/Tools/AjaxRequest.js: 234
        this.request.setRequestHeader(m, header[m]); // ../Include/Tools/AjaxRequest.js: 235
    } // ../Include/Tools/AjaxRequest.js: 236
} // ../Include/Tools/AjaxRequest.js: 237

AjaxRequest.prototype.Abort = function() { // ../Include/Tools/AjaxRequest.js: 239
    if (!this.$completed) { // ../Include/Tools/AjaxRequest.js: 240
        this.request.abort(); // ../Include/Tools/AjaxRequest.js: 241
    }  // ../Include/Tools/AjaxRequest.js: 242
} // ../Include/Tools/AjaxRequest.js: 243

AjaxRequest.prototype.Success = function() { // ../Include/Tools/AjaxRequest.js: 245
    var s = this.GetStatus(); // ../Include/Tools/AjaxRequest.js: 246
    return (!s || (s >= 200 && s < 300)); // ../Include/Tools/AjaxRequest.js: 247
} // ../Include/Tools/AjaxRequest.js: 248

AjaxRequest.prototype.GetStatus = function() { // ../Include/Tools/AjaxRequest.js: 250
    try { // ../Include/Tools/AjaxRequest.js: 251
        return this.request.status || 0; // ../Include/Tools/AjaxRequest.js: 252
    } // ../Include/Tools/AjaxRequest.js: 253
    catch (e) { // ../Include/Tools/AjaxRequest.js: 254
        return 0;  // ../Include/Tools/AjaxRequest.js: 255
    } // ../Include/Tools/AjaxRequest.js: 256
} // ../Include/Tools/AjaxRequest.js: 257

AjaxRequest.prototype.GetResponseHeader = function(name) { // ../Include/Tools/AjaxRequest.js: 259
    try { // ../Include/Tools/AjaxRequest.js: 260
        return this.request.getResponseHeader(name) || null; // ../Include/Tools/AjaxRequest.js: 261
    } // ../Include/Tools/AjaxRequest.js: 262
    catch (e) { // ../Include/Tools/AjaxRequest.js: 263
        return null; // ../Include/Tools/AjaxRequest.js: 264
    } // ../Include/Tools/AjaxRequest.js: 265
} // ../Include/Tools/AjaxRequest.js: 266

AjaxRequest.prototype.GetResponseText = function() { // ../Include/Tools/AjaxRequest.js: 268
    return (this.Success() ? this.request.responseText : null);  // ../Include/Tools/AjaxRequest.js: 269
} // ../Include/Tools/AjaxRequest.js: 270

AjaxRequest.prototype.GetResponseXML = function() { // ../Include/Tools/AjaxRequest.js: 272
    return (this.Success() ? this.request.responseXML : null);  // ../Include/Tools/AjaxRequest.js: 273
} // ../Include/Tools/AjaxRequest.js: 274

/* Rolled into each call above for Fail()
AjaxRequest.prototype.$OnException = function(e) {
  if (this.options.OnException)
    this.options.OnException(this, e);
  else
    Fail('', e);
}
*/ // ../Include/Tools/AjaxRequest.js: 283

//* <FileEnd path="../Include/Tools/AjaxRequest.js"/>


//* <FileBegin path="../Include/Common/ConfigDefaults.js"/>
//TODO: Matyi: Seems deprecated
/*
var ConfigDefaults = {
    'SmartHelp': {
        'HelpKey': 'F9',
        'ContentMap': []
    }
};
*/ // ../Include/Common/ConfigDefaults.js: 9

//* <FileEnd path="../Include/Common/ConfigDefaults.js"/>


//* <FileBegin path="../Include/Common/ApplicationData.js"/>
var ApplicationData =  // ../Include/Common/ApplicationData.js: 1
//// <if xconfig="Ignore"/>
    {} // ../Include/Common/ApplicationData.js: 3
//// <end/>
//// <reference path="../../../../../Release/HINT/applicationdata.json"/>
; // ../Include/Common/ApplicationData.js: 6

//* <FileEnd path="../Include/Common/ApplicationData.js"/>


//* <FileBegin path="../Include/Common/UpkMeta.js"/>
//x /// <reference path="../Tools/Base.js"/>
//x /// <reference path="../Tools/Array.js" />
//x /// <reference path="../Tools/Url.js" />
//x /// <reference path="../Tools/String.js" />
//x /// <reference path="../Tools/Dom.js" />
//x /// <reference path="../Tools/WindowUtils.js" />
//x /// <reference path="../Tools/RawQuery.js" />
//x /// <reference path="ApplicationInfo.js" />

//* <FileBegin path="../Include/Tools/Array.js"/>
//<!--Version 1-->

function ArrayPad(a, obj, count) { // ../Include/Tools/Array.js: 3
    while (a.length < count) // ../Include/Tools/Array.js: 4
        a.push(obj); // ../Include/Tools/Array.js: 5
    return a; // ../Include/Tools/Array.js: 6
} // ../Include/Tools/Array.js: 7

function ArrayClone(obj) { // ../Include/Tools/Array.js: 9
    return [].concat(obj); // ../Include/Tools/Array.js: 10
} // ../Include/Tools/Array.js: 11

function ArrayIndexOf(a, item, i) { // ../Include/Tools/Array.js: 13
    i = i || 0; // ../Include/Tools/Array.js: 14
    var l = a.length; // ../Include/Tools/Array.js: 15
    if (i < 0) i = l + i; // ../Include/Tools/Array.js: 16
    for (; i < l; i++) if (a[i] == item) return i; // ../Include/Tools/Array.js: 17
    return -1; // ../Include/Tools/Array.js: 18
} // ../Include/Tools/Array.js: 19
//* <FileEnd path="../Include/Tools/Array.js"/>


//* <FileBegin path="../Include/Tools/Url.js"/>
//x /// <reference path="Assert.js"/>

var Url = { // ../Include/Tools/Url.js: 3
    AddParameters: function(url, params) { // ../Include/Tools/Url.js: 4
        var a = []; // ../Include/Tools/Url.js: 5
        for (var key in params) { // ../Include/Tools/Url.js: 6
            var value = params[key]; // ../Include/Tools/Url.js: 7
            a.push(encodeURIComponent(key) + ((value == void 0) ? '' : '=' + encodeURIComponent(String(value)))); // ../Include/Tools/Url.js: 8
        } // ../Include/Tools/Url.js: 9
        if(!a.length) // ../Include/Tools/Url.js: 10
            return url; // ../Include/Tools/Url.js: 11
        return '' + url + (/\?/.test(url) ? '&' : '?') + a.join('&'); // ../Include/Tools/Url.js: 12
    }, // ../Include/Tools/Url.js: 13
    DecodeLocationSearch: function (searchStr, caseInsensitive) { // ../Include/Tools/Url.js: 14
//(ignore)//         Assert.NonNull('Url.DecodeLocationSearch', searchStr, 'searchStr'); // ../Include/Tools/Url.js: 15
        if (searchStr.length == 0) // ../Include/Tools/Url.js: 16
            return {}; // ../Include/Tools/Url.js: 17
        return Url.DecodeQuery(searchStr.substring(1), caseInsensitive); // ../Include/Tools/Url.js: 18
    }, // ../Include/Tools/Url.js: 19
    DecodeLocationSearchTokens: function (searchStr) { // ../Include/Tools/Url.js: 20
//(ignore)//         Assert.NonNull('Url.DecodeLocationSearchTokens', searchStr, 'searchStr'); // ../Include/Tools/Url.js: 21
        if (searchStr.length == 0) // ../Include/Tools/Url.js: 22
            return []; // ../Include/Tools/Url.js: 23
        return Url.DecodeQueryTokens(searchStr.substring(1)); // ../Include/Tools/Url.js: 24
    }, // ../Include/Tools/Url.js: 25
    DecodeQuery: function (queryStr, caseInsensitive) { // ../Include/Tools/Url.js: 26
//(ignore)//         Assert.NonNull('Url.DecodeQuery', queryStr, 'queryStr'); // ../Include/Tools/Url.js: 27
        var query = {}; // ../Include/Tools/Url.js: 28
        var tokens = queryStr.split('&'); // ../Include/Tools/Url.js: 29
        var name; // ../Include/Tools/Url.js: 30
        for (var i = 0, n = tokens.length; i < n; ++i) { // ../Include/Tools/Url.js: 31
            var token = tokens[i]; // ../Include/Tools/Url.js: 32
            var eqPos = token.indexOf('='); // ../Include/Tools/Url.js: 33
            if (eqPos == -1) { // ../Include/Tools/Url.js: 34
                name = decodeURIComponent(token); // ../Include/Tools/Url.js: 35
                query[caseInsensitive ? name.toLowerCase() : name] = ''; // ../Include/Tools/Url.js: 36
            } // ../Include/Tools/Url.js: 37
            else { // ../Include/Tools/Url.js: 38
                name = decodeURIComponent(token.substr(0, eqPos)); // ../Include/Tools/Url.js: 39
                query[caseInsensitive ? name.toLowerCase() : name] = decodeURIComponent(token.substr(eqPos + 1)); // ../Include/Tools/Url.js: 40
            } // ../Include/Tools/Url.js: 41
        } // ../Include/Tools/Url.js: 42
        return query; // ../Include/Tools/Url.js: 43
    }, // ../Include/Tools/Url.js: 44
    DecodeQueryTokens: function (queryStr) { // ../Include/Tools/Url.js: 45
//(ignore)//         Assert.NonNull('Url.DecodeQueryTokens', queryStr, 'queryStr'); // ../Include/Tools/Url.js: 46
        var tokens = queryStr.split('&'); // ../Include/Tools/Url.js: 47
        for (var i = 0, n = tokens.length; i < n; ++i) // ../Include/Tools/Url.js: 48
            tokens[i] = decodeURIComponent(tokens[i]); // ../Include/Tools/Url.js: 49
        return tokens; // ../Include/Tools/Url.js: 50
    }, // ../Include/Tools/Url.js: 51
    ReplaceLocationHash: function (location, hash) { // ../Include/Tools/Url.js: 52
        var href = location.href; // ../Include/Tools/Url.js: 53
        return (href.substr(0, href.length - location.hash.length) + '#n'); // ../Include/Tools/Url.js: 54
    }, // ../Include/Tools/Url.js: 55
    //#app=XX?query, location.hash = #app=XX?query, location.search = ''
    GetSearchQuery: function (win) { // ../Include/Tools/Url.js: 57
        var query = {}; // ../Include/Tools/Url.js: 58
        if (win && win.location) { // ../Include/Tools/Url.js: 59
            var hash = win.location.hash; // ../Include/Tools/Url.js: 60
            if (hash && hash.indexOf('#app=') == 0) { // ../Include/Tools/Url.js: 61
                var s = hash.split('?'); // ../Include/Tools/Url.js: 62
                if (s.length > 1) { // == 2
                    //copy application's own hash
                    //#app=XX?query#hash
                    var ss = s[1].split('#'); // ../Include/Tools/Url.js: 66
                    if (ss.length > 1) { // == 2
                        query = '?' + ss[0] + '&' + s[0].substr(1) + '#' + ss[1]; // ../Include/Tools/Url.js: 68
                    } // ../Include/Tools/Url.js: 69
                    else { // ../Include/Tools/Url.js: 70
                        query = '?' + s[1] + '&' + s[0].substr(1); // ../Include/Tools/Url.js: 71
                    } // ../Include/Tools/Url.js: 72
                } // ../Include/Tools/Url.js: 73
            } // ../Include/Tools/Url.js: 74
            else { // ../Include/Tools/Url.js: 75
                query = win.location.search; // ../Include/Tools/Url.js: 76
            } // ../Include/Tools/Url.js: 77
        } // ../Include/Tools/Url.js: 78
        return query; // ../Include/Tools/Url.js: 79
    } // ../Include/Tools/Url.js: 80
}; // ../Include/Tools/Url.js: 81


//* <FileEnd path="../Include/Tools/Url.js"/>


//* <FileBegin path="../Include/Tools/String.js"/>

function Trim(str) { // ../Include/Tools/String.js: 2
    return str.replace(/^\s+|\s+$/g, ''); // ../Include/Tools/String.js: 3
} // ../Include/Tools/String.js: 4

function FindSubString(sPattern, sString, sEnd) { // ../Include/Tools/String.js: 6
    var sResult = ''; // ../Include/Tools/String.js: 7
    if (sString.length == 0 || sPattern.length == 0) // ../Include/Tools/String.js: 8
        return sResult; // ../Include/Tools/String.js: 9

    sString.toLowerCase(); // ../Include/Tools/String.js: 11
    sPattern.toLowerCase(); // ../Include/Tools/String.js: 12

    var l = sString.length; // ../Include/Tools/String.js: 14
    var ll = sPattern.length; // ../Include/Tools/String.js: 15

    var i = sString.indexOf(sPattern); // ../Include/Tools/String.js: 17
    var j = 0; // ../Include/Tools/String.js: 18

    if (i != -1) { // ../Include/Tools/String.js: 20
        if (sEnd.length > 0) { // ../Include/Tools/String.js: 21
            sEnd.toLowerCase(); // ../Include/Tools/String.js: 22
            j = sString.indexOf(sEnd, i); // ../Include/Tools/String.js: 23
            if (j == -1) // ../Include/Tools/String.js: 24
                j = l; // ../Include/Tools/String.js: 25
        } // ../Include/Tools/String.js: 26
        else { // ../Include/Tools/String.js: 27
            j = l; // ../Include/Tools/String.js: 28
        } // ../Include/Tools/String.js: 29

        if (j != -1) { // ../Include/Tools/String.js: 31
            sResult = sString.substr(i + ll, j - i - ll); // ../Include/Tools/String.js: 32
        } // ../Include/Tools/String.js: 33
    } // ../Include/Tools/String.js: 34
    sResult.toUpperCase(); // ../Include/Tools/String.js: 35

    return sResult; // ../Include/Tools/String.js: 37
} // ../Include/Tools/String.js: 38
 
//* <FileEnd path="../Include/Tools/String.js"/>


//* <FileBegin path="../Include/Tools/Dom.js"/>
//x /// <reference path="Base.js" />
//x /// <reference path="Main.js" />
//x /// <reference path="Browser.js" />
//x /// <reference path="Time.js" />
//x /// <reference path="HashMap.js" />

//* <FileBegin path="../Include/Tools/Time.js"/>

var Time = { // ../Include/Tools/Time.js: 2
    GetCurrent: function() { // ../Include/Tools/Time.js: 3
        return new Date().getTime(); // ../Include/Tools/Time.js: 4
    }, // ../Include/Tools/Time.js: 5
    GetElapsedMs: function(startTime) { // ../Include/Tools/Time.js: 6
        return (new Date().getTime() - startTime); // ../Include/Tools/Time.js: 7
    } // ../Include/Tools/Time.js: 8
}; // ../Include/Tools/Time.js: 9

//* <FileEnd path="../Include/Tools/Time.js"/>


function GetElementsByTagName(win, tag) { // ../Include/Tools/Dom.js: 7
    var retValue = win.document.getElementsByTagName(tag); // ../Include/Tools/Dom.js: 8
    return retValue; // ../Include/Tools/Dom.js: 9
} // ../Include/Tools/Dom.js: 10

function GetElementsByAttribute(win, attr, value) { // ../Include/Tools/Dom.js: 12
    var ret = []; // ../Include/Tools/Dom.js: 13
//(ignore)//     Assert('GetElementsByAttribute', attr != 'class', "attr != 'class'"); // ../Include/Tools/Dom.js: 14
//(ignore)//     Assert('GetElementsByAttribute', attr != 'className', "attr != 'className'"); // ../Include/Tools/Dom.js: 15
    var all = win.document.getElementsByTagName('*'); //all
    for (var j = 0, jlength = all.length; j < jlength; j++) { // ../Include/Tools/Dom.js: 17

        if (all[j].getAttribute(attr) == value) // ../Include/Tools/Dom.js: 19
            ret.push(all[j]); // ../Include/Tools/Dom.js: 20
    } // ../Include/Tools/Dom.js: 21
    return ret; // ../Include/Tools/Dom.js: 22
} // ../Include/Tools/Dom.js: 23

function GetComments(win) { // ../Include/Tools/Dom.js: 25
    var coll = []; // ../Include/Tools/Dom.js: 26
    var doc = win.document; // ../Include/Tools/Dom.js: 27
    _GetElementsByNodeType(doc, coll, 8); // ../Include/Tools/Dom.js: 28
    return coll; // ../Include/Tools/Dom.js: 29
} // ../Include/Tools/Dom.js: 30

function _GetElementsByNodeType(node, coll, type) { // ../Include/Tools/Dom.js: 32
    //Gkod.Trace.Write(Gkod.Trace.ID.ODUT, "[ODUTILITY] : Gkod.Utility.Dom._GetElementsByNodeType() type=" + type + " node = " + node.nodeName + " [" + node.nodeValue + "][" + node.nodeType + "]", 3); 
    if (node.nodeType == type) { // ../Include/Tools/Dom.js: 34
        coll.push(node); // ../Include/Tools/Dom.js: 35
    } // ../Include/Tools/Dom.js: 36
    if (node.hasChildNodes()) { // ../Include/Tools/Dom.js: 37
        var children = node.childNodes; // ../Include/Tools/Dom.js: 38
        for (var i = 0, ilength = children.length; i < ilength; i++) { // ../Include/Tools/Dom.js: 39
            _GetElementsByNodeType(children[i], coll, type); // ../Include/Tools/Dom.js: 40
        } // ../Include/Tools/Dom.js: 41
    } // ../Include/Tools/Dom.js: 42
} // ../Include/Tools/Dom.js: 43

function MatchStyleSheetNames(win, styles, match, fullmatch) { // ../Include/Tools/Dom.js: 45
    try { // ../Include/Tools/Dom.js: 46
        var _fullmatch = IsBoolean(fullmatch) ? fullmatch : true; //default is true
        var styleelements = GetElementsByTagName(win, "link"); // ../Include/Tools/Dom.js: 48
        var _match = 0; // ../Include/Tools/Dom.js: 49
        for (var i = 0, ilength = styleelements.length; i < ilength; i++) { // ../Include/Tools/Dom.js: 50
            var _text = styleelements[i].href; // ../Include/Tools/Dom.js: 51
            if (_text != '') { // ../Include/Tools/Dom.js: 52
                var _regexp = new RegExp('.*[/|\\\\]([^/|\\\\]*)\\.[css|jsp]'); // ../Include/Tools/Dom.js: 53
                var _result = _text.match(_regexp); // ../Include/Tools/Dom.js: 54
                if (_result != null && _result.length > 1) { // ../Include/Tools/Dom.js: 55
                    if (_result[1] != null && _result[1].length > 0) { // ../Include/Tools/Dom.js: 56
                        //Gkod.Trace.Write(Gkod.Trace.ID.ODUT, "[ODUTILITY] : Gkod.Utility.Dom._MatchStyleSheetNames() style = " + _result[1] + " " + (fullmatch ? " full" : " partial"), 3);
                        for (var j = 0, jlength = styles.length; j < jlength; j++) { // ../Include/Tools/Dom.js: 58
                            if (!_fullmatch) { // ../Include/Tools/Dom.js: 59
                                var k = _result[1].indexOf(styles[j]); // ../Include/Tools/Dom.js: 60
                                if (k > -1) { // ../Include/Tools/Dom.js: 61
                                    _match++; // ../Include/Tools/Dom.js: 62
                                } // ../Include/Tools/Dom.js: 63
                            } // ../Include/Tools/Dom.js: 64
                            else { // ../Include/Tools/Dom.js: 65
                                if (_result[1] == styles[j]) { // ../Include/Tools/Dom.js: 66
                                    _match++; // ../Include/Tools/Dom.js: 67
                                } // ../Include/Tools/Dom.js: 68
                            } // ../Include/Tools/Dom.js: 69
                        } // ../Include/Tools/Dom.js: 70
                    } // ../Include/Tools/Dom.js: 71
                } // ../Include/Tools/Dom.js: 72
            } // ../Include/Tools/Dom.js: 73
        } // ../Include/Tools/Dom.js: 74
        if (_match >= match) { // ../Include/Tools/Dom.js: 75
            return true; // ../Include/Tools/Dom.js: 76
        } // ../Include/Tools/Dom.js: 77
    } catch (e) { // ../Include/Tools/Dom.js: 78
        //Gkod.Utility.OnError('[ERROR] : Error in calling Gkod.Utility.Dom.MatchStyleSheetNames()', e);
        throw (e); // ../Include/Tools/Dom.js: 80
    } // ../Include/Tools/Dom.js: 81
    return false;     // ../Include/Tools/Dom.js: 82
} // ../Include/Tools/Dom.js: 83

function MatchScriptNames(win, scripts, match, fullmatch) { // ../Include/Tools/Dom.js: 85
//x     //: <if xconfig="Debug,Trace"/>
//x     var startTime = Time.GetCurrent();
//x     Trace('MatchScriptNames');
//x     //: <end/>
    try { // ../Include/Tools/Dom.js: 90
        var _fullmatch = IsBoolean(fullmatch) ? fullmatch : true; //default is true
        var scriptelements = GetElementsByTagName(win, "script"); // ../Include/Tools/Dom.js: 92
        var _match = 0; // ../Include/Tools/Dom.js: 93
        for (var i = 0, ilength = scriptelements.length; i < ilength; i++) { // ../Include/Tools/Dom.js: 94
            var _text = scriptelements[i].src; // ../Include/Tools/Dom.js: 95
            if (_text != '') { // ../Include/Tools/Dom.js: 96
                var _regexp = new RegExp('.*[/|\\\\]([^/|\\\\]*)\\.js'); // ../Include/Tools/Dom.js: 97
                var _result = _text.match(_regexp); // ../Include/Tools/Dom.js: 98
                if (_result != null && _result.length > 1) { // ../Include/Tools/Dom.js: 99
                    if (_result[1] != null && _result[1].length > 0) { // ../Include/Tools/Dom.js: 100
                        //Gkod.Trace.Write(Gkod.Trace.ID.ODUT, "[ODUTILITY] : Gkod.Utility.Dom.MatchScriptNames() script = " + _result[1] + " " + (fullmatch ? " full" : " partial"), 3);
                        for (var j = 0, jlength = scripts.length; j < jlength; j++) { // ../Include/Tools/Dom.js: 102
                            if (!_fullmatch) { // ../Include/Tools/Dom.js: 103
                                var k = _result[1].indexOf(scripts[j]); // ../Include/Tools/Dom.js: 104
                                if (k > -1) { // ../Include/Tools/Dom.js: 105
                                    _match++; // ../Include/Tools/Dom.js: 106
                                } // ../Include/Tools/Dom.js: 107
                            } // ../Include/Tools/Dom.js: 108
                            else { // ../Include/Tools/Dom.js: 109
                                if (_result[1] == scripts[j]) { // ../Include/Tools/Dom.js: 110
                                    _match++; // ../Include/Tools/Dom.js: 111
                                } // ../Include/Tools/Dom.js: 112
                            } // ../Include/Tools/Dom.js: 113
                        } // ../Include/Tools/Dom.js: 114
                    } // ../Include/Tools/Dom.js: 115
                } // ../Include/Tools/Dom.js: 116
            } // ../Include/Tools/Dom.js: 117
        } // ../Include/Tools/Dom.js: 118

        if (_match >= match) { // ../Include/Tools/Dom.js: 120
//(ignore)//             Trace('MatchScriptNames: true, time=' + Time.GetElapsedMs(startTime)); // ../Include/Tools/Dom.js: 121
            return true; // ../Include/Tools/Dom.js: 122
        } // ../Include/Tools/Dom.js: 123
    } catch (e) { // ../Include/Tools/Dom.js: 124
        //Gkod.Utility.OnError('[ERROR] : Error in calling Gkod.Utility.Dom.MatchScriptNames()', e);
        throw (e); // ../Include/Tools/Dom.js: 126
    } // ../Include/Tools/Dom.js: 127
//(ignore)//     Trace('MatchScriptNames: false, time=' + Time.GetElapsedMs(startTime)); // ../Include/Tools/Dom.js: 128
    return false; // ../Include/Tools/Dom.js: 129
} // ../Include/Tools/Dom.js: 130

function MatchVariables(win, variables, match) { // ../Include/Tools/Dom.js: 132
    var _match = 0; // ../Include/Tools/Dom.js: 133
    for (var i = 0; i < variables.length; i++) { // ../Include/Tools/Dom.js: 134
        if (typeof (win[variables[i]]) != 'undefined') { // ../Include/Tools/Dom.js: 135
            _match++; // ../Include/Tools/Dom.js: 136
        } // ../Include/Tools/Dom.js: 137
    } // ../Include/Tools/Dom.js: 138

    if (_match >= match) { // ../Include/Tools/Dom.js: 140
        return true; // ../Include/Tools/Dom.js: 141
    } // ../Include/Tools/Dom.js: 142
    return false; // ../Include/Tools/Dom.js: 143
} // ../Include/Tools/Dom.js: 144

function MatchWindowNames(win, windownames) { // ../Include/Tools/Dom.js: 146
    for (var i = 0, ilength = windownames.length; i < ilength; i++) { // ../Include/Tools/Dom.js: 147
        //Gkod.Trace.Write(Gkod.Trace.ID.ODUT, "[ODUTILITY] : Gkod.Utility.Dom.MatchWindowNames() _window.name = " + _window.name, 3); 
        if (win.name.indexOf(windownames[i]) > -1) { // ../Include/Tools/Dom.js: 149
            return true; // ../Include/Tools/Dom.js: 150
        } // ../Include/Tools/Dom.js: 151
    } // ../Include/Tools/Dom.js: 152
    return false; // ../Include/Tools/Dom.js: 153
} // ../Include/Tools/Dom.js: 154

function MatchImageNames(win, images, match) { // ../Include/Tools/Dom.js: 156
    var imageelements = GetElementsByTagName(win, "img"); // ../Include/Tools/Dom.js: 157
    var _match = 0; // ../Include/Tools/Dom.js: 158
    for (var i = 0, ilength = imageelements.length; i < ilength; i++) { // ../Include/Tools/Dom.js: 159
        var _text = imageelements[i].src; // ../Include/Tools/Dom.js: 160
        //BHS: _text.substr(0, 5) != 'data:' is needed because of Issue-11723210
        if (_text != '' && _text.substr(0, 5) != 'data:') { // ../Include/Tools/Dom.js: 162
            var _regexp = new RegExp('.*[/|\\\\]([^/|\\\\]*)\\.gif'); // ../Include/Tools/Dom.js: 163
            var _result = _text.match(_regexp); // ../Include/Tools/Dom.js: 164
            if (_result != null && _result.length > 1) { // ../Include/Tools/Dom.js: 165
                if (_result[1] != null && _result[1].length > 0) { // ../Include/Tools/Dom.js: 166
                    //Gkod.Trace.Write(Gkod.Trace.ID.ODUT, "[ODUTILITY] : Gkod.Utility.Dom.MatchImageNames() image = " + _gkod_result[1], 3);
                    for (var j = 0, jlength = images.length; j < jlength; j++) { // ../Include/Tools/Dom.js: 168
                        //var k = _gkod_result[1].indexOf(_gkod_images_temp[j]);
                        //if (k > -1) 
                        if (_result[1] == images[j]) { // ../Include/Tools/Dom.js: 171
                            _match++; // ../Include/Tools/Dom.js: 172
                        } // ../Include/Tools/Dom.js: 173
                    } // ../Include/Tools/Dom.js: 174
                } // ../Include/Tools/Dom.js: 175
            } // ../Include/Tools/Dom.js: 176
        } // ../Include/Tools/Dom.js: 177
    } // ../Include/Tools/Dom.js: 178

    if (_match >= match) { // ../Include/Tools/Dom.js: 180
        return true; // ../Include/Tools/Dom.js: 181
    } // ../Include/Tools/Dom.js: 182
    return false; // ../Include/Tools/Dom.js: 183
} // ../Include/Tools/Dom.js: 184

function _MatchWindowNames(winArray, windownames, match) { // ../Include/Tools/Dom.js: 186
    var t = winArray; // ../Include/Tools/Dom.js: 187
    var _match = 0; // ../Include/Tools/Dom.js: 188
    if (typeof (t) == 'undefined' || t.length == 0) // ../Include/Tools/Dom.js: 189
        return false; // ../Include/Tools/Dom.js: 190

    for (var i = 0; i < t.length; i++) { // ../Include/Tools/Dom.js: 192
        for (var j = 0; j < windownames.length; j++) { // ../Include/Tools/Dom.js: 193
            if (typeof (t[i].name) == 'string' && t[i].name == windownames[j]) { // ../Include/Tools/Dom.js: 194
                _match++; // ../Include/Tools/Dom.js: 195
            } // ../Include/Tools/Dom.js: 196
        } // ../Include/Tools/Dom.js: 197
    } // ../Include/Tools/Dom.js: 198
    if (_match >= match) { // ../Include/Tools/Dom.js: 199
        return true; // ../Include/Tools/Dom.js: 200
    } // ../Include/Tools/Dom.js: 201
    return false; // ../Include/Tools/Dom.js: 202
} // ../Include/Tools/Dom.js: 203

//TODO: Matyi: Should not be used in recognition
function GetFrames(coll, win) { // ../Include/Tools/Dom.js: 206
    if ((typeof (coll)).toLowerCase() == 'object') { // ../Include/Tools/Dom.js: 207
        if ((typeof (win)).toLowerCase() == 'object') { // ../Include/Tools/Dom.js: 208
        
        } // ../Include/Tools/Dom.js: 210

        var _win = window.top; // ../Include/Tools/Dom.js: 212
        if (typeof (top) != 'undefined') { // ../Include/Tools/Dom.js: 213
            if (top == false) // ../Include/Tools/Dom.js: 214
                _win = win; // ../Include/Tools/Dom.js: 215
            if (top == true) // ../Include/Tools/Dom.js: 216
                _win = win.top; // ../Include/Tools/Dom.js: 217
        } // ../Include/Tools/Dom.js: 218
        GetSubFrames(coll, _win); // ../Include/Tools/Dom.js: 219
    } // ../Include/Tools/Dom.js: 220
} // ../Include/Tools/Dom.js: 221

function GetSubFrames(coll, win) { // ../Include/Tools/Dom.js: 223
    if ((typeof (coll)).toLowerCase() == 'object') { // ../Include/Tools/Dom.js: 224
        if ((typeof (win)).toLowerCase() == 'object') { // ../Include/Tools/Dom.js: 225
            coll.push(win); // ../Include/Tools/Dom.js: 226
            var l = win.length; // ../Include/Tools/Dom.js: 227
            for (var i = 0; i < l; i++) { // ../Include/Tools/Dom.js: 228
                GetSubFrames(coll, win.frames[i]); // ../Include/Tools/Dom.js: 229
            } // ../Include/Tools/Dom.js: 230
        } // ../Include/Tools/Dom.js: 231
    } // ../Include/Tools/Dom.js: 232
} // ../Include/Tools/Dom.js: 233

//This should work in IE, Firefox and Opera
function GetParentWindow(_document) { // ../Include/Tools/Dom.js: 236
    return _document.parentWindow ? _document.parentWindow : _document.defaultView; // ../Include/Tools/Dom.js: 237
} // ../Include/Tools/Dom.js: 238

function GetInnerText(_object) { // ../Include/Tools/Dom.js: 240
    return (_object.innerText) ? _object.innerText : (_object.textContent) ? _object.textContent : ""; // ../Include/Tools/Dom.js: 241
} // ../Include/Tools/Dom.js: 242

function IsHiddenFrame(_window) { // ../Include/Tools/Dom.js: 244
    var bhidden = false; // ../Include/Tools/Dom.js: 245
    var l = 0, r = 0, t = 0, b = 0; // ../Include/Tools/Dom.js: 246

    try { // ../Include/Tools/Dom.js: 248
        var pcanvas = null; // ../Include/Tools/Dom.js: 249
        var mode = _window.document.compatMode; // ../Include/Tools/Dom.js: 250
        if (mode == 'CSS1Compat') { // ../Include/Tools/Dom.js: 251
            pcanvas = _window.document.documentElement; // ../Include/Tools/Dom.js: 252
        } // ../Include/Tools/Dom.js: 253
        else { // ../Include/Tools/Dom.js: 254
            pcanvas = _window.document.body; // ../Include/Tools/Dom.js: 255
        } // ../Include/Tools/Dom.js: 256
        if (pcanvas != null) { // ../Include/Tools/Dom.js: 257
            //NA in FF
            //l = pcanvas.getBoundingClientRect().left;
            //r = pcanvas.getBoundingClientRect().right;
            //t = pcanvas.getBoundingClientRect().top;
            //b = pcanvas.getBoundingClientRect().bottom;

            l = pcanvas.offsetLeft; // ../Include/Tools/Dom.js: 264
            r = pcanvas.offsetLeft + pcanvas.offsetWidth; // ../Include/Tools/Dom.js: 265
            t = pcanvas.offsetTop; // ../Include/Tools/Dom.js: 266
            b = pcanvas.offsetTop + pcanvas.offsetHeight; // ../Include/Tools/Dom.js: 267
        } // ../Include/Tools/Dom.js: 268
    } // ../Include/Tools/Dom.js: 269
    catch (e) { // ../Include/Tools/Dom.js: 270
        bhidden = true; // ../Include/Tools/Dom.js: 271
    } // ../Include/Tools/Dom.js: 272

    if (r * b == 0) { // ../Include/Tools/Dom.js: 274
        bhidden = true; // ../Include/Tools/Dom.js: 275
    } // ../Include/Tools/Dom.js: 276
    //Gkod.Trace.Write(Gkod.Trace.ID.DEF, '[ODDEFS] : Gkod.Context.IsHiddenFrame() hidden=' + bhidden + ' window.name = [' + window.name + '] URL = [' + window.location.href + ']');
    return bhidden; // ../Include/Tools/Dom.js: 278
} // ../Include/Tools/Dom.js: 279

function GetPosition(cell) { // ../Include/Tools/Dom.js: 281
    var ret = 0; // ../Include/Tools/Dom.js: 282
    while (cell) { // ../Include/Tools/Dom.js: 283
        ret++; // ../Include/Tools/Dom.js: 284
        var temp = cell; // ../Include/Tools/Dom.js: 285
        temp = cell.previousSibling; // ../Include/Tools/Dom.js: 286
        cell = temp; // ../Include/Tools/Dom.js: 287
    } // ../Include/Tools/Dom.js: 288
    return ret; // ../Include/Tools/Dom.js: 289
} // ../Include/Tools/Dom.js: 290

function GetXthSiblingFromChild(pos, header) { // ../Include/Tools/Dom.js: 292
    //Gkod.Trace.Write(Gkod.Trace.ID.CTX, "Gkod.Application.Sapcrm07.GetXthSiblingFromChild() pos = " + pos + " header = " + header, 3);
    var ret = null; // ../Include/Tools/Dom.js: 294
    var i = 1; // ../Include/Tools/Dom.js: 295
    if (header) { // ../Include/Tools/Dom.js: 296
        var child = header.firstChild; // ../Include/Tools/Dom.js: 297
        if (child) // ../Include/Tools/Dom.js: 298
            ret = child; // ../Include/Tools/Dom.js: 299
        //Gkod.Trace.Write(Gkod.Trace.ID.CTX, "Gkod.Application.Sapcrm07.GetXthSiblingFromChild() child = " + child.tagName, 3);
        while (child && i < pos) { // ../Include/Tools/Dom.js: 301
            var temp = child.nextSibling; // ../Include/Tools/Dom.js: 302
            if (temp) { // ../Include/Tools/Dom.js: 303
                i++; // ../Include/Tools/Dom.js: 304
            } // ../Include/Tools/Dom.js: 305
            child = temp; // ../Include/Tools/Dom.js: 306
            if (child) // ../Include/Tools/Dom.js: 307
                ret = child; // ../Include/Tools/Dom.js: 308
        } // ../Include/Tools/Dom.js: 309
    } // ../Include/Tools/Dom.js: 310
    return ret; // ../Include/Tools/Dom.js: 311
} // ../Include/Tools/Dom.js: 312

// New DOM functions

/*
var it = document.createNodeIterator(document, NodeFilter.SHOW_COMMENT, null, false);
var nodes = [];
while ( (node = it.nextNode()) ) {
    nodes.push(node);
  }
*/ // ../Include/Tools/Dom.js: 322

var Dom = { // ../Include/Tools/Dom.js: 324
    CreateElement: function(doc, tagName, options) { // ../Include/Tools/Dom.js: 325
        var node = doc.createElement(tagName); // ../Include/Tools/Dom.js: 326
        for (i in options) { // ../Include/Tools/Dom.js: 327
            node[i] = options[i]; // ../Include/Tools/Dom.js: 328
        } // ../Include/Tools/Dom.js: 329
        return node; // ../Include/Tools/Dom.js: 330
    }, // ../Include/Tools/Dom.js: 331
    CreateElementWithName: function(doc, tagName, name) { // ../Include/Tools/Dom.js: 332
//x         //: <if xconfig="Browser.IE*"/>
//x         //: <if-not xconfig="Browser.IE9+"/>
//x         if (Browser.IsIE() && (doc['documentMode'] < 9)) {
//x             return doc.createElement('<' + tagName + ' name="' + name + '">');
//x         }
//x         //: <end/>
//x         //: <end/>
        var node = doc.createElement(tagName); // ../Include/Tools/Dom.js: 340
        node.name = name; // ../Include/Tools/Dom.js: 341
        return node; // ../Include/Tools/Dom.js: 342
    }, // ../Include/Tools/Dom.js: 343
    GetElementById: function(node, id) { // ../Include/Tools/Dom.js: 344
        return node.getElementById(id); // ../Include/Tools/Dom.js: 345
    }, // ../Include/Tools/Dom.js: 346
    GetElementsByTagName: function(node, tagName) { // ../Include/Tools/Dom.js: 347
        return node.getElementsByTagName(tagName); // ../Include/Tools/Dom.js: 348
    }, // ../Include/Tools/Dom.js: 349
    GetElementByTagAndClassName: function(node, tagName, className) { // ../Include/Tools/Dom.js: 350
        if (node.getElementsByClassName) { // ../Include/Tools/Dom.js: 351
            var anyTag = (tagName == '*'); // ../Include/Tools/Dom.js: 352
            var elements = node.getElementsByClassName(className); // ../Include/Tools/Dom.js: 353
            for (var i = 0, n = elements.length; i < n; ++i) { // ../Include/Tools/Dom.js: 354
                if (anyTag || (elements.item(i).tagName == tagName)) // ../Include/Tools/Dom.js: 355
                    return elements.item(i); // ../Include/Tools/Dom.js: 356
            } // ../Include/Tools/Dom.js: 357
        } // ../Include/Tools/Dom.js: 358
        else { // ../Include/Tools/Dom.js: 359
            var elements = node.getElementsByTagName(tagName); // ../Include/Tools/Dom.js: 360
            for (var i = 0, n = elements.length; i < n; ++i) { // ../Include/Tools/Dom.js: 361
                if (elements.item(i).className == className) // ../Include/Tools/Dom.js: 362
                    return elements.item(i); // ../Include/Tools/Dom.js: 363
            } // ../Include/Tools/Dom.js: 364
        } // ../Include/Tools/Dom.js: 365
        return null; // ../Include/Tools/Dom.js: 366
    }, // ../Include/Tools/Dom.js: 367
    IncludeScript: function(doc, src, onReady, timeoutMs) { // ../Include/Tools/Dom.js: 368
        var head = doc.getElementsByTagName('head')[0]; // ../Include/Tools/Dom.js: 369
        var script = doc.createElement('script'); // ../Include/Tools/Dom.js: 370
        script.setAttribute('type', 'text/javascript'); // ../Include/Tools/Dom.js: 371
        script.setAttribute('src', src); // ../Include/Tools/Dom.js: 372
        if (onReady) { // ../Include/Tools/Dom.js: 373
            var completed = false; // ../Include/Tools/Dom.js: 374
            function OnCompleted(result) { // ../Include/Tools/Dom.js: 375
                if (!completed) { // ../Include/Tools/Dom.js: 376
                    completed = true; // ../Include/Tools/Dom.js: 377
                    setTimeout(function() { onReady(result); }, 100); // ../Include/Tools/Dom.js: 378
                } // ../Include/Tools/Dom.js: 379
            } // ../Include/Tools/Dom.js: 380
            function OnSuccess() { // ../Include/Tools/Dom.js: 381
                OnCompleted(true); // ../Include/Tools/Dom.js: 382
            } // ../Include/Tools/Dom.js: 383
            function OnFailed() { // ../Include/Tools/Dom.js: 384
                OnCompleted(false); // ../Include/Tools/Dom.js: 385
            } // ../Include/Tools/Dom.js: 386
            if (Browser.IsIE()) { // ../Include/Tools/Dom.js: 387
                script.onreadystatechange = function() { // ../Include/Tools/Dom.js: 388
                    var readyState = script.readyState; // ../Include/Tools/Dom.js: 389
                    if (readyState == 'complete' || readyState == 'loaded') // ../Include/Tools/Dom.js: 390
                        OnSuccess(); // ../Include/Tools/Dom.js: 391
                } // ../Include/Tools/Dom.js: 392
            } // ../Include/Tools/Dom.js: 393
            else script.onload = OnSuccess; // ../Include/Tools/Dom.js: 394
            if (timeoutMs) // ../Include/Tools/Dom.js: 395
                setTimeout(OnFailed, timeoutMs); // ../Include/Tools/Dom.js: 396
        } // ../Include/Tools/Dom.js: 397
        head.appendChild(script); // ../Include/Tools/Dom.js: 398
    }, // ../Include/Tools/Dom.js: 399
    MatchElementsAttribute: function(node, tagName, attributeName, values, requiredCount) { // ../Include/Tools/Dom.js: 400
//x         //: <if xconfig="Debug,Trace"/>
//x         var startTime = Time.GetCurrent();
//x         Trace('MatchElementsAttribute: tagName=' + tagName + ', attributeName=' + attributeName);
//x         //: <end/>
        var hash = HashMap.FromArray(values, true); // ../Include/Tools/Dom.js: 405
        var matchHash = {}; // ../Include/Tools/Dom.js: 406
        var matchCount = 0; // ../Include/Tools/Dom.js: 407
        var elements = node.getElementsByTagName(tagName); // ../Include/Tools/Dom.js: 408
        for (var i = 0, n = elements.length; i < n; ++i) { // ../Include/Tools/Dom.js: 409
            var value = elements.item(i).getAttribute(attributeName); // ../Include/Tools/Dom.js: 410
            if (hash[value] && !matchHash[value]) { // ../Include/Tools/Dom.js: 411
                matchHash[value] = true; // ../Include/Tools/Dom.js: 412
                ++matchCount; // ../Include/Tools/Dom.js: 413
                if (matchCount >= requiredCount) { // ../Include/Tools/Dom.js: 414
//(ignore)//                     Trace('MatchElementsAttribute: true, time=' + Time.GetElapsedMs(startTime)); // ../Include/Tools/Dom.js: 415
                    return true; // ../Include/Tools/Dom.js: 416
                } // ../Include/Tools/Dom.js: 417
            } // ../Include/Tools/Dom.js: 418
        } // ../Include/Tools/Dom.js: 419
//(ignore)//         Trace('MatchElementsAttribute: false, time=' + Time.GetElapsedMs(startTime)); // ../Include/Tools/Dom.js: 420
        return false; // ../Include/Tools/Dom.js: 421
    }, // ../Include/Tools/Dom.js: 422
    MatchElementsMember: function(node, tagName, memberName, values, requiredCount) { // ../Include/Tools/Dom.js: 423
//x         //: <if xconfig="Debug,Trace"/>
//x         var startTime = Time.GetCurrent();
//x         Trace('MatchElementsMember: tagName=' + tagName + ', memberName=' + memberName);
//x         //: <end/>
        var hash = HashMap.FromArray(values, true); // ../Include/Tools/Dom.js: 428
        var matchHash = {}; // ../Include/Tools/Dom.js: 429
        var matchCount = 0; // ../Include/Tools/Dom.js: 430
        var elements = node.getElementsByTagName(tagName); // ../Include/Tools/Dom.js: 431
        for (var i = 0, n = elements.length; i < n; ++i) { // ../Include/Tools/Dom.js: 432
            var value = elements.item(i)[memberName]; // ../Include/Tools/Dom.js: 433
            if (hash[value] && !matchHash[value]) { // ../Include/Tools/Dom.js: 434
                matchHash[value] = true; // ../Include/Tools/Dom.js: 435
                ++matchCount; // ../Include/Tools/Dom.js: 436
                if (matchCount >= requiredCount) { // ../Include/Tools/Dom.js: 437
//(ignore)//                     Trace('MatchElementsMember: true, time=' + Time.GetElapsedMs(startTime)); // ../Include/Tools/Dom.js: 438
                    return true; // ../Include/Tools/Dom.js: 439
                } // ../Include/Tools/Dom.js: 440
            } // ../Include/Tools/Dom.js: 441
        } // ../Include/Tools/Dom.js: 442
//(ignore)//         Trace('MatchElementsMember: false, time=' + Time.GetElapsedMs(startTime)); // ../Include/Tools/Dom.js: 443
        return false; // ../Include/Tools/Dom.js: 444
    }, // ../Include/Tools/Dom.js: 445
    MatchElementsName: function(node, tagName, values, requiredCount) { // ../Include/Tools/Dom.js: 446
        return Dom.MatchElementsMember(node, tagName, 'name', values, requiredCount); // ../Include/Tools/Dom.js: 447
    }, // ../Include/Tools/Dom.js: 448
    MatchElementsId: function(node, tagName, values, requiredCount) { // ../Include/Tools/Dom.js: 449
        return Dom.MatchElementsMember(node, tagName, 'id', values, requiredCount); // ../Include/Tools/Dom.js: 450
    }, // ../Include/Tools/Dom.js: 451
    MatchElementsClassName: function(node, tagName, values, requiredCount) { // ../Include/Tools/Dom.js: 452
        return Dom.MatchElementsMember(node, tagName, 'className', values, requiredCount); // ../Include/Tools/Dom.js: 453
    } // ../Include/Tools/Dom.js: 454
}; // ../Include/Tools/Dom.js: 455

//* <FileEnd path="../Include/Tools/Dom.js"/>


//* <FileBegin path="../Include/Tools/WindowUtils.js"/>
//x /// <reference path="Base.js"/>
//x /// <reference path="Browser.js"/>
//x /// <reference path="Events.js"/>
//x /// <reference path="Cookie.js"/>

//* <FileBegin path="../Include/Tools/Events.js"/>

function AddListener(element, type, callback) { // ../Include/Tools/Events.js: 2
    if (element.addEventListener) // ../Include/Tools/Events.js: 3
        element.addEventListener(type, callback, false); // ../Include/Tools/Events.js: 4
    else element['attachEvent']('on' + type, callback); // ../Include/Tools/Events.js: 5
} // ../Include/Tools/Events.js: 6

function PreventDefault(event) { // ../Include/Tools/Events.js: 8
    if (event.preventDefault)  // ../Include/Tools/Events.js: 9
        event.preventDefault(); // ../Include/Tools/Events.js: 10
    else event['returnValue'] = false; // ../Include/Tools/Events.js: 11
} // ../Include/Tools/Events.js: 12

function StopPropagation(event) { // ../Include/Tools/Events.js: 14
    if (event.stopPropagation)  // ../Include/Tools/Events.js: 15
        event.stopPropagation(); // ../Include/Tools/Events.js: 16
    else event['cancelBubble'] = true; // ../Include/Tools/Events.js: 17
} // ../Include/Tools/Events.js: 18

function CancelEvent(event) { // ../Include/Tools/Events.js: 20
    StopPropagation(event); // ../Include/Tools/Events.js: 21
    PreventDefault(event); // ../Include/Tools/Events.js: 22
} // ../Include/Tools/Events.js: 23

function GetEventTarget(event) { // ../Include/Tools/Events.js: 25
    return event.target || event['srcElement']; // ../Include/Tools/Events.js: 26
} // ../Include/Tools/Events.js: 27
//* <FileEnd path="../Include/Tools/Events.js"/>


//* <FileBegin path="../Include/Tools/Cookie.js"/>
//x /// <reference path="Trace.js"/>

var _Cookie = { // ../Include/Tools/Cookie.js: 3
    Create: function(name, evalue, keepDays, path, domain, secure) { // ../Include/Tools/Cookie.js: 4
        var ename = encodeURIComponent(name); // ../Include/Tools/Cookie.js: 5
        var cookie = ename + '=' + evalue; // ../Include/Tools/Cookie.js: 6
        if (keepDays >= -1) { // ../Include/Tools/Cookie.js: 7
            var time = new Date().getTime(); // ../Include/Tools/Cookie.js: 8
            var millisecondsSinceMidnight = time % 86400000; // ../Include/Tools/Cookie.js: 9
            var expires = new Date(time - millisecondsSinceMidnight + 86400000 * (keepDays + 1)); // ../Include/Tools/Cookie.js: 10
            cookie += "; expires=" + expires.toGMTString(); // ../Include/Tools/Cookie.js: 11
        } // ../Include/Tools/Cookie.js: 12
        if (path) // ../Include/Tools/Cookie.js: 13
            cookie += "; path=" + path; // ../Include/Tools/Cookie.js: 14
        if (domain) // ../Include/Tools/Cookie.js: 15
            cookie += "; domain=" + domain; // ../Include/Tools/Cookie.js: 16
        if (secure) // ../Include/Tools/Cookie.js: 17
            cookie += "; secure"; // ../Include/Tools/Cookie.js: 18
//(ignore)//         Trace('_Cookie.Create', cookie); // ../Include/Tools/Cookie.js: 19
        return cookie; // ../Include/Tools/Cookie.js: 20
    }, // ../Include/Tools/Cookie.js: 21
    TryGet: function(cookie, name) { // ../Include/Tools/Cookie.js: 22
        var ename = encodeURIComponent(name); // ../Include/Tools/Cookie.js: 23
        var nameValueList = cookie.split('; '); // ../Include/Tools/Cookie.js: 24
        for (var i = 0, n = nameValueList.length; i < n; ++i) { // ../Include/Tools/Cookie.js: 25
            var nameValue = nameValueList[i]; // ../Include/Tools/Cookie.js: 26
            if (nameValue == ename) // ../Include/Tools/Cookie.js: 27
                return ''; // ../Include/Tools/Cookie.js: 28
            var eqPos = nameValue.indexOf('='); // ../Include/Tools/Cookie.js: 29
            if ((eqPos > 0) && (eqPos == ename.length) && (nameValue.substr(0, eqPos) == ename)) // ../Include/Tools/Cookie.js: 30
                return nameValue.substr(eqPos + 1); // ../Include/Tools/Cookie.js: 31
        } // ../Include/Tools/Cookie.js: 32
        return null; // ../Include/Tools/Cookie.js: 33
    } // ../Include/Tools/Cookie.js: 34
}; // ../Include/Tools/Cookie.js: 35

var Cookie = { // ../Include/Tools/Cookie.js: 37
    EncodeHash: function(hash) { // ../Include/Tools/Cookie.js: 38
        if (!hash) // ../Include/Tools/Cookie.js: 39
            return ''; // ../Include/Tools/Cookie.js: 40
        var tokens = []; // ../Include/Tools/Cookie.js: 41
        for (var key in hash) // ../Include/Tools/Cookie.js: 42
            tokens.push(encodeURIComponent(key) + ':' + encodeURIComponent(hash[key])); // ../Include/Tools/Cookie.js: 43
        return tokens.join('&'); // ../Include/Tools/Cookie.js: 44
    }, // ../Include/Tools/Cookie.js: 45
    DecodeHash: function(value) { // ../Include/Tools/Cookie.js: 46
        var hash = {}; // ../Include/Tools/Cookie.js: 47
        if (value) { // ../Include/Tools/Cookie.js: 48
            var tokens = value.split('&'); // ../Include/Tools/Cookie.js: 49
            for (var i = 0, n = tokens.length; i < n; ++i) { // ../Include/Tools/Cookie.js: 50
                var keyValue = tokens[i].split(':'); // ../Include/Tools/Cookie.js: 51
                hash[decodeURIComponent(keyValue[0])] = ((keyValue.length == 2) ? decodeURIComponent(keyValue[1]) : ''); // ../Include/Tools/Cookie.js: 52
            } // ../Include/Tools/Cookie.js: 53
        } // ../Include/Tools/Cookie.js: 54
        return hash; // ../Include/Tools/Cookie.js: 55
    }, // ../Include/Tools/Cookie.js: 56
    CreateFromEncoded: function(name, evalue, keepDays, path, domain, secure) { // ../Include/Tools/Cookie.js: 57
        return _Cookie.Create(name, evalue, keepDays, path, domain, secure); // ../Include/Tools/Cookie.js: 58
    }, // ../Include/Tools/Cookie.js: 59
    CreateFromValue: function(name, value, keepDays, path, domain, secure) { // ../Include/Tools/Cookie.js: 60
        return _Cookie.Create(name, encodeURIComponent(value), keepDays, path, domain, secure); // ../Include/Tools/Cookie.js: 61
    }, // ../Include/Tools/Cookie.js: 62
    CreateFromHash: function(name, hash, keepDays, path, domain, secure) { // ../Include/Tools/Cookie.js: 63
        return _Cookie.Create(name, Cookie.EncodeHash(hash), keepDays, path, domain, secure); // ../Include/Tools/Cookie.js: 64
    }, // ../Include/Tools/Cookie.js: 65
    CreateExpired: function(name, path, domain) { // ../Include/Tools/Cookie.js: 66
        return _Cookie.Create(name, '', -1, path, domain); // ../Include/Tools/Cookie.js: 67
    }, // ../Include/Tools/Cookie.js: 68
    TryGetEncoded: function(cookie, name, defaultValue) { // ../Include/Tools/Cookie.js: 69
        var evalue = _Cookie.TryGet(cookie, name); // ../Include/Tools/Cookie.js: 70
        if (evalue == null) // ../Include/Tools/Cookie.js: 71
            return defaultValue; // ../Include/Tools/Cookie.js: 72
        return evalue; // ../Include/Tools/Cookie.js: 73
    }, // ../Include/Tools/Cookie.js: 74
    TryGetValue: function(cookie, name, defaultValue) { // ../Include/Tools/Cookie.js: 75
        var evalue = _Cookie.TryGet(cookie, name); // ../Include/Tools/Cookie.js: 76
        if (evalue == null) // ../Include/Tools/Cookie.js: 77
            return defaultValue; // ../Include/Tools/Cookie.js: 78
        return decodeURIComponent(evalue); // ../Include/Tools/Cookie.js: 79
    }, // ../Include/Tools/Cookie.js: 80
    TryGetHash: function(cookie, name, defaultValue) { // ../Include/Tools/Cookie.js: 81
        var evalue = _Cookie.TryGet(cookie, name); // ../Include/Tools/Cookie.js: 82
        if (evalue == null) // ../Include/Tools/Cookie.js: 83
            return defaultValue; // ../Include/Tools/Cookie.js: 84
        return Cookie.DecodeHash(evalue); // ../Include/Tools/Cookie.js: 85
    } // ../Include/Tools/Cookie.js: 86
} // ../Include/Tools/Cookie.js: 87

//* <FileEnd path="../Include/Tools/Cookie.js"/>


var WindowUtils = { // ../Include/Tools/WindowUtils.js: 6

    Unwrap: function(win) { // ../Include/Tools/WindowUtils.js: 8
//x         //:<if xconfig="SmartHelp"/>
//x         //:<if xconfig="Browser.FF*"/>
//x         if (Browser.IsFirefox()) {
//x             try {
//x                 if (window['XPCNativeWrapper'] && window['XPCNativeWrapper']['unwrap'])
//x                     win = window['XPCNativeWrapper']['unwrap'](win);
//x             }
//x             catch (xe) {
//x                 Trace('WindowUtils.Unwrap', 'XPCNativeWrapper.unwrap exception: ' + xe.message);
//x             }
//x         }
//x         //:<end/>
//x         //:<end/>
        return win; // ../Include/Tools/WindowUtils.js: 22
    }, // ../Include/Tools/WindowUtils.js: 23

    TryCall: function(win, name) { // ../Include/Tools/WindowUtils.js: 25
//(ignore)//         Assert.NonNull('WindowUtils.TryCall', win, 'win'); // ../Include/Tools/WindowUtils.js: 26
        win = WindowUtils.Unwrap(win); // ../Include/Tools/WindowUtils.js: 27
        try { // ../Include/Tools/WindowUtils.js: 28
            if (win[name]) // ../Include/Tools/WindowUtils.js: 29
                return win[name].call(win); // ../Include/Tools/WindowUtils.js: 30
        } // ../Include/Tools/WindowUtils.js: 31
        catch (xe) { // ../Include/Tools/WindowUtils.js: 32
//(ignore)//             Trace.Exception('WindowUtils.TryCall:' + name, xe); // ../Include/Tools/WindowUtils.js: 33
        } // ../Include/Tools/WindowUtils.js: 34
        return void 0; // ../Include/Tools/WindowUtils.js: 35
    }, // ../Include/Tools/WindowUtils.js: 36

    TryCallWithArguments: function(win, name, args) { // ../Include/Tools/WindowUtils.js: 38
        win = WindowUtils.Unwrap(win); // ../Include/Tools/WindowUtils.js: 39
        try { // ../Include/Tools/WindowUtils.js: 40
            if (win[name]) // ../Include/Tools/WindowUtils.js: 41
                return win[name].apply(win, args); // ../Include/Tools/WindowUtils.js: 42
        } // ../Include/Tools/WindowUtils.js: 43
        catch (xe) { // ../Include/Tools/WindowUtils.js: 44
//(ignore)//             Trace.Exception('WindowUtils.TryCallWithArguments:' + name, xe); // ../Include/Tools/WindowUtils.js: 45
        } // ../Include/Tools/WindowUtils.js: 46
        return void 0; // ../Include/Tools/WindowUtils.js: 47
    }, // ../Include/Tools/WindowUtils.js: 48

    TryGet: function(win, name) { // ../Include/Tools/WindowUtils.js: 50
//(ignore)//         Assert.NonNull('WindowUtils.TryGet', win, 'win'); // ../Include/Tools/WindowUtils.js: 51
        win = WindowUtils.Unwrap(win); // ../Include/Tools/WindowUtils.js: 52
        try { // ../Include/Tools/WindowUtils.js: 53
            return win[name]; // ../Include/Tools/WindowUtils.js: 54
        } // ../Include/Tools/WindowUtils.js: 55
        catch (xe) { // ../Include/Tools/WindowUtils.js: 56
//(ignore)//             Trace.Exception('WindowUtils.TryGet:' + name, xe); // ../Include/Tools/WindowUtils.js: 57
        } // ../Include/Tools/WindowUtils.js: 58
        return void 0; // ../Include/Tools/WindowUtils.js: 59
    }, // ../Include/Tools/WindowUtils.js: 60

    TryAccess: function(win) { // ../Include/Tools/WindowUtils.js: 62
        try { // ../Include/Tools/WindowUtils.js: 63
            return (win && win.location && win.location.href && 1); // ../Include/Tools/WindowUtils.js: 64
        } // ../Include/Tools/WindowUtils.js: 65
        catch (xe) { } // ../Include/Tools/WindowUtils.js: 66
        return 0; // ../Include/Tools/WindowUtils.js: 67
    }, // ../Include/Tools/WindowUtils.js: 68

    CloseWindow: function(win) { // ../Include/Tools/WindowUtils.js: 70
        // Make IE not to display the following message: 
        // The webpage you are viewing is trying to close the window.
        if (Browser.IsIE()) { // ../Include/Tools/WindowUtils.js: 73
            try { // ../Include/Tools/WindowUtils.js: 74
                win.open('', '_parent', ''); // ../Include/Tools/WindowUtils.js: 75
            } // ../Include/Tools/WindowUtils.js: 76
            catch (xe) { } // ../Include/Tools/WindowUtils.js: 77
        } // ../Include/Tools/WindowUtils.js: 78
        win.close(); // ../Include/Tools/WindowUtils.js: 79
    }, // ../Include/Tools/WindowUtils.js: 80

    OpenWindow: function(url, name, features) { // ../Include/Tools/WindowUtils.js: 82
        return window.open(url, name, features); // ../Include/Tools/WindowUtils.js: 83
    }, // ../Include/Tools/WindowUtils.js: 84

    Focus: function(win) { // ../Include/Tools/WindowUtils.js: 86
        win.focus(); // ../Include/Tools/WindowUtils.js: 87
    }, // ../Include/Tools/WindowUtils.js: 88

    GetOpener: function(win) { // ../Include/Tools/WindowUtils.js: 90
        try { // ../Include/Tools/WindowUtils.js: 91
            if (win.opener && WindowUtils.TryAccess(win.opener)) // ../Include/Tools/WindowUtils.js: 92
                return win.opener; // ../Include/Tools/WindowUtils.js: 93
        } // ../Include/Tools/WindowUtils.js: 94
        catch (xe) { // ../Include/Tools/WindowUtils.js: 95
        } // ../Include/Tools/WindowUtils.js: 96
    }, // ../Include/Tools/WindowUtils.js: 97

    HasParent: function(win) { // ../Include/Tools/WindowUtils.js: 99
        return (win.parent !== win); // ../Include/Tools/WindowUtils.js: 100
    } // ../Include/Tools/WindowUtils.js: 101

}; // ../Include/Tools/WindowUtils.js: 103

//* <FileEnd path="../Include/Tools/WindowUtils.js"/>


//* <FileBegin path="../Include/Tools/RawQuery.js"/>
//x /// <reference path="Assert.js"/>

var RawQuery = { // ../Include/Tools/RawQuery.js: 3
    DecodeLocationSearch: function(searchStr, lowercaseNames, valueDecoder) { // ../Include/Tools/RawQuery.js: 4
//(ignore)//         Assert.NonNull('RawQuery.DecodeLocationSearch', searchStr, 'searchStr'); // ../Include/Tools/RawQuery.js: 5
        if (searchStr.length == 0) // ../Include/Tools/RawQuery.js: 6
            return {}; // ../Include/Tools/RawQuery.js: 7
        return RawQuery.DecodeString(searchStr.substring(1), lowercaseNames, valueDecoder); // ../Include/Tools/RawQuery.js: 8
    }, // ../Include/Tools/RawQuery.js: 9
    DecodeString: function(queryStr, lowercaseNames, valueDecoder) { // ../Include/Tools/RawQuery.js: 10
//(ignore)//         Assert.NonNull('RawQuery.DecodeString', queryStr, 'queryStr'); // ../Include/Tools/RawQuery.js: 11
        var query = {}; // ../Include/Tools/RawQuery.js: 12
        if (queryStr.length > 0) { // ../Include/Tools/RawQuery.js: 13
            var tokens = queryStr.split('&'); // ../Include/Tools/RawQuery.js: 14
            var name; // ../Include/Tools/RawQuery.js: 15
            var value; // ../Include/Tools/RawQuery.js: 16
            for (var i = 0, n = tokens.length; i < n; ++i) { // ../Include/Tools/RawQuery.js: 17
                var token = tokens[i]; // ../Include/Tools/RawQuery.js: 18
                var eqPos = token.indexOf('='); // ../Include/Tools/RawQuery.js: 19
                if (eqPos == -1) { // ../Include/Tools/RawQuery.js: 20
                    name = decodeURIComponent(token); // ../Include/Tools/RawQuery.js: 21
                    value = ''; // ../Include/Tools/RawQuery.js: 22
                } // ../Include/Tools/RawQuery.js: 23
                else { // ../Include/Tools/RawQuery.js: 24
                    name = decodeURIComponent(token.substr(0, eqPos)); // ../Include/Tools/RawQuery.js: 25
                    value = token.substr(eqPos + 1); // ../Include/Tools/RawQuery.js: 26
                } // ../Include/Tools/RawQuery.js: 27
                if (lowercaseNames) // ../Include/Tools/RawQuery.js: 28
                    name = name.toLowerCase(); // ../Include/Tools/RawQuery.js: 29
                query[name] = (valueDecoder ? valueDecoder(value, name) : value); // ../Include/Tools/RawQuery.js: 30
            } // ../Include/Tools/RawQuery.js: 31
        } // ../Include/Tools/RawQuery.js: 32
        return query; // ../Include/Tools/RawQuery.js: 33
    } // ../Include/Tools/RawQuery.js: 34
}; // ../Include/Tools/RawQuery.js: 35

//* <FileEnd path="../Include/Tools/RawQuery.js"/>


//* <FileBegin path="../Include/Common/ApplicationInfo.js"/>

/** @constructor */ // ../Include/Common/ApplicationInfo.js: 2
function ApplicationInfo(name, nsName, version, language, rawContext, rawTags, enableSM) { // ../Include/Common/ApplicationInfo.js: 3
    if (!nsName) // ../Include/Common/ApplicationInfo.js: 4
        nsName = name; // ../Include/Common/ApplicationInfo.js: 5
    if (nsName && /~$/.test(nsName)) { // ../Include/Common/ApplicationInfo.js: 6
        enableSM = 1; // ../Include/Common/ApplicationInfo.js: 7
        nsName = nsName.replace(/~$/, ''); // ../Include/Common/ApplicationInfo.js: 8
    } // ../Include/Common/ApplicationInfo.js: 9
    this.Name = name; // ../Include/Common/ApplicationInfo.js: 10
    this.NsName = nsName; // ../Include/Common/ApplicationInfo.js: 11
    this.Version = version; // ../Include/Common/ApplicationInfo.js: 12
    this.Language = language; // ../Include/Common/ApplicationInfo.js: 13
    this.RawContext = rawContext; // ../Include/Common/ApplicationInfo.js: 14
    this.RawTags = rawTags; // ../Include/Common/ApplicationInfo.js: 15
    this.EnableSM = enableSM ? 1 : 0; // ../Include/Common/ApplicationInfo.js: 16
} // ../Include/Common/ApplicationInfo.js: 17

ApplicationInfo.ToObject = function(self) { // ../Include/Common/ApplicationInfo.js: 19
    return (self ? [self.Name, self.NsName, self.Version, self.Language, self.RawContext, self.RawTags, self.EnableSM] : null); // ../Include/Common/ApplicationInfo.js: 20
} // ../Include/Common/ApplicationInfo.js: 21

ApplicationInfo.FromObject = function(obj) { // ../Include/Common/ApplicationInfo.js: 23
    return (obj ? new ApplicationInfo(obj[0], obj[1], obj[2], obj[3], obj[4], obj[5], obj[6]) : null); // ../Include/Common/ApplicationInfo.js: 24
} // ../Include/Common/ApplicationInfo.js: 25

//* <FileEnd path="../Include/Common/ApplicationInfo.js"/>


var _UpkMeta = { // ../Include/Common/UpkMeta.js: 10
    ApplicationNameFromNsName: function(nsName) { // ../Include/Common/UpkMeta.js: 11
        if(!nsName) // ../Include/Common/UpkMeta.js: 12
            return nsName; // ../Include/Common/UpkMeta.js: 13
        nsName = nsName.replace(/~$/, ''); // ../Include/Common/UpkMeta.js: 14
        var dotPos = nsName.indexOf('.'); // ../Include/Common/UpkMeta.js: 15
        return ((dotPos != -1) ? nsName.substr(0, dotPos) : nsName); // ../Include/Common/UpkMeta.js: 16
    }, // ../Include/Common/UpkMeta.js: 17
    CreateInfo: function(ns, rawContext, rawTags) { // ../Include/Common/UpkMeta.js: 18
        var tokens = ArrayPad((ns == null) ? [''] : ns.split(';'), null, 3); // ../Include/Common/UpkMeta.js: 19

        // Parse application name
        var appNsName = Trim(tokens[0]).toUpperCase(); // ../Include/Common/UpkMeta.js: 22
        var enableSM = /~$/.test(appNsName); // ../Include/Common/UpkMeta.js: 23
        if (enableSM) // ../Include/Common/UpkMeta.js: 24
            appNsName = appNsName.replace(/~$/, ''); // ../Include/Common/UpkMeta.js: 25
        var appName = _UpkMeta.ApplicationNameFromNsName(appNsName); // ../Include/Common/UpkMeta.js: 26
        tokens.shift(); // ../Include/Common/UpkMeta.js: 27

        // Parse application version if present
        var version = (tokens[0] ? Trim(tokens[0]) : null); // ../Include/Common/UpkMeta.js: 30
        if (!version || /^[0-9@]/.test(version)) // ../Include/Common/UpkMeta.js: 31
            tokens.shift(); // ../Include/Common/UpkMeta.js: 32
        else version = null; // ../Include/Common/UpkMeta.js: 33

        // Parse application language
        var language = (tokens[0] ? Trim(tokens[0]).replace('_', '-').toLowerCase() : null); // ../Include/Common/UpkMeta.js: 36

        return new ApplicationInfo(appName, appNsName, version, language, (rawContext || null), (rawTags || null), enableSM); // ../Include/Common/UpkMeta.js: 38
    } // ../Include/Common/UpkMeta.js: 39
}; // ../Include/Common/UpkMeta.js: 40

var UpkMeta = { // ../Include/Common/UpkMeta.js: 42
    ApplicationNameFromNsName: function(nsName) { // ../Include/Common/UpkMeta.js: 43
        return _UpkMeta.ApplicationNameFromNsName(nsName); // ../Include/Common/UpkMeta.js: 44
    }, // ../Include/Common/UpkMeta.js: 45
    ApplicationInfoFromParams: function(params) { // ../Include/Common/UpkMeta.js: 46
        var ns = params['namespace']; // ../Include/Common/UpkMeta.js: 47
        var rawContext = params['context']; // ../Include/Common/UpkMeta.js: 48
        var rawTags = params['tags']; // ../Include/Common/UpkMeta.js: 49
        return (ns || rawContext || rawTags)? _UpkMeta.CreateInfo(ns, rawContext, rawTags): null; // ../Include/Common/UpkMeta.js: 50
    }, // ../Include/Common/UpkMeta.js: 51
    TokensFromWindow: function(win) { // ../Include/Common/UpkMeta.js: 52
//(ignore)//         Assert.NonNull('UpkMeta.TokensFromWindow', win, 'win'); // ../Include/Common/UpkMeta.js: 53
        var ns = null; // ../Include/Common/UpkMeta.js: 54
        var rawTags = null; // ../Include/Common/UpkMeta.js: 55
        var rawContext = null; // ../Include/Common/UpkMeta.js: 56
        try { // ../Include/Common/UpkMeta.js: 57
            var hasGetNamespace = !!WindowUtils.TryGet(win, 'UPK_GetNamespace'); // ../Include/Common/UpkMeta.js: 58
            var hasGetTags = !!WindowUtils.TryGet(win, 'UPK_GetTags'); // ../Include/Common/UpkMeta.js: 59
            var hasGetContext = !!WindowUtils.TryGet(win, 'UPK_GetContext'); // ../Include/Common/UpkMeta.js: 60

            function stringValidator(value) { // ../Include/Common/UpkMeta.js: 62
                if (value == null) // ../Include/Common/UpkMeta.js: 63
                    return null; // ../Include/Common/UpkMeta.js: 64
                return String(value); // ../Include/Common/UpkMeta.js: 65
            } // ../Include/Common/UpkMeta.js: 66

            ns = (hasGetNamespace && stringValidator(WindowUtils.TryCall(win, 'UPK_GetNamespace'))) || null; // ../Include/Common/UpkMeta.js: 68
            rawTags = (hasGetTags && stringValidator(WindowUtils.TryCall(win, 'UPK_GetTags'))) || null; // ../Include/Common/UpkMeta.js: 69

            if (!ns || !rawTags || !hasGetContext) { // ../Include/Common/UpkMeta.js: 71
                var doc = win.document; // ../Include/Common/UpkMeta.js: 72
                var metaElements = doc.getElementsByTagName('meta'); // ../Include/Common/UpkMeta.js: 73
                for (var i = 0, n = metaElements.length; i < n; ++i) { // ../Include/Common/UpkMeta.js: 74
                    var metaName = metaElements[i]['name']; // ../Include/Common/UpkMeta.js: 75
                    if (/^upk-/.test(metaName)) { // ../Include/Common/UpkMeta.js: 76
                        if (ns == null && metaName == 'upk-namespace') { // ../Include/Common/UpkMeta.js: 77
                            ns = metaElements[i]['content']; // ../Include/Common/UpkMeta.js: 78
                        } // ../Include/Common/UpkMeta.js: 79
                        else if (rawTags == null && metaName == 'upk-tags') { // ../Include/Common/UpkMeta.js: 80
                            rawTags = metaElements[i]['content']; // ../Include/Common/UpkMeta.js: 81
                        } // ../Include/Common/UpkMeta.js: 82
                        else if (rawContext == null && metaName == 'upk-context') { // ../Include/Common/UpkMeta.js: 83
                            rawContext = metaElements[i]['content']; // ../Include/Common/UpkMeta.js: 84
                        } // ../Include/Common/UpkMeta.js: 85
                    } // ../Include/Common/UpkMeta.js: 86
                } // ../Include/Common/UpkMeta.js: 87
            } // ../Include/Common/UpkMeta.js: 88
        } // ../Include/Common/UpkMeta.js: 89
        catch (xe) { // ../Include/Common/UpkMeta.js: 90
//(ignore)//             Trace.Exception('UpkMeta.TokensFromWindow', xe); // ../Include/Common/UpkMeta.js: 91
        } // ../Include/Common/UpkMeta.js: 92
        return ((ns || rawTags || rawContext) ? [ns, rawContext, rawTags] : null); // ../Include/Common/UpkMeta.js: 93
    }, // ../Include/Common/UpkMeta.js: 94
    ApplicationInfoFromWindow: function(win) { // ../Include/Common/UpkMeta.js: 95
        var tokens = UpkMeta.TokensFromWindow(win); // ../Include/Common/UpkMeta.js: 96
        if (!tokens) // ../Include/Common/UpkMeta.js: 97
            return null; // ../Include/Common/UpkMeta.js: 98
        return _UpkMeta.CreateInfo(tokens[0], tokens[1], tokens[2]); // ../Include/Common/UpkMeta.js: 99
    }, // ../Include/Common/UpkMeta.js: 100
    _DecodeDelimitedString: function(rawString) { // ../Include/Common/UpkMeta.js: 101
        var rawValues = rawString.split(';'); // ../Include/Common/UpkMeta.js: 102
        var values = []; // ../Include/Common/UpkMeta.js: 103
        for (var i = 0, n = rawValues.length; i < n; ++i) { // ../Include/Common/UpkMeta.js: 104
            var value = rawValues[i]; // ../Include/Common/UpkMeta.js: 105
            if (value) // ../Include/Common/UpkMeta.js: 106
                values.push(decodeURIComponent(value)); // ../Include/Common/UpkMeta.js: 107
        } // ../Include/Common/UpkMeta.js: 108
        return values; // ../Include/Common/UpkMeta.js: 109
    }, // ../Include/Common/UpkMeta.js: 110
    _DecodeAndSort: function(rawString) { // ../Include/Common/UpkMeta.js: 111
        var values = UpkMeta._DecodeDelimitedString(rawString); // ../Include/Common/UpkMeta.js: 112
        values.sort(); // ../Include/Common/UpkMeta.js: 113
        return values; // ../Include/Common/UpkMeta.js: 114
    }, // ../Include/Common/UpkMeta.js: 115
    DecodeContext: function(rawContext, enableMultiPart) { // ../Include/Common/UpkMeta.js: 116
//(ignore)//         Trace('UpkMeta.DecodeContext', 'rawContext=' + rawContext + ', enableMultiPart=' + enableMultiPart); // ../Include/Common/UpkMeta.js: 117
        if (rawContext == null) // ../Include/Common/UpkMeta.js: 118
            return null; // ../Include/Common/UpkMeta.js: 119
        if (!enableMultiPart) // ../Include/Common/UpkMeta.js: 120
            return decodeURIComponent(rawContext); // ../Include/Common/UpkMeta.js: 121
        return UpkMeta._DecodeAndSort(rawContext); // ../Include/Common/UpkMeta.js: 122
    }, // ../Include/Common/UpkMeta.js: 123
    DecodeTags: function(rawTags) { // ../Include/Common/UpkMeta.js: 124
        if (rawTags == null) // ../Include/Common/UpkMeta.js: 125
            return null; // ../Include/Common/UpkMeta.js: 126
        return UpkMeta._DecodeAndSort(rawTags); // ../Include/Common/UpkMeta.js: 127
    } // ../Include/Common/UpkMeta.js: 128
}; // ../Include/Common/UpkMeta.js: 129

//* <FileEnd path="../Include/Common/UpkMeta.js"/>


//TODO: Matyi: I don't like this reference to ApplicationMap, but this should remain for now.
//x /// <reference path="../Application/ApplicationMap.js"/>

//* <FileBegin path="../Include/Application/ApplicationMap.js"/>
//x /// <reference path="../Tools/Base.js"/>
//x /// <reference path="ApplicationBase.js"/>

//* <FileBegin path="../Include/Application/ApplicationBase.js"/>
//x /// <reference path="../Tools/Base.js"/>
//x /// <reference path="../Common/EcidSearch.js" xconfig="Playback"/>
//x /// <reference path="../Common/ContextPart.js"/>
//x /// <reference path="../Common/SearchExpression.js" xconfig="Playback"/>
//x /// <reference path="../Common/SearchExpressionBuilder.js" xconfig="Playback"/>
//x /// <reference path="../Common/ContextType.js"/>
//x /// <reference path="../Common/PartDescriptor.js"/>
//x /// <reference path="../Common/UpkMeta.js"/>
//x /// <reference path="../Common/ApplicationFeature.js"/>
//x /// <reference path="ApplicationContext.js"/>
//x /// <reference path="ApplicationType.js"/>

//* <FileBegin path="../Include/Common/ContextPart.js"/>
//x /// <reference path="../Tools/Base.js"/>

var ContextPart = { // ../Include/Common/ContextPart.js: 3
    CreateValue: function(name, caption, useNameAsPrefix, searchable, multiPart) { // ../Include/Common/ContextPart.js: 4
        return [name, caption, ((useNameAsPrefix == void 0) ? true : useNameAsPrefix), ((searchable == void 0) ? true : searchable), ((multiPart == void 0) ? false : multiPart)]; // ../Include/Common/ContextPart.js: 5
    }, // ../Include/Common/ContextPart.js: 6
    CreateMeta: function(name) { // ../Include/Common/ContextPart.js: 7
        return ['MC.' + name, name, false, false, false]; // ../Include/Common/ContextPart.js: 8
    }, // ../Include/Common/ContextPart.js: 9
    HasMultipleParts: function(contextPart) { // ../Include/Common/ContextPart.js: 10
        return !!contextPart[4]; // ../Include/Common/ContextPart.js: 11
    } // ../Include/Common/ContextPart.js: 12
}; // ../Include/Common/ContextPart.js: 13

//* <FileEnd path="../Include/Common/ContextPart.js"/>


//* <FileBegin path="../Include/Common/ContextType.js"/>

var ContextType = { // ../Include/Common/ContextType.js: 2
    NoContext: 0, // ../Include/Common/ContextType.js: 3
    Absolute: 1, // ../Include/Common/ContextType.js: 4
    TopRelative: 2, // ../Include/Common/ContextType.js: 5
    SmartMatch: 3, // ../Include/Common/ContextType.js: 6
    Hybrid: 4 // ../Include/Common/ContextType.js: 7
}; // ../Include/Common/ContextType.js: 8

//* <FileEnd path="../Include/Common/ContextType.js"/>


//* <FileBegin path="../Include/Common/PartDescriptor.js"/>

/** @constructor */ // ../Include/Common/PartDescriptor.js: 2
function PartDescriptor(name, caption, useNameAsPrefix, searchable, multiPart) { // ../Include/Common/PartDescriptor.js: 3
    this.Name = name; // ../Include/Common/PartDescriptor.js: 4
    this.Caption = caption; // ../Include/Common/PartDescriptor.js: 5
    this.UseNameAsPrefix = useNameAsPrefix; // ../Include/Common/PartDescriptor.js: 6
    this.Searchable = searchable; // ../Include/Common/PartDescriptor.js: 7
    this.MultiPart = multiPart; // ../Include/Common/PartDescriptor.js: 8
} // ../Include/Common/PartDescriptor.js: 9

PartDescriptor.Create = function(part) { // ../Include/Common/PartDescriptor.js: 11
    return new PartDescriptor(part[0], part[1], part[2], part[3], part[4]); // ../Include/Common/PartDescriptor.js: 12
} // ../Include/Common/PartDescriptor.js: 13

//* <FileEnd path="../Include/Common/PartDescriptor.js"/>


//* <FileBegin path="../Include/Common/ApplicationFeature.js"/>

var ApplicationFeature = { // ../Include/Common/ApplicationFeature.js: 2
    ExactMatch: 'X', // ../Include/Common/ApplicationFeature.js: 3
    SmartMatch: 'S' // ../Include/Common/ApplicationFeature.js: 4
}; // ../Include/Common/ApplicationFeature.js: 5

//* <FileEnd path="../Include/Common/ApplicationFeature.js"/>


//* <FileBegin path="../Include/Application/ApplicationContext.js"/>
//x /// <reference path="../Tools/Base.js"/>
//x /// <reference path="../Tools/Json.js"/>
//x /// <reference path="../Tools/Html.js"/>
//x /// <reference path="../Common/ContextType.js"/>

//* <FileBegin path="../Include/Tools/Html.js"/>

var Html = { // ../Include/Tools/Html.js: 2
    Escape: function(str) { // ../Include/Tools/Html.js: 3
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); // ../Include/Tools/Html.js: 4
    }, // ../Include/Tools/Html.js: 5
    EscapeAttribute: function(str) { // ../Include/Tools/Html.js: 6
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); // ../Include/Tools/Html.js: 7
    }, // ../Include/Tools/Html.js: 8
    Unescape: function(str) { // ../Include/Tools/Html.js: 9
        return String(str).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'); // ../Include/Tools/Html.js: 10
    }, // ../Include/Tools/Html.js: 11
    DecodeEntities: function(str) { // ../Include/Tools/Html.js: 12
        var element = document.createElement('div'); // ../Include/Tools/Html.js: 13
        element.innerHTML = String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;'); // ../Include/Tools/Html.js: 14
        return element.firstChild.nodeValue; // ../Include/Tools/Html.js: 15
    } // ../Include/Tools/Html.js: 16
}; // ../Include/Tools/Html.js: 17

//* <FileEnd path="../Include/Tools/Html.js"/>


var ApplicationContextFormat = { // ../Include/Application/ApplicationContext.js: 6
    JsObject: 0, // ../Include/Application/ApplicationContext.js: 7
    JsonString: 1, // ../Include/Application/ApplicationContext.js: 8
    XmlString: 2, // ../Include/Application/ApplicationContext.js: 9
    Internal: 3 // ../Include/Application/ApplicationContext.js: 10
}; // ../Include/Application/ApplicationContext.js: 11

ApplicationContextFormat.FromString = function(format, def) { // ../Include/Application/ApplicationContext.js: 13
    if (format == 'xml') // ../Include/Application/ApplicationContext.js: 14
        return ApplicationContextFormat.XmlString; // ../Include/Application/ApplicationContext.js: 15
    if (format == 'json') // ../Include/Application/ApplicationContext.js: 16
        return ApplicationContextFormat.JsonString; // ../Include/Application/ApplicationContext.js: 17
    if (format == 'object') // ../Include/Application/ApplicationContext.js: 18
        return ApplicationContextFormat.JsObject; // ../Include/Application/ApplicationContext.js: 19
    if (format == 'internal') // ../Include/Application/ApplicationContext.js: 20
        return ApplicationContextFormat.Internal; // ../Include/Application/ApplicationContext.js: 21
//(ignore)//     Assert.Null('ApplicationContextFormat.FromString', format, 'format'); // ../Include/Application/ApplicationContext.js: 22
    return def; // ../Include/Application/ApplicationContext.js: 23
}; // ../Include/Application/ApplicationContext.js: 24

/** @constructor */ // ../Include/Application/ApplicationContext.js: 26
function ApplicationContext(key, name, nsName, version, language, tagList, parts, enableSM) { // ../Include/Application/ApplicationContext.js: 27
    this.Key = key || null; // ../Include/Application/ApplicationContext.js: 28
    this.Name = name || null; // ../Include/Application/ApplicationContext.js: 29
    this.NsName = nsName || name || null; // ../Include/Application/ApplicationContext.js: 30
    this.Version = version || null; // ../Include/Application/ApplicationContext.js: 31
    this.Language = language || null; // ../Include/Application/ApplicationContext.js: 32
    this.TagList = tagList || null; // ../Include/Application/ApplicationContext.js: 33
    this.Parts = parts || null; // ../Include/Application/ApplicationContext.js: 34
    this.EnableSM = enableSM || 0; // ../Include/Application/ApplicationContext.js: 35
} // ../Include/Application/ApplicationContext.js: 36

ApplicationContext.ClassId = 'OraUpk.ApplicationContext;3'; // ../Include/Application/ApplicationContext.js: 38

ApplicationContext.FromObject = function(obj) { // ../Include/Application/ApplicationContext.js: 40
//(ignore)//     Assert.Condition('ApplicationContext.FromObject', (obj['ClassId'] == ApplicationContext.ClassId), 'obj["ClassId"] == ' + NameOf(ApplicationContext.ClassId)); // ../Include/Application/ApplicationContext.js: 41
    return new ApplicationContext(obj['Key'], obj['Name'], obj['NsName'], obj['Version'], obj['Language'], obj['TagList'], obj['Parts'], obj['EnableSM']); // ../Include/Application/ApplicationContext.js: 42
}; // ../Include/Application/ApplicationContext.js: 43

ApplicationContext.FromJson = function(json) { // ../Include/Application/ApplicationContext.js: 45
    return ApplicationContext.FromObject(Json.DecodeObject(json)); // ../Include/Application/ApplicationContext.js: 46
}; // ../Include/Application/ApplicationContext.js: 47

ApplicationContext.prototype = { // ../Include/Application/ApplicationContext.js: 49
    AddPart: function(name, value) { // ../Include/Application/ApplicationContext.js: 50
        if (value && value.length) // ../Include/Application/ApplicationContext.js: 51
            this.Parts.push([name, value]); // ../Include/Application/ApplicationContext.js: 52
    }, // ../Include/Application/ApplicationContext.js: 53
    ToObject: function() { // ../Include/Application/ApplicationContext.js: 54
        var obj = { // ../Include/Application/ApplicationContext.js: 55
            'ClassId': ApplicationContext.ClassId, // ../Include/Application/ApplicationContext.js: 56
            'Key': this.Key, // ../Include/Application/ApplicationContext.js: 57
            'Name': this.Name, // ../Include/Application/ApplicationContext.js: 58
            'NsName': this.NsName, // ../Include/Application/ApplicationContext.js: 59
            'Language': this.Language, // ../Include/Application/ApplicationContext.js: 60
            'Version': this.Version, // ../Include/Application/ApplicationContext.js: 61
            'TagList': this.TagList, // ../Include/Application/ApplicationContext.js: 62
            'Parts': this.Parts, // ../Include/Application/ApplicationContext.js: 63
            'EnableSM': this.EnableSM // ../Include/Application/ApplicationContext.js: 64
    }; // ../Include/Application/ApplicationContext.js: 65
        return obj; // ../Include/Application/ApplicationContext.js: 66
    }, // ../Include/Application/ApplicationContext.js: 67
    ToJson: function() { // ../Include/Application/ApplicationContext.js: 68
        return Json.EncodeObject(this.ToObject()); // ../Include/Application/ApplicationContext.js: 69
    }, // ../Include/Application/ApplicationContext.js: 70
    ToXml: function(appHandler) { // ../Include/Application/ApplicationContext.js: 71
        function tokens_AddPart(container, name, value, caption, useNameAsPrefix, searchable) { // ../Include/Application/ApplicationContext.js: 72
            container.push('<property name="' + name + '" caption="' + caption + '" usenameasprefix="' + useNameAsPrefix + '" searchable="' + searchable + '">'); // ../Include/Application/ApplicationContext.js: 73
            container.push('<prop_string>' + Html.Escape(value) + '</prop_string>'); // ../Include/Application/ApplicationContext.js: 74
            container.push('</property>'); // ../Include/Application/ApplicationContext.js: 75
        } // ../Include/Application/ApplicationContext.js: 76
        var nsName = this.NsName; // ../Include/Application/ApplicationContext.js: 77
        var smartMatch = this.EnableSM; // ../Include/Application/ApplicationContext.js: 78
        var tokens = ['<?xml version="1.0"?><propertyset>']; // ../Include/Application/ApplicationContext.js: 79
        var contextInfo = this.Name; // ../Include/Application/ApplicationContext.js: 80
        if (appHandler) { // ../Include/Application/ApplicationContext.js: 81
            contextInfo += smartMatch ? ';SM' : ''; // ../Include/Application/ApplicationContext.js: 82
            contextInfo += ';V' + appHandler.ContextVersion; // ../Include/Application/ApplicationContext.js: 83
            contextInfo += ';R12.1.0.0'; // ../Include/Application/ApplicationContext.js: 84
            var partMap; // ../Include/Application/ApplicationContext.js: 85
            var parts; // ../Include/Application/ApplicationContext.js: 86
            if (appHandler.ContextType == ContextType.Hybrid) { // ../Include/Application/ApplicationContext.js: 87
                partMap = appHandler.A.PartMap; // ../Include/Application/ApplicationContext.js: 88
                parts = (this.Parts && this.Parts.length && this.Parts[0][0] == 'A') ? this.Parts[0][1] : null; // ../Include/Application/ApplicationContext.js: 89
            } // ../Include/Application/ApplicationContext.js: 90
            else { // ../Include/Application/ApplicationContext.js: 91
                partMap = appHandler.PartMap; // ../Include/Application/ApplicationContext.js: 92
                parts = this.Parts; // ../Include/Application/ApplicationContext.js: 93
            } // ../Include/Application/ApplicationContext.js: 94
            if (parts) { // ../Include/Application/ApplicationContext.js: 95
                for (var i = 0, n = parts.length; i < n; ++i) { // ../Include/Application/ApplicationContext.js: 96
                    var part_i = parts[i]; // ../Include/Application/ApplicationContext.js: 97
                    var part_i_name = part_i[0]; // ../Include/Application/ApplicationContext.js: 98
                    var partDesc = partMap[part_i_name]; // ../Include/Application/ApplicationContext.js: 99
//(ignore)//                     Assert('ApplicationContext.ToXml', (partDesc != null), 'Invalid part ' + NameOf(part_i[0]) + ' in ' + NameOf(this.Key) + ' context.'); // ../Include/Application/ApplicationContext.js: 100
                    if (/^MC\./.test(part_i_name)) // ../Include/Application/ApplicationContext.js: 101
                        contextInfo += ';' + partDesc.Caption + part_i[1]; // ../Include/Application/ApplicationContext.js: 102
                    else tokens_AddPart(tokens, part_i[0], part_i[1], partDesc.Caption, partDesc.UseNameAsPrefix, partDesc.Searchable); // ../Include/Application/ApplicationContext.js: 103
                } // ../Include/Application/ApplicationContext.js: 104
            } // ../Include/Application/ApplicationContext.js: 105
        } // ../Include/Application/ApplicationContext.js: 106
        if ((nsName != null) && (nsName.indexOf('.') != -1)) // ../Include/Application/ApplicationContext.js: 107
            tokens_AddPart(tokens, 'MA', nsName, 'Application Name', true, true); // ../Include/Application/ApplicationContext.js: 108
        tokens_AddPart(tokens, 'MC', contextInfo, 'Context Info', true, false); // ../Include/Application/ApplicationContext.js: 109
        if (this.Version != null) // ../Include/Application/ApplicationContext.js: 110
            tokens_AddPart(tokens, 'MV', this.Version, 'Application Version', true, false); // ../Include/Application/ApplicationContext.js: 111
        if (this.TagList != null) { // ../Include/Application/ApplicationContext.js: 112
            var tagList = this.TagList; // ../Include/Application/ApplicationContext.js: 113
            for (var i = 0, n = tagList.length; i < n; ++i) // ../Include/Application/ApplicationContext.js: 114
                tokens_AddPart(tokens, 'MT', tagList[i], 'Application Tag', true, true); // ../Include/Application/ApplicationContext.js: 115
        } // ../Include/Application/ApplicationContext.js: 116
        tokens.push('</propertyset>'); // ../Include/Application/ApplicationContext.js: 117
        return tokens.join(''); // ../Include/Application/ApplicationContext.js: 118
    } // ../Include/Application/ApplicationContext.js: 119
} // ../Include/Application/ApplicationContext.js: 120

//* <FileEnd path="../Include/Application/ApplicationContext.js"/>


//* <FileBegin path="../Include/Application/ApplicationType.js"/>

var ApplicationType = { // ../Include/Application/ApplicationType.js: 2
    None: 0, // ../Include/Application/ApplicationType.js: 3
    StandaloneFlag: 1, // ../Include/Application/ApplicationType.js: 4
    PortalFlag: 2, // ../Include/Application/ApplicationType.js: 5
    Standalone: 1, // ../Include/Application/ApplicationType.js: 6
    Portal: 2 // ../Include/Application/ApplicationType.js: 7
}; // ../Include/Application/ApplicationType.js: 8

//* <FileEnd path="../Include/Application/ApplicationType.js"/>


/** @constructor */ // ../Include/Application/ApplicationBase.js: 13
function ApplicationBase() { // ../Include/Application/ApplicationBase.js: 14
}; // ../Include/Application/ApplicationBase.js: 15

ApplicationBase.prototype = { // ../Include/Application/ApplicationBase.js: 17
    Key: null, // ../Include/Application/ApplicationBase.js: 18
    Name: '$UNKNOWN', // ../Include/Application/ApplicationBase.js: 19

    ConfigDefaults: { // ../Include/Application/ApplicationBase.js: 21
        'ContentMap': [], // ../Include/Application/ApplicationBase.js: 22
        'GatewayTitle': '',           // DEPRECATED // String (100)	the title of the gateway page   ""
        'GatewayLinksTitle': 'Links',               // String (100)	the title of gateway links 	"Linked Resources"
        'GatewayLinks': [],                         // Array<Resource>	an array of gateway links	[]
        'GatewayPages': [],                         // Array<Resource>	an array of gateway pages	[]
        'GatewayRememberTab': 1                     // Integer	1 to keep the last tab selected	or 0 otherwise
    }, // ../Include/Application/ApplicationBase.js: 28

    SupportedFeatures: ApplicationFeature.ExactMatch, // ../Include/Application/ApplicationBase.js: 30
    ContextType: ContextType.Absolute, // ../Include/Application/ApplicationBase.js: 31
    ContextDiscovery: false, // ../Include/Application/ApplicationBase.js: 32
    ContextVersion: 0, // ../Include/Application/ApplicationBase.js: 33
    ContextParts: [ // ../Include/Application/ApplicationBase.js: 34
        ContextPart.CreateValue('C', 'Context ID') // ../Include/Application/ApplicationBase.js: 35
    ], // ../Include/Application/ApplicationBase.js: 36
    ContextStdPartsMap: { // ../Include/Application/ApplicationBase.js: 37
        'MA': ContextPart.CreateValue('MA', 'Application Name'), // ../Include/Application/ApplicationBase.js: 38
        'MT': ContextPart.CreateValue('MT', 'Application Tag', true, true, true) // ../Include/Application/ApplicationBase.js: 39
    }, // ../Include/Application/ApplicationBase.js: 40
    PartMap: null, // ../Include/Application/ApplicationBase.js: 41
    CombineExactAndSmart: 1, // ../Include/Application/ApplicationBase.js: 42
    CreatePartsFromValues: function(values) { // ../Include/Application/ApplicationBase.js: 43
        var contextParts = this.ContextParts; // ../Include/Application/ApplicationBase.js: 44
//(ignore)//         Assert.Condition('ApplicationBase.CreatePartsFromValues', (values.length <= contextParts.length), '(values.length <= contextParts.length)'); // ../Include/Application/ApplicationBase.js: 45
        var parts = []; // ../Include/Application/ApplicationBase.js: 46
        if (values) { // ../Include/Application/ApplicationBase.js: 47
            var i, n; // ../Include/Application/ApplicationBase.js: 48
            for (i = 0, n = values.length; i < n; ++i) { // ../Include/Application/ApplicationBase.js: 49
                var value = values[i]; // ../Include/Application/ApplicationBase.js: 50
                if (value != null) { // ../Include/Application/ApplicationBase.js: 51
                    if (ContextPart.HasMultipleParts(contextParts[i])) { // ../Include/Application/ApplicationBase.js: 52
//(ignore)//                         Assert.Array('ApplicationBase.CreatePartsFromValues', value, 'values[' + i + ']'); // ../Include/Application/ApplicationBase.js: 53
                        if (value.length != 0) { // ../Include/Application/ApplicationBase.js: 54
                            for (var value_i = 0; value_i < value.length; ++value_i) { // ../Include/Application/ApplicationBase.js: 55
                                var v = value[value_i]; // ../Include/Application/ApplicationBase.js: 56
                                if (v != '') // ../Include/Application/ApplicationBase.js: 57
                                    parts.push([contextParts[i][0], v]); // ../Include/Application/ApplicationBase.js: 58
                            } // ../Include/Application/ApplicationBase.js: 59
                        } // ../Include/Application/ApplicationBase.js: 60
                    } // ../Include/Application/ApplicationBase.js: 61
                    else { // ../Include/Application/ApplicationBase.js: 62
                        if (value != '') // ../Include/Application/ApplicationBase.js: 63
                            parts.push([contextParts[i][0], value]); // ../Include/Application/ApplicationBase.js: 64
                    } // ../Include/Application/ApplicationBase.js: 65
                } // ../Include/Application/ApplicationBase.js: 66
            } // ../Include/Application/ApplicationBase.js: 67
//x             //: <if xconfig="Debug,Trace"/>
//x             var missingParts = [];
//x             for (n = contextParts.length; i < n; ++i) {
//x                 if (contextParts[i][3])
//x                     missingParts.push(contextParts[i][0] + ': ' + contextParts[i][0]);
//x             }
//x             Assert('ApplicationBase.CreatePartsFromValues', !missingParts.length, 'The following searchable parts were not specified: ' + missingParts.join(', '));
//x             //: <end/>
        } // ../Include/Application/ApplicationBase.js: 76
        return parts; // ../Include/Application/ApplicationBase.js: 77
    }, // ../Include/Application/ApplicationBase.js: 78

//x     //: <if xconfig="Recognition,Playback"/>
//x     ApplicationType: ApplicationType.Portal,
//x     EnableSmartMatch: false,
//x     EnableUpkMeta: false,
//x     EnableIdentify: false,
//x     EnablePartsCache: false,
//x     IdentifyTopWindowOnly: false,
//x     RequiredFrames: null,
//x     OptionalFrames: null,
//x     OptionalFramesNeeded: 0,
//x     IdentifyFrames: null, // function(framesByName)
//x     Identify: null, // function(frameDesc)
//x     IdentifyFast: null, // function(frameDesc)
//x     GetPartValuesWrapper: null, // wrapper that calls the right GetPartValues, initialized in Initialize()
//x     GetPartValues: null, // function(frameDesc)
//x     GetPartValues_Default: function(frameDesc) {
//x         Assert.MustOverride('ApplicationBase.GetPartValues_UpkMeta,App.' + this.Key);
//x         return null;
//x     },
//x     GetPartValues_UpkMeta: function(frameDesc) {
//x         Trace('ApplicationBase.GetPartValues_UpkMeta,App.' + this.Key, 'frameDesc.FrameIndex = ' + frameDesc.FrameIndex);
//x         Assert.NonNull('ApplicationBase.GetPartValues_UpkMeta,App.' + this.Key, frameDesc.NativeWindow, 'frameDesc.NativeWindow');
//x         var rawContext = WindowUtils.TryCall(frameDesc.NativeWindow, 'UPK_GetContext');
//x         Trace('ApplicationBase.GetPartValues_UpkMeta,App.' + this.Key, 'rawContext = ' + rawContext);
//x         Trace('ApplicationBase.GetPartValues_UpkMeta,App.' + this.Key, 'frameDesc.AppDesc = ' + Json.EncodeObject(frameDesc.AppDesc));
//x 
//x         return ((rawContext != null) ? [UpkMeta.DecodeContext(rawContext, ContextPart.HasMultipleParts(this.ContextParts[0]))] : null);
//x     },
//x     GetPartValues_Both: function(frameDesc) {
//x         return (this.GetPartValues_UpkMeta(frameDesc) || this.GetPartValues(frameDesc));
//x     },
//x     GetParts: function(frameDesc) {
//x         var values = this.GetPartValuesWrapper(frameDesc);
//x         return (values ? this.CreatePartsFromValues(values) : null);
//x     },
//x     //: <end/>
//x     //: <if xconfig="Playback"/>
//x     SearchType: EcidSearch.All,
//x     FilterSearchParts: function(unfilteredParts) {
//x         var filterdParts = [];
//x         var partMap = this.PartMap;
//x         for (var i = 0, n = unfilteredParts.length; i < n; ++i) {
//x             var part = unfilteredParts[i];
//x             if (part) {
//x                 if (partMap[part[0]].Searchable)
//x                     filterdParts.push(part);
//x             }
//x         }
//x         Trace.Object('FilterSearchParts', filterdParts, 'filterdParts');
//x         return filterdParts.length? filterdParts: null;
//x     },
//x     CreateSearchParts: function(values) {
//x         var parts = this.CreatePartsFromValues(values);
//x         Trace.Object('CreateSearchParts', parts, 'parts');
//x         return parts;
//x     },
//x     CreateSearchXpBuilder: function(appId) {
//x         var appName = this.HintOverrideName;
//x         var dotPos = appId.indexOf('.');
//x         appId = appName + ((dotPos == -1) ? '' : appId.substr(dotPos));
//x         return new SearchXpApplicationBuilder(appId, this.CombineExactAndSmart);
//x     },
//x     //TODO: Matyi: Unused and contains bug
//x     /*
//x     BuildSearchXpFromValues: function(builder, values) {
//x         var parts = this.CreatePartsFromValues(values);
//x         this.BuildSearchXp(builder, parts);
//x     },
//x     */
//x     BuildSearchXp: function(builder, parts) {
//x         Trace.Object('BuildSearchXp', parts, 'parts');
//x         if (parts) {
//x             parts = this.FilterSearchParts(parts);
//x             if (parts) {
//x                 builder.AddPartsBySearchType(parts, this.SearchType);
//x             }
//x         }
//x     },
//x     //: <end/>
    IntegrateParts: function(partsList, dropList, ignoreLimits) { // ../Include/Application/ApplicationBase.js: 159
//x         /// <summary>
//x         /// Creates a single list with the unique parts accumulted from the "partsList" parameter.
//x         /// dropList and ignoreLimits is ignored in the default implementation (SmartMatch uses them)
//x         /// </summary>
        var uList = []; // ../Include/Application/ApplicationBase.js: 164
        var uHash = {}; // ../Include/Application/ApplicationBase.js: 165
        for (var i = 0, n = partsList.length; i < n; ++i) { // ../Include/Application/ApplicationBase.js: 166
            var parts = partsList[i]; // ../Include/Application/ApplicationBase.js: 167
            if (parts) { // ../Include/Application/ApplicationBase.js: 168
                for (var j = 0, m = parts.length; j < m; ++j) { // ../Include/Application/ApplicationBase.js: 169
                    if (HashMap.AddNewItem(uHash, parts[j][0] + parts[j][1], true)) // ../Include/Application/ApplicationBase.js: 170
                        uList.push(parts[j]); // ../Include/Application/ApplicationBase.js: 171
                } // ../Include/Application/ApplicationBase.js: 172
            } // ../Include/Application/ApplicationBase.js: 173
        } // ../Include/Application/ApplicationBase.js: 174
        return (uList.length ? uList : null); // ../Include/Application/ApplicationBase.js: 175
    }, // ../Include/Application/ApplicationBase.js: 176
    Initialize: function() { // ../Include/Application/ApplicationBase.js: 177
        if (!this.HintOverrideName) // ../Include/Application/ApplicationBase.js: 178
            this.HintOverrideName = this.Name; // ../Include/Application/ApplicationBase.js: 179

        if (!this.Key) // ../Include/Application/ApplicationBase.js: 181
            this.Key = this.Name + ':' + this.SupportedFeatures; // ../Include/Application/ApplicationBase.js: 182

//x         //: <if xconfig="Recognition"/>
//x         Assert.NonNull('App.' + this.Key + ',ApplicationBase.Initialize', !this.EnableIdentify || this.Identify, '!this.EnableIdentify || this.Identify');
//x         if (this.EnableIdentify && !this.IdentifyFast)
//x             this.IdentifyFast = this.Identify;
//x         if (!this.GetPartValues)
//x             this.GetPartValuesWrapper = this.EnableUpkMeta ? this.GetPartValues_UpkMeta : this.GetPartValues_Default;
//x         else this.GetPartValuesWrapper = this.EnableUpkMeta ? this.GetPartValues_Both : this.GetPartValues;
//x         //: <end/>

        var partMap = {}; // ../Include/Application/ApplicationBase.js: 193
        var i, n, part; // ../Include/Application/ApplicationBase.js: 194

        var stdPartsMap = this.ContextStdPartsMap; // ../Include/Application/ApplicationBase.js: 196
        for (var partName in stdPartsMap) { // ../Include/Application/ApplicationBase.js: 197
            part = stdPartsMap[partName]; // ../Include/Application/ApplicationBase.js: 198
            partMap[part[0]] = PartDescriptor.Create(part); // ../Include/Application/ApplicationBase.js: 199
        } // ../Include/Application/ApplicationBase.js: 200

        var contextParts = this.ContextParts; // ../Include/Application/ApplicationBase.js: 202
        for (i = 0, n = contextParts.length; i < n; ++i) { // ../Include/Application/ApplicationBase.js: 203
            part = contextParts[i]; // ../Include/Application/ApplicationBase.js: 204
            partMap[part[0]] = PartDescriptor.Create(part); // ../Include/Application/ApplicationBase.js: 205
        } // ../Include/Application/ApplicationBase.js: 206

        this.PartMap = partMap; // ../Include/Application/ApplicationBase.js: 208
    } // ../Include/Application/ApplicationBase.js: 209
}; // ../Include/Application/ApplicationBase.js: 210

//* <FileEnd path="../Include/Application/ApplicationBase.js"/>


var ApplicationMap = { // ../Include/Application/ApplicationMap.js: 4
    Keys: [], // ../Include/Application/ApplicationMap.js: 5
    Names: [], // ../Include/Application/ApplicationMap.js: 6
    AppByKey: {}, // ../Include/Application/ApplicationMap.js: 7
    AppsByName: {}, // ../Include/Application/ApplicationMap.js: 8
    Register: function(app) { // ../Include/Application/ApplicationMap.js: 9
//(ignore)//         Assert.NonNull('ApplicationMap.Register', app, 'app'); // ../Include/Application/ApplicationMap.js: 10
        app.Initialize(); // ../Include/Application/ApplicationMap.js: 11
        var appKey = app.Key; // ../Include/Application/ApplicationMap.js: 12
//(ignore)//         Assert.Undefined('ApplicationMap.Register', ApplicationMap.AppByKey[appKey], 'ApplicationMap.AppByKey[' + NameOf(appKey) + ']'); // ../Include/Application/ApplicationMap.js: 13
        ApplicationMap.AppByKey[appKey] = app; // ../Include/Application/ApplicationMap.js: 14
        ApplicationMap.Keys.push(appKey); // ../Include/Application/ApplicationMap.js: 15
        var appName = app.Name; // ../Include/Application/ApplicationMap.js: 16
        var apps = ApplicationMap.AppsByName[appName]; // ../Include/Application/ApplicationMap.js: 17
        if (apps) // ../Include/Application/ApplicationMap.js: 18
            apps.push(app); // ../Include/Application/ApplicationMap.js: 19
        else { // ../Include/Application/ApplicationMap.js: 20
            ApplicationMap.Names.push(appName); // ../Include/Application/ApplicationMap.js: 21
            ApplicationMap.AppsByName[appName] = [app]; // ../Include/Application/ApplicationMap.js: 22
        } // ../Include/Application/ApplicationMap.js: 23
    }, // ../Include/Application/ApplicationMap.js: 24
    TryGetApplicationByKey: function(appKey) { // ../Include/Application/ApplicationMap.js: 25
        return (ApplicationMap.AppByKey[appKey] || null); // ../Include/Application/ApplicationMap.js: 26
    }, // ../Include/Application/ApplicationMap.js: 27
    TryGetApplicationsByName: function(appName) { // ../Include/Application/ApplicationMap.js: 28
        return (ApplicationMap.AppsByName[appName] || null); // ../Include/Application/ApplicationMap.js: 29
    }, // ../Include/Application/ApplicationMap.js: 30
    TryGetApplication: function(appName) { // ../Include/Application/ApplicationMap.js: 31
        var apps = (ApplicationMap.AppsByName[appName] || null); // ../Include/Application/ApplicationMap.js: 32
        return (apps ? apps[0] : null); // ../Include/Application/ApplicationMap.js: 33
    }, // ../Include/Application/ApplicationMap.js: 34
    //TODO: Matyi: Seems to be unused
    //TryGetApplicationDefaults: function(appName) {
    //    var appHandler = ApplicationMap.TryGetApplication(appName);
    //    return (appHandler ? appHandler.ConfigDefaults : ApplicationBase.prototype.ConfigDefaults);
    //},
    GetApplication: function(appName, featureList) { // ../Include/Application/ApplicationMap.js: 40
        var result; // ../Include/Application/ApplicationMap.js: 41
        if (featureList) { // ../Include/Application/ApplicationMap.js: 42
            var appKey = ApplicationMap.GetApplicationKey(appName, featureList); // ../Include/Application/ApplicationMap.js: 43
            result = (appKey? ApplicationMap.TryGetApplicationByKey(appKey): null); // ../Include/Application/ApplicationMap.js: 44
//(ignore)//             Assert.NonNull('ApplicationMap.GetApplication', result, 'ApplicationMap.AppsByName[' + NameOf(appName) + '] with ' + Json.EncodeObject(featureList)); // ../Include/Application/ApplicationMap.js: 45
        } // ../Include/Application/ApplicationMap.js: 46
        else { // ../Include/Application/ApplicationMap.js: 47
            result = ApplicationMap.TryGetApplication(appName); // ../Include/Application/ApplicationMap.js: 48
//(ignore)//             Assert.NonNull('ApplicationMap.GetApplication', result, 'ApplicationMap.AppsByName[' + NameOf(appName) + ']'); // ../Include/Application/ApplicationMap.js: 49
        } // ../Include/Application/ApplicationMap.js: 50
        return result; // ../Include/Application/ApplicationMap.js: 51
    }, // ../Include/Application/ApplicationMap.js: 52
    GetApplicationName: function(appKey) { // ../Include/Application/ApplicationMap.js: 53
        if (!appKey) // ../Include/Application/ApplicationMap.js: 54
            return ''; // ../Include/Application/ApplicationMap.js: 55
        return (appKey.split(':'))[0]; // ../Include/Application/ApplicationMap.js: 56
    }, // ../Include/Application/ApplicationMap.js: 57
    GetApplicationKey: function(appName, featureList) { // ../Include/Application/ApplicationMap.js: 58
        var apps = ApplicationMap.TryGetApplicationsByName(appName); // ../Include/Application/ApplicationMap.js: 59
        if (!apps) // ../Include/Application/ApplicationMap.js: 60
            return null; // ../Include/Application/ApplicationMap.js: 61
        if (!featureList) // ../Include/Application/ApplicationMap.js: 62
            return apps[0]; // ../Include/Application/ApplicationMap.js: 63
        for (var appIndex = 0; appIndex < apps.length; ++appIndex) { // ../Include/Application/ApplicationMap.js: 64
            var app = apps[appIndex]; // ../Include/Application/ApplicationMap.js: 65
            var i; // ../Include/Application/ApplicationMap.js: 66
            var n = featureList.length; // ../Include/Application/ApplicationMap.js: 67
            for (i = 0; i < n; ++i) { // ../Include/Application/ApplicationMap.js: 68
                if (app.SupportedFeatures.indexOf(featureList[i]) == -1) // ../Include/Application/ApplicationMap.js: 69
                    break; // ../Include/Application/ApplicationMap.js: 70
            } // ../Include/Application/ApplicationMap.js: 71
            if (i == n) // ../Include/Application/ApplicationMap.js: 72
                return app.Key; // ../Include/Application/ApplicationMap.js: 73
        } // ../Include/Application/ApplicationMap.js: 74
        return null; // ../Include/Application/ApplicationMap.js: 75
    } // ../Include/Application/ApplicationMap.js: 76
}; // ../Include/Application/ApplicationMap.js: 77


//* <FileEnd path="../Include/Application/ApplicationMap.js"/>


var _ConfigData = { // ../Include/Common/ConfigData.js: 11
    ContentUrl: '../../', // ../Include/Common/ConfigData.js: 12
    Root: null, // ../Include/Common/ConfigData.js: 13
    RootLoaded: false, // ../Include/Common/ConfigData.js: 14
    PublishDataLoaded: false, // ../Include/Common/ConfigData.js: 15
    _Cache: null, // ../Include/Common/ConfigData.js: 16
    Reset: function() { // ../Include/Common/ConfigData.js: 17
//(ignore)//         Trace('_ConfigData.Reset'); // ../Include/Common/ConfigData.js: 18
        _ConfigData.ContentUrl = '../../'; // ../Include/Common/ConfigData.js: 19
        _ConfigData.Root = new ConfigNode({}); // ../Include/Common/ConfigData.js: 20
        _ConfigData.RootLoaded = false; // ../Include/Common/ConfigData.js: 21
        _ConfigData.PublishDataLoaded = false; // ../Include/Common/ConfigData.js: 22
        _ConfigData._Cache = {}; // ../Include/Common/ConfigData.js: 23
    }, // ../Include/Common/ConfigData.js: 24
    Request: function(url) { // ../Include/Common/ConfigData.js: 25
        if (!url) // ../Include/Common/ConfigData.js: 26
            return null; // ../Include/Common/ConfigData.js: 27
        url = /^~\//.test(url) ? url.substr(2) : _ConfigData.ContentUrl + url; // ../Include/Common/ConfigData.js: 28
//(ignore)//         Trace('_ConfigData.Load', url); // ../Include/Common/ConfigData.js: 29
        var data = AjaxRequest.LoadJson(url); // ../Include/Common/ConfigData.js: 30
//(ignore)//         Trace.Object('_ConfigData.Load', data, 'data'); // ../Include/Common/ConfigData.js: 31
        return data; // ../Include/Common/ConfigData.js: 32
    }, // ../Include/Common/ConfigData.js: 33
    Load: function(url) { // ../Include/Common/ConfigData.js: 34
        if (!url) // ../Include/Common/ConfigData.js: 35
            return null; // ../Include/Common/ConfigData.js: 36
        var data = _ConfigData._Cache[url]; // ../Include/Common/ConfigData.js: 37
        if (data === void 0) { // ../Include/Common/ConfigData.js: 38
            data = _ConfigData.Request(url); // ../Include/Common/ConfigData.js: 39
            _ConfigData._Cache[url] = data || null; // ../Include/Common/ConfigData.js: 40
        } // ../Include/Common/ConfigData.js: 41
        return data; // ../Include/Common/ConfigData.js: 42
    } // ../Include/Common/ConfigData.js: 43
}; // ../Include/Common/ConfigData.js: 44

var ConfigData = { // ../Include/Common/ConfigData.js: 46
    GetPublishDataLocation: function() { // ../Include/Common/ConfigData.js: 47
        return 'publishdata.json.js'; // ../Include/Common/ConfigData.js: 48
    }, // ../Include/Common/ConfigData.js: 49
    //TODO: Matyi: Seems to be deprecated
    //GetRootConfigDataLocation: function() {
    //    return 'stdhemi/configdata.json.js';
    //},
    GetApplicationConfigDataLocation: function(appName) { // ../Include/Common/ConfigData.js: 54
        //var id = UpkMeta.ApplicationNameFromNsName(appName);
        //var apps = ApplicationData['Applications'];
        //if (!apps)
        return '~/configdata.json.js'; // ../Include/Common/ConfigData.js: 58
        //if (!apps[id])
        //    return null;
        //return apps[id]['Config'] || null;
    }, // ../Include/Common/ConfigData.js: 62
    GetApplicationKey: function(appName) { // ../Include/Common/ConfigData.js: 63
        return 'Applications/' + appName; // ../Include/Common/ConfigData.js: 64
    }, // ../Include/Common/ConfigData.js: 65
    SetContentUrl: function(contentUrl) { // ../Include/Common/ConfigData.js: 66
//(ignore)//         Trace('ConfigData.SetContentUrl', Called({ 'contentUrl': contentUrl })); // ../Include/Common/ConfigData.js: 67
        _ConfigData.Reset(); // ../Include/Common/ConfigData.js: 68
        _ConfigData.ContentUrl = contentUrl; // ../Include/Common/ConfigData.js: 69
    }, // ../Include/Common/ConfigData.js: 70
    LoadPublishData: function() { // ../Include/Common/ConfigData.js: 71
        return _ConfigData.Load(ConfigData.GetPublishDataLocation()); // ../Include/Common/ConfigData.js: 72
    }, // ../Include/Common/ConfigData.js: 73
    //TODO: Matyi: Seems to be not used
    //LoadRootConfigData: function() {
    //    return _ConfigData.Load(ConfigData.GetRootConfigDataLocation());
    //},
    LoadApplicationConfigData: function(appName) { // ../Include/Common/ConfigData.js: 78
        return _ConfigData.Load(ConfigData.GetApplicationConfigDataLocation(appName)); // ../Include/Common/ConfigData.js: 79
    }, // ../Include/Common/ConfigData.js: 80
    GetValueByKey: function(key) { // ../Include/Common/ConfigData.js: 81
//(ignore)//         Assert('ConfigData.GetValueByKey', _ConfigData.ContentUrl != null, 'ContentUrl was not set'); // ../Include/Common/ConfigData.js: 82
//(ignore)//         Assert.String('ConfigData.GetValueByKey', key, 'key'); // ../Include/Common/ConfigData.js: 83

        var value = _ConfigData.Root.TryGetValueByKey(key); // ../Include/Common/ConfigData.js: 85
        if (value === void 0) { // ../Include/Common/ConfigData.js: 86
            var configNode = ConfigData.OpenKey(key); // ../Include/Common/ConfigData.js: 87
            return (configNode ? configNode.Node : void 0); // ../Include/Common/ConfigData.js: 88
        } // ../Include/Common/ConfigData.js: 89
        return value; // ../Include/Common/ConfigData.js: 90
    }, // ../Include/Common/ConfigData.js: 91
    OpenKey: function(key) { // ../Include/Common/ConfigData.js: 92
//(ignore)//         Assert('ConfigData.OpenKey', _ConfigData.ContentUrl != null, 'ContentUrl was not set'); // ../Include/Common/ConfigData.js: 93
//(ignore)//         Assert.String('ConfigData.OpenKey', key, 'key'); // ../Include/Common/ConfigData.js: 94

        return (_ConfigData.Root.TryOpenKey(key) || ConfigData._LoadKey(key)); // ../Include/Common/ConfigData.js: 96
    }, // ../Include/Common/ConfigData.js: 97
    //TODO: Matyi: Seems to be deprecated
    /*
    GetApplicationDefaults: function(appName) {
        Assert.String('ConfigData.GetApplicationDefaults', appName, 'appName');

        var appHandler = ApplicationMap.GetApplication(appName);
        return (appHandler ? appHandler.ConfigDefaults : ApplicationBase.prototype.ConfigDefaults);
    },
    */ // ../Include/Common/ConfigData.js: 106
    GetApplicationConfig: function(appName, url) { // ../Include/Common/ConfigData.js: 107
//(ignore)//         Assert.String('ConfigData.GetApplicationConfig', appName, 'appName'); // ../Include/Common/ConfigData.js: 108
//(ignore)//         Assert('ConfigData.GetApplicationConfig', _ConfigData.ContentUrl != null, 'ContentUrl was not set'); // ../Include/Common/ConfigData.js: 109

        var configNode = (_ConfigData.Root.TryOpenKey(ConfigData.GetApplicationKey(appName)) || ConfigData._LoadAndCacheApplicationConfig(appName, url)); // ../Include/Common/ConfigData.js: 111
//(ignore)//         Trace.Object('ConfigData.GetApplicationConfig', configNode, 'configNode'); // ../Include/Common/ConfigData.js: 112
        return configNode; // ../Include/Common/ConfigData.js: 113
    }, // ../Include/Common/ConfigData.js: 114
    GetApplicationList: function() { // ../Include/Common/ConfigData.js: 115
        var appHash = ConfigData.GetValueByKey('PublishData.Applications'); // ../Include/Common/ConfigData.js: 116
        if (appHash) // ../Include/Common/ConfigData.js: 117
            return HashMap.GetKeys(appHash); // ../Include/Common/ConfigData.js: 118
        return []; // ../Include/Common/ConfigData.js: 119
    }, // ../Include/Common/ConfigData.js: 120
    GetDisabledApplicationList: function() { // ../Include/Common/ConfigData.js: 121
        var apps = []; // ../Include/Common/ConfigData.js: 122
        var appHash = ConfigData.GetValueByKey('PublishData.Applications'); // ../Include/Common/ConfigData.js: 123
        if (appHash) { // ../Include/Common/ConfigData.js: 124
            for (var appName in appHash) { // ../Include/Common/ConfigData.js: 125
                var appInfo = appHash[appName]; // ../Include/Common/ConfigData.js: 126
                var enabled = appInfo['Enabled']; // ../Include/Common/ConfigData.js: 127
                if ((enabled !== void 0) && !enabled) // ../Include/Common/ConfigData.js: 128
                    apps.push(appName); // ../Include/Common/ConfigData.js: 129
            } // ../Include/Common/ConfigData.js: 130
        } // ../Include/Common/ConfigData.js: 131
        return apps; // ../Include/Common/ConfigData.js: 132
    }, // ../Include/Common/ConfigData.js: 133
    //TODO: Matyi: Seems deprecated
    /*
    GetSmartHelpApplicationList: function() {
        var uList = [];
        var uHash = {};
        var appHash = ConfigData.GetValueByKey('PublishData.Applications');
        if (appHash) {
            for (var appName in appHash) {
                var appInfo = appHash[appName];
                if (appInfo['Published'] && appInfo['Enabled'] && HashMap.AddNewItem(uHash, appName, true))
                    uList.push(appName);
            }
        }
        var contentMap = ConfigData.GetValueByKey('SmartHelp.ContentMap');
        if (contentMap && contentMap.length) {
            for (var i = 0, n = contentMap.length; i < n; ++i) {
                var mapping = contentMap[i];
                var appName = mapping['Application'];
                if (appName && HashMap.AddNewItem(uHash, appName, true))
                    uList.push(appName);
            }
        }
        return uList;
    },
    */ // ../Include/Common/ConfigData.js: 158
    Reset: function() { // ../Include/Common/ConfigData.js: 159
        _ConfigData.Reset(); // ../Include/Common/ConfigData.js: 160
    }, // ../Include/Common/ConfigData.js: 161
    _LoadKey: function(key) { // ../Include/Common/ConfigData.js: 162
        if (/^Applications\//.test(key)) { // ../Include/Common/ConfigData.js: 163
            var nameList = key.split('/'); // ../Include/Common/ConfigData.js: 164
            var appName = nameList[1]; // ../Include/Common/ConfigData.js: 165
//(ignore)//             Assert('ConfigData._LoadKey', appName.length && (appName.toUpperCase() == appName), 'appName must be a non-empty uppercase string'); // ../Include/Common/ConfigData.js: 166
            ConfigData._LoadAndCacheApplicationConfig(appName); // ../Include/Common/ConfigData.js: 167
        } // ../Include/Common/ConfigData.js: 168
        //TODO: Matyi: Seems to be deprecated
        //else if (/^SmartHelp(?:\..+)?$/.test(key)) {
        //    ConfigData._LoadAndCacheRootConfig();
        //}
        else if (/^PublishData(?:\/.+)?$/.test(key)) { // ../Include/Common/ConfigData.js: 173
            ConfigData._LoadAndCachePublishData(); // ../Include/Common/ConfigData.js: 174
        } // ../Include/Common/ConfigData.js: 175
        else { // ../Include/Common/ConfigData.js: 176
//(ignore)//             Assert('ConfigData._LoadKey', false, 'Invalid ConfigData key: ' + NameOf(key)); // ../Include/Common/ConfigData.js: 177
            return null; // ../Include/Common/ConfigData.js: 178
        } // ../Include/Common/ConfigData.js: 179
        var configNode = _ConfigData.Root.TryOpenKey(key); // ../Include/Common/ConfigData.js: 180
//(ignore)//         TraceIf.Warning(!configNode, 'ConfigData._LoadKey', 'ConfigData key not found: ' + NameOf(key)); // ../Include/Common/ConfigData.js: 181
        return configNode; // ../Include/Common/ConfigData.js: 182
    }, // ../Include/Common/ConfigData.js: 183
    _LoadAndCachePublishData: function() { // ../Include/Common/ConfigData.js: 184
        //TODO: Matyi: Seems to be deprecated
        //ConfigData._LoadAndCacheRootConfig();
        //if (_ConfigData.PublishDataLoaded)
        //    return true;

        _ConfigData.PublishDataLoaded = true; // ../Include/Common/ConfigData.js: 190
        var data = _ConfigData.Load(ConfigData.GetPublishDataLocation()); // ../Include/Common/ConfigData.js: 191
        if (data) // ../Include/Common/ConfigData.js: 192
            _ConfigData.Root.CreateKey('PublishData').Extend(data); // ../Include/Common/ConfigData.js: 193
    }, // ../Include/Common/ConfigData.js: 194
    //TODO: Matyi: Seems to be deprecated
    //_LoadAndCacheRootConfig: function() {
    //    if (_ConfigData.RootLoaded)
    //        return true;
    //
    //    _ConfigData.RootLoaded = true;
    //    var configNode = _ConfigData.Root;
    //    configNode.Extend(ConfigDefaults);
    //    var data = _ConfigData.Load(ConfigData.GetRootConfigDataLocation());
    //    if (data) {
    //        _ConfigData.PublishDataLoaded = true; // we don't need PublishData if rootconfig is loaded
    //        configNode.Extend(data);
    //        configNode.Delete('Info');
    //    }
    //},
    _LoadAndCacheApplicationConfig: function(appNsName, url) { // ../Include/Common/ConfigData.js: 210
        var configKey = ConfigData.GetApplicationKey(appNsName); // ../Include/Common/ConfigData.js: 211
        var configNode = _ConfigData.Root.CreateKey(configKey); // ../Include/Common/ConfigData.js: 212

        var appName = UpkMeta.ApplicationNameFromNsName(appNsName); // ../Include/Common/ConfigData.js: 214
        var appHandler = ApplicationMap.TryGetApplication(appName); // ../Include/Common/ConfigData.js: 215
        var configDefaults = appHandler ? appHandler.ConfigDefaults : ApplicationBase.prototype.ConfigDefaults; // ../Include/Common/ConfigData.js: 216

//(ignore)//         Trace.Object('ConfigData.GetApplicationConfig', configDefaults, 'configDefaults'); // ../Include/Common/ConfigData.js: 218
        configNode.Extend(configDefaults); // ../Include/Common/ConfigData.js: 219
//(ignore)//         Trace.Object('ConfigData.GetApplicationConfig', configNode, 'configNode'); // ../Include/Common/ConfigData.js: 220

        url = ((url != null) ? url + 'configdata.json.js' : ConfigData.GetApplicationConfigDataLocation(appName)); // ../Include/Common/ConfigData.js: 222
        var data = _ConfigData.Load(url); // ../Include/Common/ConfigData.js: 223
        if (data) { // ../Include/Common/ConfigData.js: 224
            var node = ConfigNode.FindKey(data, configKey); // ../Include/Common/ConfigData.js: 225
            if (node) // ../Include/Common/ConfigData.js: 226
                configNode.Extend(node); // ../Include/Common/ConfigData.js: 227
            configNode.CreateKey('ConfigData').Extend(data); // ../Include/Common/ConfigData.js: 228
        } // ../Include/Common/ConfigData.js: 229
        return configNode; // ../Include/Common/ConfigData.js: 230
    } // ../Include/Common/ConfigData.js: 231
}; // ../Include/Common/ConfigData.js: 232


//* <FileEnd path="../Include/Common/ConfigData.js"/>


//* <FileBegin path="../Include/Tools/DomTable.js"/>
//x /// <reference path="../../Include/Tools/Trace.js"/>
//x /// <reference path="../../Include/Tools/Dom.js"/>

/** @constructor */ // ../Include/Tools/DomTable.js: 4
function DomTable(rows, cols, name, caption, _window) { // ../Include/Tools/DomTable.js: 5
//(ignore)//     Trace('DomTable()', 'rows = ' + rows + ' cols = ' + cols + ' name = ' + name + ' caption = ' + caption); // ../Include/Tools/DomTable.js: 6
    this.Doc = _window ? _window.document : window.document; // ../Include/Tools/DomTable.js: 7
    this.Rows = rows; // ../Include/Tools/DomTable.js: 8
    this.Columns = cols; // ../Include/Tools/DomTable.js: 9
    this.Name = name; // ../Include/Tools/DomTable.js: 10
    var table = this.Doc.createElement('table'); // ../Include/Tools/DomTable.js: 11
    var body = this.Doc.createElement('tbody'); // ../Include/Tools/DomTable.js: 12
    table.appendChild(body); // ../Include/Tools/DomTable.js: 13
    table.createTHead(); // ../Include/Tools/DomTable.js: 14
    table.createTFoot(); // ../Include/Tools/DomTable.js: 15
    table.id = name; // ../Include/Tools/DomTable.js: 16
    table.style.borderCollapse = 'collapse'; // ../Include/Tools/DomTable.js: 17
    table.border = 1; // ../Include/Tools/DomTable.js: 18
    this.Doc.body.appendChild(table); // ../Include/Tools/DomTable.js: 19
    if (caption) { // ../Include/Tools/DomTable.js: 20
        var cap = table.createCaption(); // ../Include/Tools/DomTable.js: 21
        cap.innerHTML = caption; // ../Include/Tools/DomTable.js: 22
        cap.style.fontWeight = 'bold'; // ../Include/Tools/DomTable.js: 23
        cap.style.textAlign = 'left'; // ../Include/Tools/DomTable.js: 24
        this.caption = cap; // ../Include/Tools/DomTable.js: 25
    } // ../Include/Tools/DomTable.js: 26
    this.Create(); // ../Include/Tools/DomTable.js: 27
    return this; // ../Include/Tools/DomTable.js: 28
} // ../Include/Tools/DomTable.js: 29

DomTable.prototype = { // ../Include/Tools/DomTable.js: 31
    GetTable: function() { // ../Include/Tools/DomTable.js: 32
        return this.Doc.getElementById(this.Name); // ../Include/Tools/DomTable.js: 33
    }, // ../Include/Tools/DomTable.js: 34
    Create: function() { // ../Include/Tools/DomTable.js: 35
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 36
        for (var i = 0; i < this.Rows; i++) { // ../Include/Tools/DomTable.js: 37
            var tr = this.Doc.createElement('tr'); // ../Include/Tools/DomTable.js: 38
            if (table.rows && table.rows.length > 0) { // ../Include/Tools/DomTable.js: 39
                if (i > 0 && i / 2 != parseInt(i / 2)) { //odd
                    tr.style.backgroundColor = '#F0F0F6'; // ../Include/Tools/DomTable.js: 41
                } // ../Include/Tools/DomTable.js: 42
            } // ../Include/Tools/DomTable.js: 43
            for (var j = 0; j < this.Columns; j++) { // ../Include/Tools/DomTable.js: 44
                var td = this.Doc.createElement('td'); // ../Include/Tools/DomTable.js: 45
                var div = this.Doc.createElement('div'); // ../Include/Tools/DomTable.js: 46
                td.appendChild(div); // ../Include/Tools/DomTable.js: 47
                tr.appendChild(td); // ../Include/Tools/DomTable.js: 48
            } // ../Include/Tools/DomTable.js: 49
            table.tBodies[0].appendChild(tr); // ../Include/Tools/DomTable.js: 50
        } // ../Include/Tools/DomTable.js: 51
    }, // ../Include/Tools/DomTable.js: 52
    FillCells: function(data) { //data[row][column]
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 54
        for (var i = 0; i < this.Rows; i++) { // ../Include/Tools/DomTable.js: 55
            for (var j = 0; j < this.Columns; j++) { // ../Include/Tools/DomTable.js: 56
                table.rows[i].cells[j].firstChild.innerHTML = data[i][j]; // ../Include/Tools/DomTable.js: 57
            } // ../Include/Tools/DomTable.js: 58
        } // ../Include/Tools/DomTable.js: 59
    }, // ../Include/Tools/DomTable.js: 60
    FillCell: function(row, col, data, color, colspan, bold) { // ../Include/Tools/DomTable.js: 61
        //Trace('FillCell', 'row = ' + row + ' col = ' + col + ' data = ' + data + ' colspan = ' + colspan);
        var _colspan = colspan || 0; // ../Include/Tools/DomTable.js: 63
        var _bold = bold || false; // ../Include/Tools/DomTable.js: 64
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 65
        table.rows[row].cells[col].firstChild.innerHTML = data; // ../Include/Tools/DomTable.js: 66
        if (color) { // ../Include/Tools/DomTable.js: 67
            table.rows[row].cells[col].style.backgroundColor = color; // ../Include/Tools/DomTable.js: 68
        } // ../Include/Tools/DomTable.js: 69
        if (_colspan) { // ../Include/Tools/DomTable.js: 70
            table.rows[row].cells[col].colSpan = _colspan; // ../Include/Tools/DomTable.js: 71
        } // ../Include/Tools/DomTable.js: 72
        if (_bold) { // ../Include/Tools/DomTable.js: 73
            table.rows[row].cells[col].firstChild.style.fontWeight = 'bold'; // ../Include/Tools/DomTable.js: 74
        } // ../Include/Tools/DomTable.js: 75
    }, // ../Include/Tools/DomTable.js: 76
    AddHeaders: function(data) { // ../Include/Tools/DomTable.js: 77
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 78
        if (table.tHead.rows.length == 0) { // ../Include/Tools/DomTable.js: 79
            table.tHead.insertRow(-1); // ../Include/Tools/DomTable.js: 80
        } // ../Include/Tools/DomTable.js: 81
        for (var i = 0; i < data.length; i++) { // ../Include/Tools/DomTable.js: 82
            var cell = table.tHead.rows[0].insertCell(-1); // ../Include/Tools/DomTable.js: 83
            var el = this.Doc.createElement('div'); // ../Include/Tools/DomTable.js: 84
            el.style.fontWeight = 'bold'; // ../Include/Tools/DomTable.js: 85
            el.style.backgroundColor = '#8DBDD8'; // ../Include/Tools/DomTable.js: 86
            el.innerHTML = data[i]; // ../Include/Tools/DomTable.js: 87
            cell.style.backgroundColor = '#8DBDD8'; // ../Include/Tools/DomTable.js: 88
            cell.appendChild(el); // ../Include/Tools/DomTable.js: 89
        } // ../Include/Tools/DomTable.js: 90
    }, // ../Include/Tools/DomTable.js: 91
    AddHeader: function(col, data, colspan) { // ../Include/Tools/DomTable.js: 92
        var _colspan = colspan || 0; // ../Include/Tools/DomTable.js: 93
//(ignore)//         Trace('AddHeader', 'col = ' + col + ' data = ' + data + ' colspan = ' + colspan); // ../Include/Tools/DomTable.js: 94
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 95
        if (table.tHead.rows.length == 0) { // ../Include/Tools/DomTable.js: 96
            table.tHead.insertRow(-1); // ../Include/Tools/DomTable.js: 97
        } // ../Include/Tools/DomTable.js: 98
        if (table.tHead.rows[0].cells.length == 0) { // ../Include/Tools/DomTable.js: 99
            for (var i = 0; i < this.Columns; i++) { // ../Include/Tools/DomTable.js: 100
                var cell = table.tHead.rows[0].insertCell(-1); // ../Include/Tools/DomTable.js: 101
                var el = this.Doc.createElement('div'); // ../Include/Tools/DomTable.js: 102
                el.style.fontWeight = 'bold'; // ../Include/Tools/DomTable.js: 103
                el.style.backgroundColor = '#8DBDD8'; // ../Include/Tools/DomTable.js: 104
                cell.style.backgroundColor = '#8DBDD8'; // ../Include/Tools/DomTable.js: 105
                cell.appendChild(el); // ../Include/Tools/DomTable.js: 106
            } // ../Include/Tools/DomTable.js: 107
        } // ../Include/Tools/DomTable.js: 108
        if (_colspan) { // ../Include/Tools/DomTable.js: 109
            table.tHead.rows[0].cells[col].colSpan = _colspan; // ../Include/Tools/DomTable.js: 110
        } // ../Include/Tools/DomTable.js: 111
        table.tHead.rows[0].cells[col].firstChild.innerHTML = data; // ../Include/Tools/DomTable.js: 112
    }, // ../Include/Tools/DomTable.js: 113
    AddHeaderLink: function(col, data) { // ../Include/Tools/DomTable.js: 114
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 115
        var cell = table.tHead.rows[0].cells[col]; // ../Include/Tools/DomTable.js: 116
        var el = cell.firstChild; // ../Include/Tools/DomTable.js: 117
        var link = this.Doc.createElement('a'); // ../Include/Tools/DomTable.js: 118
        link['href'] = data; // ../Include/Tools/DomTable.js: 119
        link['target'] = 'blank'; // ../Include/Tools/DomTable.js: 120
        link.style.color = 'black'; // ../Include/Tools/DomTable.js: 121
        link.innerHTML = el.innerHTML; // ../Include/Tools/DomTable.js: 122
        el.innerHTML = ''; // ../Include/Tools/DomTable.js: 123
        el.appendChild(link); // ../Include/Tools/DomTable.js: 124
    }, // ../Include/Tools/DomTable.js: 125
    UpdateHeaderLink: function(index, data) { // ../Include/Tools/DomTable.js: 126
        //Trace('DomTable.UpdateHeaderLink', 'index = ' + index);
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 128
        var row0 = table.tHead.rows[0]; // ../Include/Tools/DomTable.js: 129
        for (var i = 0; i < row0.cells.length; i++) { // ../Include/Tools/DomTable.js: 130
            if (row0.cells[i]) { // ../Include/Tools/DomTable.js: 131
                var el = row0.cells[i].firstChild; // ../Include/Tools/DomTable.js: 132
                if (el.innerHTML == index) { // ../Include/Tools/DomTable.js: 133
                    this.AddHeaderLink(i, data); // ../Include/Tools/DomTable.js: 134
                    break; // ../Include/Tools/DomTable.js: 135
                } // ../Include/Tools/DomTable.js: 136
            } // ../Include/Tools/DomTable.js: 137
        } // ../Include/Tools/DomTable.js: 138
    }, // ../Include/Tools/DomTable.js: 139
    AddHeaderToolTip: function(col, data) { // ../Include/Tools/DomTable.js: 140
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 141
        var cell = table.tHead.rows[0].cells[col]; // ../Include/Tools/DomTable.js: 142
        var el = cell.firstChild; // ../Include/Tools/DomTable.js: 143
        el['title'] = data; // ../Include/Tools/DomTable.js: 144
    }, // ../Include/Tools/DomTable.js: 145
    UpdateHeaderToolTip: function(index, data) { // ../Include/Tools/DomTable.js: 146
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 147
        var row0 = table.tHead.rows[0]; // ../Include/Tools/DomTable.js: 148
        for (var i = 0; i < row0.cells.length; i++) { // ../Include/Tools/DomTable.js: 149
            if (row0.cells[i]) { // ../Include/Tools/DomTable.js: 150
                var el = row0.cells[i].firstChild.firstChild; //div, a
                if (el.innerHTML == index) { // ../Include/Tools/DomTable.js: 152
                    this.AddHeaderToolTip(i, data); // ../Include/Tools/DomTable.js: 153
                    break; // ../Include/Tools/DomTable.js: 154
                } // ../Include/Tools/DomTable.js: 155
            } // ../Include/Tools/DomTable.js: 156
        } // ../Include/Tools/DomTable.js: 157
    }, // ../Include/Tools/DomTable.js: 158
    GetCellContent: function(row, col) { // ../Include/Tools/DomTable.js: 159
        var ret = null; // ../Include/Tools/DomTable.js: 160
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 161
        var cell = table.rows[row].cells[col]; // ../Include/Tools/DomTable.js: 162
        var el = cell.firstChild; //div, a
        if (el) { // ../Include/Tools/DomTable.js: 164
            ret = el.innerHTML; // ../Include/Tools/DomTable.js: 165
        } // ../Include/Tools/DomTable.js: 166
        return ret; // ../Include/Tools/DomTable.js: 167
    }, // ../Include/Tools/DomTable.js: 168
    GetCellContentByHeaderContains: function(index, row, adjust) { // ../Include/Tools/DomTable.js: 169
        var _adjust = adjust || 0; // ../Include/Tools/DomTable.js: 170
        return this.GetCellContent(row, this.GetColumnNumberByHeaderContains(index) + _adjust); // ../Include/Tools/DomTable.js: 171
    }, // ../Include/Tools/DomTable.js: 172
    GetColumnNumberByHeaderContains: function(index) { // ../Include/Tools/DomTable.js: 173
        var ret = null; // ../Include/Tools/DomTable.js: 174
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 175
        var row0 = table.tHead.rows[0]; // ../Include/Tools/DomTable.js: 176
        for (var i = 0; i < row0.cells.length; i++) { // ../Include/Tools/DomTable.js: 177
            if (row0.cells[i]) { // ../Include/Tools/DomTable.js: 178
                var el = row0.cells[i].firstChild; //div
                if (el.innerHTML == index) { // ../Include/Tools/DomTable.js: 180
                    ret = i; // ../Include/Tools/DomTable.js: 181
                    break; // ../Include/Tools/DomTable.js: 182
                } // ../Include/Tools/DomTable.js: 183
            } // ../Include/Tools/DomTable.js: 184
        } // ../Include/Tools/DomTable.js: 185
        return ret; // ../Include/Tools/DomTable.js: 186
    }, // ../Include/Tools/DomTable.js: 187
    AddRow: function(data, color, bold, pre/*add pre element*/, pre_column/*which columns*/, tabifyjson/*call tabifyjson*/) { // ../Include/Tools/DomTable.js: 188
        //Trace('AddRow - data = ' + data.toString());
        this.Rows++; // ../Include/Tools/DomTable.js: 190
        if (this.Columns == 0) { // ../Include/Tools/DomTable.js: 191
            this.Columns = data.length; // ../Include/Tools/DomTable.js: 192
        } // ../Include/Tools/DomTable.js: 193
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 194

        var tr = this.Doc.createElement('tr'); // ../Include/Tools/DomTable.js: 196
        if (table.rows && table.rows.length > 0) { // ../Include/Tools/DomTable.js: 197
            if (table.rows.length / 2 != parseInt(table.rows.length / 2)) { //odd
                tr.style.backgroundColor = '#F0F0F6'; // ../Include/Tools/DomTable.js: 199
            } // ../Include/Tools/DomTable.js: 200
        } // ../Include/Tools/DomTable.js: 201

        if (color) { // ../Include/Tools/DomTable.js: 203
            tr.style.backgroundColor = color; // ../Include/Tools/DomTable.js: 204
        } // ../Include/Tools/DomTable.js: 205
        table.tBodies[0].appendChild(tr); // ../Include/Tools/DomTable.js: 206
        for (var x = 0; x < data.length; x++) { // ../Include/Tools/DomTable.js: 207
            var td = this.Doc.createElement('td'); // ../Include/Tools/DomTable.js: 208
            var div = Dom.CreateElement(this.Doc, 'div'); // ../Include/Tools/DomTable.js: 209
            if (bold) { // ../Include/Tools/DomTable.js: 210
                div.style.fontWeight = 'bold'; // ../Include/Tools/DomTable.js: 211
            } // ../Include/Tools/DomTable.js: 212
            var preel = null; // ../Include/Tools/DomTable.js: 213
            var add = false; // ../Include/Tools/DomTable.js: 214
            if (pre_column) { // ../Include/Tools/DomTable.js: 215
                for (i in pre_column) { // ../Include/Tools/DomTable.js: 216
                    if (pre_column[i] == x) { // ../Include/Tools/DomTable.js: 217
                        add = true; // ../Include/Tools/DomTable.js: 218
                        break; // ../Include/Tools/DomTable.js: 219
                    } // ../Include/Tools/DomTable.js: 220
                } // ../Include/Tools/DomTable.js: 221
            } // ../Include/Tools/DomTable.js: 222
            var _data = data[x]; // ../Include/Tools/DomTable.js: 223
            if (tabifyjson) { // ../Include/Tools/DomTable.js: 224
                _data = this.TabifyJson(data[x]); // ../Include/Tools/DomTable.js: 225
            } // ../Include/Tools/DomTable.js: 226
            if (pre && add) { // ../Include/Tools/DomTable.js: 227
                preel = Dom.CreateElement(this.Doc, 'pre'); // ../Include/Tools/DomTable.js: 228
                preel.appendChild(this.Doc.createTextNode(_data)); // ../Include/Tools/DomTable.js: 229
            } // ../Include/Tools/DomTable.js: 230
            else { // ../Include/Tools/DomTable.js: 231
                div.appendChild(this.Doc.createTextNode(_data)); // ../Include/Tools/DomTable.js: 232
            } // ../Include/Tools/DomTable.js: 233
            if (preel) { // ../Include/Tools/DomTable.js: 234
                div.appendChild(preel); // ../Include/Tools/DomTable.js: 235
            } // ../Include/Tools/DomTable.js: 236
            td.appendChild(div); // ../Include/Tools/DomTable.js: 237
            tr.appendChild(td); // ../Include/Tools/DomTable.js: 238
        } // ../Include/Tools/DomTable.js: 239
        this.Rows++; // ../Include/Tools/DomTable.js: 240
    }, // ../Include/Tools/DomTable.js: 241
    UpdateRow: function(row, data) { // ../Include/Tools/DomTable.js: 242
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 243
        for (var i = 0; i < data.length; i++) { // ../Include/Tools/DomTable.js: 244
            if (data[i]) { // ../Include/Tools/DomTable.js: 245
                table.rows[row].cells[i].firstChild.innerHTML = data[i]; // ../Include/Tools/DomTable.js: 246
            } // ../Include/Tools/DomTable.js: 247
        } // ../Include/Tools/DomTable.js: 248
    }, // ../Include/Tools/DomTable.js: 249
    UpdateRowColor: function(color) { // ../Include/Tools/DomTable.js: 250
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 251
        table.rows[table.rows.length - 1].style.backgroundColor = color; // ../Include/Tools/DomTable.js: 252
    }, // ../Include/Tools/DomTable.js: 253
    UpdateColumn: function(cols, color, row) { // ../Include/Tools/DomTable.js: 254
        var _row = row || 1; // ../Include/Tools/DomTable.js: 255
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 256
        for (var i = _row; i < table.rows.length; i++) { // ../Include/Tools/DomTable.js: 257
            for (var j = 0; j < cols.length; j++) { // ../Include/Tools/DomTable.js: 258
                table.rows[i].cells[cols[j]].style.backgroundColor = color; // ../Include/Tools/DomTable.js: 259
            } // ../Include/Tools/DomTable.js: 260
        } // ../Include/Tools/DomTable.js: 261
    }, // ../Include/Tools/DomTable.js: 262
    AddSpaceAfter: function() { // ../Include/Tools/DomTable.js: 263
        function insertAfter(newEl, targetEl) { // ../Include/Tools/DomTable.js: 264
            var parentEl = targetEl.parentNode; // ../Include/Tools/DomTable.js: 265
            if (parentEl.lastChild == targetEl) { // ../Include/Tools/DomTable.js: 266
                parentEl.appendChild(newEl); // ../Include/Tools/DomTable.js: 267
            } // ../Include/Tools/DomTable.js: 268
            else { // ../Include/Tools/DomTable.js: 269
                parentEl.insertBefore(newEl, targetEl.nextSibling); // ../Include/Tools/DomTable.js: 270
            } // ../Include/Tools/DomTable.js: 271
        } // ../Include/Tools/DomTable.js: 272

        var el = this.Doc.getElementById(this.Name); // ../Include/Tools/DomTable.js: 274
        if (el) { // ../Include/Tools/DomTable.js: 275
            insertAfter(Dom.CreateElement(this.Doc, 'br'), el); // ../Include/Tools/DomTable.js: 276
            insertAfter(Dom.CreateElement(this.Doc, 'br'), el); // ../Include/Tools/DomTable.js: 277
        } // ../Include/Tools/DomTable.js: 278
    }, // ../Include/Tools/DomTable.js: 279
    AddSpaceBefore: function() { // ../Include/Tools/DomTable.js: 280
        //old.parentNode.insertBefore(new, old);
        var el = this.Doc.getElementById(this.Name); // ../Include/Tools/DomTable.js: 282
        el.parentNode.insertBefore(Dom.CreateElement(this.Doc, 'br'), el); // ../Include/Tools/DomTable.js: 283
        el.parentNode.insertBefore(Dom.CreateElement(this.Doc, 'br'), el); // ../Include/Tools/DomTable.js: 284
    }, // ../Include/Tools/DomTable.js: 285
    AddFooter: function(text, colspan) { // ../Include/Tools/DomTable.js: 286
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 287
        var footer = table.tFoot; // ../Include/Tools/DomTable.js: 288
        var row = footer.insertRow(footer.rows.length); // ../Include/Tools/DomTable.js: 289
        var cell = row.insertCell(-1); // ../Include/Tools/DomTable.js: 290
        cell.innerHTML = text; // ../Include/Tools/DomTable.js: 291
        if (colspan) { // ../Include/Tools/DomTable.js: 292
            cell.colSpan = this.Columns; // ../Include/Tools/DomTable.js: 293
        } // ../Include/Tools/DomTable.js: 294
    }, // ../Include/Tools/DomTable.js: 295
    MergeCells: function(row, col, colspan) { // ../Include/Tools/DomTable.js: 296
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 297
        table.rows[row].cells[col].colSpan = colspan; // ../Include/Tools/DomTable.js: 298
        for (var i = 1; i < colspan; i++) { // ../Include/Tools/DomTable.js: 299
            table.rows[row].deleteCell(col + i); // ../Include/Tools/DomTable.js: 300
        } // ../Include/Tools/DomTable.js: 301
    }, // ../Include/Tools/DomTable.js: 302
    Sort: function(firstrow, lastrow, column, type/*desc=true*/) { // ../Include/Tools/DomTable.js: 303
        var table = this.GetTable(); // ../Include/Tools/DomTable.js: 304
        var _last = lastrow || table.rows.length; // ../Include/Tools/DomTable.js: 305
        var _first = firstrow || 0; // ../Include/Tools/DomTable.js: 306
        var arr = []; // ../Include/Tools/DomTable.js: 307
        for (var i = _first; i < _last; i++) { // ../Include/Tools/DomTable.js: 308
            var z = parseInt(table.rows[i].cells[column].innerText); // ../Include/Tools/DomTable.js: 309
            arr.push({'position':i, 'value':z}); // ../Include/Tools/DomTable.js: 310
        } // ../Include/Tools/DomTable.js: 311
        this.QuickSort(arr); // ../Include/Tools/DomTable.js: 312
    }, // ../Include/Tools/DomTable.js: 313
    QuickSort: function(arr) { // ../Include/Tools/DomTable.js: 314
        if (arr.length == 0) // ../Include/Tools/DomTable.js: 315
            return []; // ../Include/Tools/DomTable.js: 316

        var left = new Array(); // ../Include/Tools/DomTable.js: 318
        var right = new Array(); // ../Include/Tools/DomTable.js: 319
        var pivot = arr[0]; // ../Include/Tools/DomTable.js: 320

        for (var i = 1; i < arr.length; i++) { // ../Include/Tools/DomTable.js: 322
            if (arr[i] < pivot) { // ../Include/Tools/DomTable.js: 323
                left.push(arr[i]); // ../Include/Tools/DomTable.js: 324
            } else { // ../Include/Tools/DomTable.js: 325
                right.push(arr[i]); // ../Include/Tools/DomTable.js: 326
            } // ../Include/Tools/DomTable.js: 327
        } // ../Include/Tools/DomTable.js: 328

        return QuickSort(left).concat(pivot, quicksort(right)); // ../Include/Tools/DomTable.js: 330
    }, // ../Include/Tools/DomTable.js: 331
    TabifyJson: function(json) { // ../Include/Tools/DomTable.js: 332
//(ignore)//         Trace('DomTable()', Called({ 'json': json })); // ../Include/Tools/DomTable.js: 333

        //[{"Language":"fr","Param":"author","Url":"http://upk_fr"},{"Param":"author","Url": "http://upk-author"},{
        //"Language":"fr","Url":"http://upk-segmentation/fr"},{"Url":"http://upk-validation"}]

        //  [
        //      {
        //          "Language":"fr",
        //          "Param":"author",
        //          "Url":"http://upk_fr"
        //      },
        //      {
        //          "Param":"author",
        //          "Url": "http://upk-author"
        //      },
        //      {
        //          "Language":"fr",
        //          "Url":"http://upk-segmentation/fr"
        //      },
        //      {
        //          "Url":"http://upk-validation"
        //      }
        //  ]


        var indent = "\t"; // ../Include/Tools/DomTable.js: 358
        var count = 0; // ../Include/Tools/DomTable.js: 359
        var lineBreak = "\r\n"; // ../Include/Tools/DomTable.js: 360

        json = json.replace(/\[/g, '[' + lineBreak) // ../Include/Tools/DomTable.js: 362
        json = json.replace(/\]/g, lineBreak + ']') // ../Include/Tools/DomTable.js: 363
        json = json.replace(/\{/g, '{' + lineBreak) // ../Include/Tools/DomTable.js: 364
        json = json.replace(/\}/g, lineBreak + '}') // ../Include/Tools/DomTable.js: 365
        json = json.replace(/\,/g, ',' + lineBreak) // ../Include/Tools/DomTable.js: 366

        var jsonLines = json.split(lineBreak); // ../Include/Tools/DomTable.js: 368

        function insertAt(string, index, text, c) { // ../Include/Tools/DomTable.js: 370
            var _text = ''; // ../Include/Tools/DomTable.js: 371
            for (var k = 0; k < c; k++) { // ../Include/Tools/DomTable.js: 372
                _text += text; // ../Include/Tools/DomTable.js: 373
            } // ../Include/Tools/DomTable.js: 374
            return string.substr(0, index) + _text + string.substr(index); // ../Include/Tools/DomTable.js: 375
        } // ../Include/Tools/DomTable.js: 376
        var _line = ''; // ../Include/Tools/DomTable.js: 377
        for (var i = 0; i < jsonLines.length; i++) { // ../Include/Tools/DomTable.js: 378
            _line = insertAt(jsonLines[i], 0, indent, count); // ../Include/Tools/DomTable.js: 379
            if (jsonLines[i][0] == '{' || jsonLines[i][0] == '[') { // ../Include/Tools/DomTable.js: 380
                count++; // ../Include/Tools/DomTable.js: 381
            } // ../Include/Tools/DomTable.js: 382
            else if (jsonLines[i][0] == '}' || jsonLines[i][0] == ']') { // ../Include/Tools/DomTable.js: 383
                count--; // ../Include/Tools/DomTable.js: 384
                _line = insertAt(jsonLines[i], 0, indent, count); // ../Include/Tools/DomTable.js: 385
            } // ../Include/Tools/DomTable.js: 386

            jsonLines[i] = _line; // ../Include/Tools/DomTable.js: 388
        } // ../Include/Tools/DomTable.js: 389

        json = jsonLines.join(lineBreak); // ../Include/Tools/DomTable.js: 391
        return json; // ../Include/Tools/DomTable.js: 392
    }, // ../Include/Tools/DomTable.js: 393
 
    _: void 0 // ../Include/Tools/DomTable.js: 395
} // ../Include/Tools/DomTable.js: 396



//* <FileEnd path="../Include/Tools/DomTable.js"/>


//IE8 missing bind
if (!Function.prototype.bind) { // ../Include/CoreScripts/SmartMatch.js: 9
    Function.prototype.bind = function(oThis) { // ../Include/CoreScripts/SmartMatch.js: 10
        if (typeof this !== "function") { // ../Include/CoreScripts/SmartMatch.js: 11
            // closest thing possible to the ECMAScript 5 internal IsCallable function
            throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable"); // ../Include/CoreScripts/SmartMatch.js: 13
        } // ../Include/CoreScripts/SmartMatch.js: 14

        var aArgs = Array.prototype.slice.call(arguments, 1), // ../Include/CoreScripts/SmartMatch.js: 16
            fToBind = this, // ../Include/CoreScripts/SmartMatch.js: 17
            fNOP = function() { }, // ../Include/CoreScripts/SmartMatch.js: 18
            fBound = function() { // ../Include/CoreScripts/SmartMatch.js: 19
                return fToBind.apply(this instanceof fNOP && oThis ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments))); // ../Include/CoreScripts/SmartMatch.js: 20
            }; // ../Include/CoreScripts/SmartMatch.js: 21

        fNOP.prototype = this.prototype; // ../Include/CoreScripts/SmartMatch.js: 23
        fBound.prototype = new fNOP(); // ../Include/CoreScripts/SmartMatch.js: 24

        return fBound; // ../Include/CoreScripts/SmartMatch.js: 26
    }; // ../Include/CoreScripts/SmartMatch.js: 27
} // ../Include/CoreScripts/SmartMatch.js: 28


var smlogger_enabled = false; // ../Include/CoreScripts/SmartMatch.js: 31
//var smlogger_enabled = true;

function logger(title, text) { // ../Include/CoreScripts/SmartMatch.js: 34
    if (smlogger_enabled) { // ../Include/CoreScripts/SmartMatch.js: 35
        try { // ../Include/CoreScripts/SmartMatch.js: 36
            if (window['console']) { // ../Include/CoreScripts/SmartMatch.js: 37
                window['console']['log'](title + (text ? (':' + text) : '')); // ../Include/CoreScripts/SmartMatch.js: 38
            } // ../Include/CoreScripts/SmartMatch.js: 39
        } catch (e) { } // ../Include/CoreScripts/SmartMatch.js: 40
    } // ../Include/CoreScripts/SmartMatch.js: 41
} // ../Include/CoreScripts/SmartMatch.js: 42

function SearchSM(node, callBack) { // ../Include/CoreScripts/SmartMatch.js: 44
    logger('SearchSM', 'node = ' + Dump(node)); // ../Include/CoreScripts/SmartMatch.js: 45
    logger('SearchSM', 'callBack = ' + callBack); // ../Include/CoreScripts/SmartMatch.js: 46
    var appName = node[0]['App']; // ../Include/CoreScripts/SmartMatch.js: 47
    var appExtName = node[0]['AppExt'] || appName; // ../Include/CoreScripts/SmartMatch.js: 48
    var parts = node.slice(1); // ../Include/CoreScripts/SmartMatch.js: 49
    SearchProcessor.StartSearch(appName, appExtName, parts, callBack); // ../Include/CoreScripts/SmartMatch.js: 50
} // ../Include/CoreScripts/SmartMatch.js: 51

var SearchProcessor = { // ../Include/CoreScripts/SmartMatch.js: 53
    callBack: null, // ../Include/CoreScripts/SmartMatch.js: 54
    appName: '', // ../Include/CoreScripts/SmartMatch.js: 55
    appExtName: '', // ../Include/CoreScripts/SmartMatch.js: 56
    parts: [], // ../Include/CoreScripts/SmartMatch.js: 57
    originalResultSet: { rs: {}}, // ../Include/CoreScripts/SmartMatch.js: 58
    currentResultSet: {}, // ../Include/CoreScripts/SmartMatch.js: 59
    currentResultSetBeforeCutOff: {}, // ../Include/CoreScripts/SmartMatch.js: 60
    indexMap: {}, // ../Include/CoreScripts/SmartMatch.js: 61
    test: 0, // ../Include/CoreScripts/SmartMatch.js: 62
    index: 0, // ../Include/CoreScripts/SmartMatch.js: 63
    partNumber: 0, // ../Include/CoreScripts/SmartMatch.js: 64
    published: false, // ../Include/CoreScripts/SmartMatch.js: 65

    StartSearch: function(appName, appExtName, parts, callBack) { // ../Include/CoreScripts/SmartMatch.js: 67
        if (callBack) { // ../Include/CoreScripts/SmartMatch.js: 68
            this.callBack = callBack; // ../Include/CoreScripts/SmartMatch.js: 69
        } // ../Include/CoreScripts/SmartMatch.js: 70
        this.appName = appName; // ../Include/CoreScripts/SmartMatch.js: 71
        this.appExtName = appExtName; // ../Include/CoreScripts/SmartMatch.js: 72
        this.parts = parts; // ../Include/CoreScripts/SmartMatch.js: 73
        this.weight = (100.0 / this.parts.length); // ../Include/CoreScripts/SmartMatch.js: 74

        //if not published we do not make the search
        ConfigData.SetContentUrl('../'); // ../Include/CoreScripts/SmartMatch.js: 77
        this.published = ConfigData.GetValueByKey('PublishData/Applications/' + this.appExtName) ? true : false; // ../Include/CoreScripts/SmartMatch.js: 78
        if (!this.published) { // ../Include/CoreScripts/SmartMatch.js: 79
            logger('SearchProcessor.StartSearch', 'not published: ' + this.appName); // ../Include/CoreScripts/SmartMatch.js: 80
            SearchProcess_Show(false); // ../Include/CoreScripts/SmartMatch.js: 81
            this.currentResultSetBeforeCutOff.rs = []; // ../Include/CoreScripts/SmartMatch.js: 82
            this.currentResultSet.rs = []; // ../Include/CoreScripts/SmartMatch.js: 83
            return this.Finish(); // ../Include/CoreScripts/SmartMatch.js: 84
        } // ../Include/CoreScripts/SmartMatch.js: 85

        this.partNumber = this.parts.length; // ../Include/CoreScripts/SmartMatch.js: 87

        //logger('SearchProcessor.StartSearch', 'parts = ' + Dump(this.parts));
        if (this.index < this.partNumber) { // ../Include/CoreScripts/SmartMatch.js: 90
            this.ProcessPart(); // ../Include/CoreScripts/SmartMatch.js: 91
        } // ../Include/CoreScripts/SmartMatch.js: 92
    }, // ../Include/CoreScripts/SmartMatch.js: 93

    ProcessPart: function() { // ../Include/CoreScripts/SmartMatch.js: 95
        var expr = this.appName + '$' + Escape.MyEscape(this.parts[this.index]); // ../Include/CoreScripts/SmartMatch.js: 96
        logger('SearchProcessor.ProcessPart', 'parts[' + this.index + '] = ' + expr); // ../Include/CoreScripts/SmartMatch.js: 97
        try { // ../Include/CoreScripts/SmartMatch.js: 98
            SearchDBs['g'].Search(expr, false, this.SearchEnded.bind(this)); // ../Include/CoreScripts/SmartMatch.js: 99
        } // ../Include/CoreScripts/SmartMatch.js: 100
        catch (e) { // ../Include/CoreScripts/SmartMatch.js: 101
            logger('SearchProcessor.ProcessPart', 'SearchDBs[\'g\'].Search exception = ' + e.message ? e.message : e); // ../Include/CoreScripts/SmartMatch.js: 102
        } // ../Include/CoreScripts/SmartMatch.js: 103
    }, // ../Include/CoreScripts/SmartMatch.js: 104

    SearchEnded: function(r) { // ../Include/CoreScripts/SmartMatch.js: 106
        var result = r; // ../Include/CoreScripts/SmartMatch.js: 107
        logger('SearchProcessor.SearchEnded', 'original result = ' + Dump(result.rs)); // ../Include/CoreScripts/SmartMatch.js: 108
        var copy = CloneObject(result);//copy object
        logger('SearchProcessor.SearchEnded', 'copy = ' + Dump(copy)); // ../Include/CoreScripts/SmartMatch.js: 110
        logger('SearchProcessor.SearchEnded', 'this.parts = ' + Dump(this.parts)); // ../Include/CoreScripts/SmartMatch.js: 111
        logger('SearchProcessor.SearchEnded', 'this.index = ' + this.index); // ../Include/CoreScripts/SmartMatch.js: 112
        this.originalResultSet.rs[this.parts[this.index]] = copy.rs; // ../Include/CoreScripts/SmartMatch.js: 113
        logger('SearchProcessor.SearchEnded', 'originalresultset = ' + Dump(this.originalResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 114
        //logger('SearchProcessor.SearchEnded', 'copy result = ' + this.parts[this.index] + ' -> ' + Dump(this.originalResultSet[this.parts[this.index]]));
        if (this.index == 0) { // ../Include/CoreScripts/SmartMatch.js: 116
            //update first result's weight
            for (var i = 0; i < result.rs.length; i++) { // ../Include/CoreScripts/SmartMatch.js: 118
                result.rs[i].weight = this.weight; // ../Include/CoreScripts/SmartMatch.js: 119
            } // ../Include/CoreScripts/SmartMatch.js: 120
            this.currentResultSet = result; // ../Include/CoreScripts/SmartMatch.js: 121
            logger('SearchProcessor.SearchEnded', 'updated result = ' + Dump(this.currentResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 122
        } // ../Include/CoreScripts/SmartMatch.js: 123
        else { // ../Include/CoreScripts/SmartMatch.js: 124
            logger('SearchProcessor.SearchEnded', 'before combine = ' + Dump(this.currentResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 125
            this.currentResultSet.Combine(result, this.weight); // ../Include/CoreScripts/SmartMatch.js: 126
            logger('SearchProcessor.SearchEnded', 'after combine = ' + Dump(this.currentResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 127
        } // ../Include/CoreScripts/SmartMatch.js: 128
        this.index++; // ../Include/CoreScripts/SmartMatch.js: 129
        if (this.index < this.partNumber) { // ../Include/CoreScripts/SmartMatch.js: 130
            this.ProcessPart(); // ../Include/CoreScripts/SmartMatch.js: 131
        } // ../Include/CoreScripts/SmartMatch.js: 132
        else { // ../Include/CoreScripts/SmartMatch.js: 133
            this.EndSearch(); // ../Include/CoreScripts/SmartMatch.js: 134
        } // ../Include/CoreScripts/SmartMatch.js: 135
    }, // ../Include/CoreScripts/SmartMatch.js: 136

    EndSearch: function() { // ../Include/CoreScripts/SmartMatch.js: 138
        //update weight to int
        logger('SearchProcessor.EndSearch', 'Final Result = ' + Dump(this.currentResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 140

        this.currentResultSetBeforeCutOff = CloneObject(this.currentResultSet);//copy object

        SearchProcess_Show(false);//remove progressbar

        var appSection = ConfigData.GetValueByKey('PublishData/Applications/' + this.appExtName + '/SmartMatch'); // ../Include/CoreScripts/SmartMatch.js: 146
        logger('SearchProcessor.EndSearch', 'appSection = ' + Dump(appSection)); // ../Include/CoreScripts/SmartMatch.js: 147
        this.MaxSearch = appSection['MaxSearch']; // ../Include/CoreScripts/SmartMatch.js: 148
        this.Threshold = appSection['Threshold']; // ../Include/CoreScripts/SmartMatch.js: 149
        this.MinScore = appSection['MinScore']; // ../Include/CoreScripts/SmartMatch.js: 150
        logger('SearchProcessor.EndSearch', 'maxSearch = ' + this.MaxSearch + ' threshold = ' + this.Threshold + ' minScore = ' + this.MinScore); // ../Include/CoreScripts/SmartMatch.js: 151
        this.HighScore = this.currentResultSet.GetMaxWeight(); // ../Include/CoreScripts/SmartMatch.js: 152
        logger('SearchProcessor.EndSearch', 'highScore = ' + this.HighScore); // ../Include/CoreScripts/SmartMatch.js: 153
        this.CutOffLimit = parseInt(Math.max(this.MinScore, (this.Threshold / 100) * this.HighScore)); // ../Include/CoreScripts/SmartMatch.js: 154
        logger('SearchProcessor.EndSearch', 'cutofflimit = ' + this.CutOffLimit); // ../Include/CoreScripts/SmartMatch.js: 155
        this.currentResultSet.CutOffByLimit(this.CutOffLimit); // ../Include/CoreScripts/SmartMatch.js: 156
        logger('SearchProcessor.EndSearch', 'Final Result after cutoff = ' + Dump(this.currentResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 157
        logger('SearchProcessor.EndSearch', 'Original Result = ' + Dump(this.originalResultSet.rs)); // ../Include/CoreScripts/SmartMatch.js: 158
        this.Finish(); // ../Include/CoreScripts/SmartMatch.js: 159
    }, // ../Include/CoreScripts/SmartMatch.js: 160
    ShowTestResults: function() { // ../Include/CoreScripts/SmartMatch.js: 161
        var data = {}; // ../Include/CoreScripts/SmartMatch.js: 162
        data['Application'] = this.appName; // ../Include/CoreScripts/SmartMatch.js: 163
        data['MinScore'] = this.MinScore; // ../Include/CoreScripts/SmartMatch.js: 164
        data['MaxSearch'] = this.MaxSearch; // ../Include/CoreScripts/SmartMatch.js: 165
        data['Threshold'] = this.Threshold; // ../Include/CoreScripts/SmartMatch.js: 166
        data['CutOffLimit'] = this.CutOffLimit; // ../Include/CoreScripts/SmartMatch.js: 167
        data['currentResultSetBeforeCutOff'] = this.currentResultSetBeforeCutOff; // ../Include/CoreScripts/SmartMatch.js: 168
        data['partNumber'] = this.partNumber; // ../Include/CoreScripts/SmartMatch.js: 169
        data['parts'] = this.parts; // ../Include/CoreScripts/SmartMatch.js: 170
        data['published'] = this.published; // ../Include/CoreScripts/SmartMatch.js: 171
        data['originalResultSet'] = this.originalResultSet; // ../Include/CoreScripts/SmartMatch.js: 172

        XdTransfer.PostMessage(window.parent, 'oraupk-debuginfo_searchresult', { 'data': data }); // ../Include/CoreScripts/SmartMatch.js: 174
    }, // ../Include/CoreScripts/SmartMatch.js: 175
    Finish: function() { // ../Include/CoreScripts/SmartMatch.js: 176
        this.CheckTestMode(); // ../Include/CoreScripts/SmartMatch.js: 177
        if (this.test) { // ../Include/CoreScripts/SmartMatch.js: 178
            this.ShowTestResults(); // ../Include/CoreScripts/SmartMatch.js: 179
        } // ../Include/CoreScripts/SmartMatch.js: 180
        if (this.callBack) { // ../Include/CoreScripts/SmartMatch.js: 181
            for (var i = 0; i < this.currentResultSet.rs.length; i++) { // ../Include/CoreScripts/SmartMatch.js: 182
                this.currentResultSet.rs[i].weight /= 100.0; // ../Include/CoreScripts/SmartMatch.js: 183
            } // ../Include/CoreScripts/SmartMatch.js: 184
            this.callBack(this.currentResultSet); // ../Include/CoreScripts/SmartMatch.js: 185
        } // ../Include/CoreScripts/SmartMatch.js: 186
    }, // ../Include/CoreScripts/SmartMatch.js: 187
    CheckTestMode: function() { // ../Include/CoreScripts/SmartMatch.js: 188
        if (window['UserPrefs']) { // ../Include/CoreScripts/SmartMatch.js: 189
            if (window['UserPrefs']['EnableShowDiagnostics'] || (window['Debug'] && window['Debug']['is_ta_debug'])) { // ../Include/CoreScripts/SmartMatch.js: 190
                this.test = true; // ../Include/CoreScripts/SmartMatch.js: 191
            } // ../Include/CoreScripts/SmartMatch.js: 192
        } // ../Include/CoreScripts/SmartMatch.js: 193

    }, // ../Include/CoreScripts/SmartMatch.js: 195

    __: void 0 // ../Include/CoreScripts/SmartMatch.js: 197
} // ../Include/CoreScripts/SmartMatch.js: 198

window['SearchSM'] = SearchSM; // ../Include/CoreScripts/SmartMatch.js: 200
//* <FileEnd path="../Include/CoreScripts/SmartMatch.js"/>

    return XdTransfer; // tascriptsintoc.js: 6
})(); // tascriptsintoc.js: 7


//* <FileEnd path="tascriptsintoc.js"/>
