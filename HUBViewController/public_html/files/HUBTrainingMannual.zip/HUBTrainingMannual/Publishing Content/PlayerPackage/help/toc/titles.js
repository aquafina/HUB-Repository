﻿/******************************************************************
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
******************************************************************/
var titles=new Array("216cc25e-50ec-4d05-b5c4-49699946e30e_1");var appnames=new Array("Content Player");