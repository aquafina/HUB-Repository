﻿/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/
var UIComponents = {
    BannerStatus : false,
    ShowMoreTopics : false,
    ShareLink: true,
    SeeAlso: true,
    AskAnExpert : false,
    Notes : false,
    KPathPortal : false,
    KPathLogout : false,
    Preferences : false,
    Help : false,
    TopicHelp: false,
    TitlePrefix : false  
};