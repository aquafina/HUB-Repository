{
  "data":
  {
    "17":[{"t": "Use Do It! Mode in Firefox", "y":"E", "g":"bcf1cdda-4dda-47bb-a741-d4368d828e95", "o":18, "r":[18,18], "c":1 }],
    "19":[{"t": "Know It? Mode Action Types and Events", "y":"E", "g":"9b71048c-c257-44d9-af7f-3b7009b1b24e", "o":20, "r":[20,20], "c":1 },
         {"t": "Enter Text in Know It? Mode", "y":"E", "g":"96e9446a-8a63-459f-8dcd-dffb2ac52e5b", "o":21, "r":[21,21], "c":1 },
         {"t": "Print Know It? Results", "y":"E", "g":"da1367f4-d092-46b4-9ff3-0c50146a398d", "o":22, "r":[22,22], "c":1 }],
    "24":[{"t": "View Remediation", "y":"E", "g":"90542980-01bd-4846-92fd-8227aab0bb95", "o":25, "r":[25,25], "c":1 }],
    "26":[{"t": "Use the Assessment Summary Page", "y":"E", "g":"ac205be2-c8a0-4af0-85f9-a8d5324ef015", "o":27, "r":[27,27], "c":1 }]  }
}
