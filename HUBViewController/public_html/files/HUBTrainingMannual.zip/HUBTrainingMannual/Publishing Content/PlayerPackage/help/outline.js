﻿/******************************************************************
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
******************************************************************/

var moduleName="Content Player";
var bypassToc=false;var soundIsExported = false;var toc_hash="wNGRq9Miqeyjt7PWwUp+mtcpEzg="