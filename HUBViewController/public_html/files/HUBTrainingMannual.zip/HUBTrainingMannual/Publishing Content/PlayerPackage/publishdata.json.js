{
	"Compatibility":"12.1.0.0",
	"SmartHelpVersion":"12.1.0.0",
	"SmartHelpMinVersion":"12.1.0.0",
	"Title":"The HUB Training",
	"LastPublishDate":"2015-07-13T18:19:26",
	"Hash":"{a19785e3-824f-4c1c-be4d-d299ac91f30b}",
	"PlayerLanguage":"en",
	"Applications":
	{
		"FUSION":
		{
			"Name":"Oracle Fusion",
			"Published":true,
			"SmartMatch":
			{
				"Threshold":75,
				"MinScore":50,
				"MaxSearch":80,
				"MaxHit":200
			}
		}
	}
}