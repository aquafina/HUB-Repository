{
	"ProductVersion":"12.1.0",
	"Applications":
	{
		"FUSION":
		{
			"Name":"Oracle Fusion",
			"Gateway":"stdhemi/hint_gateway.html"
		}
	}
}