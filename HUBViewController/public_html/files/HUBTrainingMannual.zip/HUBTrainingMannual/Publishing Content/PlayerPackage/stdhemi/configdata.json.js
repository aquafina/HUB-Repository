{
	"Compatibility":"12.1.0",
	"Applications":
	{
		"FUSION":{
		}
	}
}