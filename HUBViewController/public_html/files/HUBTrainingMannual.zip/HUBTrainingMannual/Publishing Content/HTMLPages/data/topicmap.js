﻿/******************************************************************
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
******************************************************************/
function LoadMap(){A("1a4b801f-3c49-4eed-9af4-440784a74cf9","HUB"); }