﻿/*--
Copyright © 1998, 2014, Oracle and/or its affiliates.  All rights reserved.
--*/

//defines
var SM_CYCAPTION = 19;
var SM_CYFRAME = 4;

function GetDualMonitor() {
    primarydisplay = true;

    if (PlayerConfig.DualMonitorSupport) {
        var testwindow = window.open("", "", "width=10,height=10");
        twscreenX = (testwindow.screenX != null ? testwindow.screenX : testwindow.screenLeft)
        twscreenY = (testwindow.screenY != null ? testwindow.screenY : testwindow.screenTop)
        if (twscreenX < 0 || twscreenX > this.screen.width)
            primarydisplay = false;
        if (twscreenY < 0 || twscreenY > this.screen.height)
            primarydisplay = false;
        testwindow.close();
    }

    var features = "";
    if (primarydisplay) {
        if (PlayerConfig.DualMonitorFixedSize == true) {
            var lngMaxWidth = 1024;
            var lngMaxHeight = 768;
            var lngWidth;
            var lngHeight;
            var lngLeft = 0;
            var lngTop = 0;
            if (screen.width > lngMaxWidth) {
                lngWidth = lngMaxWidth;
                lngLeft = Math.round((screen.width / 2) - lngMaxWidth / 2);
            }
            else {
                lngWidth = screen.width - 8;
            }
            if (screen.height > lngMaxHeight) {
                lngHeight = lngMaxHeight;
                lngTop = Math.round(((screen.height - 60) / 2) - lngMaxHeight / 2);
            }
            else {
                lngHeight = screen.height - 60;
            }
            features = "top=" + lngTop + ",left=" + lngLeft + ",width=" + lngWidth + ",height=" + lngHeight;
        }
        else {
            features = "fullscreen=1";
        }
    }
    else {
        sw = window.screen.availWidth - 2 * SM_CYFRAME; 			// screen width
        sh = window.screen.availHeight - 2 * SM_CYFRAME - SM_CYCAPTION; // screen height
        features = "top=0,left=0,width=" + sw + ",height=" + sh;
    }
    return features;
}